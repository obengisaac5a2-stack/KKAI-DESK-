package com.kkdex.desktop

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var controllerWebView: WebView
    private lateinit var bridge: NativeBridge
    private lateinit var displayManager: DisplayManager
    private var presentation: DesktopPresentation? = null
    private var pendingSaf: ((Int, Intent?) -> Unit)? = null
    private var pendingPermission: ((Map<String, Boolean>) -> Unit)? = null
    private var pendingFileChooser: ValueCallback<Array<Uri>>? = null

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {
            refreshPresentation()
            bridge.pushDisplayStatus()
        }

        override fun onDisplayRemoved(displayId: Int) {
            if (presentation?.display?.displayId == displayId) {
                presentation?.dismiss()
                presentation = null
            }
            refreshPresentation()
            bridge.pushDisplayStatus()
        }

        override fun onDisplayChanged(displayId: Int) {
            if (presentation?.display?.displayId == displayId) {
                bridge.pushDisplayStatus()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompatCompat.configurePhoneWindow(this)
        bridge = NativeBridge(this, BuildConfig.VERSION_NAME)
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, null)
        setupController()
        refreshPresentation()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (controllerWebView.canGoBack()) controllerWebView.goBack()
                else finish()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        refreshPresentation()
        bridge.pushDisplayStatus()
    }

    override fun onStop() {
        presentation?.dismiss()
        presentation = null
        bridge.presentationStopped()
        super.onStop()
    }

    override fun onDestroy() {
        displayManager.unregisterDisplayListener(displayListener)
        pendingFileChooser?.onReceiveValue(null)
        pendingFileChooser = null
        presentation?.dismiss()
        presentation = null
        bridge.destroy()
        if (::controllerWebView.isInitialized) {
            controllerWebView.stopLoading()
            controllerWebView.loadUrl("about:blank")
            controllerWebView.destroy()
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bridge.pushDisplayStatus()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_SAF -> {
                val callback = pendingSaf
                pendingSaf = null
                callback?.invoke(resultCode, data)
            }
            REQUEST_FILE_CHOOSER -> {
                val callback = pendingFileChooser
                pendingFileChooser = null
                val uris = if (resultCode == Activity.RESULT_OK && data != null) {
                    val clip = data.clipData
                    if (clip != null) {
                        (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
                    } else {
                        data.data?.let { listOf(it) } ?: emptyList()
                    }
                } else {
                    emptyList()
                }
                if (uris.isNotEmpty()) bridge.persistDocumentGrants(data?.flags ?: 0, uris)
                callback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MEDIA_PERMISSIONS) {
            val callback = pendingPermission
            pendingPermission = null
            val result = permissions.mapIndexed { index, permission ->
                permission to (grantResults.getOrNull(index) == PackageManager.PERMISSION_GRANTED)
            }.toMap()
            callback?.invoke(result)
        }
    }

    fun launchSaf(intent: Intent, callback: (Int, Intent?) -> Unit): Boolean {
        if (pendingSaf != null) return false
        pendingSaf = callback
        return try {
            startActivityForResult(intent, REQUEST_SAF)
            true
        } catch (error: Exception) {
            pendingSaf = null
            false
        }
    }

    fun requestMediaPermissions(callback: (Map<String, Boolean>) -> Unit): Boolean {
        val required = requiredMediaPermissions()
        val missing = required.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            callback(required.associateWith { true })
            return true
        }
        if (pendingPermission != null) return false
        pendingPermission = callback
        ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_MEDIA_PERMISSIONS)
        return true
    }

    fun showDocumentChooser(callback: ValueCallback<Array<Uri>>, acceptTypes: Array<String>?, multiple: Boolean): Boolean {
        if (pendingFileChooser != null) {
            callback.onReceiveValue(null)
            return false
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        if (multiple) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        val mimeTypes = acceptTypes?.filter { it.isNotBlank() }
        if (!mimeTypes.isNullOrEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
        pendingFileChooser = callback
        return try {
            startActivityForResult(intent, REQUEST_FILE_CHOOSER)
            true
        } catch (error: Exception) {
            pendingFileChooser = null
            callback.onReceiveValue(null)
            false
        }
    }

    fun showToast(message: String) {
        runOnUiThread {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
            bridge.pushControllerMessage(message)
        }
    }

    fun openSystemSettings() {
        startActivity(Intent(Settings.ACTION_SETTINGS))
    }

    fun externalDisplayId(): Int = presentation?.display?.displayId
        ?: displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
            .firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }
            ?.displayId
        ?: -1

    fun displayStatus(): JSONObject {
        val display = presentation?.display
            ?: displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
                .firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }
        if (display == null) {
            return JSONObject()
                .put("connected", false)
                .put("displayId", -1)
                .put("displayName", "No external display")
                .put("width", 0)
                .put("height", 0)
                .put("densityDpi", 0)
                .put("presentationActive", false)
        }
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getMetrics(metrics)
        return JSONObject()
            .put("connected", true)
            .put("displayId", display.displayId)
            .put("displayName", display.name ?: "External display")
            .put("width", metrics.widthPixels)
            .put("height", metrics.heightPixels)
            .put("densityDpi", metrics.densityDpi)
            .put("presentationActive", presentation?.isShowing == true)
    }

    fun openFolderOnDesktop(root: JSONObject) {
        val active = presentation?.webView ?: run {
            showToast("Connect an external display before authorizing a folder for the desktop.")
            return
        }
        active.post {
            active.evaluateJavascript(
                "window.KKDexDesktop && window.KKDexDesktop.openApp('storage');",
                null,
            )
        }
        active.postDelayed({
            active.evaluateJavascript(
                "window.KKDexAndroidNavigation && window.KKDexAndroidNavigation.openFolder(JSON.parse(${JSONObject.quote(root.toString())}));",
                null,
            )
        }, 220)
    }

    fun openExternalIntent(intent: Intent): String {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val displayId = externalDisplayId()
        if (displayId > 0) {
            try {
                val options = android.app.ActivityOptions.makeBasic()
                    .setLaunchDisplayId(displayId)
                    .toBundle()
                startActivity(intent, options)
                return "Android accepted the viewer launch request on the external display. If the viewer appeared only on the phone, that app does not support external-display launch."
            } catch (_: Exception) {
                // Honest fallback below.
            }
        }
        return try {
            startActivity(intent)
            "Android launched the viewer on the phone. KK DEX did not claim that the app rendered on the television."
        } catch (error: Exception) {
            throw IllegalStateException(
                "No Android activity accepted this file or URL: ${error.message}",
            )
        }
    }

    fun notifyDisplayChanged() {
        bridge.pushDisplayStatus()
    }

    private fun setupController() {
        controllerWebView = WebView(this).apply {
            setBackgroundColor(Color.rgb(18, 37, 28))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
        }
        setContentView(controllerWebView)
        bridge.attachController(controllerWebView)
        controllerWebView.loadUrl(NativeBridge.CONTROLLER_URL)
    }

    private fun refreshPresentation() {
        if (isFinishing || isDestroyed || !::bridge.isInitialized) return
        val display = findPresentationDisplay()
        if (display == null) {
            presentation?.dismiss()
            presentation = null
            bridge.pushDisplayStatus()
            return
        }
        if (presentation?.display?.displayId == display.displayId && presentation?.isShowing == true) {
            bridge.pushDisplayStatus()
            return
        }
        presentation?.dismiss()
        val next = DesktopPresentation(this, display, bridge)
        try {
            next.show()
            presentation = next
            showToast(
                "KK DEX desktop opened on ${display.name.orEmpty().ifBlank { "the external display" }}. The phone remains the controller.",
            )
        } catch (error: WindowManager.InvalidDisplayException) {
            showToast("Android rejected the external display presentation: ${error.message}")
        } catch (error: SecurityException) {
            showToast("Android denied presentation access for this display: ${error.message}")
        }
        bridge.pushDisplayStatus()
    }

    private fun findPresentationDisplay(): Display? {
        val presentationDisplays =
            displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        val candidates: Array<Display> = if (presentationDisplays.isNotEmpty()) {
            presentationDisplays
        } else {
            displayManager.displays
                .filter { it.displayId != Display.DEFAULT_DISPLAY }
                .toTypedArray()
        }
        return candidates.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY && it.isValid }
    }

    private fun requiredMediaPermissions(): Array<String> {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
            )
            else -> arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
            )
        }
    }


    companion object {
        private const val REQUEST_SAF = 9102
        private const val REQUEST_FILE_CHOOSER = 9103
        private const val REQUEST_MEDIA_PERMISSIONS = 9104
    }
}

/**
 * Applies a stable full-screen phone-controller surface without turning the
 * controller WebView into a mirrored desktop.
 */
private object WindowCompatCompat {
    fun configurePhoneWindow(activity: Activity) {
        activity.window?.apply {
            statusBarColor = Color.rgb(18, 37, 28)
            navigationBarColor = Color.rgb(18, 37, 28)
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            decorView.systemUiVisibility = 0
        }
    }
}
