package com.kkdex.desktop

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

class DownloadController(private val context: Context) {
    private val manager =
        context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun enqueue(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?,
        contentLength: Long,
    ): Long {
        val uri = Uri.parse(url)
        if (uri.scheme != "http" && uri.scheme != "https") {
            throw IllegalArgumentException(
                "Android DownloadManager can save HTTP(S) downloads. This link uses ${uri.scheme}; blob/data downloads require the app that created them or a native share flow.",
            )
        }
        val name = safeFileName(
            contentDisposition?.let { parseFileName(it) }
                ?: uri.lastPathSegment
                ?: "KK DEX download",
        )
        val request = DownloadManager.Request(uri)
            .setTitle(name)
            .setDescription("Downloaded through KK DEX")
            .setMimeType(mimeType ?: "application/octet-stream")
            .setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED,
            )
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
        CookieManager.getInstance().getCookie(url)?.let {
            request.addRequestHeader("Cookie", it)
        }
        return manager.enqueue(request)
    }

    fun list(): JSONArray {
        val cursor = manager.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_PENDING or DownloadManager.STATUS_RUNNING or DownloadManager.STATUS_PAUSED or DownloadManager.STATUS_SUCCESSFUL or DownloadManager.STATUS_FAILED))
        val downloads = JSONArray()
        cursor.use { value ->
            while (value.moveToNext()) {
                val id = value.getLong(value.getColumnIndexOrThrow(DownloadManager.COLUMN_ID))
                val status = value.getInt(value.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val localUri = runCatching { manager.getUriForDownloadedFile(id)?.toString() }
                    .getOrNull()
                downloads.put(
                    JSONObject()
                        .put("id", id)
                        .put("title", value.getStringOrNull(manager, DownloadManager.COLUMN_TITLE))
                        .put("description", value.getStringOrNull(manager, DownloadManager.COLUMN_DESCRIPTION))
                        .put("mime", value.getStringOrNull(manager, DownloadManager.COLUMN_MEDIA_TYPE))
                        .put("size", value.getLongOrZero(manager, DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        .put("downloaded", value.getLongOrZero(manager, DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        .put("status", statusName(status))
                        .put("localUri", localUri ?: JSONObject.NULL)
                        .put("timestamp", value.getLongOrZero(manager, DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)),
                )
            }
        }
        return downloads
    }

    fun open(id: Long): Uri {
        val uri = manager.getUriForDownloadedFile(id)
            ?: throw IllegalArgumentException("This download is incomplete or Android removed the local file.")
        return uri
    }

    private fun android.database.Cursor.getStringOrNull(
        manager: DownloadManager,
        column: String,
    ): String? {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) null else getString(index)
    }

    private fun android.database.Cursor.getLongOrZero(
        manager: DownloadManager,
        column: String,
    ): Long {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) 0L else getLong(index)
    }

    private fun statusName(status: Int): String = when (status) {
        DownloadManager.STATUS_PENDING -> "pending"
        DownloadManager.STATUS_RUNNING -> "running"
        DownloadManager.STATUS_PAUSED -> "paused"
        DownloadManager.STATUS_SUCCESSFUL -> "successful"
        DownloadManager.STATUS_FAILED -> "failed"
        else -> "other"
    }

    private fun parseFileName(disposition: String): String {
        val encoded = disposition.substringAfter("filename*=", "")
        if (encoded.isNotBlank()) {
            return runCatching {
                val value = encoded.substringAfter("''", encoded).substringBefore(';').trim()
                URLDecoder.decode(value, "UTF-8")
            }.getOrDefault(encoded.trim())
        }
        return disposition.substringAfter("filename=", "download")
            .substringBefore(';')
            .trim()
            .trim('"')
    }

    private fun safeFileName(value: String): String {
        val name = value.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(160)
        return if (name.isBlank() || name == "." || name == "..") {
            "KK DEX download ${System.currentTimeMillis()}"
        } else name
    }
}
