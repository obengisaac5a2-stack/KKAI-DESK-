package com.kkdex.desktop

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.util.Locale

/**
 * All access is through content:// URIs.
 *
 * - Authorized trees come from ACTION_OPEN_DOCUMENT_TREE and are retained with
 *   persistable URI permission.
 * - One-off files come from the Android document picker.
 * - Media collections are queried only after Android grants the matching
 *   READ_MEDIA_* (or legacy READ_EXTERNAL_STORAGE) permission.
 *
 * The app never receives a raw filesystem path from JavaScript, and every SAF
 * operation is enforced by ContentResolver and the document provider.
 */
class StorageController(private val context: Context) {
    private val resolver: ContentResolver = context.contentResolver
    private val preferences =
        context.getSharedPreferences("kkdex_storage", Context.MODE_PRIVATE)

    private data class MediaSpec(
        val uri: Uri,
        val mediaType: String,
        val description: String,
    )

    fun mediaRoots(): JSONArray {
        val roots = JSONArray()
        roots.put(root("media-images", "media://images", "media", "Pictures", "images", "Android MediaStore images"))
        roots.put(root("media-videos", "media://videos", "media", "Videos", "videos", "Android MediaStore video"))
        roots.put(root("media-audio", "media://audio", "media", "Music & recordings", "audio", "Android MediaStore audio"))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            roots.put(root("media-downloads", "media://downloads", "media", "Android Downloads", "downloads", "MediaStore Downloads collection"))
        }
        savedTrees().forEach { uri ->
            roots.put(
                root(
                    "tree-${uri.hashCode()}",
                    uri.toString(),
                    "tree",
                    displayName(uri) ?: "Authorized Android folder",
                    null,
                    "SAF folder with retained permission",
                ),
            )
        }
        return roots
    }

    fun listDirectory(treeValue: String?, documentValue: String?): JSONArray {
        if (treeValue == null) throw IOException("An authorized tree URI is required.")
        if (treeValue.startsWith("media://")) return listMedia(treeValue)
        val tree = Uri.parse(treeValue)
        val parent = if (documentValue.isNullOrBlank()) {
            treeDocument(tree)
        } else {
            Uri.parse(documentValue)
        }
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree,
            DocumentsContract.getDocumentId(parent),
        )
        val rows = JSONArray()
        val cursor = resolver.query(
            childrenUri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            ),
            null,
            null,
            "${DocumentsContract.Document.COLUMN_DISPLAY_NAME} COLLATE NOCASE ASC",
        ) ?: throw IOException("Android returned no listing for this folder.")

        cursor.use { value ->
            while (value.moveToNext()) {
                val documentId = value.getString(0)
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, documentId)
                val mime = value.getStringOrNull(2) ?: "application/octet-stream"
                rows.put(
                    JSONObject()
                        .put("uri", uri.toString())
                        .put("treeUri", tree.toString())
                        .put("name", value.getStringOrNull(1) ?: "Unnamed")
                        .put("mime", mime)
                        .put("size", value.getLongOrZero(3))
                        .put("modified", value.getLongOrZero(4))
                        .put("isDirectory", mime == DocumentsContract.Document.MIME_TYPE_DIR)
                        .put("source", "saf"),
                )
            }
        }
        return rows
    }

    private fun listMedia(treeValue: String): JSONArray {
        val spec = when (treeValue) {
            "media://images" -> MediaSpec(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "images", "images")
            "media://videos" -> MediaSpec(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "videos", "video")
            "media://audio" -> MediaSpec(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio", "audio")
            "media://downloads" -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    throw IOException("MediaStore Downloads requires Android 10 or newer. Authorize the Downloads folder with SAF instead.")
                }
                MediaSpec(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "downloads", "downloads")
            }
            else -> throw IOException("Unknown Android media collection.")
        }
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
        )
        val rows = JSONArray()
        try {
            resolver.query(
                spec.uri,
                projection,
                null,
                null,
                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC",
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(0)
                    val uri = ContentUris.withAppendedId(spec.uri, id)
                    rows.put(
                        JSONObject()
                            .put("uri", uri.toString())
                            .put("treeUri", treeValue)
                            .put("name", cursor.getStringOrNull(1) ?: "Unnamed media")
                            .put("mime", cursor.getStringOrNull(2) ?: "${spec.mediaType}/*")
                            .put("size", cursor.getLongOrZero(3))
                            .put(
                                "modified",
                                cursor.getLongOrZero(4) * 1000L,
                            )
                            .put("isDirectory", false)
                            .put("source", "media"),
                    )
                }
            } ?: throw IOException("Android returned no media rows.")
        } catch (error: SecurityException) {
            throw IOException(
                "Android denied access to this media collection. Grant the matching media permission from Android Storage > Media permissions, or authorize the folder with Android's Storage Access Framework picker. No files were listed.",
                error,
            )
        }
        return rows
    }

    fun describePicked(uri: Uri): JSONObject {
        val name = displayName(uri) ?: "Android file"
        val size = queryLong(uri, OpenableColumns.SIZE) ?: -1L
        val modified = queryLong(uri, DocumentsContract.Document.COLUMN_LAST_MODIFIED) ?: 0L
        val mime = resolver.getType(uri) ?: guessMime(name)
        return JSONObject()
            .put("uri", uri.toString())
            .put("name", name)
            .put("mime", mime)
            .put("size", size)
            .put("modified", modified)
            .put("isDirectory", mime == DocumentsContract.Document.MIME_TYPE_DIR)
            .put("source", "picked")
    }

    fun treeRoot(uri: Uri): JSONObject =
        root(
            "tree-${uri.hashCode()}",
            uri.toString(),
            "tree",
            displayName(uri) ?: "Authorized Android folder",
            null,
            "SAF folder with retained Android permission",
        )

    fun saveTree(uri: Uri) {
        val current = savedTrees().map { it.toString() }.toMutableSet()
        current.add(uri.toString())
        preferences.edit().putStringSet(KEY_TREES, current).apply()
    }

    fun savedTrees(): List<Uri> =
        preferences.getStringSet(KEY_TREES, emptySet())
            .orEmpty()
            .mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }

    fun createDirectory(treeValue: String, parentValue: String, name: String): JSONObject {
        val tree = Uri.parse(treeValue)
        val parent = resolveDocument(parentValue, tree)
        val created = DocumentsContract.createDocument(
            resolver,
            parent,
            DocumentsContract.Document.MIME_TYPE_DIR,
            requireName(name),
        ) ?: throw IOException("Android's document provider did not create the folder.")
        return describeCreated(created, tree)
    }

    fun rename(treeValue: String, documentValue: String, newName: String): JSONObject {
        val tree = Uri.parse(treeValue)
        val document = Uri.parse(documentValue)
        val renamed = DocumentsContract.renameDocument(resolver, document, requireName(newName))
            ?: throw IOException("This provider does not support safe rename in place. Create a copy with a new name instead.")
        return describeCreated(renamed, tree)
    }

    fun delete(documentValue: String) {
        val document = Uri.parse(documentValue)
        if (!DocumentsContract.deleteDocument(resolver, document)) {
            throw IOException("Android's document provider refused to delete this item. The file was not deleted.")
        }
    }

    fun copyOrMove(
        treeValue: String,
        sourceValue: String,
        destinationValue: String,
        move: Boolean,
    ): JSONObject {
        val tree = Uri.parse(treeValue)
        val source = Uri.parse(sourceValue)
        val parent = resolveDocument(destinationValue, tree)
        val name = displayName(source) ?: "KK DEX copy"
        val mime = resolver.getType(source) ?: "application/octet-stream"
        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
            throw IOException("Recursive folder copy is not supported by this provider-safe bridge. Open the folder and copy supported files individually.")
        }
        val created = DocumentsContract.createDocument(resolver, parent, mime, name)
            ?: throw IOException("Android could not create the destination document.")
        try {
            openInput(source).use { input ->
                resolver.openOutputStream(created, "w")?.use { output ->
                    input.copyTo(output, DEFAULT_BUFFER_SIZE)
                } ?: throw IOException("Android could not open the destination for writing.")
            }
        } catch (error: Exception) {
            runCatching { DocumentsContract.deleteDocument(resolver, created) }
            throw IOException("Android could not copy the file bytes. A partial destination was removed when the provider allowed it.", error)
        }
        if (move) {
            try {
                delete(source.toString())
            } catch (error: Exception) {
                throw IOException(
                    "The copy was created, but Android could not remove the original. Check the folder's write permission. Original: ${error.message}",
                    error,
                )
            }
        }
        return describeCreated(created, tree)
    }

    fun readBytes(uriValue: String, maximum: Long = MAX_FILE_BYTES): ByteArray {
        val uri = contentUri(uriValue)
        openInput(uri).use { input ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
                if (total > maximum) {
                    throw IOException("This file exceeds the ${maximum / (1024 * 1024)} MB safe bridge limit. Use its Android viewer instead.")
                }
                output.write(buffer, 0, read)
            }
            return output.toByteArray()
        }
    }

    fun writeBytes(uriValue: String, bytes: ByteArray) {
        if (bytes.size > MAX_FILE_BYTES) {
            throw IOException("The write exceeds the ${MAX_FILE_BYTES / (1024 * 1024)} MB safe bridge limit.")
        }
        val uri = contentUri(uriValue)
        val output = resolver.openOutputStream(uri, "wt")
            ?: throw IOException("Android did not grant write access to this document. Reopen it with a writable picker grant.")
        output.use { it.write(bytes); it.flush() }
    }

    fun exportName(uriValue: String): String =
        displayName(contentUri(uriValue)) ?: "KK DEX export"

    fun displayName(uri: Uri): String? {
        if (uri.scheme != ContentResolver.SCHEME_CONTENT) return null
        return queryString(uri, OpenableColumns.DISPLAY_NAME)
            ?: runCatching {
                resolver.query(
                    uri,
                    arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                    null,
                    null,
                    null,
                )?.use { if (it.moveToFirst()) it.getStringOrNull(0) else null }
            }.getOrNull()
            ?: uri.lastPathSegment
    }

    private fun describeCreated(uri: Uri, tree: Uri): JSONObject {
        val name = displayName(uri) ?: "Android item"
        val mime = resolver.getType(uri) ?: guessMime(name)
        return JSONObject()
            .put("uri", uri.toString())
            .put("treeUri", tree.toString())
            .put("name", name)
            .put("mime", mime)
            .put("size", queryLong(uri, OpenableColumns.SIZE) ?: 0L)
            .put("modified", System.currentTimeMillis())
            .put("isDirectory", mime == DocumentsContract.Document.MIME_TYPE_DIR)
            .put("source", "saf")
    }

    private fun resolveDocument(parentValue: String, tree: Uri): Uri {
        val parent = Uri.parse(parentValue)
        return if (DocumentsContract.isTreeUri(parent)) {
            DocumentsContract.buildDocumentUriUsingTree(
                parent,
                DocumentsContract.getTreeDocumentId(parent),
            )
        } else {
            if (parent.toString() != tree.toString()) parent else treeDocument(tree)
        }
    }

    private fun treeDocument(tree: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(
            tree,
            DocumentsContract.getTreeDocumentId(tree),
        )

    private fun contentUri(value: String): Uri {
        val uri = Uri.parse(value)
        if (uri.scheme != ContentResolver.SCHEME_CONTENT) {
            throw IOException("Only Android content:// URIs are accepted by the native bridge.")
        }
        return uri
    }

    private fun openInput(uri: Uri): InputStream =
        resolver.openInputStream(uri)
            ?: throw FileNotFoundException("Android could not open this content URI. The grant may have expired or been revoked.")

    private fun requireName(value: String): String {
        val name = value.trim()
        if (name.isEmpty() || name.contains('/') || name.contains('\\') || name == "." || name == "..") {
            throw IOException("Enter a valid document name without slashes.")
        }
        return name
    }

    private fun queryString(uri: Uri, column: String): String? =
        runCatching {
            resolver.query(uri, arrayOf(column), null, null, null)?.use {
                if (it.moveToFirst()) it.getStringOrNull(0) else null
            }
        }.getOrNull()

    private fun queryLong(uri: Uri, column: String): Long? =
        runCatching {
            resolver.query(uri, arrayOf(column), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else null
            }
        }.getOrNull()

    private fun root(
        id: String,
        uri: String,
        kind: String,
        name: String,
        mediaType: String?,
        description: String,
    ): JSONObject = JSONObject()
        .put("id", id)
        .put("uri", uri)
        .put("kind", kind)
        .put("name", name)
        .put("mediaType", mediaType)
        .put("description", description)

    private fun guessMime(name: String): String {
        val extension = name.substringAfterLast('.', "").lowercase(Locale.US)
        return when (extension) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "wav" -> "audio/wav"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "apk" -> "application/vnd.android.package-archive"
            "txt", "md", "log", "py", "js", "ts", "json", "html", "css", "kt", "java" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    private fun Cursor.getStringOrNull(index: Int): String? =
        if (isNull(index)) null else getString(index)

    private fun Cursor.getLongOrZero(index: Int): Long =
        if (isNull(index)) 0L else getLong(index)

    companion object {
        private const val KEY_TREES = "authorized_trees"
        const val MAX_FILE_BYTES = 50L * 1024L * 1024L
        const val TREE_READ_WRITE =
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    }
}
