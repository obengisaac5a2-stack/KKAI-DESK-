import { test, expect, type Page } from "@playwright/test";
import JSZip from "jszip";

const textBase64 = Buffer.from("Phone text content", "utf8").toString("base64");
const png =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lk3Q6wAAAABJRU5ErkJggg==";

async function installMockBridge(page: Page, failures: Record<string, string> = {}) {
  await page.addInitScript(
    ({ textBase64, png, failures }) => {
      const calls: { method: string; args: Record<string, unknown> }[] = [];
      (window as unknown as { __nativeCalls: typeof calls }).__nativeCalls = calls;
      const now = Date.now();
      const file = (name: string, mime: string, isDirectory = false, uri = `content://mock/${encodeURIComponent(name)}`) => ({
        uri,
        treeUri: "content://mock/tree",
        name,
        mime,
        size: isDirectory ? 0 : 321,
        modified: now,
        isDirectory,
        source: "saf",
      });
      const roots = [
        { id: "tree-mock", uri: "content://mock/tree", kind: "tree", name: "Mock folder", description: "SAF folder with retained permission" },
        { id: "media-images", uri: "media://images", kind: "media", name: "Pictures", mediaType: "images", description: "Android MediaStore images" },
      ];
      const download = { id: 4, title: "KK DEX test.pdf", description: "Downloaded through KK DEX", mime: "application/pdf", size: 1200, downloaded: 1200, status: "successful", localUri: "content://mock/download/4", timestamp: now };
      const installed = [
        { packageName: "com.mock.notes", label: "Mock Notes", iconUrl: null, system: false },
        { packageName: "com.mock.tool", label: "Mock Tool", iconUrl: null, system: true },
      ];
      const result = (method: string, args: Record<string, unknown>) => {
        if (failures[method]) throw new Error(failures[method]);
        switch (method) {
          case "ping": return { ok: true, version: 1, appVersion: "1.0.0", role: "desktop" };
          case "displayStatus": return { connected: true, displayId: 2, displayName: "Test TV", width: 1920, height: 1080, densityDpi: 240, presentationActive: true };
          case "pickFiles": {
            const mime = String(args.mime || "");
            if (mime.includes("pdf")) return [file("Phone PDF.pdf", "application/pdf")];
            if (mime.startsWith("video")) return [file("Phone video.mp4", "video/mp4")];
            if (mime.startsWith("audio")) return [file("Phone audio.mp3", "audio/mpeg")];
            if (mime.startsWith("text")) return [file("Phone note.txt", "text/plain")];
            if (mime.includes("zip")) return [file("Phone archive.zip", "application/zip")];
            return [file("Phone photo.jpg", "image/jpeg")];
          }
          case "pickFolder":
          case "chooseFolderForDesktop": return { id: "tree-mock", uri: "content://mock/tree", kind: "tree", name: "Mock folder", description: "SAF folder with retained permission" };
          case "listRoots": return roots;
          case "listDirectory": return [
            file("Phone note.txt", "text/plain"),
            file("Phone photo.jpg", "image/jpeg"),
            file("Phone video.mp4", "video/mp4"),
            file("Phone audio.mp3", "audio/mpeg"),
            file("Phone PDF.pdf", "application/pdf"),
            file("Phone archive.zip", "application/zip"),
            file("Subfolder", "vnd.android.document/directory", true, "content://mock/tree/document/subfolder"),
          ];
          case "readFile": return { base64: textBase64, name: "Phone note.txt", mime: "text/plain", size: 18 };
          case "writeFile": return true;
          case "createDirectory": return file(String(args.name || "New folder"), "vnd.android.document/directory", true);
          case "renameDocument": return file(String(args.name || "Renamed"), "text/plain");
          case "deleteDocument": case "copyDocument": case "moveDocument": return method === "deleteDocument" ? true : file("Copied.txt", "text/plain");
          case "contentUrl": return "https://appassets.androidplatform.net/native-content/mock-token";
          case "openDocument": return "Android launched the viewer on the phone. KK DEX did not claim that the app rendered on the television.";
          case "openUrl": return "Android launched the browser on the phone.";
          case "exportFile": case "exportExistingFile": return String(args.name || "export.bin");
          case "getInstalledApps": return installed;
          case "launchApp": return `Android accepted a launch request for ${args.packageName} on display 2. Some apps ignore external-display routing.`;
          case "getDownloads": return [download];
          case "openDownload": return "Android launched the viewer on the phone.";
          case "getSystemInfo": return {
            appVersion: "1.0.0", manufacturer: "Google", brand: "google", model: "Mock Pixel", device: "mock", androidRelease: "15", sdkInt: 35, webViewVersion: "Chrome 139", externalDisplay: { connected: true, displayId: 2, displayName: "Test TV", width: 1920, height: 1080, densityDpi: 240, presentationActive: true }, runtimes: { python3: "/system/bin/python3 · Python 3.12.1", node: null, git: null, toybox: "/system/bin/toybox" }, supportedAbis: ["arm64-v8a"], dataPath: "/data/user/0/com.kkdex.desktop/files", totalStorage: 128000000000, freeStorage: 64000000000,
          };
          case "setVolume": return Number(args.percent);
          case "getVolume": return 65;
          case "runCommand": return { stdout: `mock app sandbox: ${args.command}\n`, stderr: "", exitCode: 0, backend: "Android app UID shell · not root" };
          case "requestMediaPermissions": return { permissions: { READ_MEDIA_IMAGES: true }, explanation: "Android granted: READ_MEDIA_IMAGES." };
          case "pdfInfo": return { pageCount: 2, name: "Phone PDF.pdf" };
          case "pdfRenderPage": return { image: png, page: Number(args.page), pageCount: 2, width: 900, height: 1200 };
          case "controllerInput": return true;
          default: throw new Error(`Unknown mock native method: ${method}`);
        }
      };
      (window as unknown as { KKDexNative: unknown }).KKDexNative = {
        onmessage: null,
        postMessage(raw: string) {
          const request = JSON.parse(raw) as { id: string; method: string; args: Record<string, unknown> };
          calls.push({ method: request.method, args: request.args });
          setTimeout(() => {
            let response: Record<string, unknown>;
            try { response = { id: request.id, ok: true, data: result(request.method, request.args) }; }
            catch (error) { response = { id: request.id, ok: false, error: error instanceof Error ? error.message : String(error), code: "MOCK_FAILURE" }; }
            const receiver = (window as unknown as { KKDexNative: { onmessage: (event: { data: string }) => void } }).KKDexNative;
            receiver.onmessage({ data: JSON.stringify(response) });
          }, 0);
        },
      };
    },
    { textBase64, png, failures },
  );
}

const open = async (page: Page, id: string) => {
  await page.evaluate((id) => window.KKDexDesktop!.openApp(id), id);
  await expect(page.locator(`[data-app="${id}"]`)).toBeVisible();
  await page.waitForTimeout(160);
};

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await page.waitForTimeout(200);
});

test("Android-only apps reject fake success when the native app is absent", async ({ page }) => {
  expect(await page.evaluate(() => Boolean(window.KKDexHost?.available))).toBe(false);
  for (const id of ["storage", "video", "music", "pdf", "downloads", "sysinfo", "appmanager"]) {
    await open(page, id);
    await expect(page.locator(`[data-app="${id}"] .native-required`)).toBeVisible();
    await expect(page.locator(`[data-app="${id}"]`)).toContainText("Nothing was simulated");
  }
});

test("native editor opens, reads and saves a real Android document URI", async ({ page }) => {
  await installMockBridge(page);
  await page.reload();
  expect(await page.evaluate(() => window.KKDexHost?.available)).toBe(true);
  await open(page, "editor");
  await page.getByRole("button", { name: "Open from Android", exact: true }).click();
  await expect(page.getByRole("textbox", { name: "Android text editor content" })).toHaveValue("Phone text content");
  await page.getByRole("textbox", { name: "Android text editor content" }).fill("Edited through the television");
  await page.getByRole("button", { name: "Save in place", exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.filter((call) => call.method === "writeFile").length)).toBeGreaterThan(0);
  const call = await page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.find((call) => call.method === "writeFile"));
  expect(call!.args.uri).toBe("content://mock/Phone%20note.txt");
});

test("Android Storage lists authorized folders and rejects failed reads visibly", async ({ page }) => {
  await installMockBridge(page);
  await page.reload();
  await open(page, "storage");
  await page.getByRole("button", { name: /Authorize a folder/ }).click();
  await expect(page.getByText("Phone note.txt")).toBeVisible();
  await expect(page.getByText("Phone photo.jpg")).toBeVisible();
  await expect(page.getByText("Phone video.mp4")).toBeVisible();
  await page.getByText("Phone note.txt").dblclick();
  await expect(page.locator('[data-app="editor"]')).toBeVisible();
  await expect(page.getByRole("textbox", { name: "Android text editor content" })).toHaveValue("Phone text content");
});

test("Android text read failures are surfaced rather than shown as empty success", async ({ page }) => {
  await installMockBridge(page, { readFile: "Android revoked access to this document." });
  await page.reload();
  await open(page, "editor");
  await page.getByRole("button", { name: "Open from Android", exact: true }).click();
  await expect(page.getByRole("dialog", { name: "Android could not read this text file", exact: true })).toContainText("Android revoked access");
});

test("App manager uses Android PackageManager data and reports launch routing", async ({ page }) => {
  await installMockBridge(page);
  await page.reload();
  await open(page, "appmanager");
  await expect(page.getByText("Mock Notes")).toBeVisible();
  await expect(page.getByText("com.mock.notes")).toBeVisible();
  await page.locator(".installed-app").filter({ hasText: "Mock Notes" }).getByRole("button", { name: "Launch", exact: true }).click();
  await expect(page.getByRole("status")).toContainText("Android accepted a launch request");
  const launch = await page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.find((call) => call.method === "launchApp"));
  expect(launch!.args).toMatchObject({ packageName: "com.mock.notes", preferExternal: true });
});

test("System Information displays real bridge fields and external display status", async ({ page }) => {
  await installMockBridge(page);
  await page.reload();
  await open(page, "sysinfo");
  await expect(page.getByText("Mock Pixel")).toBeVisible();
  await expect(page.getByText("Test TV")).toBeVisible();
  await expect(page.getByText("1920 × 1080 @ 240 dpi", { exact: false })).toBeVisible();
  await expect(page.getByText("/system/bin/python3 · Python 3.12.1", { exact: false })).toBeVisible();
});

test("PDF Viewer renders actual PdfRenderer fixture pages one at a time", async ({ page }) => {
  await installMockBridge(page);
  await page.reload();
  await open(page, "pdf");
  await page.getByRole("button", { name: "Choose PDF", exact: true }).click();
  await expect(page.locator(".pdf-stage img")).toBeVisible();
  await expect(page.getByText("Page 1 of 2", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Next PDF page", exact: true }).click();
  await expect(page.getByText("Page 2 of 2", { exact: true })).toBeVisible();
});

test("Downloads and terminal expose native backend output without simulation", async ({ page }) => {
  await installMockBridge(page);
  await page.reload();
  await open(page, "downloads");
  await expect(page.getByText("KK DEX test.pdf")).toBeVisible();
  await expect(page.locator(".download-status")).toHaveText("successful");
  await open(page, "terminal");
  const input = page.getByRole("textbox", { name: "Terminal command" });
  await input.fill("native printf genuine");
  await input.press("Enter");
  await expect(page.locator(".terminal-output")).toContainText("mock app sandbox: printf genuine");
  await expect(page.locator(".terminal-status")).toContainText("Real shell · non-root");
});

test("Archive Manager lists and extracts a genuine ZIP fixture", async ({ page }) => {
  const archive = new JSZip();
  archive.file("hello.txt", "real archive content");
  archive.file("folder/nested.txt", "nested content");
  const buffer = await archive.generateAsync({ type: "nodebuffer" });
  await open(page, "archives");
  await page.locator('.archive-app input[type="file"]').setInputFiles({ name: "fixture.zip", mimeType: "application/zip", buffer });
  await expect(page.getByText("hello.txt")).toBeVisible();
  await expect(page.getByText("folder/nested.txt")).toBeVisible();
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Extract hello.txt", exact: true }).click();
  expect((await download).suggestedFilename()).toBe("hello.txt");
});

test("successful controller file transfer and app launch use the native controller allowlist", async ({ page }) => {
  await installMockBridge(page);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/?controller");
  await expect(page.locator(".controller-connection")).toContainText("Desktop connected to TV");
  await page.getByRole("button", { name: /Send folder to TV/ }).click();
  await expect(page.locator(".controller-notice")).toContainText('opening that folder in Android Storage');
  await page.getByRole("button", { name: /Android apps/ }).click();
  await expect(page.getByText("Mock Notes")).toBeVisible();
  await page.getByText("Mock Notes").click();
  await expect(page.locator(".controller-apps-sheet")).toHaveCount(0);
  const calls = await page.evaluate(() => (window as unknown as { __nativeCalls: { method: string }[] }).__nativeCalls.map((call) => call.method));
  expect(calls).toEqual(expect.arrayContaining(["chooseFolderForDesktop", "getInstalledApps", "launchApp", "displayStatus"]));
});
