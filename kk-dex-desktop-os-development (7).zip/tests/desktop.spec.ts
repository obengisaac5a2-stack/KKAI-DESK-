import { test, expect, type Page } from "@playwright/test";

const state = (page: Page) =>
  page.evaluate(
    () =>
      window.KKDexDesktop!.getState() as {
        windows: {
          id: string;
          appId: string;
          x: number;
          y: number;
          width: number;
          height: number;
          minimized: boolean;
          maximized: boolean;
        }[];
        activeWindow: string;
      },
  );
const launch = async (page: Page, app: string, payload?: string) => {
  await page.evaluate(
    ([id, data]) => window.KKDexDesktop!.openApp(id!, data),
    [app, payload],
  );
  await expect(page.locator(`[data-app="${app}"]`)).toBeAttached();
  await page.waitForTimeout(220);
};
const remoteAt = async (
  page: Page,
  selector: string,
  action = "pointerClick",
) => {
  const box = await page.locator(selector).boundingBox();
  if (!box) throw new Error(`No box: ${selector}`);
  await page.evaluate(
    ({ x, y, action }) => {
      window.KKDexDesktop!.movePointer(x, y);
      const api = window.KKDexDesktop!;
      if (action === "pointerDoubleClick") api.pointerDoubleClick();
      else if (action === "pointerRightClick") api.pointerRightClick();
      else api.pointerClick();
    },
    { x: box.x + box.width / 2, y: box.y + box.height / 2, action },
  );
  await page.waitForTimeout(100);
};

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(page.locator('[data-app="files"]')).toBeVisible();
  await page.waitForTimeout(240);
});

test("desktop fills the viewport with SVG icons and independent floating apps", async ({
  page,
}) => {
  await expect(page.locator(".desktop-icon")).toHaveCount(11);
  const layout = await page.evaluate(() => ({
    width: document.querySelector(".desktop")!.clientWidth,
    height: document.querySelector(".desktop")!.clientHeight,
    scrollWidth: document.documentElement.scrollWidth,
    scrollHeight: document.documentElement.scrollHeight,
    icons: document.querySelectorAll(".desktop-icon svg").length,
  }));
  expect(layout).toEqual({
    width: 1440,
    height: 900,
    scrollWidth: 1440,
    scrollHeight: 900,
    icons: 11,
  });
  await page.locator('[data-desktop-icon="calculator"]').click();
  await expect(page.locator('[data-desktop-icon="calculator"]')).toHaveClass(
    /selected/,
  );
  await expect(page.locator('[data-app="calculator"]')).toHaveCount(0);
  await page.locator('[data-desktop-icon="calculator"]').dblclick();
  await expect(page.locator('[data-app="calculator"]')).toBeVisible();
  const s = await state(page);
  expect(s.windows).toHaveLength(2);
  expect(s.windows.every((w) => w.width < 1440 && w.height < 836)).toBeTruthy();
});

test("titlebar dragging moves real window geometry", async ({ page }) => {
  const initial = (await state(page)).windows[0];
  await page.mouse.move(initial.x + 180, initial.y + 20);
  await page.mouse.down();
  await page.mouse.move(initial.x + 270, initial.y + 75, { steps: 12 });
  await page.mouse.up();
  const moved = (await state(page)).windows[0];
  expect(moved.x).toBe(initial.x + 90);
  expect(moved.y).toBe(initial.y + 55);
});

test("all eight resize edges and corners change the intended dimensions", async ({
  page,
}) => {
  for (const [edge, dx, dy] of [
    ["e", 18, 0],
    ["s", 0, 18],
    ["w", -18, 0],
    ["n", 0, -18],
    ["ne", 12, -12],
    ["nw", -12, -12],
    ["se", 12, 12],
    ["sw", -12, 12],
  ] as const) {
    const initial = (await state(page)).windows[0],
      handle = page.locator(`[data-resize="${edge}"]`),
      box = await handle.boundingBox();
    expect(box).toBeTruthy();
    await page.mouse.move(box!.x + box!.width / 2, box!.y + box!.height / 2);
    await page.mouse.down();
    await page.mouse.move(
      box!.x + box!.width / 2 + dx,
      box!.y + box!.height / 2 + dy,
      { steps: 4 },
    );
    await page.mouse.up();
    const resized = (await state(page)).windows[0];
    if (dx) expect(resized.width).toBeGreaterThan(initial.width);
    if (dy) expect(resized.height).toBeGreaterThan(initial.height);
  }
});

test("minimize, taskbar restore, maximize, restore and close update state", async ({
  page,
}) => {
  const original = (await state(page)).windows[0];
  await page
    .getByRole("button", { name: "Minimize Files", exact: true })
    .click();
  expect((await state(page)).windows[0].minimized).toBeTruthy();
  await page.locator('[data-taskbar-app="files"]').click();
  expect((await state(page)).windows[0].minimized).toBeFalsy();
  await page
    .getByRole("button", { name: "Maximize Files", exact: true })
    .click();
  let w = (await state(page)).windows[0];
  expect(w.maximized).toBeTruthy();
  expect(w.width).toBe(1440);
  expect(w.height).toBe(836);
  await page
    .getByRole("button", { name: "Restore Files", exact: true })
    .click();
  w = (await state(page)).windows[0];
  expect(w.width).toBe(original.width);
  expect(w.x).toBe(original.x);
  await page
    .locator(".window-titlebar")
    .dblclick({ position: { x: 180, y: 20 } });
  expect((await state(page)).windows[0].maximized).toBeTruthy();
  await page.getByRole("button", { name: "Close Files", exact: true }).click();
  await expect(page.locator('[data-app="files"]')).toHaveCount(0);
  await expect(page.locator('[data-taskbar-app="files"]')).not.toHaveClass(
    /running/,
  );
});

test("Start launches filtered apps and closes on outside clicks", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Start menu", exact: true }).click();
  await expect(
    page.getByRole("dialog", { name: "Start menu", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Search apps in Start" })
    .fill("calc");
  await expect(page.locator(".start-all-apps > button")).toHaveCount(1);
  await page.locator(".start-all-apps > button").click();
  await expect(page.locator('[data-app="calculator"]')).toBeVisible();
  await expect(page.locator(".start-panel")).toHaveCount(0);
  await page.getByRole("button", { name: "Start menu", exact: true }).click();
  await page.mouse.click(1330, 60);
  await expect(page.locator(".start-panel")).toHaveCount(0);
});

test("desktop context menu creates an actual persistent folder", async ({
  page,
}) => {
  await page.mouse.click(1350, 100, { button: "right" });
  await page.getByRole("menuitem", { name: "New folder", exact: true }).click();
  await page
    .getByRole("textbox", { name: "Folder name", exact: true })
    .fill("My workspace");
  await page
    .getByRole("button", { name: "Create folder", exact: true })
    .click();
  await expect(
    page.locator(".desktop-icon").filter({ hasText: "My workspace" }),
  ).toHaveCount(1);
  await page.reload();
  await expect(
    page.locator(".desktop-icon").filter({ hasText: "My workspace" }),
  ).toHaveCount(1);
});

test("desktop icons drag to non-overlapping persistent grid positions", async ({
  page,
}) => {
  const icon = page.locator('[data-desktop-icon="browser"]'),
    before = await icon.boundingBox();
  await page.mouse.move(before!.x + 40, before!.y + 30);
  await page.mouse.down();
  await page.mouse.move(250, 200, { steps: 12 });
  await page.mouse.up();
  const after = await icon.boundingBox();
  expect(after!.x).not.toBe(before!.x);
  const positions = await page
    .locator(".desktop-icon")
    .evaluateAll((elements) =>
      elements.map(
        (el) =>
          `${(el as HTMLElement).offsetLeft}:${(el as HTMLElement).offsetTop}`,
      ),
    );
  expect(new Set(positions).size).toBe(positions.length);
  await page.reload();
  expect((await icon.boundingBox())!.x).toBe(after!.x);
});

test("Files navigation, search, creation, rename, copy, recycle and restore work", async ({
  page,
}) => {
  const win = page.locator('[data-app="files"]');
  await win.locator(".sidebar-item").filter({ hasText: "Documents" }).click();
  await expect(win.locator("h1")).toHaveText("Documents");
  await win.getByRole("button", { name: "Back", exact: true }).click();
  await expect(win.locator("h1")).toHaveText("Welcome home.");
  await win.getByRole("button", { name: "Forward", exact: true }).click();
  await expect(win.locator("h1")).toHaveText("Documents");
  await win.getByRole("textbox", { name: "Search files" }).fill("Weekend");
  await expect(win.locator(".file-row")).toHaveCount(1);
  await win.getByRole("button", { name: "Clear file search" }).click();
  await win.getByRole("button", { name: "New", exact: true }).click();
  await page.getByRole("textbox", { name: "Folder name" }).fill("Test folder");
  await page
    .getByRole("button", { name: "Create folder", exact: true })
    .click();
  const row = win.locator(".file-row").filter({ hasText: "Test folder" });
  await row.click();
  await page.keyboard.press("F2");
  await page.getByRole("textbox", { name: "New name" }).fill("Renamed folder");
  await page.getByRole("button", { name: "Rename", exact: true }).click();
  await win.locator(".file-row").filter({ hasText: "Renamed folder" }).click();
  await page.keyboard.press("Control+c");
  await page.keyboard.press("Control+v");
  await expect(
    win.locator(".file-row").filter({ hasText: "Renamed folder - Copy" }),
  ).toHaveCount(1);
  await win
    .locator(".file-row")
    .filter({ hasText: "Renamed folder - Copy" })
    .click();
  await page.keyboard.press("Delete");
  await launch(page, "bin");
  await expect(page.locator(".recycle-file")).toHaveCount(1);
  await page
    .getByRole("button", { name: "Restore Renamed folder - Copy", exact: true })
    .click();
  await expect(page.locator(".recycle-file")).toHaveCount(0);
  await page
    .getByRole("button", { name: "Close Recycle Bin", exact: true })
    .click();
  await expect(
    win.locator(".file-row").filter({ hasText: "Renamed folder - Copy" }),
  ).toHaveCount(1);
});

test("real file input imports text and opens editable content", async ({
  page,
}) => {
  await page
    .locator('input[type="file"]')
    .setInputFiles({
      name: "Imported.txt",
      mimeType: "text/plain",
      buffer: Buffer.from("Real imported content"),
    });
  await page
    .locator('[data-app="files"] .sidebar-item')
    .filter({ hasText: "Documents" })
    .click();
  await page
    .locator(".file-row")
    .filter({ hasText: "Imported.txt" })
    .dblclick();
  await expect(
    page.getByRole("textbox", { name: "Note content", exact: true }),
  ).toHaveValue("Real imported content");
});

test("Notes create, edit, save, export and persist actual text", async ({
  page,
}) => {
  await launch(page, "notes");
  const notes = page.locator('[data-app="notes"]');
  await notes.getByRole("button", { name: "Create note", exact: true }).click();
  await notes
    .getByRole("textbox", { name: "Note title" })
    .fill("A test thought");
  await notes
    .getByRole("textbox", { name: "Note content", exact: true })
    .fill("Something worth remembering.");
  await page.keyboard.press("Control+s");
  await expect(page.getByRole("status")).toContainText("saved on this device");
  const download = page.waitForEvent("download");
  await notes.getByRole("button", { name: "Export note" }).click();
  expect((await download).suggestedFilename()).toBe("A test thought.txt");
  await page.reload();
  await launch(page, "notes");
  await expect(
    page.locator(".note-list-item").filter({ hasText: "A test thought" }),
  ).toHaveCount(1);
  await expect(
    page.getByRole("textbox", { name: "Note content", exact: true }),
  ).toHaveValue("Something worth remembering.");
});

test("calculator respects precedence, percentages and division errors", async ({
  page,
}) => {
  await launch(page, "calculator");
  await page.keyboard.type("2+3*4");
  await page.keyboard.press("Enter");
  await expect(page.locator(".calculator-answer")).toHaveText("14");
  await page
    .locator('[data-app="calculator"]')
    .getByRole("button", { name: "C", exact: true })
    .click();
  await page.keyboard.type("50%*200");
  await page.keyboard.press("Enter");
  await expect(page.locator(".calculator-answer")).toHaveText("100");
  await page
    .locator('[data-app="calculator"]')
    .getByRole("button", { name: "C", exact: true })
    .click();
  await page.keyboard.type("1/0");
  await page.keyboard.press("Enter");
  await expect(page.locator(".calculator-answer")).toHaveText(
    "Cannot divide by zero",
  );
});

test("Terminal executes workspace operations, not fake Android commands", async ({
  page,
}) => {
  await launch(page, "terminal");
  const input = page.getByRole("textbox", { name: "Terminal command" });
  await input.fill("pwd");
  await input.press("Enter");
  await expect(page.locator(".terminal-output")).toContainText(
    "workspace:/Documents",
  );
  await input.fill("ls");
  await input.press("Enter");
  await expect(page.locator(".terminal-output")).toContainText(
    "Getting started.md",
  );
  await input.fill("uname -a");
  await input.press("Enter");
  await expect(page.locator(".terminal-output")).toContainText(
    "Unknown workspace command: uname",
  );
  await input.fill("native whoami");
  await input.press("Enter");
  await expect(page.locator(".terminal-output")).toContainText(
    "No Android shell backend is connected",
  );
});

test("Browser uses real tab navigation and genuine iframe content", async ({
  page,
}) => {
  let requests = 0;
  await page.route("https://example.com/kkdex/**", async (route) => {
    requests++;
    await route.fulfill({
      contentType: "text/html",
      body: "<!doctype html><title>Integration fixture</title><h1>Actual iframe fixture</h1>",
    });
  });
  await launch(page, "browser");
  const address = page.getByRole("textbox", {
    name: "Browser address",
    exact: true,
  });
  await address.fill("https://example.com/kkdex/one");
  await address.press("Enter");
  await expect(page.frameLocator("iframe").getByRole("heading")).toHaveText(
    "Actual iframe fixture",
  );
  await address.fill("https://example.com/kkdex/two");
  await address.press("Enter");
  await page.getByRole("button", { name: "Go back", exact: true }).click();
  await expect(address).toHaveValue("https://example.com/kkdex/one");
  await page.getByRole("button", { name: "Go forward", exact: true }).click();
  await expect(address).toHaveValue("https://example.com/kkdex/two");
  await page.getByRole("button", { name: "Reload page", exact: true }).click();
  await expect.poll(() => requests).toBeGreaterThan(2);
  await page
    .getByRole("button", { name: "New browser tab", exact: true })
    .click();
  await expect(page.locator(".browser-tab")).toHaveCount(2);
  await expect(page.locator(".browser-home")).toBeVisible();
});

test("KK AI explains missing backend and uses only connected responses", async ({
  page,
}) => {
  await launch(page, "ai");
  await page.getByRole("textbox", { name: "Message KK AI" }).fill("Hello");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(page.locator(".inline-notice")).toContainText(
    "Your text has not been sent",
  );
  await expect(page.locator(".ai-message.assistant")).toHaveCount(0);
  await page.evaluate(() => {
    window.KKDexServices = {
      chat: async (messages) =>
        `Integration fixture response to: ${messages[messages.length - 1].content}`,
    };
  });
  await page
    .getByRole("textbox", { name: "Message KK AI" })
    .fill("Connected test");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(page.locator(".ai-message.assistant")).toContainText(
    "Integration fixture response to: Connected test",
  );
  await page
    .getByRole("button", { name: "Clear conversation", exact: true })
    .click();
  await expect(page.locator(".ai-message")).toHaveCount(0);
});

test("Gallery loads real images with working viewer, zoom and download", async ({
  page,
}) => {
  await launch(page, "gallery");
  await expect(page.locator(".photo-grid > button")).toHaveCount(3);
  expect(
    await page
      .locator(".photo-grid img")
      .first()
      .evaluate((el: HTMLImageElement) => el.complete && el.naturalWidth > 0),
  ).toBeTruthy();
  await page.locator(".photo-grid > button").first().dblclick();
  await expect(page.locator(".gallery-viewer")).toBeVisible();
  await page.getByRole("button", { name: "Zoom in", exact: true }).click();
  await expect(page.locator(".gallery-toolbar")).toContainText("125%");
  await page.getByRole("button", { name: "Next photo", exact: true }).click();
  await expect(page.locator(".gallery-toolbar")).toContainText("Ocean air.jpg");
  const download = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Download image", exact: true })
    .click();
  expect((await download).suggestedFilename()).toBe("Ocean air.jpg");
});

test("Settings changes theme and wallpaper, with real quick controls", async ({
  page,
}) => {
  await launch(page, "settings");
  await page.getByRole("button", { name: "After hours", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.getByRole("button", { name: "Ocean air", exact: true }).click();
  await expect(page.locator(".wallpaper-coast")).toHaveCount(1);
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await expect(page.locator(".wallpaper-coast")).toHaveCount(1);
  await page
    .getByRole("button", { name: "Network, volume and display settings" })
    .click();
  await page.getByRole("button", { name: /Dark mode/ }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  await page.getByRole("button", { name: /Bluetooth/ }).click();
  await expect(
    page.getByRole("dialog", { name: "Bluetooth", exact: true }),
  ).toContainText("not connected");
});

test("calendar, notifications, task view, and context menu submenus work", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Open calendar", exact: true })
    .click();
  const old = await page.locator(".calendar-month > strong").textContent();
  await page.getByRole("button", { name: "Next month", exact: true }).click();
  expect(await page.locator(".calendar-month > strong").textContent()).not.toBe(
    old,
  );
  await page
    .getByRole("button", { name: "Notification center", exact: true })
    .click();
  await expect(page.locator(".notification-item")).toHaveCount(1);
  await page.getByRole("button", { name: "Clear all", exact: true }).click();
  await expect(page.locator(".notifications-empty")).toBeVisible();
  await page.getByRole("button", { name: "Task view", exact: true }).click();
  await expect(page.locator(".task-preview")).toHaveCount(1);
  await page.keyboard.press("Escape");
  await page.mouse.click(1340, 100, { button: "right" });
  await page.getByRole("menuitem", { name: "View", exact: true }).click();
  await page
    .getByRole("menuitem", { name: "Small icons", exact: true })
    .click();
  await expect(page.locator(".desktop-icons")).toHaveClass(/small/);
});

test("keyboard shortcuts switch, close, snap and show desktop without breaking typing", async ({
  page,
}) => {
  await launch(page, "notes");
  await launch(page, "calculator");
  await page.keyboard.press("Alt+Tab");
  expect((await state(page)).activeWindow).toContain("notes");
  await page.keyboard.press("Alt+F4");
  await expect(page.locator('[data-app="notes"]')).toHaveCount(0);
  await page.keyboard.press("Meta+e");
  expect((await state(page)).activeWindow).toContain("files");
  await page.keyboard.press("Meta+ArrowLeft");
  let w = (await state(page)).windows.find((w) => w.appId === "files")!;
  expect(w.x).toBe(0);
  expect(w.width).toBe(720);
  await page.keyboard.press("Meta+d");
  expect((await state(page)).windows.every((w) => w.minimized)).toBeTruthy();
  await page.keyboard.press("Meta+d");
  expect((await state(page)).windows.every((w) => !w.minimized)).toBeTruthy();
});

test("KKDexAPI pointer activates actual HTML, drags windows, and types into Notes", async ({
  page,
}) => {
  for (const name of [
    "movePointer",
    "pointerDown",
    "pointerUp",
    "pointerClick",
    "pointerDoubleClick",
    "pointerRightClick",
    "scrollDesktop",
    "insertText",
    "pressKey",
    "getState",
    "openApp",
    "setTheme",
    "setWallpaper",
  ])
    expect(
      await page.evaluate(
        (n) => typeof (window.KKDexAPI as Record<string, unknown>)[n],
        name,
      ),
    ).toBe("function");
  await remoteAt(page, '[data-desktop-icon="notes"]', "pointerDoubleClick");
  await expect(page.locator('[data-app="notes"]')).toBeVisible();
  await remoteAt(page, ".note-text");
  await page.evaluate(() => {
    window.KKDexDesktop!.pressKey("a", { ctrl: true });
    window.KKDexDesktop!.insertText("Hello from the phone bridge");
  });
  await expect(
    page.getByRole("textbox", { name: "Note content", exact: true }),
  ).toHaveValue("Hello from the phone bridge");
  await page.evaluate(() => window.KKDexDesktop!.pressKey("Backspace"));
  await expect(
    page.getByRole("textbox", { name: "Note content", exact: true }),
  ).toHaveValue("Hello from the phone bridg");
  const initial = (await state(page)).windows.find((w) => w.appId === "notes")!;
  await page.evaluate(({ x, y }) => {
    const api = window.KKDexDesktop!;
    api.movePointer(x + 120, y + 20);
    api.pointerDown();
    api.movePointer(x + 170, y + 60);
    api.pointerUp();
  }, initial);
  const moved = (await state(page)).windows.find((w) => w.appId === "notes")!;
  expect(moved.x).toBe(initial.x + 50);
  expect(moved.y).toBe(initial.y + 40);
  await page.evaluate(() => {
    window.KKDexDesktop!.movePointer(1350, 80);
    window.KKDexDesktop!.pointerRightClick();
  });
  await expect(page.getByRole("menu")).toBeVisible();
});

test("all eleven app registrations launch and remain independent", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  for (const id of [
    "pc",
    "files",
    "browser",
    "ai",
    "store",
    "settings",
    "gallery",
    "notes",
    "calculator",
    "terminal",
    "bin",
  ])
    await launch(page, id);
  expect((await state(page)).windows).toHaveLength(11);
  expect(errors).toEqual([]);
});

test("desktop fits common external-display resolutions", async ({ page }) => {
  for (const viewport of [
    { width: 1920, height: 1080 },
    { width: 1280, height: 720 },
    { width: 1024, height: 768 },
    { width: 800, height: 600 },
  ]) {
    await page.setViewportSize(viewport);
    await page.waitForTimeout(100);
    const s = await state(page);
    const bar = await page.locator(".taskbar").boundingBox();
    expect(bar!.y + bar!.height).toBe(viewport.height);
    for (const w of s.windows) {
      expect(w.x).toBeGreaterThanOrEqual(0);
      expect(w.y).toBeGreaterThanOrEqual(0);
      expect(w.x + w.width).toBeLessThanOrEqual(viewport.width);
      expect(w.y + w.height).toBeLessThanOrEqual(viewport.height - 64);
    }
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth),
    ).toBe(viewport.width);
  }
});

test("phone controller is separate and never pretends an unavailable connection", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/?controller");
  await expect(page.locator(".desktop")).toHaveCount(0);
  await expect(page.locator(".touchpad")).toBeVisible();
  await expect(page.locator(".controller-connection")).toHaveText(
    "Not connected",
  );
  await page.getByRole("button", { name: "Right click", exact: true }).click();
  await expect(page.locator(".controller-notice")).toContainText(
    "No external display transport is connected",
  );
  await page.reload();
  await page.evaluate(() => {
    (window as unknown as { inputMessages: unknown[] }).inputMessages = [];
    window.KKDexControllerBridge = {
      sendInput: (message) =>
        (window as unknown as { inputMessages: unknown[] }).inputMessages.push(
          JSON.parse(message),
        ),
    };
  });
  await page
    .getByRole("button", { name: "Keyboard & shortcuts", exact: true })
    .click();
  await page
    .getByRole("textbox", { name: "Text to send to desktop" })
    .fill("Controller text");
  await page.getByRole("button", { name: "Send text", exact: true }).click();
  expect(
    await page.evaluate(
      () => (window as unknown as { inputMessages: unknown[] }).inputMessages,
    ),
  ).toContainEqual({ type: "insertText", text: "Controller text" });
});
