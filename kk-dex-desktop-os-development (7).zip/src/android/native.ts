/**
 * Adapter for the trusted Android KKDexNative WebMessage bridge.
 *
 * The bridge is injected only into the local desktop and controller documents
 * by the native WebView. Browsers, remote pages, and cross-origin iframes never
 * receive it. When the adapter is absent every operation returns an explicit
 * unavailable error instead of pretending that Android work succeeded.
 */
import type {
  AndroidDisplayStatus,
  AndroidDownload,
  AndroidFileEntry,
  AndroidRoot,
  AndroidSystemInfo,
  InstalledAndroidApp,
  NativeResponse,
} from "../types";

export class AndroidUnavailableError extends Error {
  code = "NATIVE_BRIDGE_UNAVAILABLE";
}

export class AndroidOperationError extends Error {
  code: string;
  constructor(message: string, code = "ANDROID_OPERATION_FAILED") {
    super(message);
    this.name = "AndroidOperationError";
    this.code = code;
  }
}

type Pending = {
  resolve: (value: unknown) => void;
  reject: (reason: Error) => void;
  timer: ReturnType<typeof setTimeout>;
};
const pending = new Map<string, Pending>();
let sequence = 0;

function installBridge() {
  const native = window.KKDexNative;
  if (!native || typeof native.postMessage !== "function") return false;
  if (window.KKDexHost?.available) return true;

  native.onmessage = (event) => {
    let payload: {
      id?: string;
      ok?: boolean;
      data?: unknown;
      error?: string;
      code?: string;
    };
    try {
      payload =
        typeof event.data === "string" ? JSON.parse(event.data) : event.data;
    } catch {
      return;
    }
    if (!payload?.id) return;
    const entry = pending.get(payload.id);
    if (!entry) return;
    pending.delete(payload.id);
    clearTimeout(entry.timer);
    if (payload.ok) entry.resolve(payload.data);
    else
      entry.reject(
        new AndroidOperationError(
          payload.error || "Android could not complete this operation.",
          payload.code,
        ),
      );
  };

  const call = <T,>(method: string, args: Record<string, unknown> = {}) =>
    new Promise<T>((resolve, reject) => {
      const id = `kk-${Date.now().toString(36)}-${(++sequence).toString(36)}`;
      const pickerMethod = [
        "pickFiles",
        "pickFolder",
        "exportFile",
        "exportExistingFile",
        "chooseFolderForDesktop",
        "requestMediaPermissions",
      ].includes(method);
      const timer = setTimeout(
        () => {
          pending.delete(id);
          reject(
            new AndroidOperationError(
              pickerMethod
                ? "Android did not return a picker result. Reopen the picker and try again."
                : `Android did not respond to ${method}.`,
              "NATIVE_TIMEOUT",
            ),
          );
        },
        pickerMethod ? 300_000 : 60_000,
      );
      pending.set(id, {
        resolve: resolve as (value: unknown) => void,
        reject,
        timer,
      });
      try {
        native.postMessage(JSON.stringify({ id, method, args }));
      } catch (error) {
        clearTimeout(timer);
        pending.delete(id);
        reject(
          new AndroidOperationError(
            error instanceof Error ? error.message : "Could not reach Android.",
            "NATIVE_POST_FAILED",
          ),
        );
      }
    });

  window.KKDexHost = { call, available: true };
  window.KKDexNativeEvents = {
    onDisplayChanged: (status) =>
      window.dispatchEvent(
        new CustomEvent<AndroidDisplayStatus>("kkdex:display-status", {
          detail: status,
        }),
      ),
    onNativeMessage: (message) =>
      window.dispatchEvent(
        new CustomEvent<string>("kkdex:native-message", { detail: message }),
      ),
  };
  window.KKDexAndroidNavigation = {
    openFolder: (root) =>
      window.dispatchEvent(
        new CustomEvent<AndroidRoot>("kkdex:android-folder", { detail: root }),
      ),
  };
  window.KKDexServices = {
    ...window.KKDexServices,
    execute: async (command: string) => {
      const result = await call<{
        stdout: string;
        stderr: string;
        exitCode: number;
        backend: string;
      }>("runCommand", { command });
      const output = [result.stdout, result.stderr]
        .filter(Boolean)
        .join(result.stdout && result.stderr ? "\n" : "");
      const header = `[${result.backend}${result.exitCode === 0 ? "" : ` · exit ${result.exitCode}`}]`;
      return `${header}\n${output || "(no output)"}`;
    },
    openBrowser: async (url: string) => {
      await call("openUrl", { url });
    },
    setVolume: (value: number) => {
      void call("setVolume", { percent: value }).catch(() => undefined);
    },
    requestStorageAccess: async () => {
      await pickFolder();
      return true;
    },
    openDocument: (uri: string, mime: string) =>
      call<string>("openDocument", { uri, mime }),
  };
  if (!window.KKDexControllerBridge) {
    window.KKDexControllerBridge = {
      sendInput: (message) => {
        void call("controllerInput", { message }).catch(() => undefined);
      },
    };
  }
  return true;
}

installBridge();

export const nativeAvailable = () => Boolean(window.KKDexHost?.available);
export const nativeCall = <T = unknown>(
  method: string,
  args: Record<string, unknown> = {},
) => {
  if (!window.KKDexHost?.available)
    return Promise.reject(
      new AndroidUnavailableError(
        "Android integration is unavailable. This action requires the KK DEX Android application; the browser preview cannot grant device files or launch phone applications.",
      ),
    );
  return window.KKDexHost.call<T>(method, args);
};

export const pickFiles = (mime = "*/*") =>
  nativeCall<AndroidFileEntry[]>("pickFiles", { mime });
export const pickFolder = () => nativeCall<AndroidRoot>("pickFolder");
export const listRoots = () => nativeCall<AndroidRoot[]>("listRoots");
export const listDirectory = (treeUri: string, documentUri?: string) =>
  nativeCall<AndroidFileEntry[]>("listDirectory", { treeUri, documentUri });
export const readFile = (uri: string) =>
  nativeCall<{ base64: string; name: string; mime: string; size: number }>(
    "readFile",
    { uri },
  );
export const writeFile = (uri: string, text: string) =>
  nativeCall<boolean>("writeFile", {
    uri,
    base64: btoa(unescape(encodeURIComponent(text))),
  });
export const createDirectory = (treeUri: string, parentUri: string, name: string) =>
  nativeCall<AndroidFileEntry>("createDirectory", {
    treeUri,
    parentUri,
    name,
  });
export const renameDocument = (treeUri: string, uri: string, name: string) =>
  nativeCall<AndroidFileEntry>("renameDocument", { treeUri, uri, name });
export const deleteDocument = (treeUri: string, uri: string) =>
  nativeCall<boolean>("deleteDocument", { treeUri, uri });
export const copyDocument = (
  treeUri: string,
  sourceUri: string,
  destinationUri: string,
  move = false,
) =>
  nativeCall<AndroidFileEntry>(move ? "moveDocument" : "copyDocument", {
    treeUri,
    sourceUri,
    destinationUri,
  });
export const exportExistingFile = (treeUri: string, uri: string, name: string) =>
  nativeCall<string>("exportExistingFile", { treeUri, uri, name });
export const exportBase64 = (name: string, mime: string, base64: string) =>
  nativeCall<string>("exportFile", { name, mime, base64 });
export const contentUrl = (treeUri: string, uri: string, mime: string) =>
  nativeCall<string>("contentUrl", { treeUri, uri, mime });
export const openDocument = (treeUri: string, uri: string, mime: string) =>
  nativeCall<string>("openDocument", { treeUri, uri, mime });
export const requestMediaPermissions = () =>
  nativeCall<{ permissions: Record<string, boolean>; explanation: string }>(
    "requestMediaPermissions",
  );
export const getInstalledApps = () =>
  nativeCall<InstalledAndroidApp[]>("getInstalledApps");
export const launchInstalledApp = (packageName: string, preferExternal = true) =>
  nativeCall<string>("launchApp", { packageName, preferExternal });
export const getDownloads = () => nativeCall<AndroidDownload[]>("getDownloads");
export const openDownload = (id: number) =>
  nativeCall<string>("openDownload", { id });
export const getSystemInfo = () => nativeCall<AndroidSystemInfo>("getSystemInfo");
export const getDisplayStatus = () =>
  nativeCall<AndroidDisplayStatus>("displayStatus");
export const setAndroidVolume = (percent: number) =>
  nativeCall<number>("setVolume", { percent });
export const getAndroidVolume = () => nativeCall<number>("getVolume");
export const chooseFolderForDesktop = () =>
  nativeCall<AndroidRoot>("chooseFolderForDesktop");
export const pdfInfo = (treeUri: string, uri: string) =>
  nativeCall<{ pageCount: number; name: string }>("pdfInfo", { treeUri, uri });
export const pdfRenderPage = (
  treeUri: string,
  uri: string,
  page: number,
  width: number,
) =>
  nativeCall<{ image: string; page: number; width: number; height: number }>(
    "pdfRenderPage",
    { treeUri, uri, page, width },
  );

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let index = 0; index < bytes.length; index += chunk)
    binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
  return btoa(binary);
}

export function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++)
    bytes[index] = binary.charCodeAt(index);
  return bytes;
}

export function base64ToText(base64: string): string {
  return new TextDecoder("utf-8").decode(base64ToBytes(base64));
}

export function encodeAndroidPayload(entry: AndroidFileEntry): string {
  return JSON.stringify({
    uri: entry.uri,
    treeUri: entry.treeUri,
    name: entry.name,
    mime: entry.mime,
    size: entry.size,
    modified: entry.modified,
  });
}

export function parseAndroidPayload(payload?: string): AndroidFileEntry | null {
  if (!payload) return null;
  try {
    const value = JSON.parse(payload) as AndroidFileEntry;
    return value.uri ? value : null;
  } catch {
    return null;
  }
}

export function androidMediaKind(mime: string, name = "") {
  const lower = `${mime} ${name}`.toLowerCase();
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  if (mime === "application/pdf" || lower.endsWith(".pdf")) return "pdf";
  if (mime === "application/zip" || /\.(zip|apk|jar)$/.test(lower)) return "archive";
  if (
    mime.startsWith("text/") ||
    /\.(md|txt|json|csv|js|ts|css|html|xml|log|yaml|yml|kt|java|py)$/.test(
      lower,
    )
  )
    return "text";
  return "file";
}

export function formatAndroidBytes(value: number) {
  if (!Number.isFinite(value) || value < 0) return "Unknown";
  if (value < 1024) return `${value} B`;
  if (value < 1_048_576) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1_073_741_824)
    return `${(value / 1_048_576).toFixed(1)} MB`;
  return `${(value / 1_073_741_824).toFixed(1)} GB`;
}

export function formatAndroidDate(timestamp: number) {
  if (!timestamp) return "Unknown";
  return new Date(timestamp).toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

export type { NativeResponse };
