import { useState, type ComponentType, type PointerEvent } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Copy, Maximize2, Minus, Move, Square, X } from "lucide-react";
import { AppIcon } from "./icons";
import { appRegistry } from "./registry";
import { TASKBAR_HEIGHT, useSystem } from "./system";
import type { AppId, DesktopWindow, Rect } from "./types";
import FilesApp from "./apps/Files";
import { CalculatorApp, NotesApp, TerminalApp } from "./apps/Productivity";
import { AIApp, AppCenter, BrowserApp } from "./apps/Connected";
import { GalleryApp, RecycleBinApp, SettingsApp } from "./apps/SystemApps";
import {
  AndroidStorageApp,
  AppManagerApp,
  ArchiveManagerApp,
  DownloadsApp,
  MediaPlayerApp,
  PdfViewerApp,
  SystemInfoApp,
  TextEditorApp,
} from "./apps/AndroidApps";

const appContent: Record<AppId, ComponentType<{ win: DesktopWindow }>> = {
  pc: FilesApp,
  files: FilesApp,
  browser: BrowserApp,
  ai: AIApp,
  store: AppCenter,
  settings: SettingsApp,
  gallery: GalleryApp,
  notes: NotesApp,
  calculator: CalculatorApp,
  terminal: TerminalApp,
  bin: RecycleBinApp,
  storage: AndroidStorageApp,
  editor: TextEditorApp,
  video: ({ win }) => <MediaPlayerApp win={win} mode="video" />,
  music: ({ win }) => <MediaPlayerApp win={win} mode="music" />,
  pdf: PdfViewerApp,
  downloads: DownloadsApp,
  sysinfo: SystemInfoApp,
  appmanager: AppManagerApp,
  archives: ArchiveManagerApp,
};
function AppContent({ win }: { win: DesktopWindow }) {
  const Content = appContent[win.appId];
  return <Content win={win} />;
}

type Edge = "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";
export default function WindowManager() {
  const {
    windows,
    activeId,
    size,
    preferences,
    focusWindow,
    updateWindow,
    minimizeWindow,
    maximizeWindow,
    closeWindow,
    setContextMenu,
    snapWindow,
  } = useSystem();
  const [dragging, setDragging] = useState<string | null>(null);
  const [snap, setSnap] = useState<"left" | "right" | "top" | null>(null);
  const beginInteraction = (
    e: PointerEvent,
    win: DesktopWindow,
    edge?: Edge,
  ) => {
    if (e.button !== 0 || (!edge && (e.target as Element).closest("button")))
      return;
    e.preventDefault();
    setDragging(win.id);
    setContextMenu(null);
    let original: Rect = {
      x: win.x,
      y: win.y,
      width: win.width,
      height: win.height,
    };
    if (win.maximized && !edge) {
      const restored = win.restoreRect || {
        x: 30,
        y: 30,
        ...appRegistry[win.appId].defaultSize,
      };
      original = {
        ...restored,
        x: Math.max(
          0,
          Math.min(
            size.width - restored.width,
            e.clientX - restored.width * (e.clientX / size.width),
          ),
        ),
        y: Math.max(0, e.clientY - 18),
      };
      updateWindow(win.id, { ...original, maximized: false });
    }
    const start = { x: e.clientX, y: e.clientY };
    const definition = appRegistry[win.appId];
    let snapTarget: "left" | "right" | "top" | null = null;
    const move = (event: globalThis.PointerEvent) => {
      const dx = event.clientX - start.x,
        dy = event.clientY - start.y;
      const next = { ...original };
      if (!edge) {
        next.x = Math.max(
          0,
          Math.min(size.width - original.width, original.x + dx),
        );
        next.y = Math.max(
          0,
          Math.min(
            size.height - TASKBAR_HEIGHT - original.height,
            original.y + dy,
          ),
        );
        snapTarget =
          event.clientX < 12
            ? "left"
            : event.clientX > size.width - 12
              ? "right"
              : event.clientY < 8
                ? "top"
                : null;
        setSnap(snapTarget);
      } else {
        const minW = Math.min(definition.minSize.width, size.width - 16),
          minH = Math.min(
            definition.minSize.height,
            size.height - TASKBAR_HEIGHT - 12,
          );
        if (edge.includes("e"))
          next.width = Math.max(
            minW,
            Math.min(size.width - original.x, original.width + dx),
          );
        if (edge.includes("s"))
          next.height = Math.max(
            minH,
            Math.min(
              size.height - TASKBAR_HEIGHT - original.y,
              original.height + dy,
            ),
          );
        if (edge.includes("w")) {
          next.x = Math.max(
            0,
            Math.min(original.x + original.width - minW, original.x + dx),
          );
          next.width = original.width + original.x - next.x;
        }
        if (edge.includes("n")) {
          next.y = Math.max(
            0,
            Math.min(original.y + original.height - minH, original.y + dy),
          );
          next.height = original.height + original.y - next.y;
        }
      }
      updateWindow(win.id, next);
    };
    const end = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
      setDragging(null);
      setSnap(null);
      if (!edge && snapTarget) {
        if (snapTarget === "top") maximizeWindow(win.id);
        else snapWindow(win.id, snapTarget);
      }
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
  };
  return (
    <div className="window-layer">
      <AnimatePresence>
        {snap && (
          <motion.div
            className="snap-preview"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            style={{
              left: snap === "right" ? size.width / 2 + 8 : 8,
              top: 8,
              width: snap === "top" ? size.width - 16 : size.width / 2 - 16,
              height: size.height - TASKBAR_HEIGHT - 16,
            }}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {windows.map((win) => (
          <motion.section
            key={win.id}
            data-window={win.id}
            data-app={win.appId}
            data-testid={`window-${win.appId}`}
            aria-label={`${appRegistry[win.appId].name} window`}
            aria-hidden={win.minimized}
            inert={win.minimized}
            className={`desktop-window ${activeId === win.id ? "active-window" : ""} ${win.maximized ? "maximized" : ""} ${dragging === win.id ? "interacting" : ""} ${win.minimized ? "minimized" : ""}`}
            style={{
              left: win.x,
              top: win.y,
              width: win.width,
              height: win.height,
              zIndex: win.z,
              pointerEvents: win.minimized ? "none" : "auto",
            }}
            initial={{ opacity: 0, scale: 0.965, y: 12 }}
            animate={
              win.minimized
                ? { opacity: 0, scale: 0.92, y: 45 }
                : { opacity: 1, scale: 1, y: 0 }
            }
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{
              duration: preferences.reducedMotion ? 0 : 0.18,
              ease: [0.2, 0.8, 0.2, 1],
            }}
            onPointerDownCapture={() => focusWindow(win.id)}
            onContextMenu={(e) => e.stopPropagation()}
          >
            <header
              className="window-titlebar"
              onPointerDown={(e) => beginInteraction(e, win)}
              onDoubleClick={(e) => {
                if (!(e.target as Element).closest("button"))
                  maximizeWindow(win.id);
              }}
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setContextMenu({
                  x: e.clientX,
                  y: e.clientY,
                  items: [
                    {
                      label: "Restore",
                      icon: <Copy size={14} />,
                      disabled: !win.maximized && !win.restoreRect,
                      action: () => {
                        if (win.maximized) maximizeWindow(win.id);
                        else if (win.restoreRect)
                          updateWindow(win.id, {
                            ...win.restoreRect,
                            restoreRect: undefined,
                          });
                      },
                    },
                    {
                      label: "Snap left",
                      icon: <Move size={14} />,
                      shortcut: "Super+Left",
                      action: () => snapWindow(win.id, "left"),
                    },
                    {
                      label: "Snap right",
                      icon: <Move size={14} />,
                      shortcut: "Super+Right",
                      action: () => snapWindow(win.id, "right"),
                    },
                    {
                      label: "Minimize",
                      icon: <Minus size={14} />,
                      action: () => minimizeWindow(win.id),
                      divider: true,
                    },
                    {
                      label: win.maximized ? "Restore down" : "Maximize",
                      icon: <Maximize2 size={14} />,
                      action: () => maximizeWindow(win.id),
                    },
                    {
                      label: "Close",
                      icon: <X size={14} />,
                      shortcut: "Alt+F4",
                      action: () => closeWindow(win.id),
                      danger: true,
                      divider: true,
                    },
                  ],
                });
              }}
            >
              <div className="window-title">
                <AppIcon app={win.appId} size={19} />
                <span>{win.title}</span>
              </div>
              <div className="window-controls">
                <button
                  aria-label={`Minimize ${win.title}`}
                  title="Minimize"
                  onClick={() => minimizeWindow(win.id)}
                >
                  <Minus size={15} />
                </button>
                <button
                  aria-label={`${win.maximized ? "Restore" : "Maximize"} ${win.title}`}
                  title={win.maximized ? "Restore down" : "Maximize"}
                  onClick={() => maximizeWindow(win.id)}
                >
                  {win.maximized ? <Copy size={12} /> : <Square size={12} />}
                </button>
                <button
                  className="window-close"
                  aria-label={`Close ${win.title}`}
                  title="Close"
                  onClick={() => closeWindow(win.id)}
                >
                  <X size={17} />
                </button>
              </div>
            </header>
            <div className="window-content">
              <AppContent win={win} />
            </div>
            {!win.maximized &&
              (["n", "s", "e", "w", "ne", "nw", "se", "sw"] as Edge[]).map(
                (edge) => (
                  <div
                    key={edge}
                    aria-label={`Resize ${edge}`}
                    data-resize={edge}
                    className={`resize-handle resize-${edge}`}
                    onPointerDown={(e) => beginInteraction(e, win, edge)}
                  />
                ),
              )}
          </motion.section>
        ))}
      </AnimatePresence>
    </div>
  );
}
