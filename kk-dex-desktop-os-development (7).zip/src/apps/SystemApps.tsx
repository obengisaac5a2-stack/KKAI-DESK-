import { useEffect, useState } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronRight,
  HardDrive,
  Image,
  Info,
  Keyboard,
  Maximize,
  Monitor,
  Moon,
  MousePointer2,
  Palette,
  RotateCcw,
  Search,
  ShieldCheck,
  Smartphone,
  AppWindow,
  FolderSearch,
  Sun,
  Trash2,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { AppIcon, BrandMark } from "../icons";
import { wallpaperPaths } from "../registry";
import { useSystem } from "../system";
import { formatBytes } from "../storage";
import { EmptyState, IconButton, Toggle } from "../ui";
import { FileArtwork } from "./Files";
import { contentUrl, exportExistingFile, getDisplayStatus, nativeAvailable, parseAndroidPayload, requestMediaPermissions } from "../android/native";
import type { AndroidFileEntry, DesktopWindow, Preferences } from "../types";

export function playTestSound(volume: number) {
  try {
    const audio = new AudioContext();
    const oscillator = audio.createOscillator(),
      gain = audio.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(523.25, audio.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(
      783.99,
      audio.currentTime + 0.15,
    );
    gain.gain.setValueAtTime(0, audio.currentTime);
    gain.gain.linearRampToValueAtTime(volume * 0.15, audio.currentTime + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.45);
    oscillator.connect(gain);
    gain.connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + 0.5);
    oscillator.onended = () => void audio.close();
    return true;
  } catch {
    return false;
  }
}

const settingsSections = [
  { id: "appearance", label: "Personalization", icon: Palette },
  { id: "display", label: "Display", icon: Monitor },
  { id: "sound", label: "Sound", icon: Volume2 },
  { id: "input", label: "Mouse & keyboard", icon: MousePointer2 },
  { id: "storage", label: "Storage", icon: HardDrive },
  { id: "android", label: "Android & display", icon: Smartphone },
  { id: "about", label: "About KK DEX", icon: Info },
];
export function SettingsApp({ win }: { win: DesktopWindow }) {
  const {
    preferences: p,
    setPreference,
    size,
    files,
    explain,
    setDialog,
    openApp,
  } = useSystem();
  const [section, setSection] = useState(win.payload || "appearance");
  const [query, setQuery] = useState("");
  const [androidDisplay, setAndroidDisplay] = useState<Awaited<ReturnType<typeof getDisplayStatus>> | null>(null);
  const [permissionMessage, setPermissionMessage] = useState("");
  useEffect(() => {
    if (nativeAvailable()) void getDisplayStatus().then(setAndroidDisplay).catch(() => undefined);
  }, []);
  useEffect(() => {
    if (win.payload) setSection(win.payload);
  }, [win.payload]);
  const setVolume = (value: number) => {
    setPreference("volume", value);
    window.KKDexServices?.setVolume?.(value);
  };
  const headings: Record<string, string[]> = {
    appearance: [
      "Make it yours.",
      "A workspace that feels a little more like you.",
    ],
    display: [
      "A bigger perspective.",
      "Find a comfortable view for your screen.",
    ],
    sound: ["Set the tone.", "A little quieter. A little louder. Just right."],
    input: [
      "A natural connection.",
      "Fine-tune the way you move through your workspace.",
    ],
    storage: [
      "Room for what matters.",
      "Understand where your workspace lives.",
    ],
    android: [
      "Phone meets television.",
      "Real Android access, explicit permissions, honest limits.",
    ],
    about: ["This is KK DEX.", "Your phone. A bigger possibility."],
  };
  const heading = headings[section] || headings.appearance;
  return (
    <div className="settings-app">
      <aside className="settings-sidebar">
        <div className="settings-profile">
          <span className="profile-avatar">KK</span>
          <div>
            <strong>KK DEX</strong>
            <small>Personal workspace</small>
          </div>
        </div>
        <div className="settings-search">
          <Search size={13} />
          <input
            aria-label="Search settings"
            placeholder="Find a setting"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <nav>
          {settingsSections
            .filter((s) => s.label.toLowerCase().includes(query.toLowerCase()))
            .map(({ id, label, icon: Icon }) => (
              <button
                className={`sidebar-item ${section === id ? "active" : ""}`}
                key={id}
                onClick={() => setSection(id)}
              >
                <Icon size={16} />
                <span>{label}</span>
              </button>
            ))}
        </nav>
        <div className="settings-sidebar-footer">
          <BrandMark size={17} />
          <span>Consider it your space.</span>
        </div>
      </aside>
      <main className="settings-content">
        <h1>{heading[0]}</h1>
        <p className="settings-description">{heading[1]}</p>
        {section === "appearance" && (
          <>
            <section className="setting-section">
              <div className="setting-section-heading">
                <h3>Your wallpaper</h3>
                <span>A change of scenery.</span>
              </div>
              <div className="wallpaper-options">
                {(
                  Object.keys(wallpaperPaths) as Preferences["wallpaper"][]
                ).map((key) => (
                  <button
                    key={key}
                    aria-label={
                      key === "alpine"
                        ? "Alpine morning"
                        : key === "coast"
                          ? "Ocean air"
                          : "Quiet dunes"
                    }
                    className={p.wallpaper === key ? "selected" : ""}
                    onClick={() => setPreference("wallpaper", key)}
                  >
                    <img src={wallpaperPaths[key]} alt={`${key} wallpaper`} />
                    {p.wallpaper === key && (
                      <span>
                        <Check size={13} />
                      </span>
                    )}
                    <strong>
                      {key === "alpine"
                        ? "Alpine morning"
                        : key === "coast"
                          ? "Ocean air"
                          : "Quiet dunes"}
                    </strong>
                  </button>
                ))}
              </div>
            </section>
            <section className="setting-section">
              <div className="setting-section-heading">
                <h3>Choose your mood</h3>
              </div>
              <div className="theme-options">
                {(["light", "dark"] as const).map((theme) => (
                  <button
                    key={theme}
                    className={`theme-option ${theme} ${p.theme === theme ? "selected" : ""}`}
                    onClick={() => setPreference("theme", theme)}
                  >
                    <div className="theme-preview">
                      <span />
                      <div>
                        <i />
                        <i />
                        <i />
                      </div>
                    </div>
                    <span>
                      {theme === "light" ? (
                        <Sun size={14} />
                      ) : (
                        <Moon size={14} />
                      )}
                      <strong>
                        {theme === "light" ? "Light & airy" : "After hours"}
                      </strong>
                      {p.theme === theme && <Check size={14} />}
                    </span>
                  </button>
                ))}
              </div>
            </section>
            <div className="setting-row">
              <div>
                <strong>Desktop icons</strong>
                <small>Keep your essentials within reach.</small>
              </div>
              <Toggle
                label="Show desktop icons"
                checked={p.showIcons}
                onChange={(value) => setPreference("showIcons", value)}
              />
            </div>
            <div className="setting-row">
              <div>
                <strong>Reduce motion</strong>
                <small>A calmer experience with fewer animations.</small>
              </div>
              <Toggle
                label="Reduce animations"
                checked={p.reducedMotion}
                onChange={(value) => setPreference("reducedMotion", value)}
              />
            </div>
          </>
        )}
        {section === "display" && (
          <>
            <div className="display-preview">
              <Monitor size={76} strokeWidth={1} />
              <span>1</span>
              <p>Your workspace display</p>
              <small>
                {size.width} x {size.height} CSS pixels
              </small>
            </div>
            <div className="setting-row">
              <div>
                <strong>Full-screen desktop</strong>
                <small>Use all the space your display has to offer.</small>
              </div>
              <button
                className="secondary-button"
                onClick={async () => {
                  try {
                    if (document.fullscreenElement)
                      await document.exitFullscreen();
                    else await document.documentElement.requestFullscreen();
                  } catch {
                    explain(
                      "Full screen unavailable",
                      "This WebView does not allow full-screen requests. The Android host can enable immersive mode for the external display.",
                    );
                  }
                }}
              >
                <Maximize size={14} />
                Toggle full screen
              </button>
            </div>
            <div className="setting-row">
              <div>
                <strong>Workspace brightness</strong>
                <small>Adjusts the desktop, not the physical display.</small>
              </div>
              <div className="setting-slider">
                <Sun size={15} />
                <input
                  type="range"
                  aria-label="Workspace brightness"
                  min="35"
                  max="100"
                  value={p.brightness}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    setPreference("brightness", v);
                    window.KKDexServices?.setBrightness?.(v);
                  }}
                />
                <span>{p.brightness}%</span>
              </div>
            </div>
            <div className="setting-row">
              <div>
                <strong>Text size</strong>
                <small>
                  A comfortable size for desktop labels and controls.
                </small>
              </div>
              <select
                aria-label="Desktop text size"
                value={p.textScale}
                onChange={(e) =>
                  setPreference("textScale", Number(e.target.value))
                }
              >
                <option value=".9">Small (90%)</option>
                <option value="1">Default (100%)</option>
                <option value="1.15">Large (115%)</option>
              </select>
            </div>
            <div className="setting-row">
              <div>
                <strong>Desktop icon size</strong>
              </div>
              <select
                aria-label="Desktop icon size"
                value={p.iconSize}
                onChange={(e) =>
                  setPreference(
                    "iconSize",
                    e.target.value as Preferences["iconSize"],
                  )
                }
              >
                <option value="small">Small</option>
                <option value="medium">Medium</option>
              </select>
            </div>
          </>
        )}
        {section === "sound" && (
          <>
            <div className="sound-illustration">
              <Volume2 size={52} strokeWidth={1.2} />
            </div>
            <div className="setting-row">
              <div>
                <strong>Workspace volume</strong>
                <small>
                  {window.KKDexServices?.setVolume
                    ? "Connected to device audio."
                    : "Applies to workspace audio. Device audio is not connected."}
                </small>
              </div>
              <div className="setting-slider">
                <IconButton
                  label={p.muted ? "Unmute workspace" : "Mute workspace"}
                  onClick={() => setPreference("muted", !p.muted)}
                >
                  {p.muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </IconButton>
                <input
                  aria-label="Workspace volume"
                  type="range"
                  min="0"
                  max="100"
                  value={p.volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                />
                <span>{p.volume}%</span>
              </div>
            </div>
            <div className="setting-row">
              <div>
                <strong>Try a little sound</strong>
                <small>Play a soft workspace tone.</small>
              </div>
              <button
                className="secondary-button"
                disabled={p.muted}
                onClick={() => {
                  if (!playTestSound(p.volume / 100))
                    explain(
                      "Audio unavailable",
                      "This WebView does not support workspace audio. Connect the native audio adapter to play device audio.",
                    );
                }}
              >
                Play test sound
              </button>
            </div>
            <div className="inline-notice">
              <Info size={16} />
              <span>
                Hardware audio outputs and Android volume controls require the
                native audio adapter.
              </span>
            </div>
          </>
        )}
        {section === "input" && (
          <>
            <div className="setting-row">
              <div>
                <strong>Pointer speed</strong>
                <small>For relative movement from the phone touchpad.</small>
              </div>
              <div className="setting-slider">
                <input
                  type="range"
                  aria-label="Phone pointer speed"
                  min=".3"
                  max="2.5"
                  step=".1"
                  value={p.pointerSpeed}
                  onChange={(e) =>
                    setPreference("pointerSpeed", Number(e.target.value))
                  }
                />
                <span>{p.pointerSpeed.toFixed(1)}x</span>
              </div>
            </div>
            <h3 className="setting-subheading">A few useful shortcuts</h3>
            <div className="shortcut-reference">
              {[
                ["Open Start", "Super"],
                ["Show desktop", "Super + D"],
                ["Open Files", "Super + E"],
                ["Switch windows", "Alt + Tab"],
                ["Close active window", "Alt + F4"],
                ["Snap a window", "Super + Left / Right"],
                ["Save a note", "Ctrl + S"],
                ["Rename a file", "F2"],
              ].map(([label, shortcut]) => (
                <div key={label}>
                  <span>{label}</span>
                  <kbd>{shortcut}</kbd>
                </div>
              ))}
            </div>
            <button
              className="settings-link"
              onClick={() =>
                explain(
                  "Your phone, your controller",
                  "The separate controller is available at ?controller. The Android host must relay its input messages to the external-display WebView through KKDexAPI. It must not mirror the phone screen. See INTEGRATION.md for the exact input contract.",
                )
              }
            >
              <Keyboard size={16} />
              About the phone controller
              <ChevronRight size={14} />
            </button>
          </>
        )}
        {section === "storage" && (
          <>
            <div className="storage-summary">
              <HardDrive size={38} />
              <div>
                <strong>KK DEX Workspace</strong>
                <span>
                  {formatBytes(new Blob([JSON.stringify(files)]).size)} of
                  managed data
                </span>
                <small>
                  {
                    files.filter((f) => !f.deleted && f.kind !== "folder")
                      .length
                  }{" "}
                  files in local WebView storage
                </small>
              </div>
            </div>
            <div className="inline-notice">
              <ShieldCheck size={17} />
              <span>
                This workspace is saved locally. Clearing your browser or
                WebView data will remove its files and notes. Export important
                work regularly.
              </span>
            </div>
            <div className="setting-row">
              <div>
                <strong>Browse your workspace</strong>
                <small>Organize, import, and export your files.</small>
              </div>
              <button
                className="secondary-button"
                onClick={() => openApp("files")}
              >
                Open Files
                <ChevronRight size={14} />
              </button>
            </div>
            <div className="setting-row">
              <div>
                <strong>Deleted files</strong>
                <small>
                  {files.filter((f) => f.deleted).length} items in your Recycle
                  Bin.
                </small>
              </div>
              <button
                className="secondary-button"
                onClick={() => openApp("bin")}
              >
                Open Recycle Bin
              </button>
            </div>
            <div className="setting-row">
              <div>
                <strong>Reset desktop layout</strong>
                <small>Put your shortcuts back in their original places.</small>
              </div>
              <button
                className="secondary-button"
                onClick={() =>
                  setDialog({
                    title: "Reset desktop layout?",
                    message:
                      "Your desktop shortcuts will return to their original positions. Files, notes, and other settings will not be changed.",
                    confirmLabel: "Reset layout",
                    onConfirm: () => {
                      localStorage.removeItem("kkdex:icon-positions");
                      window.dispatchEvent(
                        new CustomEvent("kkdex:reset-desktop"),
                      );
                    },
                  })
                }
              >
                <RotateCcw size={13} />
                Reset
              </button>
            </div>
          </>
        )}
        {section === "android" && (
      <>
        <div className="system-connection-card">
          <div className={androidDisplay?.connected ? "connected" : ""}><Smartphone size={25} /></div>
          <span>
            <strong>{nativeAvailable() ? androidDisplay?.connected ? `Connected to ${androidDisplay.displayName}` : "Android app connected · no external display" : "Android bridge not connected"}</strong>
            <small>{nativeAvailable() ? androidDisplay?.presentationActive ? `${androidDisplay.width} × ${androidDisplay.height}. The television owns the desktop WebView; this phone remains the controller.` : "Open or reconnect a supported external display. The phone does not mirror the desktop here." : "The Android features are unavailable in this browser preview. Open KK DEX from the installed APK to use SAF, Android apps, real volume and the app-sandbox terminal."}</small>
          </span>
        </div>
        <div className="setting-row">
          <div><strong>Authorized Android storage</strong><small>Use Android's Storage Access Framework picker for real folders and files, or grant MediaStore permissions separately.</small></div>
          <button className="secondary-button" onClick={() => openApp("storage")}><FolderSearch size={13} /> Open</button>
        </div>
        <div className="setting-row">
          <div><strong>Media permissions</strong><small>Android 13+ asks for images, video and audio separately. Folder grants remain separate from media permissions.</small></div>
          <button className="secondary-button" disabled={!nativeAvailable()} onClick={() => void requestMediaPermissions().then((result) => setPermissionMessage(result.explanation)).catch((error) => setPermissionMessage(error instanceof Error ? error.message : "Permission request failed."))}><ShieldCheck size={13} /> Request</button>
        </div>
        {permissionMessage && <div className="inline-notice"><Info size={15}/><span>{permissionMessage}</span></div>}
        <div className="setting-row">
          <div><strong>Installed Android applications</strong><small>Discover launcher activities, inspect package names, and request a launch on the external display where supported.</small></div>
          <button className="secondary-button" onClick={() => openApp("appmanager")}><AppWindow size={13} /> Manage</button>
        </div>
        <div className="setting-row">
          <div><strong>System information</strong><small>View the actual external display, device, WebView and runtime availability reported by Android.</small></div>
          <button className="secondary-button" onClick={() => openApp("sysinfo")}><Info size={13} /> Open</button>
        </div>
      </>
    )}
    {section === "about" && (
          <>
            <div className="about-brand">
              <BrandMark size={50} />
              <h2>KK DEX</h2>
              <p>A bigger view. A better flow.</p>
              <span>Desktop experience 1.0</span>
            </div>
            <div className="about-details">
              <div>
                <span>Environment</span>
                <strong>
                  {window.KKDexServices
                    ? "Native services adapter available"
                    : "Browser / WebView workspace"}
                </strong>
              </div>
              <div>
                <span>Display</span>
                <strong>
                  {size.width} x {size.height}
                </strong>
              </div>
              <div>
                <span>Controller interface</span>
                <strong>KKDexAPI bridge</strong>
              </div>
              <div>
                <span>Android shell</span>
                <strong>
                  {window.KKDexServices?.execute
                    ? "Connected"
                    : "Not connected"}
                </strong>
              </div>
              <div>
                <span>AI service</span>
                <strong>
                  {window.KKDexServices?.chat ? "Connected" : "Not connected"}
                </strong>
              </div>
            </div>
            <p className="about-note">
              Built around your ideas, not the size of your screen.
            </p>
          </>
        )}
      </main>
    </div>
  );
}

export function GalleryApp({ win }: { win: DesktopWindow }) {
  const { files, deleteFiles, setPreference, setContextMenu, explain, notify } = useSystem();
  const images = files.filter((f) => f.kind === "image" && !f.deleted);
  const initialAndroidPayload = parseAndroidPayload(win.payload);
  const [viewing, setViewing] = useState<string | null>(initialAndroidPayload ? null : win.payload || null);
  const [androidImage, setAndroidImage] = useState<AndroidFileEntry | null>(initialAndroidPayload);
  const [androidSource, setAndroidSource] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [query, setQuery] = useState("");
  useEffect(() => {
    const payload = parseAndroidPayload(win.payload);
    if (payload) {
      setViewing(null);
      setSelected(null);
      setAndroidImage(payload);
      setZoom(1);
      void contentUrl(payload.treeUri || "", payload.uri, payload.mime || "image/*")
        .then(setAndroidSource)
        .catch((cause) => {
          setAndroidSource("");
          explain(
            "Android image unavailable",
            cause instanceof Error
              ? cause.message
              : "Android did not grant access to this image.",
          );
        });
      return;
    }
    if (win.payload) {
      setAndroidImage(null);
      setAndroidSource("");
      setViewing(win.payload);
      setZoom(1);
    }
  }, [win.payload]);
  const image = images.find((f) => f.id === viewing);
  const viewerOpen = Boolean(image || androidImage);
  const index = images.findIndex((f) => f.id === viewing);
  const next = (direction: number) => {
    if (androidImage) return;
    setViewing(
      images[(index + direction + images.length) % images.length]?.id || null,
    );
    setZoom(1);
  };
  const download = () => {
    if (androidImage) {
      void exportExistingFile(
        androidImage.treeUri || "",
        androidImage.uri,
        androidImage.name,
      )
        .then((name) =>
          notify(
            "Image exported",
            `${name} was written through Android's real document picker.`,
            "gallery",
          ),
        )
        .catch((cause) =>
          explain(
            "Android export was not completed",
            cause instanceof Error
              ? cause.message
              : "Android did not export the image.",
          ),
        );
      return;
    }
    if (!image) return;
    const a = document.createElement("a");
    a.href = image.content || "";
    a.download = image.name;
    a.click();
  };
  return (
    <div className={`gallery-app ${viewerOpen ? "viewing" : ""}`}>
      <div className="gallery-toolbar">
        {viewerOpen ? (
          <>
            <IconButton
              label="Back to all photos"
              onClick={() => {
                setViewing(null);
                setAndroidImage(null);
                setAndroidSource("");
              }}
            >
              <ArrowLeft size={17} />
            </IconButton>
            <strong>{androidImage?.name || image?.name}</strong>
            <div className="toolbar-spacer" />
            <IconButton
              label="Zoom out"
              disabled={zoom <= 0.5}
              onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
            >
              <ZoomOut size={17} />
            </IconButton>
            <button className="text-tool" onClick={() => setZoom(1)}>
              {Math.round(zoom * 100)}%
            </button>
            <IconButton
              label="Zoom in"
              disabled={zoom >= 3}
              onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
            >
              <ZoomIn size={17} />
            </IconButton>
            <span className="toolbar-divider" />
            <IconButton label="Download image" onClick={download}>
              <ArrowDownToLine size={17} />
            </IconButton>
            {image && (
              <IconButton
                label="Move image to Recycle Bin"
                onClick={() => {
                  deleteFiles([image.id]);
                  setViewing(null);
                }}
              >
                <Trash2 size={16} />
              </IconButton>
            )}
          </>
        ) : (
          <>
            <strong>All photos</strong>
            <span className="gallery-count">{images.length} moments</span>
            <div className="toolbar-spacer" />
            <div className="app-search">
              <Search size={14} />
              <input
                aria-label="Search photos"
                placeholder="Find a photo"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
          </>
        )}
      </div>
      {viewerOpen ? (
        <div className="gallery-viewer">
          <IconButton
            className="gallery-prev"
            label="Previous photo"
            disabled={Boolean(androidImage)}
            onClick={() => next(-1)}
          >
            <ArrowLeft size={20} />
          </IconButton>
          <div className="gallery-image-area">
            {androidImage && !androidSource ? (
              <div className="native-loading">Reading image through Android ContentResolver…</div>
            ) : (
              <img
                src={androidImage ? androidSource : image?.content}
                alt={androidImage?.name || image?.name}
                style={{ transform: `scale(${zoom})` }}
              />
            )}
          </div>
          <IconButton
            className="gallery-next"
            label="Next photo"
            disabled={Boolean(androidImage)}
            onClick={() => next(1)}
          >
            <ArrowRight size={20} />
          </IconButton>
          <span className="gallery-image-position">
            {androidImage
              ? `Android content URI · ${Math.round(zoom * 100)}%`
              : `${index + 1} / ${images.length}`}
          </span>
        </div>
      ) : (
        <div className="gallery-collection">
          <div className="gallery-heading">
            <span className="eyebrow">THE LITTLE THINGS, IN FOCUS</span>
            <h1>A view worth keeping.</h1>
            <p>Your images, all together.</p>
          </div>
          <div className="photo-grid">
            {images
              .filter((f) => f.name.toLowerCase().includes(query.toLowerCase()))
              .map((f) => (
                <button
                  key={f.id}
                  className={selected === f.id ? "selected" : ""}
                  onClick={() => setSelected(f.id)}
                  onDoubleClick={() => {
                    setViewing(f.id);
                    setZoom(1);
                  }}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setContextMenu({
                      x: e.clientX,
                      y: e.clientY,
                      items: [
                        {
                          label: "View photo",
                          icon: <Image size={15} />,
                          action: () => setViewing(f.id),
                        },
                        ...Object.entries(wallpaperPaths)
                          .filter(([, path]) => path === f.content)
                          .map(([key]) => ({
                            label: "Set as wallpaper",
                            icon: <Monitor size={15} />,
                            action: () =>
                              setPreference(
                                "wallpaper",
                                key as Preferences["wallpaper"],
                              ),
                          })),
                        {
                          label: "Move to Recycle Bin",
                          icon: <Trash2 size={15} />,
                          danger: true,
                          action: () => deleteFiles([f.id]),
                        },
                      ],
                    });
                  }}
                >
                  <img src={f.content} alt={f.name} />
                  <span>
                    <strong>{f.name}</strong>
                    <small>Workspace photo</small>
                  </span>
                  {selected === f.id && (
                    <span className="photo-selected">
                      <Check size={12} />
                    </span>
                  )}
                </button>
              ))}
          </div>
          {!images.length && (
            <EmptyState
              icon={<Image size={32} />}
              title="Your story starts here"
              description="Import images in Files to see them in your gallery."
            />
          )}
          <p className="gallery-hint">
            Double-click a photo to take a closer look.
          </p>
        </div>
      )}
    </div>
  );
}

export function RecycleBinApp({ win }: { win: DesktopWindow }) {
  const { files, restoreFiles, purgeFiles, setContextMenu, activeId } =
    useSystem();
  const deleted = files.filter(
    (f) => f.deleted && !files.find((p) => p.id === f.parent)?.deleted,
  );
  const [selected, setSelected] = useState<string[]>([]);
  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      if (
        activeId !== win.id ||
        (e.target instanceof Element && e.target.closest("input,textarea"))
      )
        return;
      if ((e.ctrlKey || e.metaKey) && e.key === "a") {
        e.preventDefault();
        setSelected(deleted.map((f) => f.id));
      }
      if (e.key === "Delete" && selected.length) {
        e.preventDefault();
        purgeFiles(selected);
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  });
  return (
    <div className="recycle-app">
      <div className="recycle-toolbar">
        <button
          className="secondary-button"
          disabled={!deleted.length}
          onClick={() => purgeFiles(deleted.map((f) => f.id))}
        >
          <Trash2 size={15} />
          Empty Recycle Bin
        </button>
        <button
          className="text-tool"
          disabled={!selected.length}
          onClick={() => {
            restoreFiles(selected);
            setSelected([]);
          }}
        >
          <RotateCcw size={15} />
          Restore selected
        </button>
        <div className="toolbar-spacer" />
        {deleted.length > 0 && (
          <button
            className="text-tool"
            onClick={() => restoreFiles(deleted.map((f) => f.id))}
          >
            Restore all
          </button>
        )}
      </div>
      {deleted.length ? (
        <main className="recycle-content">
          <h1>A second chance.</h1>
          <p>Restore something you still need, or let it go for good.</p>
          <div className="recycle-list">
            {deleted.map((f) => (
              <div
                className={`recycle-file ${selected.includes(f.id) ? "selected" : ""}`}
                key={f.id}
                onClick={(e) =>
                  setSelected((s) =>
                    e.ctrlKey
                      ? s.includes(f.id)
                        ? s.filter((x) => x !== f.id)
                        : [...s, f.id]
                      : [f.id],
                  )
                }
                onDoubleClick={() => restoreFiles([f.id])}
                onContextMenu={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setSelected([f.id]);
                  setContextMenu({
                    x: e.clientX,
                    y: e.clientY,
                    items: [
                      {
                        label: "Restore",
                        icon: <RotateCcw size={15} />,
                        action: () => restoreFiles([f.id]),
                      },
                      {
                        label: "Delete permanently",
                        icon: <Trash2 size={15} />,
                        danger: true,
                        action: () => purgeFiles([f.id]),
                      },
                    ],
                  });
                }}
              >
                <FileArtwork file={f} size={32} />
                <div>
                  <strong>{f.name}</strong>
                  <small>
                    {files.find((p) => p.id === f.originalParent)?.name ||
                      "Workspace"}
                  </small>
                </div>
                <span>
                  {f.kind === "folder" ? "Folder" : formatBytes(f.size)}
                </span>
                <IconButton
                  label={`Restore ${f.name}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    restoreFiles([f.id]);
                  }}
                >
                  <RotateCcw size={16} />
                </IconButton>
              </div>
            ))}
          </div>
        </main>
      ) : (
        <EmptyState
          icon={<AppIcon app="bin" size={64} />}
          title="A clean slate."
          description="Your Recycle Bin is empty. Deleted workspace files will appear here."
        />
      )}
      <footer className="recycle-footer">
        {deleted.length} items<span>KK DEX managed files only</span>
      </footer>
    </div>
  );
}
