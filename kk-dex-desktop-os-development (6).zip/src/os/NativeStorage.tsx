import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Download,
  ExternalLink,
  FolderOpen,
  FolderPlus,
  HardDrive,
  Image as ImageIcon,
  Import,
  Info,
  Loader2,
  Music,
  Pencil,
  RefreshCw,
  Search,
  ShieldCheck,
  Smartphone,
  Trash2,
  Video,
  X,
} from "lucide-react";
import {
  browserImport,
  nativeBridge,
  nativeKindLabel,
  readBrowserFileAsDataUrl,
  readBrowserFileAsText,
  type NativeBridgeState,
  type NativeFile,
} from "./native";
import { useOS } from "./OSContext";
import type { FileKind } from "./types";
import { EmptyState } from "./ui";
import { cn } from "@/utils/cn";

const FOLDERS_KEY = "kkdex.authorizedFolders";

interface AuthorizedFolder {
  uri: string;
  name: string;
  addedAt: number;
}

function useNativeState(): NativeBridgeState {
  const [state, setState] = useState<NativeBridgeState>(nativeBridge.getState());
  useEffect(() => {
    const unsubscribe = nativeBridge.subscribe(setState);
    return () => {
      unsubscribe();
    };
  }, []);
  useEffect(() => {
    if (!nativeBridge.getState().available) void nativeBridge.detect();
  }, []);
  return state;
}

function fileKindFromNative(file: NativeFile): FileKind {
  if (file.kind === "folder") return "folder";
  if (file.kind === "image") return "image";
  if (file.kind === "audio") return "audio";
  if (file.kind === "video") return "video";
  if (file.kind === "archive") return "archive";
  if (file.kind === "document") return file.name.endsWith(".js") || file.name.endsWith(".ts") ? "code" : "document";
  return "file";
}

function NativeGlyph({ kind }: { kind: NativeFile["kind"] }) {
  if (kind === "folder") return <FolderOpen size={19} color="#f0ae3c" strokeWidth={1.7} />;
  if (kind === "image") return <ImageIcon size={19} color="#f0729b" strokeWidth={1.7} />;
  if (kind === "audio") return <Music size={19} color="#a78bfa" strokeWidth={1.7} />;
  if (kind === "video") return <Video size={19} color="#fb923c" strokeWidth={1.7} />;
  if (kind === "archive") return <Download size={19} color="#facc15" strokeWidth={1.7} />;
  return <HardDrive size={19} color="#94a3b8" strokeWidth={1.7} />;
}

function loadFolders(): AuthorizedFolder[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(FOLDERS_KEY) ?? "[]") as AuthorizedFolder[];
    return Array.isArray(parsed) ? parsed.filter((folder) => folder?.uri) : [];
  } catch {
    return [];
  }
}

export function NativeStorage({ onExit }: { onExit: () => void }) {
  const { addFile, launch, notify, showConfirm, showPrompt, showInfo, pushExportedFile } = useOS();
  const state = useNativeState();
  const caps = state.capabilities;
  const [folders, setFolders] = useState<AuthorizedFolder[]>(loadFolders);
  const [activeFolder, setActiveFolder] = useState<AuthorizedFolder | null>(null);
  const [files, setFiles] = useState<NativeFile[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [preview, setPreview] = useState<{ file: NativeFile; content: string } | null>(null);

  useEffect(() => {
    localStorage.setItem(FOLDERS_KEY, JSON.stringify(folders));
  }, [folders]);

  const authorized = state.available && state.ready && caps.storageAccessFramework;

  const loadFolder = async (folder: AuthorizedFolder) => {
    setBusy(true);
    setError("");
    setActiveFolder(folder);
    try {
      const listing = await nativeBridge.listDirectory(folder.uri);
      setFiles(listing.files);
    } catch (err) {
      setFiles([]);
      setError(err instanceof Error ? err.message : "The folder could not be read.");
    } finally {
      setBusy(false);
    }
  };

  const authorizeFolder = async () => {
    setBusy(true);
    setError("");
    try {
      const selected = await nativeBridge.pickFolder();
      if (!selected) return;
      const folder: AuthorizedFolder = { ...selected, addedAt: Date.now() };
      setFolders((prev) => [folder, ...prev.filter((item) => item.uri !== folder.uri)]);
      await loadFolder(folder);
      notify("Folder authorized", `${selected.name} is now readable by KK DEX on this device.`, { tone: "success" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Folder authorization failed.");
    } finally {
      setBusy(false);
    }
  };

  const importNative = async (file: NativeFile) => {
    setBusy(true);
    try {
      if (file.kind === "folder") {
        const listing = await nativeBridge.listDirectory(file.uri);
        setActiveFolder({ uri: file.uri, name: file.name, addedAt: Date.now() });
        setFolders((prev) => [{ uri: file.uri, name: file.name, addedAt: Date.now() }, ...prev.filter((item) => item.uri !== file.uri)]);
        setFiles(listing.files);
        return;
      }
      let src: string | undefined;
      let content: string | undefined;
      if (["image", "audio", "video", "pdf"].includes(file.kind)) {
        if (file.size > 18 * 1024 * 1024) {
          showInfo(
            "File too large to copy into the workspace",
            `${file.name} is ${(file.size / 1024 / 1024).toFixed(1)} MB. It can still be opened directly from Android storage or sent to another Android application. Copying extremely large media into browser-persistent storage is intentionally blocked.`,
            <HardDrive size={26} />,
          );
          return;
        }
        src = await nativeBridge.readDataUrl(file.uri, file.mime || "application/octet-stream");
      } else if (file.kind === "document") {
        if (file.size > 900_000) throw new Error("This text file exceeds the 900 KB workspace import limit.");
        const result = await nativeBridge.readFile(file.uri);
        content = result.encoding === "base64" ? atob(result.content) : result.content;
      }
      const id = addFile("downloads", file.name, fileKindFromNative(file), { src, content, size: file.size });
      notify("File imported", `${file.name} is now available in Downloads.`, { tone: "success", silent: true });
      return id;
    } catch (err) {
      setError(err instanceof Error ? err.message : "The selected file could not be imported.");
    } finally {
      setBusy(false);
    }
  };

  const importFromBrowser = async () => {
    setBusy(true);
    setError("");
    try {
      const selected = await browserImport("*/*", true);
      if (!selected.length) return;
      for (const file of selected) {
        const kind: FileKind = file.type.startsWith("image/")
          ? "image"
          : file.type.startsWith("audio/")
            ? "audio"
            : file.type.startsWith("video/")
              ? "video"
              : /\.(txt|md|json|csv|log)$/i.test(file.name)
                ? "document"
                : /\.(js|ts|css|html|py)$/i.test(file.name)
                  ? "code"
                  : /\.(zip|rar|7z|tar|gz)$/i.test(file.name)
                    ? "archive"
                    : "file";
        const src = ["image", "audio", "video"].includes(kind) && file.size <= 18 * 1024 * 1024 ? await readBrowserFileAsDataUrl(file) : undefined;
        const content = ["document", "code"].includes(kind) && file.size <= 900_000 ? await readBrowserFileAsText(file) : undefined;
        addFile("downloads", file.name, kind, { src, content, size: file.size });
        if (src) pushExportedFile({ id: `browser-${file.name}-${Date.now()}`, name: file.name, kind, size: file.size, src, createdAt: Date.now(), origin: "Browser file picker" });
      }
      notify("Import complete", `${selected.length} file${selected.length === 1 ? "" : "s"} added to workspace Downloads.`, { tone: "success" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "The browser file picker could not read the selection.");
    } finally {
      setBusy(false);
    }
  };

  const openNative = async (file: NativeFile) => {
    setBusy(true);
    setError("");
    try {
      if (file.kind === "image") {
        const src = await nativeBridge.readDataUrl(file.uri, file.mime);
        launch("gallery", { payload: { imageSrc: src, imageName: file.name } });
      } else if (file.kind === "audio" || file.kind === "video") {
        const src = await nativeBridge.readDataUrl(file.uri, file.mime);
        launch("media", { payload: { src, name: file.name, automaticallyOpen: true } });
      } else if (file.kind === "pdf") {
        const src = await nativeBridge.readDataUrl(file.uri, "application/pdf");
        launch("pdf", { payload: { src, name: file.name } });
      } else if (file.kind === "document") {
        const result = await nativeBridge.readFile(file.uri);
        setPreview({ file, content: result.encoding === "base64" ? "Binary content cannot be displayed as text." : result.content });
      } else if (file.kind === "folder") {
        await importNative(file);
      } else {
        const opened = await nativeBridge.openWith(file.uri, file.mime || "*/*");
        if (opened) notify("Opened on Android", `${file.name} was sent to an Android application.`, { silent: true });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to open this Android file.");
    } finally {
      setBusy(false);
    }
  };

  const renameNative = (file: NativeFile) => {
    showPrompt({
      title: "Rename Android file",
      message: "The document provider controls whether renaming is permitted.",
      label: "New name",
      value: file.name,
      confirmLabel: "Rename",
      icon: <NativeGlyph kind={file.kind} />,
      onConfirm: async (value) => {
        if (!value.trim() || value.trim() === file.name) return;
        setBusy(true);
        try {
          await nativeBridge.renameFile(file.uri, value.trim());
          notify("File renamed", `Renamed to “${value.trim()}”.`, { tone: "success" });
          if (activeFolder) await loadFolder(activeFolder);
        } catch (err) {
          setError(err instanceof Error ? err.message : "This provider refused the rename.");
        } finally {
          setBusy(false);
        }
      },
    });
  };

  const deleteNative = (file: NativeFile) => {
    showConfirm(
      `Delete “${file.name}” from Android storage?`,
      "Android will permanently delete this file. It will not enter the KK DEX Recycle Bin because it is outside the workspace storage.",
      async () => {
        setBusy(true);
        try {
          await nativeBridge.deleteFile(file.uri);
          notify("Android file deleted", file.name, { tone: "success" });
          if (activeFolder) await loadFolder(activeFolder);
        } catch (err) {
          setError(err instanceof Error ? err.message : "The provider refused deletion.");
        } finally {
          setBusy(false);
        }
      },
      "Delete from Android",
    );
  };

  const newNativeFolder = () => {
    if (!activeFolder) return;
    showPrompt({
      title: "New folder on Android",
      label: "Folder name",
      value: "New folder",
      confirmLabel: "Create",
      onConfirm: async (value) => {
        if (!value.trim()) return;
        setBusy(true);
        try {
          await nativeBridge.createFolder(activeFolder.uri, value.trim());
          await loadFolder(activeFolder);
        } catch (err) {
          setError(err instanceof Error ? err.message : "The provider refused folder creation.");
        } finally {
          setBusy(false);
        }
      },
    });
  };

  const filtered = files.filter((file) => file.name.toLowerCase().includes(query.toLowerCase()));
  const capabilityRows = useMemo(
    () => [
      { label: "Storage Access Framework", on: caps.storageAccessFramework },
      { label: "MediaStore", on: caps.mediaStore },
      { label: "Installed application discovery", on: caps.installedApps },
      { label: "Native app launching", on: caps.appLaunch },
      { label: "External display", on: caps.externalDisplay },
      { label: "Native command runtime", on: caps.shellExecution },
    ],
    [caps],
  );

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <button className="icon-btn h-7 w-7" aria-label="Back to workspace files" onClick={onExit}><ArrowLeft size={14} /></button>
        <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: "rgba(44,201,160,.13)", color: "#2cc9a0" }}><Smartphone size={15} /></div>
        <div className="min-w-0">
          <div className="text-[12.5px] font-semibold leading-tight">Android device storage</div>
          <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>
            {authorized ? "SAF bridge connected" : state.available ? "Bridge present · storage capability unavailable" : "Standalone browser session"}
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" onClick={importFromBrowser} disabled={busy}><Import size={12} /> Import from this device</button>
          <button className="btn btn-sm btn-accent" onClick={authorizeFolder} disabled={!authorized || busy}>
            {busy ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />} Authorize folder
          </button>
        </div>
      </div>

      {!authorized ? (
        <div className="px-3 pt-2.5">
          <div className="rounded-lg p-2.5" style={{ background: "rgba(245,158,11,.09)", border: "1px solid rgba(245,158,11,.22)" }}>
            <div className="flex items-center gap-1.5 text-[10.5px] font-medium"><AlertTriangle size={12} style={{ color: "#f5b84a" }} /> Android storage is not connected in this host</div>
            <p className="mt-1 text-[9.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
              {state.available
                ? "The Android bridge is present, but it does not advertise Storage Access Framework support. No device files are shown because none can be read safely."
                : "This page is running in a normal browser without the KKDexNative Android bridge. Android SAF picks cannot be opened from a web page. Use “Import from this device” to read user-selected local files genuinely, or host this interface inside the KK DEX Android WebView to enable SAF."}
            </p>
            {state.error ? <div className="mt-1 font-mono text-[8.5px]" style={{ color: "#f3d18b" }}>{state.error}</div> : null}
            <button className="btn btn-sm mt-2" onClick={() => void nativeBridge.detect()}><RefreshCw size={11} /> Recheck bridge</button>
          </div>
        </div>
      ) : null}

      <div className="flex min-h-0 flex-1">
        <aside className="flex w-[190px] shrink-0 flex-col p-2" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
          <div className="px-1 pb-1 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Authorized folders</div>
          {folders.length === 0 ? (
            <div className="px-1 py-2 text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>No Android folders authorized yet.</div>
          ) : (
            folders.map((folder) => (
              <button key={folder.uri} className={cn("sidebar-item", activeFolder?.uri === folder.uri && "active")} onClick={() => void loadFolder(folder)} title={folder.uri}>
                <FolderOpen size={14} style={{ color: "#f0ae3c" }} />
                <span className="truncate">{folder.name}</span>
              </button>
            ))
          )}
          <button className="sidebar-item mt-1" onClick={authorizeFolder} disabled={!authorized || busy}><FolderPlus size={14} /> Add folder…</button>
          <button className="sidebar-item" onClick={importFromBrowser}><Import size={14} /> Import file…</button>
          <div className="mx-1 my-2 divider" />
          <div className="px-1 pb-1 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Capabilities</div>
          {capabilityRows.map((row) => (
            <div key={row.label} className="flex items-center gap-1.5 px-1.5 py-1 text-[8.5px]" style={{ color: row.on ? "var(--text)" : "var(--faint)" }}>
              <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: row.on ? "#34d399" : "var(--surface-4)" }} />
              <span className="truncate">{row.label}</span>
            </div>
          ))}
          <button className="mt-auto flex items-center gap-1 rounded px-1.5 py-1 text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => showInfo("Why SAF needs Android", "Modern Android does not allow a WebView to read arbitrary filesystem paths. The desktop must ask the native Android layer to launch the SAF picker, retain the returned content:// grants, and proxy reads through ContentResolver. The included starter integration implements that contract.", <ShieldCheck size={24} />)}>
            <Info size={9} /> How device access works
          </button>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center gap-2 px-3 py-1.5" style={{ borderBottom: "1px solid var(--border)" }}>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[11px] font-medium">{activeFolder?.name ?? "Select an authorized folder"}</div>
              <div className="truncate font-mono text-[8px]" style={{ color: "var(--faint)" }}>{activeFolder?.uri ?? "content:// not granted"}</div>
            </div>
            <div className="relative flex items-center">
              <Search size={11} className="pointer-events-none absolute left-2" style={{ color: "var(--faint)" }} />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Filter files" className="field !h-7 !w-[140px] pl-6 !text-[10px]" />
            </div>
            <button className="icon-btn h-7 w-7" title="Refresh folder" disabled={!activeFolder || busy} onClick={() => activeFolder && void loadFolder(activeFolder)}><RefreshCw size={12} /></button>
            <button className="icon-btn h-7 w-7" title="New folder on Android" disabled={!activeFolder || busy} onClick={newNativeFolder}><FolderPlus size={13} /></button>
          </div>
          {error ? (
            <div className="mx-3 mt-2 flex items-start gap-1.5 rounded-lg px-2.5 py-2 text-[9px] leading-relaxed" style={{ background: "rgba(239,68,68,.1)", border: "1px solid rgba(239,68,68,.22)", color: "var(--text)" }}>
              <AlertTriangle size={11} className="mt-0.5 shrink-0" /> {error}
              <button className="ml-auto shrink-0" aria-label="Dismiss error" onClick={() => setError("")}><X size={10} /></button>
            </div>
          ) : null}
          <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-2">
            {!activeFolder ? (
              <EmptyState icon={<Smartphone size={22} />} title="No device folder selected" description="Authorize a folder to read its actual contents through Android SAF. KK DEX never guesses device files." />
            ) : busy ? (
              <div className="flex h-full items-center justify-center gap-2 text-[10px]" style={{ color: "var(--muted)" }}><Loader2 size={14} className="animate-spin" /> Reading Android storage…</div>
            ) : filtered.length === 0 ? (
              <EmptyState icon={<FolderOpen size={22} />} title={query ? "No matching files" : "This folder is empty"} description={query ? "Clear the filter to see all returned entries." : "Android SAF returned no readable children for this folder."} />
            ) : (
              <div className="grid gap-1">
                {filtered.map((file) => (
                  <div key={file.uri} className="group flex items-center gap-2 rounded-lg px-2 py-1.5 row-hover" style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }}>
                    <button className="flex min-w-0 flex-1 items-center gap-2 text-left" onDoubleClick={() => void openNative(file)} onClick={() => void openNative(file)}>
                      <NativeGlyph kind={file.kind} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[10.5px] font-medium">{file.name}</span>
                        <span className="block truncate text-[8.5px]" style={{ color: "var(--muted)" }}>{nativeKindLabel(file.kind)} · {file.size ? `${(file.size / 1024).toFixed(file.size < 10240 ? 1 : 0)} KB` : "—"} · {file.mime || "unknown type"}</span>
                      </span>
                    </button>
                    <button className="btn btn-sm !h-6 !px-2" title="Copy into KK DEX workspace" onClick={() => void importNative(file)} disabled={busy}><Download size={10} /> Import</button>
                    <button className="icon-btn h-6 w-6" title="Open with another Android app" onClick={() => nativeBridge.openWith(file.uri, file.mime).then((ok) => { if (!ok) notify("No Android viewer accepted this file", file.name, { tone: "error" }); }).catch((err) => setError(err.message))}><ExternalLink size={11} /></button>
                    <button className="icon-btn h-6 w-6" title="Rename" onClick={() => renameNative(file)}><Pencil size={11} /></button>
                    <button className="icon-btn h-6 w-6" title="Delete from Android" onClick={() => deleteNative(file)}><Trash2 size={11} /></button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="flex h-6 items-center justify-between px-3 text-[8.5px]" style={{ borderTop: "1px solid var(--border)", background: "var(--surface-2)", color: "var(--faint)" }}>
            <span>{activeFolder ? `${files.length} native entries` : "No SAF grant active"}</span>
            <span className="flex items-center gap-1"><ShieldCheck size={9} /> Access limited to folders you authorize</span>
          </div>
        </div>
      </div>

      {preview ? (
        <div className="absolute inset-0 z-30 flex flex-col" style={{ background: "var(--surface-solid)" }}>
          <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
            <NativeGlyph kind={preview.file.kind} />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[11.5px] font-medium">{preview.file.name}</div>
              <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{nativeKindLabel(preview.file.kind)} · {preview.file.mime}</div>
            </div>
            <button className="icon-btn h-7 w-7" aria-label="Close preview" onClick={() => setPreview(null)}><X size={13} /></button>
          </div>
          <pre className="scroll-thin min-h-0 flex-1 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-relaxed" style={{ background: "var(--surface-2)" }}>{preview.content}</pre>
          <div className="flex items-center gap-2 border-t px-3 py-2" style={{ borderColor: "var(--border)" }}>
            <button className="btn btn-sm" onClick={() => void importNative(preview.file)}><Download size={11} /> Copy to Downloads</button>
            <button className="btn btn-sm ml-auto" onClick={() => setPreview(null)}>Close</button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

export { useNativeState };
