import type { ComponentType, ReactNode } from "react";

export type AppId =
  | "thispc"
  | "files"
  | "browser"
  | "ai"
  | "appcenter"
  | "settings"
  | "gallery"
  | "notes"
  | "calculator"
  | "terminal"
  | "recycle"
  | "phone"
  | "downloads"
  | "media"
  | "pdf"
  | "archive"
  | "developer";

export type AppCategory = "System" | "Productivity" | "Media" | "Utilities" | "AI";

export interface AppMeta {
  id: AppId;
  name: string;
  category: AppCategory;
  description: string;
  defaultSize: [number, number];
  minSize: [number, number];
  pinned: boolean;
  desktop: boolean;
  keywords?: string[];
}

export interface AppContentProps {
  windowId: string;
  payload?: Record<string, unknown>;
}

export interface RegisteredApp extends AppMeta {
  Component: ComponentType<AppContentProps>;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface WindowState extends Rect {
  id: string;
  appId: AppId;
  z: number;
  minimized: boolean;
  maximized: boolean;
  prev?: Rect;
  payload?: Record<string, unknown>;
  createdAt: number;
}

export type FileKind =
  | "folder"
  | "image"
  | "document"
  | "audio"
  | "video"
  | "archive"
  | "code"
  | "file";

export interface FsNode {
  id: string;
  name: string;
  kind: FileKind;
  parentId: string | null;
  size: number;
  modified: number;
  content?: string;
  src?: string;
  starred?: boolean;
  locked?: boolean;
}

export interface TrashItem {
  id: string;
  rootId: string;
  name: string;
  kind: FileKind;
  originalParentId: string;
  deletedAt: number;
  nodes: FsNode[];
  size: number;
}

export interface ExportedFile {
  id: string;
  name: string;
  kind: FileKind;
  size: number;
  src?: string;
  content?: string;
  createdAt: number;
  origin: string;
}

export interface Note {
  id: string;
  title: string;
  body: string;
  modified: number;
  pinned: boolean;
  color: string;
}

export interface Notification {
  id: string;
  title: string;
  body: string;
  time: number;
  appId?: AppId;
  read: boolean;
}

export type WallpaperId = "aurora" | "dunes" | "graphite" | "ocean" | "ember";
export type ThemeMode = "dark" | "light";
export type AccentId = "blue" | "violet" | "emerald" | "amber" | "rose";

export interface Settings {
  wallpaper: WallpaperId;
  theme: ThemeMode;
  accent: AccentId;
  sound: boolean;
  volume: number;
  muted: boolean;
  doNotDisturb: boolean;
  nightLight: boolean;
  brightness: number;
  iconSize: "small" | "medium" | "large";
  reduceMotion: boolean;
  pointerSpeed: number;
  pointerSize: number;
  clickEffects: boolean;
  taskbarPins: AppId[];
  wallpapers: number;
}

export interface MenuItemConfig {
  id?: string;
  label?: string;
  icon?: ReactNode;
  shortcut?: string;
  danger?: boolean;
  disabled?: boolean;
  checked?: boolean;
  separator?: boolean;
  children?: MenuItemConfig[];
  action?: () => void;
}

export interface MenuState {
  x: number;
  y: number;
  items: MenuItemConfig[];
  title?: string;
  width?: number;
  minX?: number;
}

export interface DialogState {
  kind: "prompt" | "confirm" | "info";
  title: string;
  message?: string;
  label?: string;
  value?: string;
  placeholder?: string;
  confirmLabel?: string;
  danger?: boolean;
  icon?: ReactNode;
  onConfirm?: (value: string) => void;
}

export interface Toast {
  id: string;
  title: string;
  message?: string;
  appId?: AppId;
  tone?: "default" | "success" | "error";
}

export interface SystemPanelState {
  kind: "notifications" | "quick" | "calendar" | "volume" | "network" | "battery";
}

export type OpenOptions = {
  payload?: Record<string, unknown>;
  newInstance?: boolean;
  minimized?: boolean;
};
