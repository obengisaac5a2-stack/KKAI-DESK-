/**
 * KK DEX native bridge adapter.
 *
 * Android hosts may expose `window.KKDexNative`. Methods may return a JSON string
 * synchronously or signal completion through `window.KKDexNativeResult(requestId,
 * payloadJson)`. The adapter supports both shapes. It never fabricates a successful
 * response: unavailable capabilities are surfaced to the UI.
 */

export type NativeMethod =
  | "getCapabilities"
  | "requestStoragePermission"
  | "pickFiles"
  | "pickFolder"
  | "listDirectory"
  | "readFile"
  | "writeFile"
  | "createFolder"
  | "renameFile"
  | "deleteFile"
  | "copyFile"
  | "moveFile"
  | "getInstalledApps"
  | "launchAndroidApp"
  | "openWith"
  | "getDownloads"
  | "getDisplayInfo"
  | "exec";

export interface NativeCapabilities {
  bridge: string;
  platform: string;
  sdkInt: number;
  storageAccessFramework: boolean;
  mediaStore: boolean;
  installedApps: boolean;
  appLaunch: boolean;
  externalDisplay: boolean;
  shellExecution: boolean;
  python: boolean;
  node: boolean;
  git: boolean;
  downloads: boolean;
  writeAccess: boolean;
}

export interface NativeFile {
  uri: string;
  name: string;
  mime: string;
  size: number;
  modified: number;
  isDirectory: boolean;
  kind: "folder" | "image" | "video" | "audio" | "document" | "pdf" | "archive" | "apk" | "file";
  source?: string;
}

export interface NativeApp {
  packageName: string;
  label: string;
  icon?: string;
  category?: string;
}

export interface NativeListing {
  uri: string;
  name: string;
  files: NativeFile[];
}

type HostApi = Record<string, unknown>;

const CAPABILITY_DEFAULTS: NativeCapabilities = {
  bridge: "browser",
  platform: "Web",
  sdkInt: 0,
  storageAccessFramework: false,
  mediaStore: false,
  installedApps: false,
  appLaunch: false,
  externalDisplay: false,
  shellExecution: false,
  python: false,
  node: false,
  git: false,
  downloads: false,
  writeAccess: false,
};

const CALLBACK_TIMEOUT = 45_000;

function parse<T>(raw: unknown): T {
  if (typeof raw === "string") {
    const text = raw.trim();
    if (!text) throw new Error("Native service returned an empty response.");
    return JSON.parse(text) as T;
  }
  if (raw && typeof raw === "object") return raw as T;
  throw new Error("Native service returned an unsupported response.");
}

function kindForMime(mime: string, name: string): NativeFile["kind"] {
  const value = (mime || "").toLowerCase();
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (value === "application/pdf" || ext === "pdf") return "pdf";
  if (value.startsWith("image/")) return "image";
  if (value.startsWith("video/")) return "video";
  if (value.startsWith("audio/")) return "audio";
  if (value.startsWith("text/") || ["md", "txt", "json", "js", "ts", "css", "html", "xml", "csv"].includes(ext)) return "document";
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return "archive";
  if (ext === "apk") return "apk";
  return "file";
}

export function normalizeNativeFile(input: Partial<NativeFile> & { isDirectory?: boolean }): NativeFile {
  const name = String(input.name ?? "Unnamed");
  const uri = String(input.uri ?? "");
  const mime = String(input.mime ?? "");
  const isDirectory = Boolean(input.isDirectory) || mime === "vnd.android.document/directory";
  const kind = isDirectory ? "folder" : input.kind ?? kindForMime(mime, name);
  return {
    uri,
    name,
    mime,
    size: Number(input.size ?? 0),
    modified: Number(input.modified ?? Date.now()),
    isDirectory,
    kind,
    source: input.source,
  };
}

class NativeBridge {
  private listeners = new Set<(state: NativeBridgeState) => void>();
  private state: NativeBridgeState = {
    available: false,
    ready: false,
    checking: true,
    capabilities: CAPABILITY_DEFAULTS,
    error: null,
  };
  private pending = new Map<string, { resolve: (value: unknown) => void; reject: (error: Error) => void; timer: number }>();
  private host: HostApi | null = null;
  private requestCounter = 0;

  constructor() {
    if (typeof window !== "undefined") {
      this.installCallbackReceiver();
      void this.detect();
    }
  }

  private installCallbackReceiver() {
    (window as unknown as Record<string, unknown>).KKDexNativeResult = (requestId: string, payload: unknown) => {
      const pending = this.pending.get(requestId);
      if (!pending) return;
      window.clearTimeout(pending.timer);
      this.pending.delete(requestId);
      try {
        const parsed = parse<{ ok?: boolean; error?: string }>(payload);
        if (parsed && parsed.ok === false) pending.reject(new Error(parsed.error || "Native request failed."));
        else pending.resolve(parsed);
      } catch (error) {
        pending.reject(error instanceof Error ? error : new Error("Invalid native callback payload."));
      }
    };
  }

  private setState(patch: Partial<NativeBridgeState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((listener) => listener(this.state));
  }

  subscribe(listener: (state: NativeBridgeState) => void) {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  getState() {
    return this.state;
  }

  private findHost(): HostApi | null {
    if (typeof window === "undefined") return null;
     const candidates = [
      (window as unknown as Record<string, unknown>).KKDexNative,
      (window as unknown as Record<string, unknown>).KKDexHost,
      (window as unknown as Record<string, unknown>).AndroidNative,
    ];
    return (candidates.find((candidate) => candidate && typeof candidate === "object") as HostApi | undefined) ?? null;
  }

  async detect(): Promise<NativeBridgeState> {
    const host = this.findHost();
    this.host = host;
    if (!host) {
      this.setState({ available: false, ready: true, checking: false, capabilities: CAPABILITY_DEFAULTS, error: null });
      return this.state;
    }
    this.setState({ available: true, checking: true, error: null });
    try {
      const raw = await this.invoke("getCapabilities", [], { timeout: 4000 });
      const capabilities = { ...CAPABILITY_DEFAULTS, ...(raw as Partial<NativeCapabilities>), bridge: "KKDexNative" };
      this.setState({ ready: true, checking: false, capabilities });
    } catch (error) {
      this.setState({
        ready: true,
        checking: false,
        capabilities: { ...CAPABILITY_DEFAULTS, bridge: "KKDexNative" },
        error: error instanceof Error ? error.message : "Unable to query the native bridge.",
      });
    }
    return this.state;
  }

  private async invoke(method: NativeMethod, args: unknown[], options: { timeout?: number } = {}): Promise<unknown> {
    const host = this.host ?? this.findHost();
    this.host = host;
    if (!host) throw new Error("No Android native bridge is available. The desktop is running in a standalone browser.");
    const fn = host[method];
    if (typeof fn !== "function") throw new Error(`The Android host does not implement ${method}().`);
    const requestId = `kk-${Date.now()}-${++this.requestCounter}`;
    const timeout = options.timeout ?? CALLBACK_TIMEOUT;
    return new Promise((resolve, reject) => {
      const timer = window.setTimeout(() => {
        this.pending.delete(requestId);
        reject(new Error(`${method}() did not respond. The native handler may have crashed or the picker is still open.`));
      }, timeout);
      this.pending.set(requestId, { resolve, reject, timer });
      try {
        const result = (fn as (...input: unknown[]) => unknown).call(host, ...args, requestId);
        if (typeof result === "boolean" || typeof result === "number") {
          window.clearTimeout(timer);
          this.pending.delete(requestId);
          if (result === false || result === 0) reject(new Error(`${method}() returned an unsuccessful result.`));
          else resolve({ ok: true, value: result });
          return;
        }
        if (result !== undefined && result !== null && result !== "") {
          window.clearTimeout(timer);
          this.pending.delete(requestId);
          try {
            const parsed = parse<{ ok?: boolean; error?: string }>(result);
            if (parsed && parsed.ok === false) reject(new Error(parsed.error || "Native request failed."));
            else resolve(parsed);
          } catch (error) {
            reject(error instanceof Error ? error : new Error("Unable to parse native response."));
          }
        }
      } catch (error) {
        window.clearTimeout(timer);
        this.pending.delete(requestId);
        reject(error instanceof Error ? error : new Error("Native invocation failed."));
      }
    });
  }

  async requestStoragePermission(types: ("images" | "video" | "audio" | "documents")[] = ["images", "video", "audio", "documents"]) {
    const result = (await this.invoke("requestStoragePermission", [JSON.stringify({ types })])) as { granted?: string[]; denied?: string[] };
    await this.detect();
    return result;
  }

  async pickFiles(mime = "*/*", multiple = true): Promise<NativeFile[]> {
    const result = (await this.invoke("pickFiles", [mime, multiple])) as { files?: Partial<NativeFile>[] };
    return (result.files ?? []).map(normalizeNativeFile);
  }

  async pickFolder(): Promise<{ uri: string; name: string } | null> {
    const result = (await this.invoke("pickFolder", [])) as { uri?: string; name?: string; cancelled?: boolean };
    if (!result?.uri) return null;
    return { uri: result.uri, name: result.name ?? "Authorized folder" };
  }

  async listDirectory(uri: string): Promise<NativeListing> {
    const result = (await this.invoke("listDirectory", [uri])) as { uri?: string; name?: string; files?: Partial<NativeFile>[] };
    return {
      uri: result.uri ?? uri,
      name: result.name ?? "Device storage",
      files: (result.files ?? []).map(normalizeNativeFile),
    };
  }

  async readFile(uri: string): Promise<{ content: string; encoding: "text" | "base64" }> {
    return (await this.invoke("readFile", [uri])) as { content: string; encoding: "text" | "base64" };
  }

  /** Reads a content URI into a data URL suitable for images, audio, video and PDFs. */
  async readDataUrl(uri: string, mime = "application/octet-stream"): Promise<string> {
    const result = await this.readFile(uri);
    if (/^data:/i.test(result.content)) return result.content;
    if (result.encoding === "base64") return `data:${mime};base64,${result.content}`;
    return `data:${mime};charset=utf-8,${encodeURIComponent(result.content)}`;
  }

  async writeFile(uri: string, content: string, encoding: "text" | "base64" = "text"): Promise<boolean> {
    const result = (await this.invoke("writeFile", [uri, content, encoding])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async createFolder(parentUri: string, name: string): Promise<NativeFile | null> {
    const result = (await this.invoke("createFolder", [parentUri, name])) as { file?: Partial<NativeFile> };
    return result?.file ? normalizeNativeFile(result.file) : null;
  }

  async renameFile(uri: string, name: string): Promise<boolean> {
    const result = (await this.invoke("renameFile", [uri, name])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async deleteFile(uri: string): Promise<boolean> {
    const result = (await this.invoke("deleteFile", [uri])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async getInstalledApps(): Promise<NativeApp[]> {
    const result = (await this.invoke("getInstalledApps", [])) as { apps?: NativeApp[] };
    return result.apps ?? [];
  }

  async launchAndroidApp(packageName: string): Promise<{ launched: boolean; display?: "phone" | "external"; message?: string }> {
    return (await this.invoke("launchAndroidApp", [packageName])) as { launched: boolean; display?: "phone" | "external"; message?: string };
  }

  async openWith(uri: string, mime: string): Promise<boolean> {
    const result = (await this.invoke("openWith", [uri, mime])) as { opened?: boolean; message?: string };
    if (result?.message && result.opened === false) throw new Error(result.message);
    return Boolean(result?.opened);
  }

  async getDownloads(): Promise<NativeFile[]> {
    const result = (await this.invoke("getDownloads", [])) as { files?: Partial<NativeFile>[] };
    return (result.files ?? []).map(normalizeNativeFile);
  }

  async getDisplayInfo(): Promise<Record<string, unknown>> {
    return (await this.invoke("getDisplayInfo", [])) as Record<string, unknown>;
  }

  async exec(command: string, runtime: "shell" | "python" | "node" | "git"): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    const result = (await this.invoke("exec", [command, runtime])) as { stdout?: string; stderr?: string; exitCode?: number };
    return { stdout: result.stdout ?? "", stderr: result.stderr ?? "", exitCode: result.exitCode ?? 0 };
  }
}

export interface NativeBridgeState {
  available: boolean;
  ready: boolean;
  checking: boolean;
  capabilities: NativeCapabilities;
  error: string | null;
}

export const nativeBridge = new NativeBridge();

export function nativeKindLabel(kind: NativeFile["kind"]): string {
  return {
    folder: "Folder",
    image: "Image",
    video: "Video",
    audio: "Audio",
    document: "Document",
    pdf: "PDF document",
    archive: "Archive",
    apk: "Android package",
    file: "File",
  }[kind];
}

export function browserImport(accept = "*/*", multiple = true): Promise<File[]> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = accept;
    input.multiple = multiple;
    input.style.display = "none";
    document.body.appendChild(input);
    let settled = false;
    const finish = (files: File[]) => {
      if (settled) return;
      settled = true;
      input.remove();
      resolve(files);
    };
    input.onchange = () => finish(Array.from(input.files ?? []));
    input.oncancel = () => finish([]);
    window.addEventListener(
      "focus",
      () => {
        window.setTimeout(() => finish(Array.from(input.files ?? [])), 350);
      },
      { once: true },
    );
    input.click();
  });
}

export function readBrowserFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

export function readBrowserFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsText(file);
  });
}
