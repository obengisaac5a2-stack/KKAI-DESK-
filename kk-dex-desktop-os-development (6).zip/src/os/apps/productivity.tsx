import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownUp,
  Check,
  Copy,
  Delete,
  Pin,
  Plus,
  StickyNote,
  Trash2,
} from "lucide-react";
import { APP_METAS } from "../appMeta";
import { nativeBridge } from "../native";
import { useNativeState } from "../NativeStorage";
import { formatBytes, useOS, WALLPAPERS } from "../OSContext";
import type { AppContentProps, AppId, FsNode, Note } from "../types";
import { EmptyState, SearchBox } from "../ui";
import { cn } from "@/utils/cn";

/* ---------------------------------- Notes --------------------------------- */

const NOTE_COLORS = ["#5b9dff", "#34d399", "#f7c45c", "#f0729b", "#a78bfa"];

export function NotesApp({ payload }: AppContentProps) {
  const { notes, addNote, updateNote, deleteNote, showConfirm, notify, launch } = useOS();
  const ordered = useMemo(
    () => [...notes].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.modified - a.modified),
    [notes],
  );
  const requested = typeof payload?.noteId === "string" ? payload.noteId : null;
  const [selectedId, setSelectedId] = useState<string | null>(
    requested && notes.some((n) => n.id === requested) ? requested : ordered[0]?.id ?? null,
  );
  const [draft, setDraft] = useState<{ title: string; body: string }>({ title: "", body: "" });
  const [dirty, setDirty] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const loadedRef = useRef<string | null>(null);

  const selected = notes.find((note) => note.id === selectedId) ?? null;
  const filtered = ordered.filter(
    (note) =>
      !query.trim() ||
      note.title.toLowerCase().includes(query.toLowerCase()) ||
      note.body.toLowerCase().includes(query.toLowerCase()),
  );

  useEffect(() => {
    if (requested && notes.some((n) => n.id === requested)) setSelectedId(requested);
    // Only follow explicit external navigation.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requested]);

  useEffect(() => {
    const note = notes.find((n) => n.id === selectedId);
    if (!note || loadedRef.current === selectedId) return;
    loadedRef.current = selectedId;
    setDraft({ title: note.title, body: note.body });
    setDirty(false);
    setSavedAt(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  useEffect(() => {
    if (!selected) return;
    const changed = draft.title !== selected.title || draft.body !== selected.body;
    if (!changed) return;
    setDirty(true);
    const timer = window.setTimeout(() => {
      updateNote(selected.id, { title: draft.title || "Untitled note", body: draft.body });
      setDirty(false);
      setSavedAt(Date.now());
    }, 700);
    return () => window.clearTimeout(timer);
  }, [draft, selected, updateNote]);

  const saveNow = () => {
    if (!selected) return;
    updateNote(selected.id, { title: draft.title || "Untitled note", body: draft.body });
    setDirty(false);
    setSavedAt(Date.now());
    notify("Note saved", `“${draft.title || "Untitled note"}” is up to date.`, { tone: "success", silent: true });
  };

  const createNote = () => {
    const id = addNote();
    loadedRef.current = null;
    setSelectedId(id);
    setDraft({ title: "Untitled note", body: "" });
  };

  const selectNote = (note: Note) => {
    loadedRef.current = null;
    setSelectedId(note.id);
  };

  return (
    <div className="flex h-full min-h-0" style={{ background: "var(--surface-solid)" }}>
      <aside className="flex w-[214px] shrink-0 flex-col" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <div className="flex items-center justify-between px-3 pt-3 pb-2">
          <div>
            <div className="text-[13px] font-semibold">Notes</div>
            <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>{notes.length} in workspace</div>
          </div>
          <button className="btn btn-sm btn-accent !h-7 !px-2" onClick={createNote}>
            <Plus size={12} /> New
          </button>
        </div>
        <div className="px-2.5 pb-2">
          <SearchBox value={query} onChange={setQuery} placeholder="Search notes" />
        </div>
        <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-1.5 pb-2">
          {filtered.length === 0 ? (
            <div className="px-3 py-8 text-center text-[10.5px]" style={{ color: "var(--faint)" }}>
              No notes match “{query}”.
            </div>
          ) : (
            filtered.map((note) => (
              <button
                key={note.id}
                onClick={() => selectNote(note)}
                className={cn("mb-0.5 flex w-full gap-2 rounded-lg px-2 py-2 text-left transition-colors", selectedId === note.id ? "row-selected" : "row-hover")}
              >
                <span className="mt-0.5 h-6 w-1 shrink-0 rounded-full" style={{ background: note.color }} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1">
                    <span className="truncate text-[11.5px] font-medium">{note.title || "Untitled"}</span>
                    {note.pinned ? <Pin size={9} className="shrink-0" style={{ color: "var(--accent)" }} /> : null}
                  </span>
                  <span className="mt-0.5 line-clamp-2 block text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>
                    {note.body || "Empty note"}
                  </span>
                  <span className="mt-1 block text-[8.5px]" style={{ color: "var(--faint)" }}>
                    {new Date(note.modified).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  </span>
                </span>
              </button>
            ))
          )}
        </div>
        <button className="mx-2 mb-2 flex items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-[10px]" style={{ color: "var(--muted)" }} onClick={() => launch("files", { payload: { folderId: "documents" } })}>
          <ArrowDownUp size={11} /> Notes save to this workspace
        </button>
      </aside>

      {selected ? (
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center gap-1.5 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
            <div className="flex items-center gap-1">
              {NOTE_COLORS.map((color) => (
                <button
                  key={color}
                  aria-label={`Set note color ${color}`}
                  className="h-3.5 w-3.5 rounded-full transition-transform hover:scale-125"
                  style={{ background: color, outline: selected.color === color ? "2px solid var(--text)" : "none", outlineOffset: 2 }}
                  onClick={() => updateNote(selected.id, { color })}
                />
              ))}
            </div>
            <div className="ml-auto flex items-center gap-1">
              <span className="mr-1 text-[9.5px]" style={{ color: "var(--faint)" }}>
                {dirty ? "Saving…" : savedAt ? <span className="inline-flex items-center gap-1"><Check size={10} /> Auto-saved</span> : "Saved"}
              </span>
              <button
                className="icon-btn h-7 w-7"
                title={selected.pinned ? "Unpin note" : "Pin note"}
                onClick={() => updateNote(selected.id, { pinned: !selected.pinned })}
              >
                <Pin size={13} style={{ color: selected.pinned ? "var(--accent)" : undefined }} />
              </button>
              <button className="btn btn-sm" onClick={saveNow} disabled={!dirty}>
                <Check size={12} /> Save
              </button>
              <button
                className="icon-btn h-7 w-7"
                title="Delete note"
                onClick={() =>
                  showConfirm(
                    "Delete this note?",
                    `“${selected.title || "Untitled note"}” will be permanently removed from Notes.`,
                    () => {
                      deleteNote(selected.id);
                      loadedRef.current = null;
                      const next = notes.find((n) => n.id !== selected.id);
                      setSelectedId(next?.id ?? null);
                    },
                    "Delete note",
                  )
                }
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
          <div className="flex min-h-0 flex-1 flex-col px-5 pt-3 pb-2">
            <input
              value={draft.title}
              onChange={(event) => setDraft((prev) => ({ ...prev, title: event.target.value }))}
              placeholder="Note title"
              className="w-full shrink-0 border-0 bg-transparent px-0 pb-2 text-[19px] font-semibold outline-none placeholder:text-[var(--faint)]"
              onKeyDown={(event) => {
                if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
                  event.preventDefault();
                  saveNow();
                }
              }}
            />
            <div className="mb-2 flex items-center gap-2 text-[9.5px]" style={{ color: "var(--faint)" }}>
              <StickyNote size={10} />
              {new Date(selected.modified).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
              <span>·</span>
              {draft.body.trim().split(/\s+/).filter(Boolean).length} words
            </div>
            <textarea
              value={draft.body}
              onChange={(event) => setDraft((prev) => ({ ...prev, body: event.target.value }))}
              placeholder="Start writing…"
              className="scroll-thin min-h-0 w-full flex-1 resize-none border-0 bg-transparent px-0 text-[12.5px] leading-[1.7] outline-none placeholder:text-[var(--faint)]"
              style={{ userSelect: "text" }}
              onKeyDown={(event) => {
                if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
                  event.preventDefault();
                  saveNow();
                }
              }}
            />
          </div>
          <div className="flex h-6 items-center justify-between px-3 text-[9px]" style={{ borderTop: "1px solid var(--border)", color: "var(--faint)", background: "var(--surface-2)" }}>
            <span>Plain text · Saved locally in KK DEX</span>
            <span>{dirty ? "Unsaved changes" : "All changes saved"}</span>
          </div>
        </div>
      ) : (
        <div className="flex-1">
          <EmptyState
            icon={<StickyNote size={22} />}
            title="No note selected"
            description="Choose a note from the list or create a fresh one to get started."
            action={<button className="btn btn-accent btn-sm" onClick={createNote}><Plus size={12} /> New note</button>}
          />
        </div>
      )}
    </div>
  );
}

/* -------------------------------- Calculator ------------------------------- */

function evaluateExpression(input: string): number {
  const cleaned = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/,/g, "");
  const tokens = cleaned.match(/\d*\.?\d+|[()+\-*/%^]/g);
  if (!tokens) throw new Error("Empty expression");
  let index = 0;
  const peek = () => tokens[index];
  const next = () => tokens[index++];

  const parseExpression = (): number => {
    let value = parseTerm();
    while (peek() === "+" || peek() === "-") {
      const operator = next();
      const right = parseTerm();
      value = operator === "+" ? value + right : value - right;
    }
    return value;
  };
  const parseTerm = (): number => {
    let value = parseUnary();
    while (peek() === "*" || peek() === "/" || peek() === "%") {
      const operator = next();
      const right = parseUnary();
      if (operator === "/" && right === 0) throw new Error("Division by zero");
      value = operator === "*" ? value * right : operator === "/" ? value / right : value % right;
    }
    return value;
  };
  const parseUnary = (): number => {
    if (peek() === "-") {
      next();
      return -parseUnary();
    }
    if (peek() === "+") {
      next();
      return parseUnary();
    }
    return parsePower();
  };
  const parsePower = (): number => {
    const base = parsePrimary();
    if (peek() === "^") {
      next();
      return Math.pow(base, parseUnary());
    }
    return base;
  };
  const parsePrimary = (): number => {
    const token = next();
    if (token === undefined) throw new Error("Incomplete expression");
    if (token === "(") {
      const value = parseExpression();
      if (next() !== ")") throw new Error("Unclosed parenthesis");
      return value;
    }
    if (!/^\d*\.?\d+$/.test(token)) throw new Error("Unexpected token");
    return Number(token);
  };

  const result = parseExpression();
  if (index !== tokens.length) throw new Error("Unexpected input");
  if (!Number.isFinite(result)) throw new Error("Invalid result");
  return result;
}

function formatNumber(value: number): string {
  if (Math.abs(value) > 1e12 || (Math.abs(value) < 1e-8 && value !== 0)) return value.toExponential(6);
  const rounded = Math.round(value * 1e10) / 1e10;
  return String(rounded);
}

const CALC_KEYS = [
  { label: "AC", kind: "action", value: "clear" },
  { label: "⌫", kind: "action", value: "back", icon: Delete },
  { label: "%", kind: "operator", value: "%" },
  { label: "÷", kind: "operator", value: "/" },
  { label: "7", kind: "number", value: "7" },
  { label: "8", kind: "number", value: "8" },
  { label: "9", kind: "number", value: "9" },
  { label: "×", kind: "operator", value: "*" },
  { label: "4", kind: "number", value: "4" },
  { label: "5", kind: "number", value: "5" },
  { label: "6", kind: "number", value: "6" },
  { label: "−", kind: "operator", value: "-" },
  { label: "1", kind: "number", value: "1" },
  { label: "2", kind: "number", value: "2" },
  { label: "3", kind: "number", value: "3" },
  { label: "+", kind: "operator", value: "+" },
  { label: "+/−", kind: "action", value: "sign" },
  { label: "0", kind: "number", value: "0" },
  { label: ".", kind: "number", value: "." },
  { label: "=", kind: "equals", value: "equals" },
] as const;

export function CalculatorApp() {
  const { notify, soundClick } = useOS();
  const [expression, setExpression] = useState("");
  const [lastResult, setLastResult] = useState<string | null>(null);
  const [history, setHistory] = useState<{ expr: string; result: string }[]>([]);
  const [error, setError] = useState("");
  const rootRef = useRef<HTMLDivElement>(null);

  const preview = useMemo(() => {
    if (!expression.trim() || /[+\-*/^%]$/.test(expression.trim())) return "";
    try {
      return formatNumber(evaluateExpression(expression));
    } catch {
      return "";
    }
  }, [expression]);

  const calculate = () => {
    if (!expression.trim()) return;
    try {
      const result = formatNumber(evaluateExpression(expression));
      setHistory((prev) => [{ expr: expression, result }, ...prev].slice(0, 12));
      setLastResult(`${expression} = ${result}`);
      setExpression(result);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid expression");
      setLastResult(null);
    }
  };

  const press = (kind: string, value: string) => {
    soundClick();
    setError("");
    setLastResult(null);
    if (kind === "number") {
      setExpression((prev) => (prev === "0" ? value : prev + value));
      return;
    }
    if (kind === "operator") {
      setExpression((prev) => {
        if (!prev) return value === "-" ? "-" : prev;
        return /[+\-*/^%]$/.test(prev) ? prev.slice(0, -1) + value : prev + value;
      });
      return;
    }
    if (kind === "equals") {
      calculate();
      return;
    }
    if (value === "clear") {
      setExpression("");
      setLastResult(null);
      setError("");
    } else if (value === "back") {
      setExpression((prev) => prev.slice(0, -1));
    } else if (value === "sign") {
      setExpression((prev) => (prev.startsWith("-") ? prev.slice(1) : `-${prev}`));
    }
  };

  const copyResult = async () => {
    const value = preview || expression;
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      notify("Copied", `${value} copied to the clipboard.`, { tone: "success", silent: true });
    } catch {
      notify("Clipboard unavailable", "Clipboard access is not permitted in this browser context.", { tone: "error" });
    }
  };

  const onKeyDown = (event: React.KeyboardEvent) => {
    const allowed = /^[0-9+\-*/().%^]$/.test(event.key);
    if (allowed) {
      event.preventDefault();
      setExpression((prev) => prev + event.key);
      soundClick();
      return;
    }
    if (event.key === "Enter" || event.key === "=") {
      event.preventDefault();
      calculate();
    } else if (event.key === "Backspace") {
      event.preventDefault();
      setExpression((prev) => prev.slice(0, -1));
    } else if (event.key === "Escape") {
      event.preventDefault();
      setExpression("");
      setError("");
    }
  };

  return (
    <div ref={rootRef} tabIndex={0} className="flex h-full flex-col outline-none" style={{ background: "var(--surface-solid)" }} onKeyDown={onKeyDown}>
      <div className="flex items-center justify-between px-3 pt-2 pb-1">
        <span className="text-[11px] font-semibold">Standard</span>
        <button className="icon-btn h-6 w-6" aria-label="Copy result" title="Copy result" onClick={copyResult}>
          <Copy size={12} />
        </button>
      </div>
      <div className="px-3 pb-2">
        <div className="min-h-[82px] rounded-xl px-3 pt-2.5 pb-2" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
          <div className="flex items-center justify-between text-[9.5px]" style={{ color: "var(--faint)" }}>
            <span className="truncate">{lastResult ?? "Expression"}</span>
            {preview ? <span>= {preview}</span> : null}
          </div>
          <div className="scroll-thin mt-1 overflow-x-auto whitespace-nowrap py-0.5 text-right font-mono text-[30px] font-light leading-tight tracking-tight">
            {expression || "0"}
          </div>
          <div className="h-3 text-right text-[9.5px]" style={{ color: "var(--danger)" }}>{error}</div>
        </div>
      </div>
      <div className="grid flex-1 grid-cols-4 gap-1.5 px-3 pb-2" style={{ minHeight: 0 }}>
        {CALC_KEYS.map((key) => {
          const KeyIcon = "icon" in key ? key.icon : null;
          return (
            <button
              key={key.label}
              type="button"
              onClick={() => press(key.kind, key.value)}
              className="flex items-center justify-center rounded-lg text-[15px] font-medium transition-all active:scale-[0.96]"
              style={{
                background: key.kind === "equals" ? "var(--accent)" : key.kind === "operator" ? "var(--surface-3)" : "var(--field)",
                color: key.kind === "equals" ? "#fff" : "var(--text)",
                border: `1px solid ${key.kind === "equals" ? "transparent" : "var(--border)"}`,
                boxShadow: key.kind === "equals" ? "0 3px 12px -3px rgba(var(--accent-rgb),.7)" : "0 1px 2px rgba(0,0,0,.06)",
              }}
            >
              {KeyIcon ? <KeyIcon size={16} /> : key.label}
            </button>
          );
        })}
      </div>
      <div className="flex max-h-[112px] flex-col border-t px-3 py-2" style={{ borderColor: "var(--border)", background: "var(--surface-2)" }}>
        <div className="mb-1 flex items-center justify-between">
          <span className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>History</span>
          <button className="text-[9px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setHistory([])} disabled={!history.length}>
            Clear
          </button>
        </div>
        <div className="scroll-thin min-h-[16px] overflow-y-auto">
          {history.length === 0 ? (
            <div className="text-[9.5px]" style={{ color: "var(--faint)" }}>Results appear here.</div>
          ) : (
            history.map((item, index) => (
              <button
                key={`${item.expr}-${index}`}
                className="flex w-full items-center justify-between rounded px-1 py-0.5 text-[10px] row-hover"
                onClick={() => setExpression(item.result)}
              >
                <span className="truncate" style={{ color: "var(--muted)" }}>{item.expr}</span>
                <span className="ml-2 font-mono">= {item.result}</span>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- Terminal -------------------------------- */

type Line = { id: string; kind: "input" | "out" | "err" | "system"; text: string };
let terminalLineId = 0;
const termLine = (kind: Line["kind"], text: string): Line => ({ id: `line-${terminalLineId++}`, kind, text });

export function TerminalApp() {
  const {
    files,
    getNode,
    childrenOf,
    createFolder,
    deleteNode,
    launch,
    openPhoneController,
    settings,
    updateSettings,
    windows,
    notify,
    getPath,
  } = useOS();
  const native = useNativeState();
  const caps = native.capabilities;
  const [cwdId, setCwdId] = useState("home");
  const [input, setInput] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [lines, setLines] = useState<Line[]>(() => [
    termLine("system", "KK DEX shell 1.0 — workspace session"),
    termLine("system", "File and preference commands affect this KK DEX workspace. Native runtimes appear only when the Android bridge actually provides them."),
    termLine("out", "Type “help” for available commands, or “runtime” to inspect native execution support."),
  ]);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const cwd = getNode(cwdId) ?? getNode("home")!;
  const pathLabel = getPath(cwdId).slice(1).map((p) => p.name).join("/") || "~";
  const prompt = `kkdex@tv:${pathLabel === "~" ? "~" : `~/${pathLabel}`}$`;

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [lines]);

  const resolve = (arg: string): FsNode | null => {
    if (!arg || arg === ".") return cwd;
    let node: FsNode | null = arg.startsWith("~") || arg.startsWith("/") ? getNode("home")! : cwd;
    const parts = arg.replace(/^~\/?/, "").replace(/^\//, "").split("/").filter(Boolean);
    for (const part of parts) {
      if (part === "..") {
        node = node?.parentId ? getNode(node.parentId) ?? null : node;
      } else if (part !== ".") {
        node = node ? childrenOf(node.id).find((n) => n.name.toLowerCase() === part.toLowerCase()) ?? null : null;
      }
    }
    return node;
  };

  const run = (raw: string) => {
    const command = raw.trim();
    if (!command) return;
    setLines((prev) => [...prev, termLine("input", `${prompt} ${command}`)]);
    setHistory((prev) => [command, ...prev].slice(0, 50));
    setHistoryIndex(-1);
    const [name, ...args] = command.split(/\s+/);
    const arg = args.join(" ");
    const lower = name.toLowerCase();
    const output: Line[] = [];
    const out = (text: string) => output.push(termLine("out", text));
    const err = (text: string) => output.push(termLine("err", text));

    switch (lower) {
      case "help":
        out("Available commands:");
        out("  ls [path]            list workspace items");
        out("  cd <folder>          change directory (.., ~)");
        out("  pwd                  print working directory");
        out("  cat <file>           print a text file");
        out("  mkdir <name>         create a folder");
        out("  rm <name>            move an item to Recycle Bin");
        out("  open <app>           open a KK DEX application");
        out("  apps                 list installed applications");
        out("  theme <dark|light>   change the desktop theme");
        out("  wallpaper <id>       change the desktop wallpaper");
        out("  neofetch             show KK DEX session details");
        out("  controller           open the phone controller");
        out("  runtime              inspect Android native execution capabilities");
        out("  shell <command>      run a real native shell command, if provided");
        out("  python <code>        run Python on the native backend, if installed");
        out("  node <code>          run Node.js on the native backend, if installed");
        out("  git <args>           run Git on the native backend, if installed");
        out("  clear                clear this terminal");
        out("  date, whoami, echo   basic info");
        break;
      case "ls": {
        const target = arg ? resolve(arg) : cwd;
        if (!target) err(`ls: no such directory: ${arg}`);
        else if (target.kind !== "folder") out(target.name);
        else {
          const items = childrenOf(target.id);
          if (items.length === 0) out("(empty)");
          items.forEach((item) =>
            out(
              item.kind === "folder"
                ? `  ${item.name}/`
                : `  ${item.name}  ${formatBytes(item.size)}  ${new Date(item.modified).toLocaleDateString()}`,
            ),
          );
        }
        break;
      }
      case "cd": {
        if (!arg || arg === "~" || arg === "/") {
          setCwdId("home");
          break;
        }
        const target = resolve(arg);
        if (!target) err(`cd: no such directory: ${arg}`);
        else if (target.kind !== "folder") err(`cd: not a directory: ${arg}`);
        else setCwdId(target.id);
        break;
      }
      case "pwd":
        out(prompt.replace("$", "").split(":")[1]);
        break;
      case "cat": {
        const target = resolve(arg);
        if (!target) err(`cat: no such file: ${arg}`);
        else if (target.kind === "folder") err(`cat: ${target.name} is a directory`);
        else if (!target.content) err(`cat: ${target.name} has no readable text content in this workspace`);
        else out(target.content);
        break;
      }
      case "mkdir": {
        if (!arg) err("mkdir: missing folder name");
        else {
          createFolder(cwd.id, arg);
          out(`Created folder “${arg}” in ${pathLabel}.`);
        }
        break;
      }
      case "rm": {
        const target = resolve(arg);
        if (!target) err(`rm: no such item: ${arg}`);
        else if (target.id === "home") err("rm: home is protected");
        else {
          deleteNode(target.id);
          out(`Moved “${target.name}” to Recycle Bin.`);
        }
        break;
      }
      case "open": {
        const key = arg.toLowerCase();
        const appId = (Object.keys(APP_METAS) as AppId[]).find(
          (id) => id === key || APP_METAS[id].name.toLowerCase() === key || APP_METAS[id].name.toLowerCase().replace(/\s/g, "") === key,
        );
        if (!appId) err(`open: unknown application “${arg}”. Type “apps” to list installed apps.`);
        else {
          launch(appId);
          out(`Opened ${APP_METAS[appId].name}.`);
        }
        break;
      }
      case "apps":
        (Object.keys(APP_METAS) as AppId[]).forEach((id) =>
          out(`  ${id.padEnd(12)} ${APP_METAS[id].name}`),
        );
        break;
      case "theme":
        if (arg === "dark" || arg === "light") {
          updateSettings({ theme: arg });
          out(`Desktop theme set to ${arg}.`);
        } else err("usage: theme <dark|light>");
        break;
      case "wallpaper": {
        const found = WALLPAPERS.find((w) => w.id === arg.toLowerCase());
        if (found) {
          updateSettings({ wallpaper: found.id });
          out(`Wallpaper set to ${found.name}.`);
        } else err(`Available wallpapers: ${WALLPAPERS.map((w) => w.id).join(", ")}`);
        break;
      }
      case "neofetch":
        out("        KK        KK DEX OS 1.0 · Desktop Session");
        out("        KK        -------------------------------");
        out("   KKKKKKKKKK     Host      : External display / WebView");
        out("   KKKKKKKKKK     Shell     : kkdex-workspace 1.0 (sandboxed)");
        out(`                  Theme     : ${settings.theme} / ${settings.accent}`);
        out(`                  Windows   : ${windows.length} open`);
        out(`                  Workspace : ${files.filter((f) => f.kind !== "folder").length} files, ${files.filter((f) => f.kind === "folder").length} folders`);
        out(`                  Storage   : ${formatBytes(files.filter((f) => f.kind !== "folder").reduce((n, f) => n + f.size, 0))}`);
        out("                  Bridge    : KKDexAPI-compatible receiver");
        break;
      case "controller":
        openPhoneController();
        out("Opening phone controller in a separate window…");
        break;
      case "date":
        out(new Date().toString());
        break;
      case "whoami":
        out("operator (local KK DEX workspace session)");
        break;
      case "echo":
        out(arg);
        break;
      case "runtime":
        out(`Host: ${native.available ? `${caps.platform} (SDK ${caps.sdkInt})` : "standalone browser"}`);
        out(`Shell: ${caps.shellExecution ? "available" : "unavailable"}`);
        out(`Python: ${caps.python ? "available" : "not reported by host"}`);
        out(`Node.js: ${caps.node ? "available" : "not reported by host"}`);
        out(`Git: ${caps.git ? "available" : "not reported by host"}`);
        out("Native execution is never simulated. JavaScript is available through Developer.");
        break;
      case "shell":
      case "python":
      case "node":
      case "git": {
        const runtimeName = lower as "shell" | "python" | "node" | "git";
        const capability = runtimeName === "shell" ? caps.shellExecution : runtimeName === "python" ? caps.python : runtimeName === "node" ? caps.node : caps.git;
        if (!arg) {
          err(`${runtimeName}: no command or code supplied`);
          break;
        }
        if (!capability) {
          err(`${runtimeName}: the Android host does not report an authorized ${runtimeName} runtime. No simulated execution was attempted.`);
          break;
        }
        setLines((prev) => [...prev, termLine("system", `Executing ${runtimeName} through the native bridge…`)]);
        void nativeBridge
          .exec(arg, runtimeName)
          .then((result) => {
            const responseLines = [...result.stdout.split("\n"), ...result.stderr.split("\n")].filter(Boolean);
            setLines((prev) => [
              ...prev,
              ...responseLines.map((line) => termLine(result.exitCode === 0 ? "out" : "err", line)),
              termLine("system", `Process exited with code ${result.exitCode}.`),
            ]);
          })
          .catch((error: unknown) => {
            setLines((prev) => [...prev, termLine("err", error instanceof Error ? error.message : "Native execution failed.")]);
          });
        break;
      }
      case "clear":
        setLines([]);
        return;
      case "sudo":
      case "shutdown":
      case "reboot":
      case "chmod":
      case "apt":
        err(`${name}: host-level commands are not supported by the KK DEX web sandbox.`);
        break;
      default:
        err(`${name}: command not found. Type “help” for supported workspace commands.`);
    }
    setLines((prev) => [...prev, ...output]);
  };

  return (
    <div
      className="flex h-full min-h-0 flex-col"
      style={{ background: "#0a0f17", color: "#d6e2f1" }}
      onClick={() => inputRef.current?.focus()}
    >
      <div className="flex h-7 shrink-0 items-center gap-2 px-3" style={{ background: "#121a26", borderBottom: "1px solid #223044" }}>
        <div className="h-2 w-2 rounded-full" style={{ background: "#34d399" }} />
        <span className="font-mono text-[9.5px]" style={{ color: "#8296ae" }}>workspace — kkdex shell</span>
        <span className="ml-auto rounded-sm px-1.5 py-0.5 font-mono text-[8.5px]" style={{ background: "#1e2a3b", color: "#7f92aa" }}>SANDBOX</span>
      </div>
      <div className="scroll-thin min-h-0 flex-1 select-text overflow-y-auto px-3 py-2 font-mono text-[11px] leading-[1.55]">
        {lines.map((line) => (
          <pre
            key={line.id}
            className="m-0 whitespace-pre-wrap break-words"
            style={{ color: line.kind === "err" ? "#fb8a8a" : line.kind === "system" ? "#7f9fc0" : line.kind === "input" ? "#9ed0ff" : "#d6e2f1" }}
          >
            {line.text}
          </pre>
        ))}
        <div className="flex items-start gap-1.5">
          <span className="shrink-0" style={{ color: "#62d9a8" }}>{prompt}</span>
          <input
            ref={inputRef}
            value={input}
            autoFocus
            spellCheck={false}
            autoCapitalize="none"
            autoComplete="off"
            className="min-w-0 flex-1 border-0 bg-transparent p-0 font-mono text-[11px] outline-none"
            style={{ color: "#eaf2fc" }}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                run(input);
                setInput("");
              } else if (event.key === "ArrowUp") {
                event.preventDefault();
                const nextIndex = Math.min(historyIndex + 1, history.length - 1);
                if (history[nextIndex]) {
                  setHistoryIndex(nextIndex);
                  setInput(history[nextIndex]);
                }
              } else if (event.key === "ArrowDown") {
                event.preventDefault();
                const nextIndex = Math.max(historyIndex - 1, -1);
                setHistoryIndex(nextIndex);
                setInput(nextIndex === -1 ? "" : history[nextIndex] ?? "");
              } else if (event.key === "l" && event.ctrlKey) {
                event.preventDefault();
                setLines([]);
              }
            }}
          />
        </div>
        <div ref={endRef} />
      </div>
      <div className="flex h-6 shrink-0 items-center gap-3 px-3 font-mono text-[8.5px]" style={{ background: "#121a26", borderTop: "1px solid #223044", color: "#71849d" }}>
        <span>workspace shell · not host shell</span>
        <span className="ml-auto">↑↓ history · Ctrl+L clear</span>
        <button onClick={() => notify("Terminal sandbox", "Commands only affect the KK DEX workspace. Host filesystem and Android shell access are not available.", { silent: true })} className="hover:underline">
          limits
        </button>
      </div>
    </div>
  );
}
