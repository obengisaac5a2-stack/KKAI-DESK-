import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ChevronRight,
  ClipboardPaste,
  Copy,
  Download,
  FileText,
  FolderPlus,
  Grid2X2,
  HardDrive,
  Home,
  Images,
  Info,
  List,
  Monitor,
  MoreHorizontal,
  Music,
  RotateCw,
  Scissors,
  Search,
  Smartphone,
  Trash2,
  Video,
} from "lucide-react";
import { NativeStorage } from "../NativeStorage";
import { FileGlyph, FILE_COLORS } from "../icons";
import { formatBytes, formatDate, useOS } from "../OSContext";
import type { AppContentProps, FileKind, FsNode, MenuItemConfig } from "../types";
import { SearchBox, Segmented } from "../ui";
import { cn } from "@/utils/cn";

type SortKey = "name" | "modified" | "size" | "kind";

const TYPE_LABEL: Record<FileKind, string> = {
  folder: "Folder",
  image: "Image",
  document: "Text document",
  audio: "Audio",
  video: "Video",
  archive: "Archive",
  code: "Source file",
  file: "File",
};

const SIDEBAR: { id: string; label: string; kind: "folder" | "app"; icon: typeof Home }[] = [
  { id: "home", label: "Home", kind: "folder", icon: Home },
  { id: "desktop", label: "Desktop", kind: "folder", icon: Monitor },
  { id: "documents", label: "Documents", kind: "folder", icon: FileText },
  { id: "downloads", label: "Downloads", kind: "folder", icon: Download },
  { id: "pictures", label: "Pictures", kind: "folder", icon: Images },
  { id: "music", label: "Music", kind: "folder", icon: Music },
  { id: "videos", label: "Videos", kind: "folder", icon: Video },
];

export default function FilesApp({ payload }: AppContentProps) {
  const {
    files,
    getNode,
    childrenOf,
    getPath,
    getFolderSize,
    launch,
    createFolder,
    renameNode,
    deleteNode,
    duplicateNode,
    moveNode,
    addNote,
    updateNote,
    openMenu,
    showPrompt,
    showConfirm,
    showInfo,
    notify,
    trash,
  } = useOS();

  const requestedFolder = typeof payload?.folderId === "string" ? payload.folderId : null;
  const requestedPreview = typeof payload?.previewId === "string" ? payload.previewId : null;
  const [history, setHistory] = useState<string[]>([requestedFolder && getNode(requestedFolder) ? requestedFolder : "home"]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("name");
  const [ascending, setAscending] = useState(true);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [clipboard, setClipboard] = useState<{ id: string; mode: "copy" | "cut"; name: string } | null>(null);
  const [refreshTick, setRefreshTick] = useState(0);
  const [nativeMode, setNativeMode] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  const currentId = history[historyIndex] ?? "home";
  const currentNode = getNode(currentId) ?? getNode("home");
  const locationName = currentNode?.name ?? "Home";

  useEffect(() => {
    if (!requestedFolder || !getNode(requestedFolder) || requestedFolder === currentId) return;
    setHistory((prev) => [...prev.slice(0, historyIndex + 1), requestedFolder]);
    setHistoryIndex((prev) => prev + 1);
    setSelectedId(null);
    setPreviewId(null);
    // History should only react to an explicit external navigation payload.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestedFolder]);

  useEffect(() => {
    const refresh = () => setRefreshTick((n) => n + 1);
    window.addEventListener("kkdex:refresh", refresh);
    return () => window.removeEventListener("kkdex:refresh", refresh);
  }, []);

  useEffect(() => {
    if (!requestedPreview) return;
    const node = getNode(requestedPreview);
    if (!node) return;
    setSelectedId(node.id);
    setPreviewId(node.id);
    // Only explicit external payloads should change the preview selection.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestedPreview]);

  const navigate = (id: string) => {
    if (!getNode(id)) {
      notify("Folder unavailable", "This location no longer exists in the workspace.", { tone: "error" });
      return;
    }
    setHistory((prev) => [...prev.slice(0, historyIndex + 1), id]);
    setHistoryIndex((prev) => prev + 1);
    setSelectedId(null);
    setPreviewId(null);
    setQuery("");
    setRefreshTick((n) => n + 1);
  };

  const allNodes = useMemo(() => {
    void refreshTick;
    return files;
  }, [files, refreshTick]);

  const collectDescendants = (parentId: string, acc: FsNode[] = []): FsNode[] => {
    allNodes
      .filter((node) => node.parentId === parentId)
      .forEach((node) => {
        acc.push(node);
        if (node.kind === "folder") collectDescendants(node.id, acc);
      });
    return acc;
  };

  const rawItems = useMemo(() => {
    const source = query.trim()
      ? collectDescendants(currentId)
      : allNodes.filter((n) => n.parentId === currentId);
    const filtered = source.filter((node) => node.name.toLowerCase().includes(query.trim().toLowerCase()));
    const sorted = [...filtered].sort((a, b) => {
      if (a.kind === "folder" && b.kind !== "folder") return -1;
      if (a.kind !== "folder" && b.kind === "folder") return 1;
      let result = 0;
      if (sort === "name") result = a.name.localeCompare(b.name, undefined, { numeric: true });
      else if (sort === "modified") result = a.modified - b.modified;
      else if (sort === "size") result = a.size - b.size;
      else result = TYPE_LABEL[a.kind].localeCompare(TYPE_LABEL[b.kind]);
      return ascending ? result : -result;
    });
    return sorted;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allNodes, currentId, query, sort, ascending]);

  const selected = selectedId ? getNode(selectedId) : undefined;
  const preview = previewId ? getNode(previewId) : undefined;
  const totalSize = useMemo(() => files.filter((f) => f.kind !== "folder").reduce((n, f) => n + f.size, 0), [files]);
  const usedPercent = Math.min(100, Math.round((totalSize / (256 * 1024 * 1024)) * 100));
  const previewNode = preview && preview.kind !== "folder" ? preview : null;

  const relativeLocation = (node: FsNode) => {
    const path = getPath(node.parentId ?? currentId);
    return path.slice(1).map((p) => p.name).join(" / ") || locationName;
  };

  const openNode = (node: FsNode) => {
    if (node.kind === "folder") {
      navigate(node.id);
      return;
    }
    if (node.kind === "image") {
      launch("gallery", { payload: { imageSrc: node.src, imageName: node.name } });
      return;
    }
    if ((node.kind === "document" || node.kind === "code") && node.content) {
      setPreviewId(node.id);
      return;
    }
    showInfo(
      TYPE_LABEL[node.kind],
      `“${node.name}” has no in-app reader in this KK DEX build. No host media player is connected to the web workspace, so the file was not opened.`,
    );
  };

  const requestRename = (node: FsNode) => {
    if (node.id === "home") {
      notify("Protected item", "This system location cannot be renamed.", { tone: "error" });
      return;
    }
    showPrompt({
      title: "Rename item",
      label: "New name",
      value: node.name,
      confirmLabel: "Rename",
      icon: <FileGlyph kind={node.kind} size={24} />,
      onConfirm: (value) => {
        if (value.trim() && value.trim() !== node.name) renameNode(node.id, value);
      },
    });
  };

  const requestDelete = (node: FsNode) => {
    showConfirm(
      `Move “${node.name}” to Recycle Bin?`,
      node.kind === "folder"
        ? "The folder and everything inside it will move to the Recycle Bin. You can restore it later."
        : "You can restore this file from the Recycle Bin until the bin is emptied.",
      () => deleteNode(node.id),
      "Move to Recycle Bin",
    );
  };

  const newFolder = () => {
    showPrompt({
      title: "New folder",
      message: `Create a folder inside ${locationName}.`,
      label: "Folder name",
      value: "New folder",
      confirmLabel: "Create folder",
      onConfirm: (value) => {
        if (!value.trim()) return;
        const id = createFolder(currentId, value);
        setSelectedId(id);
        notify("Folder created", `“${value.trim()}” was added to ${locationName}.`, { tone: "success", silent: true });
      },
    });
  };

  const copyItem = (mode: "copy" | "cut") => {
    if (!selected) return;
    if (selected.id === "home" || selected.locked) {
      notify("Protected location", "Home cannot be copied or moved.", { tone: "error" });
      return;
    }
    if (mode === "copy" && selected.kind === "folder") {
      showInfo(
        "Copying folders isn't supported",
        "This workspace can duplicate individual files. To copy a folder, create a new folder and copy its files individually. Cut and paste works for folders.",
      );
      return;
    }
    setClipboard({ id: selected.id, mode, name: selected.name });
    notify(mode === "copy" ? "Copied" : "Cut", `“${selected.name}” is ready to paste.`, { silent: true });
  };

  const pasteItem = () => {
    if (!clipboard) return;
    if (clipboard.mode === "cut") {
      if (moveNode(clipboard.id, currentId)) {
        notify("Item moved", `“${clipboard.name}” was moved to ${locationName}.`, { tone: "success", silent: true });
        setClipboard(null);
      }
    } else if (duplicateNode(clipboard.id, currentId)) {
      notify("Paste complete", `A copy of “${clipboard.name}” was created in ${locationName}.`, {
        tone: "success",
        silent: true,
      });
    }
  };

  const openMenuFor = (event: React.MouseEvent, node: FsNode | null) => {
    event.preventDefault();
    event.stopPropagation();
    if (node) setSelectedId(node.id);
    const items: MenuItemConfig[] = node
      ? [
          { label: node.kind === "folder" ? "Open folder" : "Open", icon: <ArrowRight size={14} />, action: () => openNode(node) },
          { separator: true },
          { label: "Rename", shortcut: "F2", icon: <FileText size={14} />, action: () => requestRename(node) },
          {
            label: "Copy",
            shortcut: "Ctrl+C",
            icon: <Copy size={14} />,
            action: () => {
              setSelectedId(node.id);
              if (node.kind === "folder") {
                showInfo("Copying folders isn't supported", "Use Cut and Paste for folders, or copy files individually.");
                return;
              }
              setClipboard({ id: node.id, mode: "copy", name: node.name });
              notify("Copied", `“${node.name}” is ready to paste.`, { silent: true });
            },
          },
          {
            label: "Move",
            shortcut: "Ctrl+X",
            icon: <Scissors size={14} />,
            action: () => {
              setClipboard({ id: node.id, mode: "cut", name: node.name });
              notify("Cut", `“${node.name}” is ready to paste.`, { silent: true });
            },
          },
          { separator: true },
          {
            label: "Properties",
            icon: <Info size={14} />,
            action: () =>
              showInfo(
                `${node.name} — Properties`,
                `Type: ${TYPE_LABEL[node.kind]}\nLocation: ${getPath(node.parentId ?? currentId)
                  .slice(1)
                  .map((p) => p.name)
                  .join(" / ")}\nSize: ${node.kind === "folder" ? formatBytes(getFolderSize(node.id)) : formatBytes(node.size)}\nModified: ${formatDate(node.modified)}`,
                <FileGlyph kind={node.kind} size={26} />,
              ),
          },
          { separator: true },
          { label: "Move to Recycle Bin", danger: true, icon: <Trash2 size={14} />, action: () => requestDelete(node) },
        ]
      : [
          { label: "New folder", icon: <FolderPlus size={14} />, action: newFolder },
          { label: "Paste", shortcut: "Ctrl+V", icon: <ClipboardPaste size={14} />, disabled: !clipboard, action: pasteItem },
          { separator: true },
          { label: "Refresh", shortcut: "F5", icon: <RotateCw size={14} />, action: () => setRefreshTick((n) => n + 1) },
          {
            label: "View",
            icon: <Grid2X2 size={14} />,
            children: [
              { label: "Grid view", checked: view === "grid", action: () => setView("grid") },
              { label: "List view", checked: view === "list", action: () => setView("list") },
            ],
          },
          {
            label: "Sort by",
            icon: <List size={14} />,
            children: (["name", "modified", "size", "kind"] as SortKey[]).map((key) => ({
              label: key === "name" ? "Name" : key === "modified" ? "Date modified" : key === "size" ? "Size" : "Type",
              checked: sort === key,
              action: () => setSort(key),
            })),
          },
        ];
    openMenu(event.clientX, event.clientY, items, node ? node.name : "Files");
  };

  const onKeyDown = (event: React.KeyboardEvent) => {
    const target = event.target as HTMLElement;
    if (["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName) || target.isContentEditable) return;
    const mod = event.ctrlKey || event.metaKey;
    if (mod && event.key.toLowerCase() === "c") {
      event.preventDefault();
      copyItem("copy");
    } else if (mod && event.key.toLowerCase() === "x") {
      event.preventDefault();
      copyItem("cut");
    } else if (mod && event.key.toLowerCase() === "v") {
      event.preventDefault();
      pasteItem();
    } else if (mod && event.key.toLowerCase() === "a") {
      event.preventDefault();
      const first = rawItems[0];
      if (first) setSelectedId(first.id);
    } else if (event.key === "Delete") {
      event.preventDefault();
      if (selected) requestDelete(selected);
    } else if (event.key === "F2") {
      event.preventDefault();
      if (selected) requestRename(selected);
    } else if (event.key === "Enter") {
      event.preventDefault();
      if (selected) openNode(selected);
    } else if (event.key === "F5") {
      event.preventDefault();
      setRefreshTick((n) => n + 1);
    } else if (event.key === "Escape") {
      if (previewId) setPreviewId(null);
      else setSelectedId(null);
    }
  };

  const path = getPath(currentId);

  if (nativeMode) {
    return <NativeStorage onExit={() => setNativeMode(false)} />;
  }

  return (
    <div
      ref={rootRef}
      tabIndex={0}
      className="flex h-full min-h-0 flex-col outline-none"
      onKeyDown={onKeyDown}
      style={{ background: "var(--surface-solid)" }}
    >
      <div className="flex items-center gap-1.5 px-2.5 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <button className="icon-btn h-7 w-7" aria-label="Back" disabled={historyIndex === 0} onClick={() => { setHistoryIndex((i) => Math.max(0, i - 1)); setSelectedId(null); setQuery(""); }}>
          <ArrowLeft size={14} />
        </button>
        <button className="icon-btn h-7 w-7" aria-label="Forward" disabled={historyIndex >= history.length - 1} onClick={() => { setHistoryIndex((i) => Math.min(history.length - 1, i + 1)); setSelectedId(null); setQuery(""); }}>
          <ArrowRight size={14} />
        </button>
        <button className="icon-btn h-7 w-7" aria-label="Up one level" disabled={!currentNode?.parentId} onClick={() => currentNode?.parentId && navigate(currentNode.parentId)}>
          <ArrowUp size={14} />
        </button>
        <div className="mx-1 flex h-7 min-w-0 flex-1 items-center gap-0.5 overflow-hidden rounded-md px-1.5" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
          {path.map((node, index) => (
            <div key={node.id} className="flex min-w-0 items-center">
              {index > 0 ? <ChevronRight size={11} className="mx-0.5 shrink-0" style={{ color: "var(--faint)" }} /> : null}
              <button
                className="max-w-[110px] truncate rounded px-1 py-0.5 text-[11px] hover:underline"
                style={{ color: index === path.length - 1 ? "var(--text)" : "var(--muted)" }}
                onClick={() => navigate(node.id)}
              >
                {node.name}
              </button>
            </div>
          ))}
        </div>
        <SearchBox value={query} onChange={setQuery} placeholder="Search here" className="w-[160px]" />
        <button className="btn btn-sm" onClick={() => setNativeMode(true)}>
          <Smartphone size={13} /> Import / device
        </button>
        <button className="btn btn-sm btn-accent" onClick={newFolder}>
          <FolderPlus size={13} /> New folder
        </button>
        <button className="icon-btn h-7 w-7" aria-label="More options" onClick={(event) => openMenuFor(event, null)}>
          <MoreHorizontal size={15} />
        </button>
      </div>

      <div className="flex min-h-0 flex-1">
        <aside className="flex w-[174px] shrink-0 flex-col px-2 py-2.5" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
          <div className="px-2 pb-1.5 text-[9px] font-semibold uppercase tracking-[0.13em]" style={{ color: "var(--faint)" }}>
            Quick access
          </div>
          <div className="flex flex-col gap-0.5">
            {SIDEBAR.map((item) => {
              const Icon = item.icon;
              const active = currentId === item.id;
              return (
                <button key={item.id} className={cn("sidebar-item", active && "active")} onClick={() => navigate(item.id)}>
                  <Icon size={14} strokeWidth={1.9} style={{ color: active ? "var(--accent)" : undefined }} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
          <div className="mx-2 my-2 divider" />
          <div className="flex flex-col gap-0.5">
            <button className="sidebar-item" onClick={() => setNativeMode(true)}>
              <Smartphone size={14} /> Android device
            </button>
            <button className="sidebar-item" onClick={() => launch("thispc")}>
              <HardDrive size={14} /> This PC
            </button>
            <button
              className="sidebar-item"
              onClick={() => launch("recycle")}
            >
              <Trash2 size={14} /> Recycle Bin
              {trash.length ? (
                <span className="badge badge-accent ml-auto !px-1.5 !py-0 text-[9px]">{trash.length}</span>
              ) : null}
            </button>
          </div>
          <div className="mt-auto rounded-lg p-2.5" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
            <div className="flex items-center gap-1.5 text-[10px] font-medium">
              <HardDrive size={12} style={{ color: "var(--accent)" }} />
              KK DEX workspace
            </div>
            <div className="mt-2 h-1 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}>
              <div className="h-full rounded-full" style={{ width: `${Math.max(3, usedPercent)}%`, background: "var(--accent)" }} />
            </div>
            <div className="mt-1.5 flex items-center justify-between text-[9.5px]" style={{ color: "var(--muted)" }}>
              <span>{formatBytes(totalSize)} used</span>
              <button
                className="hover:underline"
                onClick={() =>
                  showInfo(
                    "About workspace storage",
                    "KK DEX files are stored locally in this browser workspace and persist on this device. The Android bridge does not expose raw device storage operations, so no external files are read or modified.",
                    <HardDrive size={26} />,
                  )
                }
              >
                Details
              </button>
            </div>
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center justify-between gap-3 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
            <div className="min-w-0">
              <div className="truncate text-[13px] font-semibold">{locationName}</div>
              <div className="text-[10px]" style={{ color: "var(--muted)" }}>
                {rawItems.length} {rawItems.length === 1 ? "item" : "items"}
                {query ? ` matching “${query}”` : ""}
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button className="icon-btn h-7 w-7" title="Copy" disabled={!selected} onClick={() => copyItem("copy")}><Copy size={13} /></button>
              <button className="icon-btn h-7 w-7" title="Cut" disabled={!selected} onClick={() => copyItem("cut")}><Scissors size={13} /></button>
              <button className="icon-btn h-7 w-7" title="Paste" disabled={!clipboard} onClick={pasteItem}><ClipboardPaste size={13} /></button>
              <div className="mx-0.5 h-4 w-px" style={{ background: "var(--border)" }} />
              <select
                aria-label="Sort files"
                className="field !h-7 !w-[118px] !text-[11px]"
                value={sort}
                onChange={(event) => setSort(event.target.value as SortKey)}
              >
                <option value="name">Sort: Name</option>
                <option value="modified">Sort: Modified</option>
                <option value="size">Sort: Size</option>
                <option value="kind">Sort: Type</option>
              </select>
              <button className="icon-btn h-7 w-7" aria-label="Reverse sort" onClick={() => setAscending((v) => !v)} title={ascending ? "Ascending" : "Descending"}>
                <ArrowUp size={13} style={{ transform: ascending ? undefined : "rotate(180deg)" }} />
              </button>
              <Segmented
                size="sm"
                value={view}
                onChange={setView}
                options={[
                  { value: "grid", label: <Grid2X2 size={12} /> },
                  { value: "list", label: <List size={13} /> },
                ]}
              />
            </div>
          </div>

          {previewNode ? (
            <div className="flex min-h-0 flex-1 flex-col">
              <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
                <button className="btn btn-sm" onClick={() => setPreviewId(null)}><ArrowLeft size={12} /> Back to files</button>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] font-medium">{previewNode.name}</div>
                  <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>{formatBytes(previewNode.size)} · Modified {formatDate(previewNode.modified)}</div>
                </div>
                <button
                  className="icon-btn h-7 w-7"
                  title="Edit in Notes"
                  onClick={() => {
                    const id = addNote();
                    updateNote(id, { title: previewNode.name, body: previewNode.content ?? "" });
                    launch("notes", { payload: { noteId: id } });
                    notify("Sent to Notes", "An editable copy of this text was created in Notes.", { tone: "success" });
                  }}
                >
                  <FileText size={14} />
                </button>
                <button className="icon-btn h-7 w-7" aria-label="Close preview" onClick={() => setPreviewId(null)}><ArrowLeft size={14} /></button>
              </div>
              <pre className="scroll-thin min-h-0 flex-1 overflow-auto whitespace-pre-wrap p-5 font-mono text-[12px] leading-relaxed" style={{ color: "var(--text)", background: "var(--surface-2)" }}>
                {previewNode.content}
              </pre>
            </div>
          ) : rawItems.length === 0 ? (
            <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl" style={{ background: "var(--field)", color: "var(--muted)" }}>
                {query ? <Search size={21} /> : <Trash2 size={21} />}
              </div>
              <div className="text-center">
                <div className="text-[12.5px] font-medium">{query ? "No matching items" : "This folder is empty"}</div>
                <div className="mt-1 text-[10.5px]" style={{ color: "var(--muted)" }}>
                  {query ? "Try a different search term." : "Create a folder or paste a copied item here."}
                </div>
              </div>
              {!query ? <button className="btn btn-sm" onClick={newFolder}><FolderPlus size={12} /> New folder</button> : null}
            </div>
          ) : view === "grid" ? (
            <div
              className="scroll-thin min-h-0 flex-1 overflow-auto p-3"
              onClick={(event) => {
                if (event.target === event.currentTarget) setSelectedId(null);
              }}
              onContextMenu={(event) => openMenuFor(event, null)}
            >
              <div className="grid gap-1.5" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(102px, 1fr))" }}>
                {rawItems.map((node) => {
                  const active = selectedId === node.id;
                  return (
                    <button
                      key={node.id}
                      className={cn("group flex h-[104px] flex-col items-center justify-start gap-1.5 rounded-lg px-1.5 pt-3 pb-1.5 text-center transition-colors", active && "row-selected")}
                      style={{ border: `1px solid ${active ? "rgba(var(--accent-rgb),.45)" : "transparent"}` }}
                      onClick={(event) => {
                        event.stopPropagation();
                        setSelectedId(node.id);
                        rootRef.current?.focus();
                      }}
                      onDoubleClick={() => openNode(node)}
                      onContextMenu={(event) => openMenuFor(event, node)}
                      title={node.name}
                    >
                      {node.kind === "image" && node.src ? (
                        <div className="h-11 w-12 overflow-hidden rounded-md" style={{ border: "1px solid var(--border)" }}>
                          <img src={node.src} alt="" className="h-full w-full object-cover" loading="lazy" draggable={false} />
                        </div>
                      ) : (
                        <div
                          className="flex h-11 w-12 items-center justify-center rounded-lg"
                          style={{ background: `${FILE_COLORS[node.kind]}16` }}
                        >
                          <FileGlyph kind={node.kind} size={27} />
                        </div>
                      )}
                      <span className="line-clamp-2 w-full break-words text-[10.5px] leading-[1.25]">{node.name}</span>
                      {query ? (
                        <span className="line-clamp-1 w-full text-[8.5px]" style={{ color: "var(--faint)" }}>{relativeLocation(node)}</span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="scroll-thin min-h-0 flex-1 overflow-auto">
              <div className="sticky top-0 z-10 grid grid-cols-[minmax(0,1fr)_120px_110px_76px] gap-2 px-3 py-1.5 text-[9.5px] font-semibold uppercase tracking-wide" style={{ background: "var(--surface-2)", color: "var(--faint)", borderBottom: "1px solid var(--border)" }}>
                <button className="text-left hover:text-[var(--text)]" onClick={() => { setSort("name"); }}>Name</button>
                <button className="text-left hover:text-[var(--text)]" onClick={() => setSort("modified")}>Date modified</button>
                <button className="text-left hover:text-[var(--text)]" onClick={() => setSort("kind")}>Type</button>
                <button className="text-right hover:text-[var(--text)]" onClick={() => setSort("size")}>Size</button>
              </div>
              {rawItems.map((node) => {
                const active = selectedId === node.id;
                return (
                  <button
                    key={node.id}
                    className={cn("grid w-full grid-cols-[minmax(0,1fr)_120px_110px_76px] items-center gap-2 px-3 py-1.5 text-left text-[11.5px] row-hover", active && "row-selected")}
                    onClick={(event) => {
                      event.stopPropagation();
                      setSelectedId(node.id);
                      rootRef.current?.focus();
                    }}
                    onDoubleClick={() => openNode(node)}
                    onContextMenu={(event) => openMenuFor(event, node)}
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      {node.kind === "image" && node.src ? (
                        <img src={node.src} alt="" className="h-5 w-5 shrink-0 rounded object-cover" draggable={false} />
                      ) : (
                        <FileGlyph kind={node.kind} size={16} />
                      )}
                      <span className="truncate">{node.name}</span>
                    </span>
                    <span className="truncate text-[10px]" style={{ color: "var(--muted)" }}>{formatDate(node.modified)}</span>
                    <span className="truncate text-[10px]" style={{ color: "var(--muted)" }}>{TYPE_LABEL[node.kind]}</span>
                    <span className="text-right text-[10px]" style={{ color: "var(--muted)" }}>
                      {node.kind === "folder" ? `${childrenOf(node.id).length} items` : formatBytes(node.size)}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          <div className="flex h-7 shrink-0 items-center justify-between gap-3 px-3 text-[9.5px]" style={{ borderTop: "1px solid var(--border)", color: "var(--muted)", background: "var(--surface-2)" }}>
            <span className="truncate">
              {selected ? `Selected: ${selected.name} · ${TYPE_LABEL[selected.kind]}` : `${rawItems.length} items`}
            </span>
            <span className="flex items-center gap-2">
              {clipboard ? <span className="truncate">Clipboard: {clipboard.name}</span> : null}
              <span className="hidden sm:inline">Workspace storage</span>
              <HardDrive size={10} />
            </span>
          </div>
        </div>
      </div>
      {selected ? (
        <div className="sr-only" aria-live="polite">
          {selected.name} selected. Press Enter to open, F2 to rename, Delete to recycle.
        </div>
      ) : null}
    </div>
  );
}
