import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { APP_METAS, DEFAULT_PINS } from "./appMeta";
import type {
  AccentId,
  AppId,
  DialogState,
  ExportedFile,
  FileKind,
  FsNode,
  MenuItemConfig,
  MenuState,
  Note,
  Notification,
  OpenOptions,
  Rect,
  Settings,
  SystemPanelState,
  Toast,
  TrashItem,
  WallpaperId,
  WindowState,
} from "./types";

export const TASKBAR_SPACE = 56;

export interface WallpaperDef {
  id: WallpaperId;
  name: string;
  note: string;
  kind: "image" | "css";
  value: string;
}

export const WALLPAPERS: WallpaperDef[] = [
  { id: "aurora", name: "Aurora Bloom", note: "KK DEX signature", kind: "image", value: "/wallpapers/aurora.jpg" },
  { id: "dunes", name: "Golden Dunes", note: "Warm minimal", kind: "image", value: "/wallpapers/dunes.jpg" },
  {
    id: "graphite",
    name: "Graphite Flow",
    note: "Studio dark",
    kind: "css",
    value:
      "radial-gradient(ellipse at 20% 12%, #46536b 0%, transparent 48%), radial-gradient(ellipse at 82% 24%, #263a55 0%, transparent 42%), linear-gradient(135deg, #090d16, #182133 55%, #0a0e18)",
  },
  {
    id: "ocean",
    name: "Deep Current",
    note: "Ocean teal",
    kind: "css",
    value:
      "radial-gradient(ellipse at 18% 18%, #0891b2 0%, transparent 46%), radial-gradient(ellipse at 86% 28%, #0f766e 0%, transparent 44%), linear-gradient(140deg, #041322, #062e3a 58%, #021019)",
  },
  {
    id: "ember",
    name: "Ember Dusk",
    note: "Rose & amber",
    kind: "css",
    value:
      "radial-gradient(ellipse at 20% 16%, #be4568 0%, transparent 44%), radial-gradient(ellipse at 82% 24%, #b45309 0%, transparent 42%), linear-gradient(140deg, #1b0a18, #351323 58%, #120810)",
  },
];

export const ACCENTS: Record<AccentId, { name: string; hex: string; rgb: string }> = {
  blue: { name: "Coastal Blue", hex: "#4f8cff", rgb: "79, 140, 255" },
  violet: { name: "Nebula Violet", hex: "#8b7cff", rgb: "139, 124, 255" },
  emerald: { name: "Signal Emerald", hex: "#2cc9a0", rgb: "44, 201, 160" },
  amber: { name: "Solar Amber", hex: "#eaa53d", rgb: "234, 165, 61" },
  rose: { name: "Studio Rose", hex: "#ef6f9b", rgb: "239, 111, 155" },
};

export const DEFAULT_SETTINGS: Settings = {
  wallpaper: "aurora",
  theme: "dark",
  accent: "blue",
  sound: true,
  volume: 65,
  muted: false,
  doNotDisturb: false,
  nightLight: false,
  brightness: 100,
  iconSize: "medium",
  reduceMotion: false,
  pointerSpeed: 5,
  pointerSize: 3,
  clickEffects: true,
  taskbarPins: DEFAULT_PINS,
  wallpapers: 5,
};

export const GALLERY_IMAGES = [
  { id: "lg1", name: "Alpine Mirror", src: "/gallery/mountain-lake.jpg", meta: "KK DEX Collection · Landscape" },
  { id: "lg2", name: "Blue Hour Avenue", src: "/gallery/night-city.jpg", meta: "KK DEX Collection · Architecture" },
  { id: "lg3", name: "Cedar Morning", src: "/gallery/forest-path.jpg", meta: "KK DEX Collection · Nature" },
  { id: "lg4", name: "Aurora Bloom", src: "/wallpapers/aurora.jpg", meta: "KK DEX Wallpaper · Abstract" },
  { id: "lg5", name: "Golden Dunes", src: "/wallpapers/dunes.jpg", meta: "KK DEX Wallpaper · Minimal" },
  { id: "g1", name: "Blue Ridge", src: "https://images.pexels.com/photos/21033251/pexels-photo-21033251.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Robert Clark · Landscape" },
  { id: "g2", name: "Quiet Tide", src: "https://images.pexels.com/photos/14636481/pexels-photo-14636481.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Dom Sch-veg-man · Monochrome" },
  { id: "g3", name: "Coastal Sunrise", src: "https://images.pexels.com/photos/21302488/pexels-photo-21302488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Robert Clark · Coast" },
  { id: "g4", name: "Faroe Motion", src: "https://images.pexels.com/photos/36297632/pexels-photo-36297632.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Robert Clark · Abstract" },
  { id: "g5", name: "Nordic Study", src: "https://images.pexels.com/photos/32654397/pexels-photo-32654397.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Marek Piwnicki · Mountains" },
  { id: "g6", name: "Sea Glass", src: "https://images.pexels.com/photos/37046472/pexels-photo-37046472.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Reinis Brūzītis · Abstract" },
  { id: "g7", name: "Tofino Aerial", src: "https://images.pexels.com/photos/13289069/pexels-photo-13289069.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Rhys Abel · Aerial" },
  { id: "g8", name: "Sand Atlas", src: "https://images.pexels.com/photos/37245161/pexels-photo-37245161.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Pok Rie · Aerial" },
  { id: "g9", name: "Dreamline", src: "https://images.pexels.com/photos/21031988/pexels-photo-21031988.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Robert Clark · Sunset" },
  { id: "g10", name: "Currents", src: "https://images.pexels.com/photos/36311992/pexels-photo-36311992.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", meta: "Robert Clark · Abstract" },
];

export function wallpaperStyle(id: WallpaperId): CSSProperties {
  const w = WALLPAPERS.find((item) => item.id === id) ?? WALLPAPERS[0];
  if (w.kind === "image") {
    return { backgroundImage: `url("${w.value}")`, backgroundSize: "cover", backgroundPosition: "center center" };
  }
  return { background: w.value };
}

export function formatBytes(bytes: number): string {
  if (!bytes) return "0 KB";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

const now = Date.now();
const day = 86_400_000;

function makeInitialFiles(): FsNode[] {
  const base: FsNode[] = [
    { id: "home", name: "Home", kind: "folder", parentId: null, size: 0, modified: now, locked: true },
    { id: "desktop", name: "Desktop", kind: "folder", parentId: "home", size: 0, modified: now - 4 * 3600_000 },
    { id: "documents", name: "Documents", kind: "folder", parentId: "home", size: 0, modified: now - day },
    { id: "downloads", name: "Downloads", kind: "folder", parentId: "home", size: 0, modified: now - 2 * day },
    { id: "pictures", name: "Pictures", kind: "folder", parentId: "home", size: 0, modified: now - 3 * day },
    { id: "music", name: "Music", kind: "folder", parentId: "home", size: 0, modified: now - 5 * day },
    { id: "videos", name: "Videos", kind: "folder", parentId: "home", size: 0, modified: now - 8 * day },
    {
      id: "welcome-txt",
      name: "Welcome to KK DEX.txt",
      kind: "document",
      parentId: "desktop",
      size: 1280,
      modified: now - 2 * 3600_000,
      content:
        "Welcome to KK DEX.\n\nThis workspace is yours. Double-click a desktop icon to open an application, drag windows by their title bar, and resize them from any edge.\n\nYour files, notes and preferences are stored in this browser workspace and persist between visits.\n\nTip: Press Win or Ctrl+Esc to open the Start menu. Press Alt+F4 to close the active window.",
    },
    {
      id: "shortcuts-md",
      name: "Keyboard shortcuts.md",
      kind: "document",
      parentId: "documents",
      size: 2460,
      modified: now - 5 * 3600_000,
      content:
        "# KK DEX shortcuts\n\nWin / Ctrl+Esc — Start menu\nWin + D — Show desktop\nWin + E — Files\nWin + Left / Right — Snap window\nAlt + Tab — Switch apps\nAlt + F4 — Close active window\nF5 — Refresh\nF2 — Rename selection\nDelete — Move selection to Recycle Bin\n\nInside text fields, standard browser editing shortcuts apply.",
    },
    {
      id: "project-md",
      name: "Project brief.md",
      kind: "document",
      parentId: "documents",
      size: 5820,
      modified: now - day,
      content:
        "# KK DEX — Desktop platform\n\nKK DEX turns a TV or external monitor into a full desktop workspace, with the Android phone acting as a precision touchpad and keyboard.\n\n## Principles\n- Native-feeling window management\n- Honest capabilities and clear limitations\n- Premium, calm visual language\n- Keyboard-first accessibility",
    },
    {
      id: "ideas-txt",
      name: "Ideas.txt",
      kind: "document",
      parentId: "documents",
      size: 940,
      modified: now - 3 * 3600_000,
      content: "1. Pin the controller to the TV for instant pairing.\n2. Add more wallpaper packs.\n3. Keep the workspace storage in sync with the Android bridge.",
    },
    {
      id: "hello-js",
      name: "hello.js",
      kind: "code",
      parentId: "documents",
      size: 620,
      modified: now - 4 * day,
      content: 'export function greet(name) {\n  return `Hello, ${name}. Welcome to KK DEX.`;\n}\n',
    },
    {
      id: "release-txt",
      name: "KK DEX release notes.txt",
      kind: "document",
      parentId: "downloads",
      size: 3240,
      modified: now - day,
      content:
        "KK DEX OS 1.0\n\n• Floating window manager with edge and corner resizing\n• Command palette search and keyboard navigation\n• Files, Notes, Gallery, Browser and Terminal applications\n• Persistent workspace storage and Recycle Bin\n• Phone controller pairing interface",
    },
    { id: "download-zip", name: "kkdex-tools.zip", kind: "archive", parentId: "downloads", size: 18_420_000, modified: now - 6 * day },
    { id: "wallpapers-zip", name: "kkdex-wallpapers.zip", kind: "archive", parentId: "downloads", size: 6_840_000, modified: now - 11 * day },
    { id: "track-1", name: "Aurora — Nights.mp3", kind: "audio", parentId: "music", size: 8_240_000, modified: now - 22 * day },
    { id: "track-2", name: "Low Signal.mp3", kind: "audio", parentId: "music", size: 6_780_000, modified: now - 28 * day },
    { id: "clip-1", name: "Desktop demo.mp4", kind: "video", parentId: "videos", size: 94_200_000, modified: now - 15 * day },
  ];
  GALLERY_IMAGES.forEach((img, index) => {
    base.push({
      id: `picture-${index + 1}`,
      name: `${img.name}.jpg`,
      kind: "image",
      parentId: "pictures",
      size: 1_240_000 + index * 310_000,
      modified: now - (index + 1) * day,
      src: img.src,
    });
  });
  return base;
}

const INITIAL_NOTES: Note[] = [
  {
    id: "note-welcome",
    title: "Welcome to Notes",
    body: "A quiet place to think.\n\nEverything here is saved to your KK DEX workspace as you type. Use the pin button to keep important notes at the top.\n\nTry creating a note for your next idea.",
    modified: now - 36 * 60_000,
    pinned: true,
    color: "#5b9dff",
  },
  {
    id: "note-shortcuts",
    title: "Shortcut cheatsheet",
    body: "Win / Ctrl+Esc — Start\nWin + E — Files\nWin + D — Show desktop\nAlt + Tab — Switch apps\nAlt + F4 — Close window\nF2 — Rename\nDelete — Recycle\n\nCtrl+S saves the current note.",
    modified: now - day,
    pinned: false,
    color: "#34d399",
  },
  {
    id: "note-ideas",
    title: "Weekend ideas",
    body: "• Rearrange the desktop icons\n• Try a new wallpaper theme\n• Explore the virtual file workspace\n• Pair a phone controller and use the touchpad",
    modified: now - 2 * day,
    pinned: false,
    color: "#f7c45c",
  },
];

const DEFAULT_NOTIFICATIONS: Notification[] = [
  {
    id: "notif-1",
    title: "KK DEX is ready",
    body: "Your workspace loaded successfully. Double-click any desktop icon to begin.",
    time: now - 2 * 60_000,
    read: false,
  },
  {
    id: "notif-2",
    title: "Workspace storage",
    body: "Files and notes are stored locally in this browser workspace.",
    time: now - 28 * 60_000,
    read: false,
  },
  {
    id: "notif-3",
    title: "Phone controller available",
    body: "Open Phone Controller from App Center to pair your Android device.",
    time: now - 90 * 60_000,
    read: true,
  },
];

function loadStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function uid(prefix: string): string {
  const raw = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : Math.random().toString(36).slice(2);
  return `${prefix}-${raw}`;
}

const clamp = (v: number, min: number, max: number) => Math.min(Math.max(v, min), Math.max(min, max));
const WORK_H = () => window.innerHeight - TASKBAR_SPACE;

function playTone(kind: "open" | "close" | "click" = "click", volume = 0.6, enabled = true) {
  if (!enabled) return;
  try {
    const AudioCtor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtor) return;
    const ctx = new AudioCtor();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = kind === "open" ? 520 : kind === "close" ? 380 : 640;
    gain.gain.value = 0.0001;
    osc.connect(gain);
    gain.connect(ctx.destination);
    const t = ctx.currentTime;
    gain.gain.exponentialRampToValueAtTime(0.035 * volume, t + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.13);
    osc.start(t);
    osc.stop(t + 0.15);
    window.setTimeout(() => void ctx.close().catch(() => undefined), 260);
  } catch {
    /* Audio is an enhancement; never block an interaction. */
  }
}

interface OSApi {
  windows: WindowState[];
  activeWindow: WindowState | undefined;
  launch: (appId: AppId, options?: OpenOptions) => string;
  closeWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  toggleMaximize: (id: string) => void;
  restoreWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  minimizAll: () => void;
  restoreAll: () => void;
  snapWindow: (id: string, side: "left" | "right") => void;
  switchToNext: () => void;
  setWindowTitlePatch: (id: string, payload: Record<string, unknown>) => void;
  updateWindowRect: (id: string, rect: Partial<Rect>) => void;
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => void;
  setTheme: (theme: Settings["theme"]) => void;
  setWallpaper: (id: WallpaperId) => void;
  resetSettings: () => void;
  togglePin: (appId: AppId) => void;
  files: FsNode[];
  trash: TrashItem[];
  getNode: (id: string) => FsNode | undefined;
  childrenOf: (parentId: string) => FsNode[];
  getPath: (id: string) => FsNode[];
  getFolderSize: (id: string) => number;
  createFolder: (parentId: string, name?: string) => string;
  renameNode: (id: string, name: string) => boolean;
  deleteNode: (id: string) => void;
  restoreTrash: (trashId: string) => void;
  deleteForever: (trashId: string) => void;
  emptyTrash: () => void;
  updateFile: (id: string, patch: Partial<FsNode>) => void;
  duplicateNode: (id: string, targetParentId: string) => string | null;
  moveNode: (id: string, targetParentId: string) => boolean;
  addFile: (
    parentId: string,
    name: string,
    kind: FileKind,
    options?: { content?: string; src?: string; size?: number },
  ) => string;
  exportedFiles: ExportedFile[];
  pushExportedFile: (file: ExportedFile) => void;
  notes: Note[];
  addNote: () => string;
  updateNote: (id: string, patch: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  notifications: Notification[];
  notify: (title: string, body?: string, opts?: { appId?: AppId; tone?: Toast["tone"]; silent?: boolean }) => void;
  dismissNotification: (id: string) => void;
  clearNotifications: () => void;
  markNotificationsRead: () => void;
  toasts: Toast[];
  dismissToast: (id: string) => void;
  launchHistory: AppId[];
  startOpen: boolean;
  setStartOpen: (v: boolean) => void;
  startQuery: string;
  setStartQuery: (v: string) => void;
  panel: SystemPanelState | null;
  setPanel: (v: SystemPanelState | null) => void;
  menu: MenuState | null;
  openMenu: (x: number, y: number, items: MenuItemConfig[], title?: string, width?: number) => void;
  closeMenu: () => void;
  dialog: DialogState | null;
  closeDialog: () => void;
  showPrompt: (opts: Omit<DialogState, "kind"> & { onConfirm: (value: string) => void }) => void;
  showConfirm: (title: string, message: string, onConfirm: () => void, confirmLabel?: string) => void;
  showInfo: (title: string, message: string, icon?: ReactNode) => void;
  locked: boolean;
  lock: () => void;
  unlock: () => void;
  taskViewOpen: boolean;
  setTaskViewOpen: (v: boolean) => void;
  bootTime: number;
  openPhoneController: () => void;
  restartDesktop: () => void;
  factoryReset: () => void;
  soundClick: () => void;
}

const OSContext = createContext<OSApi | null>(null);

export function useOS(): OSApi {
  const ctx = useContext(OSContext);
  if (!ctx) throw new Error("useOS must be used inside OSProvider");
  return ctx;
}

export function OSProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(() => ({
    ...DEFAULT_SETTINGS,
    ...loadStored<Partial<Settings>>("kkdex.settings", {}),
  }));
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [zTop, setZTop] = useState(20);
  const [files, setFiles] = useState<FsNode[]>(() => loadStored<FsNode[]>("kkdex.files", makeInitialFiles()));
  const [exportedFiles, setExportedFiles] = useState<ExportedFile[]>(() => loadStored<ExportedFile[]>("kkdex.exported", []));
  const [trash, setTrash] = useState<TrashItem[]>(() => loadStored<TrashItem[]>("kkdex.trash", []));
  const [notes, setNotes] = useState<Note[]>(() => loadStored<Note[]>("kkdex.notes", INITIAL_NOTES));
  const [notifications, setNotifications] = useState<Notification[]>(() =>
    loadStored<Notification[]>("kkdex.notifications", DEFAULT_NOTIFICATIONS),
  );
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [launchHistory, setLaunchHistory] = useState<AppId[]>(() =>
    loadStored<AppId[]>("kkdex.recentApps", ["files", "browser", "ai"]),
  );
  const [startOpen, setStartOpen] = useState(false);
  const [startQuery, setStartQuery] = useState("");
  const [panel, setPanel] = useState<SystemPanelState | null>(null);
  const [menu, setMenu] = useState<MenuState | null>(null);
  const [dialog, setDialog] = useState<DialogState | null>(null);
  const [locked, setLocked] = useState(false);
  const [taskViewOpen, setTaskViewOpen] = useState(false);
  const [bootTime] = useState(Date.now());
  const [viewportTick, setViewportTick] = useState(0);
  const wakeLockRef = useRef(false);

  const accent = ACCENTS[settings.accent] ?? ACCENTS.blue;

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = settings.theme;
    root.style.setProperty("--accent", accent.hex);
    root.style.setProperty("--accent-rgb", accent.rgb);
    root.style.setProperty("--accent-soft", `rgba(${accent.rgb}, 0.16)`);
    root.style.setProperty("--taskbar-h", `${TASKBAR_SPACE}px`);
    root.classList.toggle("reduce-motion", settings.reduceMotion);
    document.body.style.setProperty("--night-light", settings.nightLight ? "1" : "0");
  }, [settings.theme, settings.accent, settings.reduceMotion, settings.nightLight, accent.hex, accent.rgb]);

  useEffect(() => {
    localStorage.setItem("kkdex.settings", JSON.stringify(settings));
  }, [settings]);
  useEffect(() => {
    localStorage.setItem("kkdex.files", JSON.stringify(files));
  }, [files]);
  useEffect(() => {
    localStorage.setItem("kkdex.exported", JSON.stringify(exportedFiles.slice(0, 40)));
  }, [exportedFiles]);
  useEffect(() => {
    localStorage.setItem("kkdex.trash", JSON.stringify(trash));
  }, [trash]);
  useEffect(() => {
    localStorage.setItem("kkdex.notes", JSON.stringify(notes));
  }, [notes]);
  useEffect(() => {
    localStorage.setItem("kkdex.notifications", JSON.stringify(notifications));
  }, [notifications]);
  useEffect(() => {
    localStorage.setItem("kkdex.recentApps", JSON.stringify(launchHistory));
  }, [launchHistory]);

  useEffect(() => {
    const onResize = () => {
      setViewportTick((n) => n + 1);
      const vw = window.innerWidth;
      const vh = WORK_H();
      setWindows((prev) =>
        prev.map((w) => {
          if (w.maximized) return { ...w, x: 0, y: 0, w: vw, h: vh };
          const width = Math.min(w.w, Math.max(320, vw - 16));
          const height = Math.min(w.h, Math.max(240, vh - 16));
          return {
            ...w,
            w: width,
            h: height,
            x: clamp(w.x, Math.min(0, vw - width), Math.max(0, vw - width)),
            y: clamp(w.y, 0, Math.max(0, vh - height)),
          };
        }),
      );
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const closeMenu = () => setMenu(null);
  const closeDialog = () => setDialog(null);

  const updateSettings = (patch: Partial<Settings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  };

  const soundClick = () => {
    if (settings.sound && !settings.muted) playTone("click", settings.volume / 100, true);
  };

  const pushToast = (toast: Toast) => {
    setToasts((prev) => [...prev.slice(-3), toast]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== toast.id));
    }, 4200);
  };

  const notify: OSApi["notify"] = (title, body, opts) => {
    const notification: Notification = {
      id: uid("notif"),
      title,
      body: body ?? "",
      time: Date.now(),
      appId: opts?.appId,
      read: false,
    };
    setNotifications((prev) => [notification, ...prev].slice(0, 40));
    if (!settings.doNotDisturb && !opts?.silent) {
      pushToast({ id: uid("toast"), title, message: body, appId: opts?.appId, tone: opts?.tone });
    }
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };
  const clearNotifications = () => setNotifications([]);
  const markNotificationsRead = () =>
    setNotifications((prev) => prev.map((notification) => ({ ...notification, read: true })));
  const dismissToast = (id: string) => setToasts((prev) => prev.filter((t) => t.id !== id));

  const focusWindow = (id: string) => {
    const z = Math.max(zTop, ...windows.map((window) => window.z)) + 1;
    setZTop(z);
    setWindows((prev) => prev.map((window) => (window.id === id ? { ...window, minimized: false, z } : window)));
    setActiveId(id);
    setStartOpen(false);
    setPanel(null);
    setTaskViewOpen(false);
  };

  const launch: OSApi["launch"] = (appId, options = {}) => {
    const meta = APP_METAS[appId];
    if (!meta) return "";
    setStartOpen(false);
    setPanel(null);
    setTaskViewOpen(false);
    setLaunchHistory((prev) => [appId, ...prev.filter((id) => id !== appId)].slice(0, 10));

    const existing = !options.newInstance ? windows.find((w) => w.appId === appId) : undefined;
    if (existing) {
      const z = Math.max(zTop, ...windows.map((w) => w.z)) + 1;
      setZTop(z);
      setWindows((prev) =>
        prev.map((w) =>
          w.id === existing.id
            ? {
                ...w,
                minimized: false,
                z,
                payload: options.payload ? { ...w.payload, ...options.payload } : w.payload,
              }
            : w,
        ),
      );
      setActiveId(existing.id);
      if (settings.sound && !settings.muted) playTone("open", settings.volume / 100, true);
      return existing.id;
    }

    const vw = window.innerWidth;
    const vh = WORK_H();
    const width = clamp(meta.defaultSize[0], Math.min(meta.minSize[0], vw - 24), Math.max(320, vw - 24));
    const height = clamp(meta.defaultSize[1], Math.min(meta.minSize[1], vh - 24), Math.max(260, vh - 24));
    const cascade = (windows.length % 4) * 24;
    const x = clamp(Math.round((vw - width) / 2) + cascade - 36, -width + 160, Math.max(0, vw - width));
    const y = clamp(Math.round((vh - height) / 2) + cascade - 24, 0, Math.max(0, vh - height));
    const z = Math.max(zTop, ...windows.map((w) => w.z)) + 1;
    const win: WindowState = {
      id: uid("win"),
      appId,
      x,
      y,
      w: width,
      h: height,
      z,
      minimized: Boolean(options.minimized),
      maximized: false,
      payload: options.payload,
      createdAt: Date.now(),
    };
    setZTop(z);
    setWindows((prev) => [...prev, win]);
    setActiveId(win.id);
    if (settings.sound && !settings.muted) playTone("open", settings.volume / 100, true);
    return win.id;
  };

  const activeWindow = useMemo(() => windows.find((w) => w.id === activeId), [windows, activeId]);

  const nextActiveId = (list: WindowState[]) =>
    list.filter((window) => !window.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null;

  const closeWindow = (id: string) => {
    const next = windows.filter((window) => window.id !== id);
    setWindows(next);
    if (id === activeId) setActiveId(nextActiveId(next));
    if (settings.sound && !settings.muted) playTone("close", settings.volume / 100, true);
  };

  const minimizeWindow = (id: string) => {
    const next = windows.map((window) => (window.id === id ? { ...window, minimized: true } : window));
    setWindows(next);
    if (id === activeId) setActiveId(nextActiveId(next));
  };

  const restoreWindow = (id: string) => {
    const z = Math.max(zTop, ...windows.map((window) => window.z)) + 1;
    setZTop(z);
    setWindows((prev) => prev.map((window) => (window.id === id ? { ...window, minimized: false, z } : window)));
    setActiveId(id);
    setStartOpen(false);
    setPanel(null);
  };

  const toggleMaximize = (id: string) => {
    const vw = window.innerWidth;
    const vh = WORK_H();
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        if (w.maximized) {
          const prevRect = w.prev ?? {
            x: clamp((vw - APP_METAS[w.appId].defaultSize[0]) / 2, 16, vw - 480),
            y: 48,
            w: Math.min(APP_METAS[w.appId].defaultSize[0], vw - 32),
            h: Math.min(APP_METAS[w.appId].defaultSize[1], vh - 32),
          };
          return { ...w, maximized: false, minimized: false, ...prevRect, prev: undefined };
        }
        return {
          ...w,
          prev: { x: w.x, y: w.y, w: w.w, h: w.h },
          x: 0,
          y: 0,
          w: vw,
          h: vh,
          maximized: true,
          minimized: false,
        };
      }),
    );
    setActiveId(id);
  };

  const snapWindow = (id: string, side: "left" | "right") => {
    const vw = window.innerWidth;
    const vh = WORK_H();
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        const half = Math.round(vw / 2);
        return {
          ...w,
          prev: w.maximized ? w.prev : { x: w.x, y: w.y, w: w.w, h: w.h },
          x: side === "left" ? 0 : half,
          y: 0,
          w: half,
          h: vh,
          maximized: false,
          minimized: false,
        };
      }),
    );
    setActiveId(id);
  };

  const minimizAll = () => {
    setWindows((prev) => prev.map((w) => ({ ...w, minimized: true })));
    setActiveId(null);
  };
  const restoreAll = () => {
    setWindows((prev) => {
      const visible = prev.filter((w) => !w.minimized);
      if (visible.length > 0) return prev.map((w) => ({ ...w, minimized: true }));
      return prev.map((w, i) => ({ ...w, minimized: false, z: w.z + i }));
    });
    setActiveId(null);
  };

  const switchToNext = () => {
    const open = windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z);
    if (open.length === 0) return;
    const index = open.findIndex((w) => w.id === activeId);
    const next = open[(index + 1) % open.length];
    if (next) focusWindow(next.id);
  };

  const setWindowTitlePatch = (id: string, payload: Record<string, unknown>) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, payload: { ...w.payload, ...payload } } : w)));
  };

  const updateWindowRect = (id: string, rect: Partial<Rect>) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, ...rect } : w)));
  };

  const openMenu: OSApi["openMenu"] = (x, y, items, title, width = 238) => {
    setStartOpen(false);
    setPanel(null);
    const menuWidth = width + 16;
    const safeX = clamp(x, 8, window.innerWidth - menuWidth);
    const safeY = clamp(y, 8, window.innerHeight - 160);
    setMenu({ x: safeX, y: safeY, items, title, width });
    wakeLockRef.current = true;
  };

  const showPrompt: OSApi["showPrompt"] = (opts) => setDialog({ ...opts, kind: "prompt" });
  const showConfirm = (title: string, message: string, onConfirm: () => void, confirmLabel = "Continue") =>
    setDialog({ kind: "confirm", title, message, confirmLabel, danger: true, onConfirm: () => onConfirm() });
  const showInfo = (title: string, message: string, icon?: ReactNode) =>
    setDialog({ kind: "info", title, message, icon, confirmLabel: "Done" });

  const getNode = (id: string) => files.find((f) => f.id === id);
  const childrenOf = (parentId: string) => files.filter((f) => f.parentId === parentId);
  const getPath = (id: string): FsNode[] => {
    const path: FsNode[] = [];
    let current = files.find((f) => f.id === id);
    let guard = 0;
    while (current && guard < 30) {
      path.unshift(current);
      current = current.parentId ? files.find((f) => f.id === current?.parentId) : undefined;
      guard += 1;
    }
    return path;
  };
  const getFolderSize = (id: string): number => {
    const node = files.find((f) => f.id === id);
    if (!node) return 0;
    if (node.kind !== "folder") return node.size;
    return files.filter((f) => f.parentId === id).reduce((sum, f) => sum + getFolderSize(f.id), 0);
  };

  const createFolder: OSApi["createFolder"] = (parentId, name = "New folder") => {
    const parent = files.find((f) => f.id === parentId);
    const targetParent = parent?.kind === "folder" ? parentId : "desktop";
    const siblings = files.filter((f) => f.parentId === targetParent);
    let candidate = name.trim() || "New folder";
    let n = 2;
    while (siblings.some((f) => f.name.toLowerCase() === candidate.toLowerCase())) {
      candidate = `${name.trim() || "New folder"} (${n})`;
      n += 1;
    }
    const node: FsNode = {
      id: uid("folder"),
      name: candidate,
      kind: "folder",
      parentId: targetParent,
      size: 0,
      modified: Date.now(),
    };
    setFiles((prev) => [...prev, node]);
    return node.id;
  };

  const renameNode: OSApi["renameNode"] = (id, name) => {
    const node = files.find((f) => f.id === id);
    const trimmed = name.trim();
    if (!node || node.id === "home" || !trimmed) return false;
    const clash = files.some(
      (f) => f.parentId === node.parentId && f.id !== id && f.name.toLowerCase() === trimmed.toLowerCase(),
    );
    if (clash) {
      notify("Name already in use", "Choose a different name for this item.", { tone: "error" });
      return false;
    }
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, name: trimmed, modified: Date.now() } : f)));
    notify("Item renamed", `Renamed to “${trimmed}”.`, { tone: "success", silent: true });
    return true;
  };

  const deleteNode = (id: string) => {
    const root = files.find((f) => f.id === id);
    if (!root || root.id === "home" || root.parentId === null) {
      notify("Protected location", "This system folder cannot be deleted.", { tone: "error" });
      return;
    }
    const collected: FsNode[] = [];
    const walk = (nodeId: string) => {
      const n = files.find((f) => f.id === nodeId);
      if (!n) return;
      collected.push(n);
      files.filter((f) => f.parentId === nodeId).forEach((child) => walk(child.id));
    };
    walk(id);
    const size = collected.filter((n) => n.kind !== "folder").reduce((sum, n) => sum + n.size, 0);
    const item: TrashItem = {
      id: uid("trash"),
      rootId: id,
      name: root.name,
      kind: root.kind,
      originalParentId: root.parentId ?? "desktop",
      deletedAt: Date.now(),
      nodes: collected,
      size,
    };
    const ids = new Set(collected.map((n) => n.id));
    setFiles((prev) => prev.filter((n) => !ids.has(n.id)));
    setTrash((prev) => [item, ...prev]);
    notify("Moved to Recycle Bin", `“${root.name}” can be restored later.`);
  };

  const restoreTrash: OSApi["restoreTrash"] = (trashId) => {
    const item = trash.find((t) => t.id === trashId);
    if (!item) return;
    const parentExists = files.some((f) => f.id === item.originalParentId && f.kind === "folder");
    setFiles((prev) => [
      ...prev,
      ...item.nodes.map((n) =>
        n.id === item.rootId && !parentExists ? { ...n, parentId: "desktop" } : n,
      ),
    ]);
    setTrash((prev) => prev.filter((t) => t.id !== trashId));
    notify("Item restored", `“${item.name}” is available again.`, { tone: "success" });
  };

  const deleteForever = (trashId: string) => {
    const item = trash.find((t) => t.id === trashId);
    if (!item) return;
    setTrash((prev) => prev.filter((t) => t.id !== trashId));
    notify("Permanently deleted", `“${item.name}” was removed from the workspace.`);
  };

  const emptyTrash = () => {
    setTrash([]);
    notify("Recycle Bin emptied", "All deleted items were removed permanently.");
  };

  const updateFile = (id: string, patch: Partial<FsNode>) => {
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, ...patch } : f)));
  };

  const moveNode = (id: string, targetParentId: string): boolean => {
    const node = files.find((f) => f.id === id);
    const target = files.find((f) => f.id === targetParentId);
    if (!node || !target || target.kind !== "folder" || node.parentId === null || node.locked) return false;
    if (node.kind === "folder") {
      const targetPath = getPath(targetParentId);
      if (targetPath.some((item) => item.id === id)) {
        notify("Cannot move folder", "A folder cannot be moved inside itself.", { tone: "error", silent: true });
        return false;
      }
    }
    const clash = files.some(
      (f) => f.parentId === targetParentId && f.id !== id && f.name.toLowerCase() === node.name.toLowerCase(),
    );
    if (clash) {
      notify("Name already in use", "Rename the item before moving it here.", { tone: "error", silent: true });
      return false;
    }
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, parentId: targetParentId, modified: Date.now() } : f)));
    return true;
  };

  const duplicateNode = (id: string, targetParentId: string): string | null => {
    const root = files.find((f) => f.id === id);
    const target = files.find((f) => f.id === targetParentId);
    if (!root || !target || target.kind !== "folder" || root.kind === "folder" || root.locked) return null;
    const siblings = files.filter((f) => f.parentId === targetParentId);
    let name = `${root.name.replace(/(\.[^.]+)$/, "")} copy$1`;
    let n = 2;
    while (siblings.some((f) => f.name.toLowerCase() === name.toLowerCase())) {
      name = `${root.name.replace(/(\.[^.]+)$/, "")} copy ${n}$1`;
      n += 1;
    }
    const clone: FsNode = { ...root, id: uid("file"), parentId: targetParentId, name, modified: Date.now() };
    setFiles((prev) => [...prev, clone]);
    return clone.id;
  };

  const addFile: OSApi["addFile"] = (parentId, name, kind, options = {}) => {
    const parent = files.find((f) => f.id === parentId && f.kind === "folder") ?? files.find((f) => f.id === "home");
    const targetParent = parent?.id ?? "home";
    const siblings = files.filter((f) => f.parentId === targetParent);
    let candidate = name.trim() || "Imported file";
    let n = 2;
    while (siblings.some((f) => f.name.toLowerCase() === candidate.toLowerCase())) {
      const dot = candidate.lastIndexOf(".");
      candidate = dot > 0 ? `${name.slice(0, dot)} (${n})${name.slice(dot)}` : `${name} (${n})`;
      n += 1;
    }
    const node: FsNode = {
      id: uid("file"),
      name: candidate,
      kind,
      parentId: targetParent,
      size: options.size ?? options.content?.length ?? 0,
      modified: Date.now(),
      content: options.content,
      src: options.src,
    };
    setFiles((prev) => [...prev, node]);
    return node.id;
  };

  const pushExportedFile = (file: ExportedFile) => {
    setExportedFiles((prev) => [file, ...prev.filter((item) => item.name !== file.name)].slice(0, 40));
  };

  const addNote = () => {
    const note: Note = {
      id: uid("note"),
      title: "Untitled note",
      body: "",
      modified: Date.now(),
      pinned: false,
      color: ["#5b9dff", "#34d399", "#f7c45c", "#f0729b", "#a78bfa"][notes.length % 5],
    };
    setNotes((prev) => [note, ...prev]);
    return note.id;
  };
  const updateNote = (id: string, patch: Partial<Note>) => {
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, ...patch, modified: Date.now() } : n)));
  };
  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    notify("Note deleted", "The note was removed from your workspace.", { tone: "success" });
  };

  const setTheme = (theme: Settings["theme"]) => updateSettings({ theme });
  const setWallpaper = (id: WallpaperId) => updateSettings({ wallpaper: id });
  const resetSettings = () => setSettings({ ...DEFAULT_SETTINGS, taskbarPins: [...DEFAULT_PINS] });
  const togglePin = (appId: AppId) => {
    setSettings((prev) => {
      const isPinned = prev.taskbarPins.includes(appId);
      return {
        ...prev,
        taskbarPins: isPinned
          ? prev.taskbarPins.filter((id) => id !== appId)
          : [...prev.taskbarPins, appId].slice(0, 9),
      };
    });
  };

  const openPhoneController = () => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("controller", "1");
      url.hash = "";
      const popup = window.open(url.toString(), "kkdex-phone-controller", "width=430,height=900,menubar=no,toolbar=no");
      if (!popup) {
        notify("Pop-up blocked", "Allow pop-ups for this page, then open Phone Controller from App Center.", { tone: "error" });
      }
    } catch {
      notify("Controller unavailable", "The controller view could not be opened in this environment.", { tone: "error" });
    }
  };

  const restartDesktop = () => {
    notify("Restarting session", "Your workspace is being reloaded.");
    window.setTimeout(() => window.location.reload(), 450);
  };

  const factoryReset = () => {
    ["kkdex.settings", "kkdex.files", "kkdex.trash", "kkdex.notes", "kkdex.notifications", "kkdex.recentApps"].forEach((key) =>
      localStorage.removeItem(key),
    );
    window.location.reload();
  };

  const lock = () => {
    setWindows((prev) => prev.map((w) => ({ ...w, minimized: true })));
    setActiveId(null);
    setStartOpen(false);
    setPanel(null);
    setMenu(null);
    setLocked(true);
  };
  const unlock = () => setLocked(false);

  const api: OSApi = {
    windows,
    activeWindow,
    launch,
    closeWindow,
    minimizeWindow,
    toggleMaximize,
    restoreWindow,
    focusWindow,
    minimizAll,
    restoreAll,
    snapWindow,
    switchToNext,
    setWindowTitlePatch,
    updateWindowRect,
    settings,
    updateSettings,
    setTheme,
    setWallpaper,
    resetSettings,
    togglePin,
    files,
    trash,
    getNode,
    childrenOf,
    getPath,
    getFolderSize,
    createFolder,
    renameNode,
    deleteNode,
    restoreTrash,
    deleteForever,
    emptyTrash,
    updateFile,
    duplicateNode,
    moveNode,
    addFile,
    exportedFiles,
    pushExportedFile,
    notes,
    addNote,
    updateNote,
    deleteNote,
    notifications,
    notify,
    dismissNotification,
    clearNotifications,
    markNotificationsRead,
    toasts,
    dismissToast,
    launchHistory,
    startOpen,
    setStartOpen,
    startQuery,
    setStartQuery,
    panel,
    setPanel,
    menu,
    openMenu,
    closeMenu,
    dialog,
    closeDialog,
    showPrompt,
    showConfirm,
    showInfo,
    locked,
    lock,
    unlock,
    taskViewOpen,
    setTaskViewOpen,
    bootTime,
    openPhoneController,
    restartDesktop,
    factoryReset,
    soundClick,
  };

  // viewportTick intentionally participates in re-render so size-derived UI stays fresh.
  void viewportTick;

  return <OSContext.Provider value={api}>{children}</OSContext.Provider>;
}
