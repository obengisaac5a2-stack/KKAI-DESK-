import { APP_METAS } from "./appMeta";
import type { AppId, RegisteredApp } from "./types";
import FilesApp from "./apps/Files";
import SettingsApp from "./apps/Settings";
import { CalculatorApp, NotesApp, TerminalApp } from "./apps/productivity";
import { BrowserApp, GalleryApp, KKAiApp } from "./apps/media";
import { AppCenterApp, PhoneApp, RecycleBinApp, ThisPcApp } from "./apps/system";
import { ArchiveApp, DeveloperApp, DownloadsApp, MediaPlayerApp, PdfViewerApp } from "./apps/extended";

export const REGISTRY: Record<AppId, RegisteredApp> = {
  thispc: { ...APP_METAS.thispc, Component: ThisPcApp },
  files: { ...APP_METAS.files, Component: FilesApp },
  browser: { ...APP_METAS.browser, Component: BrowserApp },
  ai: { ...APP_METAS.ai, Component: KKAiApp },
  appcenter: { ...APP_METAS.appcenter, Component: AppCenterApp },
  settings: { ...APP_METAS.settings, Component: SettingsApp },
  gallery: { ...APP_METAS.gallery, Component: GalleryApp },
  notes: { ...APP_METAS.notes, Component: NotesApp },
  calculator: { ...APP_METAS.calculator, Component: CalculatorApp },
  terminal: { ...APP_METAS.terminal, Component: TerminalApp },
  recycle: { ...APP_METAS.recycle, Component: RecycleBinApp },
  phone: { ...APP_METAS.phone, Component: PhoneApp },
  downloads: { ...APP_METAS.downloads, Component: DownloadsApp },
  media: { ...APP_METAS.media, Component: MediaPlayerApp },
  pdf: { ...APP_METAS.pdf, Component: PdfViewerApp },
  archive: { ...APP_METAS.archive, Component: ArchiveApp },
  developer: { ...APP_METAS.developer, Component: DeveloperApp },
};
