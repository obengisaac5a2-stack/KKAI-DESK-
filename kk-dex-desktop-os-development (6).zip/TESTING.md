# KK DEX — Test Report

## Scope of this report

The web desktop was executed in headless Chromium at **1440×900** and **1024×768**, plus a second browser page for the phone controller. The Android module was **not compiled or run** in this environment (no Android SDK/emulator available here), so no APK exists in this deliverable and no Android device result is claimed.

## Desktop and window manager — PASS

| Test | Result |
| --- | --- |
| Desktop fills the available viewport | PASS |
| Desktop uses vector icons, no emoji | PASS (Lucide SVG icons) |
| Desktop icon single-click selection | PASS |
| Desktop icon double-click opens application | PASS |
| Desktop icon right-click context menu | PASS |
| Desktop icon drag and persistent slot | PASS (localStorage) |
| New folder via desktop context menu | PASS |
| Multiple applications open simultaneously | PASS |
| Windows open at sensible floating size, not fullscreen | PASS |
| Window drag | PASS |
| Resize from all 8 edges/corners | PASS (tested via SE handle and code path for all 8) |
| Minimize and restore from taskbar | PASS |
| Maximize and restore | PASS |
| Close window | PASS |
| Focus / z-order / taskbar active indicator | PASS |
| Task view | PASS |
| Show desktop via Win+D (twice) | PASS (fixed after regression test) |
| Alt+F4 close active | PASS |
| Start search, launch | PASS |
| Right-click menus close with Escape | PASS |
| Wallpaper + theme + accent changes | PASS |
| Notes auto-save persistence | PASS |
| Calculator arithmetic (7 + 3 = 10) | PASS |
| Terminal workspace commands (`help`, `ls`, `mkdir`, etc.) | PASS |
| Icon drag + desktop layout at 900px height | PASS (12 apps + desktop file) |
| No uncaught console/page errors in tested flows | PASS |

## Applications — PASS where tested

| App | Test | Result |
| --- | --- | --- |
| Files | Navigation, selection, preview, search, rename/new folder paths | PASS |
| Files → Android device | Honest SAF-unavailable state in browser | PASS |
| Files → Android device | SAF contract with simulated native bridge: authorize folder, list file | PASS |
| Browser | Tabs, start page, URL handling, external-open escape hatch | PASS (site embedding depends on CSP) |
| KK AI | Local workspace summary and app commands; no fake model claim | PASS |
| Developer | Real JavaScript execution in Worker (`sum 40`) | PASS |
| Developer → Android apps | Discovery and launch with simulated native bridge | PASS |
| Downloads | Real browser file import (`test-tone.wav`) into workspace | PASS |
| Archive Manager | Open real ZIP, list entries, extract to Downloads | PASS |
| PDF Viewer | Open real PDF file and instantiate PDF object | PASS (rendering depends on WebView PDF support) |
| Media Player | Workspace and direct-URL UI; actual playback requires real media | PARTIAL (fixtures tested import only) |
| Gallery | Local image grid, viewer, favorites | PASS |
| App Center | App listing, pin/unpin | PASS |
| Settings | Sections, wallpaper, theme, accent, resets | PASS |
| This PC | Storage and device overview | PASS |
| Recycle Bin | Delete, restore, empty | PASS (workspace items) |
| Phone Controller | Link, touchpad pointer, click, text insertion, app launch | PASS (two same-origin pages) |

## Android native integration — NOT VERIFIED

The starter module contains Kotlin code for SAF, MediaStore downloads, PackageManager discovery/launch, `Presentation` external display, and guarded file operations. It must be built and device-tested before being described as working. See `android/README.md` for exact gaps.

## Known failures / remaining work

- No APK is produced here; GitHub Actions workflow is provided but unverified.
- Controller-to-desktop pointer transport across separate Android WebViews is not implemented natively. The current channel works when pages share the same JS process/origin. Android host event forwarding is required for all devices.
- Controller-native file transfer to the TV is not wired; desktop Files has working SAF import.
- No Python/Node/Git/shell runtime is integrated; those commands are explicitly refused.
- Browser embedding is site-dependent; external open is offered.
- The Starter uses `Presentation`, which many phones limit to system mirrors or refuse for third-party apps. Device-specific behavior must be tested.
