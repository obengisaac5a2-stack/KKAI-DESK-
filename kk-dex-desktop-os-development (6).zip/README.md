# KK DEX

KK DEX is a React/Vite desktop environment designed for an external TV or monitor, with a separate phone controller interface.

## Run the desktop

```bash
npm install
npm run dev
```

- Desktop: `/`
- Phone controller: `/?controller=1`
- Explicit desktop mode on a phone: `/?desktop=1`

`npm run build` creates a single-file production bundle in `dist/`. Serve the whole `dist/` directory so `/wallpapers` and `/gallery` assets resolve.

## What is implemented

- Floating window manager: drag, resize from all edges/corners, minimize, maximize, restore, close, snap, focus/z-order, Alt+Tab, taskbar state, task view.
- Desktop icons with selection, double-click, right-click, drag-to-arrange, and persistence.
- Start menu with search, pinned/all apps, recent apps, profile, power options.
- Taskbar, notifications, quick settings, calendar, volume/network/battery panels, lock screen.
- Real functional apps: Files, Notes, Calculator, Browser, Gallery, Terminal, App Center, Settings, This PC, Recycle Bin, Phone Controller, Downloads, Media Player, PDF Viewer, Archive Manager, Developer.
- Persistent workspace files/notes/settings and a working Recycle Bin.
- Real JS execution in a Web Worker; archive ZIP inspection/extraction with JSZip; browser/local media playback; Excel-style safe calculator parser.
- Browser import of user-selected local files (genuine File API import).
- Android native bridge adapter (`window.KKDexNative`) with SAF, MediaStore downloads, file operations, installed-app discovery/launch, and native runtime status.
- Separate phone controller with touchpad, gestures, scroll, drag mode, keyboard, shortcuts, app launching, and link status.
- `KKDexAPI` receiver preserves the original bridge function names.
- Starter Android host module in `android/` plus an APK workflow.

## Important limitations

- A normal browser cannot read Android shared storage. Device storage therefore requires the `KKDexNative` Android host, and the UI says so explicitly.
- No APK was built or tested in this environment. See `android/README.md`.
- The Android module is a starter: real device testing, controller-to-desktop file transfer wiring, and runtime integration remain.
- No AI model backend is connected. KK AI only performs deterministic local workspace actions.
- The terminal only modifies the KK DEX workspace; native shell/Python/Node/Git commands are refused unless a verified native runtime advertises support.
- Third-party Android app activities generally open on the phone, not the TV. The UI reports actual launch behavior instead of claiming TV placement.
- Sample audio/video metadata exists, but workspace media samples have no real media bytes. Import real media or use authorized Android files.

## Validation performed

Headless Chromium at 1440×900 and 1024×768 was used to verify the desktop, multiple windows, drag, eight-direction resize handles, maximize/restore, minimize/restore, taskbar switching, Start search, context menus, wallpaper/theme changes, Notes auto-save, calculator arithmetic, terminal workspace commands, icon dragging, folder creation, gallery viewer, App Center, and bridge pointer/theme calls. A two-page test verified controller linking, pointer movement, text insertion into a focused Notes field, and app launch on the desktop. No browser console errors were observed.

See `android/README.md` for the Native/APK status and testing gaps.
