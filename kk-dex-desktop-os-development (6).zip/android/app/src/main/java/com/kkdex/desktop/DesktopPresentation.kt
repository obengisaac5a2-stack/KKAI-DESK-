package com.kkdex.desktop

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

/**
 * The actual TV/monitor desktop. This is hosted separately from the phone controller
 * page and receives the same trusted KKDexNative bridge.
 */
class DesktopPresentation(
    outerContext: Context,
    display: Display,
    private val hostActivity: android.app.Activity,
    private val fileAccess: FileAccessManager,
) : Presentation(outerContext, display) {

    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = ViewGroup.LayoutParams.MATCH_PARENT
        val view = WebView(context)
        webView = view
        view.setBackgroundColor(Color.parseColor("#070C15"))
        view.layoutParams = ViewGroup.LayoutParams(root, root)
        setupWebView(view, "desktop")
        setContentView(view)
        view.loadUrl("$ASSET_ORIGIN/assets/index.html?desktop=1")
    }

    private fun setupWebView(view: WebView, role: String) {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            // Allow the bundle's absolute /wallpapers and /gallery asset references.
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            databaseEnabled = false
        }
        view.addJavascriptInterface(KKdexBridge(hostActivity, { webView }, fileAccess, role), "KKDexNative")
        view.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return !(url.host == "appassets.androidplatform.net" || url.scheme == "https" || url.scheme == "http")
            }
        }
    }

    override fun dismiss() {
        Handler(Looper.getMainLooper()).post {
            webView?.loadUrl("about:blank")
            webView?.removeAllViews()
            webView?.destroy()
            webView = null
        }
        super.dismiss()
    }

    companion object {
        const val ASSET_ORIGIN = "https://appassets.androidplatform.net"
    }
}
