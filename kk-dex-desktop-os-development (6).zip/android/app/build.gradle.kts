plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kkdex.desktop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kkdex.desktop"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        debug {
            isDebuggable = true
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // Copies the production single-file desktop build into the WebView assets.
    val desktopBuildDir = rootProject.projectDir.parentFile.resolve("dist")
    tasks.register<Copy>("syncDesktopAssets") {
        from(desktopBuildDir)
        into(layout.projectDirectory.dir("src/main/assets"))
        include("index.html", "wallpapers/**", "gallery/**")
    }
    tasks.named("preBuild") {
        dependsOn("syncDesktopAssets")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
