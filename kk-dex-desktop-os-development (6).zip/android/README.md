# KK DEX Android host (starter integration)

This module wraps the built KK DEX desktop bundle in an Android app:

- **Phone:** `MainActivity` hosts the controller page (`?controller=1`).
- **TV / monitor:** when Android reports a secondary display, `DesktopPresentation` hosts the actual desktop (`?desktop=1`) on that display using `Presentation`.
- **Bridge:** `KKdexBridge` is added as `window.KKDexNative` only to bundled pages loaded through `WebViewAssetLoader`.

> **Build status:** this module has **not** been compiled, installed, or device-tested in this environment. No APK is included. The GitHub Actions workflow compiles it on a runner with the Android SDK; a green workflow run is required before claiming an APK.

## Build the web bundle first

From the repository root:

```bash
npm ci
npm run build
```

The Gradle task `syncDesktopAssets` copies `dist/index.html`, `dist/wallpapers`, and `dist/gallery` into `android/app/src/main/assets/` before the Android build.

## Build the APK

From `android/` using Gradle 8.10.2 and JDK 17:

```bash
gradle assembleDebug
```

Or push to GitHub / run **Build KK DEX debug APK** manually. The workflow uploads `android/app/build/outputs/apk/debug/app-debug.apk` as `kkdex-debug-apk`.

To install on a device:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

## Native bridge contract

The Kotlin bridge exposes the methods consumed by `src/os/native.ts`:

| Area | Methods |
| --- | --- |
| Capabilities | `getCapabilities`, `getDisplayInfo`, `requestStoragePermission` |
| SAF | `pickFiles`, `pickFolder`, `listDirectory` |
| File I/O | `readFile`, `writeFile` |
| File operations | `createFolder`, `renameFile`, `deleteFile`, `copyFile`, `moveFile` |
| Downloads | `getDownloads` |
| Android apps | `getInstalledApps`, `launchAndroidApp`, `openWith` |
| Runtime | `exec` (reports unavailable until a verified runtime is integrated) |

Methods may return a JSON string or asynchronously call:

```js
window.KKDexNativeResult(requestId, JSON.stringify(payload))
```

The adapter supports both shapes. `pickFiles` and `pickFolder` are asynchronous because they launch Android's SAF picker.

### SAF permission flow

1. The desktop or controller calls `KKDexNative.pickFolder(requestId)`.
2. Android opens the system document-tree picker.
3. `FileAccessManager` retains the persistable read grant.
4. The selected `content://` tree URI is returned to JavaScript.
5. `listDirectory(uri)` uses `DocumentFile` and `ContentResolver` to enumerate only that authorized tree.
6. Reads use `ContentResolver.openInputStream`; writes require a write grant from the provider.

The bridge never opens arbitrary filesystem paths and does not expose `MANAGE_EXTERNAL_STORAGE`.

## Android app discovery and launch

`getInstalledApps()` queries launcher activities through PackageManager. Manifest `<queries>` is declared for Android 11+ visibility.

`launchAndroidApp(packageName)` uses the package's launch intent and reports:

- the app was launched on the **phone**, with an explanation;
- or a clear error if Android has no launch activity.

Most consumer Android devices do not run arbitrary third-party activities on secondary displays. KK DEX therefore does not claim that an Android app is running on the TV when Android launched it on the phone. Vendor desktop modes may offer additional support but require device-specific integration.

## Runtime execution

No Python, Node.js, Git, or shell runtime is bundled. `exec()` returns a clear unsupported error and `getCapabilities()` reports those runtimes as false. The desktop Developer app always provides real JavaScript execution in an isolated Web Worker.

Do not enable `exec()` by forwarding arbitrary commands from an unprivileged origin. If a runtime is added later, run it in an app-private directory, validate command ownership, enforce timeouts and quotas, and never expose a generic shell to remote content.

## Known integration gaps

- External-display behavior varies by OEM. Test `Presentation` on the target phone + TV with Android's `dumpsys display`.
- MediaStore download queries can be restricted by Android/OEM policy; SAF remains the reliable user-authorized path.
- The phone controller and TV desktop are separate WebViews. Pointer/keyboard input currently uses the existing `KKDexAPI` / BroadcastChannel path; on separate processes, the Android host must forward those events or enable a same-process WebView configuration.
- There is no background service, boot persistence, APK auto-update, or signing configuration in this starter.
- The controller's Android file picker UI is not yet wired to transfer selected files into the desktop WebView. The desktop Files app has the working SAF import flow.
- Web browser embedding depends on site CSP/X-Frame-Options; the desktop offers external opening when embedding is blocked.
- No real hardware or emulator build has been executed here.
