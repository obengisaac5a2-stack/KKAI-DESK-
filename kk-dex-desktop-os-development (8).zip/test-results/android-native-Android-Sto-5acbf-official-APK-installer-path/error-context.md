# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: android-native.spec.ts >> Android Storage allows multi-selection, file details and the official APK installer path
- Location: tests/android-native.spec.ts:342:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('dialog', { name: 'Install this Android APK?', exact: true })
Expected substring: "cannot install silently"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('dialog', { name: 'Install this Android APK?', exact: true }) with timeout 5000ms
  - waiting for getByRole('dialog', { name: 'Install this Android APK?', exact: true })

```

```yaml
- text: KK DEX GAMING DESKTOP
- paragraph: A bigger perspective.
- button "This PC"
- button "Files"
- button "Browser"
- button "KK AI"
- button "App Center"
- button "Settings"
- button "Gallery"
- button "Notes"
- button "Gaming Centre"
- button "Storage"
- button "Calculator"
- button "Terminal"
- button "Recycle Bin"
- region "Files window":
  - text: Files
  - button "Minimize Files"
  - button "Maximize Files"
  - button "Close Files"
  - button "Back" [disabled]
  - button "Forward" [disabled]
  - button "Up one level" [disabled]
  - button "Refresh files"
  - text: Home
  - textbox "Search files":
    - /placeholder: Search home
  - complementary:
    - button "Home"
    - text: Quick access
    - button "Desktop"
    - button "Downloads"
    - button "Documents"
    - button "Pictures"
    - button "Music"
    - button "Videos"
    - button "This PC"
    - button "Workspace"
    - button "Android storage"
    - button "Network"
    - text: KK DEX Workspace Stored on this device 2.8 KB used
  - button "New"
  - button "Cut selected" [disabled]
  - button "Copy selected" [disabled]
  - button "Paste files" [disabled]
  - button "Rename selected" [disabled]
  - button "Delete selected" [disabled]
  - button "Sort"
  - button "Switch to grid view"
  - button "More file options"
  - main:
    - heading "Welcome home." [level=1]
    - paragraph: Everything you need, right where you left it.
    - heading "Quick access" [level=3]
    - button "Documents 3 items":
      - strong: Documents
      - text: 3 items
    - button "Downloads 1 items":
      - strong: Downloads
      - text: 1 items
    - button "Pictures 3 items":
      - strong: Pictures
      - text: 3 items
    - button "Projects 1 items":
      - strong: Projects
      - text: 1 items
    - heading "Recent files" [level=3]
    - text: From your local workspace
    - grid "Files":
      - button "Name"
      - text: Location
      - button "Modified"
      - text: Size
      - row "Getting started.md Documents Nov 13 414 B"
      - row "Project brief.md Projects Nov 13 290 B"
      - row "Alpine morning.jpg Pictures Nov 13 --"
      - row "Ocean air.jpg Pictures Nov 13 --"
  - text: 4 items Local workspace
  - button "List view"
  - button "Grid view"
- region "Android Storage window":
  - text: Android Storage
  - button "Minimize Android Storage"
  - button "Maximize Android Storage"
  - button "Close Android Storage"
  - button "Android storage locations"
  - button "Refresh Android folder"
  - text: Android
  - strong: Mock folder
  - textbox "Search Android storage":
    - /placeholder: Search this folder
  - button "Open folder…"
  - button "Select files"
  - button "New folder"
  - button "Rename"
  - button "Copy"
  - button "Move"
  - button "Delete"
  - button "Export"
  - button "Share"
  - button "Import"
  - button "Media permissions"
  - text: Name Type Modified Size
  - strong: Subfolder
  - text: SAF document Folder Nov 13, 2026, 4:31 PM —
  - button "Open Subfolder"
  - strong: Phone archive.zip
  - text: SAF document application/zip Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone archive.zip"
  - strong: Phone audio.mp3
  - text: SAF document audio/mpeg Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone audio.mp3"
  - strong: Phone game.apk
  - text: SAF document application/vnd.android.package-archive Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone game.apk"
  - strong: Phone note.txt
  - text: SAF document text/plain Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone note.txt"
  - strong: Phone PDF.pdf
  - text: SAF document application/pdf Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone PDF.pdf"
  - strong: Phone photo.jpg
  - text: SAF document image/jpeg Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone photo.jpg"
  - strong: Phone video.mp4
  - text: SAF document video/mp4 Nov 13, 2026, 4:31 PM 321 B
  - button "Open Phone video.mp4"
  - text: Access is limited to Android-authorized URIs 8 visible items · 1 selected · 321 B application/vnd.android.package-archive
- region "Archive Manager window":
  - text: Archive Manager
  - button "Minimize Archive Manager"
  - button "Maximize Archive Manager"
  - button "Close Archive Manager"
  - button "Open from Android"
  - button "Open local ZIP"
  - text: ZIP · 40 MB viewer limit
  - strong: No archive open
  - text: Inspect archive contents without silently extracting files.
  - heading "Open an archive." [level=2]
  - paragraph: Choose a ZIP through Android's picker or a local browser file. KK DEX lists real entries and writes extracted files through an actual download or Android document picker.
  - text: No archive loaded Android export available
- contentinfo:
  - button "KK DEX Desktop":
    - strong: KK DEX
    - text: Desktop
  - button "Start menu"
  - button "Search desktop"
  - button "Task view"
  - button "Files - running"
  - button "Browser"
  - button "Gaming Centre"
  - button "KK AI"
  - button "App Center"
  - button "Notes"
  - button "Settings"
  - button "Android Storage - running"
  - button "Archive Manager - running"
  - button "Quick settings"
  - button "Network, volume and display settings"
  - button "Open calendar": 4:31 PM 11/13/2026
  - text: BAL
  - button "Notification center"
  - button "Show desktop"
- dialog "Could not read the shared archive":
  - button "Close dialog"
  - heading "Could not read the shared archive" [level=2]
  - paragraph: This is not an APK.
  - button "Got it"
```

# Test source

```ts
  252 |   await page.goto("/?controller");
  253 |   await expect(page.locator(".controller-connection")).toContainText("Desktop connected to TV");
  254 |   await page.getByRole("button", { name: /Send folder to TV/ }).click();
  255 |   await expect(page.locator(".controller-notice")).toContainText('opening that folder in Android Storage');
  256 |   await page.getByRole("button", { name: /Android apps/ }).click();
  257 |   await expect(page.getByText("Mock Notes")).toBeVisible();
  258 |   await page.getByText("Mock Notes").click();
  259 |   await expect(page.locator(".controller-apps-sheet")).toHaveCount(0);
  260 |   const calls = await page.evaluate(() => (window as unknown as { __nativeCalls: { method: string }[] }).__nativeCalls.map((call) => call.method));
  261 |   expect(calls).toEqual(expect.arrayContaining(["chooseFolderForDesktop", "getInstalledApps", "launchApp", "displayStatus"]));
  262 | });
  263 | 
  264 | 
  265 | test("Gaming Centre reads real game packages and reports launch routing", async ({ page }) => {
  266 |   await installMockBridge(page);
  267 |   await page.reload();
  268 |   await open(page, "gaming");
  269 |   await expect(page.getByText("Mock Racing Game")).toBeVisible();
  270 |   await expect(page.locator(".game-card")).toHaveCount(1);
  271 |   await page.getByRole("button", { name: "Launch Mock Racing Game", exact: true }).click();
  272 |   await expect(page.getByRole("status")).toContainText("Android accepted a launch request");
  273 |   await page.locator(".pc-head").scrollIntoViewIfNeeded();
  274 |   await expect(page.locator(".compatibility-card").filter({ hasText: "Windows .exe" })).toContainText("REQUIRES RUNTIME");
  275 | });
  276 | 
  277 | test("Gaming Centre device capability is labelled honestly and modes remain desktop-only", async ({ page }) => {
  278 |   await installMockBridge(page);
  279 |   await page.reload();
  280 |   await open(page, "gaming");
  281 |   await page.locator(".gaming-tabs").getByRole("button", { name: "Performance", exact: true }).click();
  282 |   await expect(page.getByText("Mock Adreno renderer", { exact: false })).toBeVisible();
  283 |   await expect(page.getByText("cannot overclock", { exact: false })).toBeVisible();
  284 |   await page.getByRole("button", { name: /Performance Fewer blur effects/ }).click();
  285 |   await expect(page.getByRole("dialog", { name: "Performance mode enabled", exact: true })).toContainText("cannot overclock");
  286 |   expect(await page.evaluate(() => document.documentElement.dataset.performance)).toBe("performance");
  287 | });
  288 | 
  289 | test("Storage manager shows real capacity categories permission states and configurable location", async ({ page }) => {
  290 |   await installMockBridge(page);
  291 |   await page.reload();
  292 |   await open(page, "storagemanager");
  293 |   await expect(page.getByText("119.2 GB", { exact: false })).toBeVisible();
  294 |   await expect(page.getByText("59.6 GB", { exact: false }).first()).toBeVisible();
  295 |   await expect(page.locator(".storage-category-grid")).toContainText("Applications");
  296 |   await expect(page.locator(".storage-category-grid")).toContainText("Access not granted");
  297 |   await page.getByRole("button", { name: "Grant", exact: true }).click();
  298 |   await expect(page.getByRole("status")).toContainText("Android granted");
  299 |   await page.getByRole("textbox", { name: "Download subfolder" }).fill("My Downloads");
  300 |   await page.locator(".storage-folder-edit button").click();
  301 |   await expect(page.locator('[data-app="storagemanager"]').getByRole("status")).toContainText("Download location updated");
  302 | });
  303 | 
  304 | test("Downloads expose real progress cancel retry location and APK installer messaging", async ({ page }) => {
  305 |   await installMockBridge(page);
  306 |   await page.reload();
  307 |   await open(page, "downloads");
  308 |   await expect(page.getByText("KK DEX test.pdf")).toBeVisible();
  309 |   await expect(page.getByText("Internal storage/Download/KK DEX", { exact: false })).toBeVisible();
  310 |   await expect(page.locator(".download-actions")).toBeVisible();
  311 |   await expect(page.locator(".download-row")).toContainText("successful");
  312 | });
  313 | 
  314 | test("Browser launches the real native engine and persists bookmarks and history", async ({ page }) => {
  315 |   await installMockBridge(page);
  316 |   await page.reload();
  317 |   await open(page, "browser");
  318 |   await expect(page.locator(".browser-engine-strip")).toContainText("NATIVE ANDROID WEBVIEW ENGINE");
  319 |   await page.getByRole("textbox", { name: "Browser address", exact: true }).fill("youtube.com");
  320 |   await page.getByRole("button", { name: "Go", exact: true }).click();
  321 |   await expect(page.getByText("The desktop browser is active.", { exact: true })).toBeVisible();
  322 |   const call = await page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.find((call) => call.method === "openBrowser"));
  323 |   expect(call!.args).toMatchObject({ url: "https://youtube.com", desktopMode: true });
  324 |   await page.getByRole("button", { name: "Browsing history", exact: true }).click();
  325 |   await expect(page.locator(".browser-popover")).toContainText("youtube.com");
  326 |   await page.getByRole("button", { name: "Close browser panel", exact: true }).click();
  327 |   await page.getByRole("button", { name: "Bookmark this address", exact: true }).click();
  328 |   await page.getByRole("button", { name: "Remove bookmark", exact: true }).click();
  329 | });
  330 | 
  331 | test("Quick settings open the real Android system panels through the bridge", async ({ page }) => {
  332 |   await installMockBridge(page);
  333 |   await page.reload();
  334 |   await page.getByRole("button", { name: "Network, volume and display settings" }).click();
  335 |   await page.locator(".quick-toggles").getByRole("button", { name: /^Network/ }).click();
  336 |   await expect.poll(() => page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.some((call) => call.method === "openSystemPanel" && call.args.panel === "wifi"))).toBe(true);
  337 |   await page.locator(".quick-toggles").getByRole("button", { name: /Bluetooth/ }).click();
  338 |   await expect.poll(() => page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.some((call) => call.method === "openSystemPanel" && call.args.panel === "bluetooth"))).toBe(true);
  339 | });
  340 | 
  341 | 
  342 | test("Android Storage allows multi-selection, file details and the official APK installer path", async ({ page }) => {
  343 |   await installMockBridge(page, { readFile: "This is not an APK." });
  344 |   await page.reload();
  345 |   await open(page, "storage");
  346 |   await page.getByRole("button", { name: /Authorize a folder/ }).click();
  347 |   await expect(page.getByText("Phone game.apk")).toBeVisible();
  348 |   await page.getByText("Phone note.txt").click();
  349 |   await page.getByText("Phone game.apk").click({ modifiers: ["Control"] });
  350 |   await expect(page.locator(".android-storage-footer")).toContainText("2 selected");
  351 |   await page.getByText("Phone game.apk").dblclick();
> 352 |   await expect(page.getByRole("dialog", { name: "Install this Android APK?", exact: true })).toContainText("cannot install silently");
      |                                                                                              ^ Error: expect(locator).toContainText(expected) failed
  353 |   await page.getByRole("button", { name: "Open Android installer", exact: true }).click();
  354 |   await expect.poll(() => page.evaluate(() => (window as unknown as { __nativeCalls: { method: string; args: Record<string, unknown> }[] }).__nativeCalls.some((call) => call.method === "installApkUri"))).toBe(true);
  355 | });
  356 | 
```