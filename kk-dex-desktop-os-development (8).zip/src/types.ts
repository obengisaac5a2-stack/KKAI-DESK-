import type { ReactNode } from "react";

export type AppId =
  | "pc"
  | "files"
  | "browser"
  | "ai"
  | "store"
  | "settings"
  | "gallery"
  | "notes"
  | "editor"
  | "storage"
  | "video"
  | "music"
  | "pdf"
  | "downloads"
  | "sysinfo"
  | "appmanager"
  | "archives"
  | "gaming"
  | "storagemanager"
  | "calculator"
  | "terminal"
  | "bin";
export type Rect = { x: number; y: number; width: number; height: number };
export type DesktopWindow = Rect & {
  id: string;
  appId: AppId;
  title: string;
  z: number;
  minimized: boolean;
  maximized: boolean;
  restoreRect?: Rect;
  payload?: string;
};
export type AppDefinition = {
  id: AppId;
  name: string;
  description: string;
  category: string;
  defaultSize: { width: number; height: number };
  minSize: { width: number; height: number };
  launchBehavior: "singleton";
  closeBehavior: "preserve-data";
};
export type FileEntry = {
  id: string;
  name: string;
  parent: string;
  kind: "folder" | "text" | "image" | "file";
  content?: string;
  size: number;
  modified: string;
  deleted?: boolean;
  originalParent?: string;
};
export type Note = {
  id: string;
  title: string;
  content: string;
  updated: string;
};
export type Preferences = {
  theme: "light" | "dark";
  wallpaper: "nexus" | "alpine" | "coast" | "dunes";
  volume: number;
  muted: boolean;
  brightness: number;
  pointerSpeed: number;
  textScale: number;
  reducedMotion: boolean;
  showIcons: boolean;
  iconSize: "small" | "medium";
  performanceMode: "performance" | "balanced" | "visual";
  downloadSubfolder: string;
};
export type SystemNotification = {
  id: string;
  title: string;
  message: string;
  time: number;
  read: boolean;
  appId?: AppId;
};
export type MenuItem = {
  label: string;
  icon?: ReactNode;
  shortcut?: string;
  action?: () => void;
  danger?: boolean;
  disabled?: boolean;
  divider?: boolean;
  children?: MenuItem[];
};
export type ContextMenuState = {
  x: number;
  y: number;
  items: MenuItem[];
} | null;
export type Panel =
  "start" | "search" | "quick" | "calendar" | "notifications" | "tasks" | null;

export type InputMessage = { type: string; [key: string]: unknown };
export type ChatMessage = { role: "user" | "assistant"; content: string };
export type AndroidFileEntry = {
  uri: string;
  treeUri?: string;
  name: string;
  mime: string;
  size: number;
  modified: number;
  isDirectory: boolean;
  source: "saf" | "media" | "picked";
};
export type AndroidRoot = {
  id: string;
  uri: string;
  kind: "tree" | "media";
  name: string;
  mediaType?: "images" | "videos" | "audio" | "downloads";
  description?: string;
};
export type InstalledAndroidApp = {
  packageName: string;
  label: string;
  iconUrl?: string;
  system: boolean;
  category?: string;
  isGame?: boolean;
};
export type AndroidDownload = {
  id: number;
  title: string;
  description: string;
  mime: string;
  size: number;
  downloaded: number;
  status: "pending" | "running" | "paused" | "successful" | "failed" | "other";
  localUri?: string;
  timestamp: number;
  reason?: number;
  reasonText?: string;
  speed?: number;
};
export type AndroidDisplayStatus = {
  connected: boolean;
  displayId: number;
  displayName: string;
  width: number;
  height: number;
  densityDpi: number;
  refreshRate?: number;
  presentationActive: boolean;
};
export type AndroidStorageCategory = {
  id: string;
  label: string;
  bytes: number;
  accessible: boolean;
  note?: string;
};
export type AndroidStorageOverview = {
  total: number;
  free: number;
  used: number;
  categories: AndroidStorageCategory[];
  downloadFolder: string;
  limitations: string[];
  updatedAt: number;
};
export type AndroidBrowserHistoryItem = {
  url: string;
  title: string;
  visitedAt: number;
};
export type AndroidSystemInfo = {
  appVersion: string;
  manufacturer: string;
  brand: string;
  model: string;
  device: string;
  androidRelease: string;
  sdkInt: number;
  webViewVersion: string;
  externalDisplay: AndroidDisplayStatus;
  runtimes: Record<string, string | null>;
  supportedAbis: string[];
  dataPath: string;
  totalStorage: number;
  freeStorage: number;
  cpuCores: number;
  cpuAbi: string;
  totalRam: number;
  availableRam: number;
  lowMemory: boolean;
  refreshRate: number;
  gpuRenderer: string;
  gpuVendor: string;
  webglAvailable: boolean;
};
export type NativeResponse<T> =
  | { ok: true; data: T }
  | { ok: false; error: string; code?: string };
export type KKDexHostAPI = {
  call: <T = unknown>(
    method: string,
    args?: Record<string, unknown>,
  ) => Promise<T>;
  available: boolean;
};
export type DesktopAPI = {
  movePointer: (
    x:
      | number
      | {
          x?: number;
          y?: number;
          dx?: number;
          dy?: number;
          relative?: boolean;
        },
    y?: number,
    relative?: boolean,
  ) => void;
  pointerDown: (button?: number) => void;
  pointerUp: (button?: number) => void;
  pointerClick: () => void;
  pointerDoubleClick: () => void;
  pointerRightClick: () => void;
  scrollDesktop: (dx: number, dy?: number) => void;
  insertText: (text: string) => void;
  pressKey: (
    key: string,
    modifiers?: {
      ctrl?: boolean;
      alt?: boolean;
      shift?: boolean;
      meta?: boolean;
    },
  ) => void;
  getState: () => unknown;
  openApp: (appId: string, payload?: string) => void;
  setTheme: (theme: "light" | "dark") => void;
  setWallpaper: (wallpaper: string) => void;
};

declare global {
  interface Window {
    KKDexAPI?: Partial<DesktopAPI> & Record<string, unknown>;
    KKDexDesktop?: DesktopAPI;
    KKDexServices?: {
      chat?: (messages: ChatMessage[]) => Promise<string>;
      execute?: (command: string) => Promise<string>;
      openBrowser?: (url: string) => void | Promise<void>;
      setVolume?: (value: number) => void;
      setBrightness?: (value: number) => void;
      setWifi?: (enabled: boolean) => void;
      power?: (action: "sleep" | "restart" | "shutdown") => void;
      requestStorageAccess?: () => Promise<boolean>;
      openDocument?: (uri: string, mime: string) => Promise<string>;
    };
    KKDexControllerBridge?: { sendInput: (message: string) => void };
    KKDexHost?: KKDexHostAPI;
    KKDexNative?: {
      postMessage: (message: string) => void;
      onmessage: ((event: { data: string }) => void) | null;
    };
    KKDexNativeEvents?: {
      onDisplayChanged: (status: AndroidDisplayStatus) => void;
      onNativeMessage: (message: string) => void;
    };
    KKDexAndroidNavigation?: {
      openFolder: (root: AndroidRoot) => void;
    };
  }
}
