import { useId } from "react";
import type { AppId } from "./types";

export function BrandMark({ size = 25 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 30 30"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M3 5h9v9H3zM16 5h11v9H16zM3 18h9v9H3zM16 18h11v9H16z"
        fill="currentColor"
        rx="2"
      />
      <path
        d="m12 5 4-3v12h-4M12 18h4v12l-4-3"
        fill="currentColor"
        opacity=".45"
      />
    </svg>
  );
}

export function FolderIcon({
  size = 48,
  color = "yellow",
}: {
  size?: number;
  color?: "yellow" | "green" | "blue";
}) {
  const id = useId().replace(/:/g, "");
  const shades =
    color === "green"
      ? ["#9cdbbe", "#4eae88"]
      : color === "blue"
        ? ["#9bcaf4", "#5295d8"]
        : ["#ffdc7c", "#efb742"];
  return (
    <svg
      width={size}
      height={size * 0.82}
      viewBox="0 0 56 46"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient
          id={id}
          x1="28"
          y1="10"
          x2="28"
          y2="44"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor={shades[0]} />
          <stop offset="1" stopColor={shades[1]} />
        </linearGradient>
      </defs>
      <path
        d="M3 10a4 4 0 0 1 4-4h15l5 5h22a4 4 0 0 1 4 4v23a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V10Z"
        fill={shades[1]}
      />
      <path
        d="M3 16a3 3 0 0 1 3-3h44a3 3 0 0 1 3 3v22a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V16Z"
        fill={`url(#${id})`}
      />
      <path d="M7 14h42" stroke="white" strokeOpacity=".5" strokeWidth="1.2" />
    </svg>
  );
}

export function AppIcon({
  app,
  size = 44,
  className = "",
}: {
  app: AppId;
  size?: number;
  className?: string;
}) {
  const id = useId().replace(/:/g, "");
  if (app === "files")
    return (
      <span
        className={`app-icon folder-app ${className}`}
        style={{ width: size, height: size }}
      >
        <FolderIcon size={size} />
      </span>
    );
  let artwork;
  switch (app) {
    case "pc":
      artwork = (
        <>
          <rect x="4" y="6" width="40" height="29" rx="3.5" fill="#d5e6e5" />
          <rect
            x="7"
            y="9"
            width="34"
            height="22"
            rx="1.5"
            fill={`url(#${id})`}
          />
          <path d="m8 29 13-14 9 8 10-10v17H8Z" fill="#c9f7e6" opacity=".6" />
          <path d="M20 35h8l1 6H19l1-6Z" fill="#aac4c7" />
          <rect x="15" y="40" width="18" height="3" rx="1.5" fill="#e3eeee" />
        </>
      );
      break;
    case "browser":
      artwork = (
        <>
          <circle cx="24" cy="24" r="20" fill={`url(#${id})`} />
          <path
            d="M10 31c11 10 27 4 29-9-7 9-14 9-20 4 4 0 9-1 9-6 0-6-7-9-12-5-9 6-5 17 3 20"
            fill="#70dfd5"
          />
          <path
            d="M6 23C7 11 20 4 30 8c6 3 9 8 8 14-2-9-12-12-18-7-3 3-2 7 0 9-7-2-12 0-14 5v-6Z"
            fill="#8ce7e4"
          />
        </>
      );
      break;
    case "ai":
      artwork = (
        <>
          <rect x="4" y="4" width="40" height="40" rx="11" fill="#e6f6ed" />
          <path
            d="M24 8c2 10 6 14 16 16-10 2-14 6-16 16-2-10-6-14-16-16 10-2 14-6 16-16Z"
            fill={`url(#${id})`}
          />
          <path
            d="m36 8 1.2 3.8L41 13l-3.8 1.2L36 18l-1.2-3.8L31 13l3.8-1.2L36 8Z"
            fill="#70bda4"
          />
        </>
      );
      break;
    case "store":
      artwork = (
        <>
          <path
            d="M8 15h32l3 26a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3l3-26Z"
            fill={`url(#${id})`}
          />
          <path
            d="M16 17v-5a8 8 0 0 1 16 0v5"
            stroke="#c7eee9"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          <path
            d="m25 23 1.4 5.6L32 30l-5.6 1.4L25 37l-1.4-5.6L18 30l5.6-1.4L25 23Z"
            fill="white"
          />
        </>
      );
      break;
    case "settings":
      artwork = (
        <>
          <path
            d="m20 4 8 .1 1.6 5 4.3 2.5 5.2-1.1 4 7-3.5 3.9v5l3.5 3.9-4 7-5.2-1-4.3 2.4-1.6 5h-8l-1.6-5-4.3-2.5-5.2 1.1-4-7L8.4 26v-5l-3.5-3.9 4-7 5.2 1 4.3-2.4L20 4Z"
            fill={`url(#${id})`}
          />
          <circle cx="24" cy="24" r="9" fill="#e6f3f1" />
          <circle cx="24" cy="24" r="5" fill="#7b9fa3" />
        </>
      );
      break;
    case "gallery":
      artwork = (
        <>
          <rect x="4" y="7" width="40" height="34" rx="5" fill="#f7e2dd" />
          <rect
            x="7"
            y="10"
            width="34"
            height="28"
            rx="3"
            fill={`url(#${id})`}
          />
          <circle cx="16" cy="18" r="4" fill="#fff0b8" />
          <path d="m7 34 10-11 7 7 8-12 9 14v6H7v-4Z" fill="#9bd0c4" />
          <path d="m15 38 11-12 12 12H15Z" fill="#448e83" />
        </>
      );
      break;
    case "notes":
      artwork = (
        <>
          <rect x="9" y="5" width="32" height="39" rx="4" fill="#f3bc48" />
          <path
            d="M8 4h28v31l-9 8H8a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z"
            fill={`url(#${id})`}
          />
          <path d="M27 43v-7a2 2 0 0 1 2-2h7" fill="#fff7ce" />
          <path
            d="M13 15h15M13 21h15M13 27h9"
            stroke="#c59d44"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </>
      );
      break;
    case "calculator":
      artwork = (
        <>
          <rect
            x="8"
            y="3"
            width="32"
            height="42"
            rx="5"
            fill={`url(#${id})`}
          />
          <rect x="13" y="8" width="22" height="10" rx="2" fill="#d7ece8" />
          <path
            d="M15 25h4m-2-2v4M27 25h4M15 34h4m-2-2v4M27 33h4m-4 4h4"
            stroke="#e9f6f3"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <rect x="24" y="30" width="10" height="11" rx="2" fill="#55b8a0" />
          <path d="M27 34h4m-4 3h4" stroke="white" strokeWidth="1.5" />
        </>
      );
      break;
    case "terminal":
      artwork = (
        <>
          <rect x="3" y="7" width="42" height="34" rx="5" fill="#243b3e" />
          <path d="M3 16h42" stroke="#496366" />
          <circle cx="9" cy="12" r="1.4" fill="#b9d6ce" />
          <circle cx="14" cy="12" r="1.4" fill="#6d9c91" />
          <path
            d="m11 24 6 5-6 5M23 34h10"
            stroke="#97e2bf"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      );
      break;
    case "bin":
      artwork = (
        <>
          <path
            d="m11 13 3 29a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3l3-29H11Z"
            fill={`url(#${id})`}
          />
          <path
            d="M8 12h32M18 7h12M19 20l1 17m9-17-1 17"
            stroke="#d6f0e6"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path d="M15 13h18l-2 28H17l-2-28Z" fill="white" opacity=".16" />
        </>
      );
      break;
    case "storage":
      artwork = (
        <>
          <rect x="5" y="7" width="38" height="34" rx="6" fill={`url(#${id})`} />
          <rect x="10" y="13" width="28" height="9" rx="3" fill="#d9edf0" />
          <rect x="10" y="27" width="28" height="8" rx="3" fill="#b4d9d5" />
          <circle cx="34" cy="17.5" r="1.5" fill="#5b8b8b" />
          <circle cx="34" cy="31" r="1.5" fill="#5b8b8b" />
          <path d="M15 17.5h12M15 31h12" stroke="#8bb7b2" strokeWidth="1.5" />
          <path d="m31 35 1 3.5L35.5 40 32 41l-1 3.5-1-3.5-3.5-1 3.5-1.5L31 35Z" fill="#e3f5e7" />
        </>
      );
      break;
    case "editor":
      artwork = (
        <>
          <path d="M9 4h23l9 9v30a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z" fill={`url(#${id})`} />
          <path d="M32 4v7a2 2 0 0 0 2 2h7" fill="#dcebe9" />
          <path d="M14 20h20M14 26h20M14 32h12" stroke="#e8f6f3" strokeWidth="2" strokeLinecap="round" />
          <path d="m28 36 7-7 4 4-7 7-5 1 1-5Z" fill="#efd485" />
        </>
      );
      break;
    case "video":
      artwork = (
        <>
          <rect x="3" y="8" width="42" height="32" rx="6" fill={`url(#${id})`} />
          <path d="m20 17 13 7-13 7V17Z" fill="#e8fff4" />
          <path d="M8 33h5M35 33h5" stroke="#a9ded4" strokeWidth="2" strokeLinecap="round" />
        </>
      );
      break;
    case "music":
      artwork = (
        <>
          <circle cx="24" cy="24" r="20" fill={`url(#${id})`} />
          <path d="M29 13v18.5a6 6 0 1 1-3-5.2V17l11-2.4v12.6a6 6 0 1 1-3-5.2V13h-5Z" fill="#e6fff5" />
          <circle cx="17" cy="33" r="6" fill="none" stroke="#e6fff5" strokeWidth="2.5" />
        </>
      );
      break;
    case "pdf":
      artwork = (
        <>
          <path d="M9 4h23l9 9v30a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z" fill="#f3e7df" />
          <path d="M32 4v9h9" fill="#d8c1b1" />
          <rect x="11" y="22" width="26" height="14" rx="3" fill="#c4564e" />
          <text x="24" y="32.5" textAnchor="middle" fontSize="8" fontWeight="700" fill="#fff" fontFamily="Arial">PDF</text>
          <path d="M15 16h14" stroke="#c5a28f" strokeWidth="2" strokeLinecap="round" />
        </>
      );
      break;
    case "downloads":
      artwork = (
        <>
          <path d="M7 7h34l3 34a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3L7 7Z" fill={`url(#${id})`} />
          <path d="M24 12v17m-7-7 7 7 7-7M14 35h20" stroke="#e8fff5" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        </>
      );
      break;
    case "sysinfo":
      artwork = (
        <>
          <rect x="4" y="6" width="40" height="30" rx="5" fill={`url(#${id})`} />
          <rect x="8" y="10" width="32" height="20" rx="2" fill="#e9f4ee" />
          <circle cx="24" cy="20" r="6.5" fill="none" stroke="#6b9a88" strokeWidth="1.6" />
          <path d="M24 16v4l3 2" stroke="#6b9a88" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M19 41h10M24 36v5" stroke="#b4d5c7" strokeWidth="3" strokeLinecap="round" />
        </>
      );
      break;
    case "appmanager":
      artwork = (
        <>
          <rect x="4" y="4" width="40" height="40" rx="9" fill={`url(#${id})`} />
          {[11, 22, 33].map((x) => [11, 22, 33].map((y) => <rect key={`${x}-${y}`} x={x} y={y} width="6" height="6" rx="1.7" fill="#e7fff3" />))}
        </>
      );
      break;
    case "gaming":
      artwork = (
        <>
          <rect x="3" y="12" width="42" height="25" rx="9" fill={`url(#${id})`} />
          <path d="M11 17v9M7 21.5h8" stroke="#e9fff4" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="32" cy="19" r="2.2" fill="#ecfff3" />
          <circle cx="37" cy="24" r="2.2" fill="#b9dfcd" />
          <path d="M17 7h14M20 7v5M28 7v5" stroke="#b9dfcd" strokeWidth="2" strokeLinecap="round" />
          <path d="M22 21.5h4" stroke="#b9dfcd" strokeWidth="2" strokeLinecap="round" />
        </>
      );
      break;
    case "storagemanager":
      artwork = (
        <>
          <rect x="6" y="5" width="36" height="38" rx="6" fill={`url(#${id})`} />
          <circle cx="24" cy="24" r="12" fill="none" stroke="#e6f7ee" strokeWidth="5" opacity=".35" />
          <path d="M24 12a12 12 0 0 1 11 7.3" fill="none" stroke="#ebfff2" strokeWidth="5" strokeLinecap="round" />
          <path d="M24 12a12 12 0 0 0-10.4 6" fill="none" stroke="#f0d798" strokeWidth="5" strokeLinecap="round" />
          <circle cx="24" cy="24" r="4" fill="#e9f8ec" />
        </>
      );
      break;
    case "archives":
      artwork = (
        <>
          <path d="M7 9h34v32a4 4 0 0 1-4 4H11a4 4 0 0 1-4-4V9Z" fill={`url(#${id})`} />
          <path d="M7 9h34v8H7z" fill="#c6e3dc" />
          <path d="M20 17h8v7h4v6h-4v14h-8V30h-4v-6h4v-7Z" fill="#f1fbf4" />
          <path d="M22 12h4M22 22h4M22 26h4" stroke="#557a70" strokeWidth="1.5" />
        </>
      );
      break;
  }
  const colors: Partial<Record<AppId, string[]>> = {
    pc: ["#8bc9c5", "#357e8c"],
    browser: ["#45b6ce", "#2368b4"],
    ai: ["#72c4a4", "#29775e"],
    store: ["#67b8ae", "#327c7d"],
    settings: ["#ccdedb", "#769aa0"],
    gallery: ["#e8b0b0", "#e9cfb5"],
    notes: ["#ffedab", "#f4cf6b"],
    calculator: ["#7f9da2", "#3e5d63"],
    bin: ["#95cbbb", "#4d8d7b"],
    storage: ["#92c9cf", "#4c8d95"],
    editor: ["#9bc7c2", "#5a918c"],
    video: ["#7fc4c9", "#4c8ba3"],
    music: ["#9ccdb5", "#568f7e"],
    pdf: ["#e8c0b0", "#b9897b"],
    downloads: ["#8ecac2", "#4d8c86"],
    sysinfo: ["#a8cec2", "#678f84"],
    appmanager: ["#85bdae", "#4e8274"],
    archives: ["#a8cbbb", "#6e9585"],
    gaming: ["#82c9aa", "#306d54"],
    storagemanager: ["#91c9c6", "#416f78"],
  };
  const gradient = colors[app] || ["#91ccbb", "#377d6e"];
  return (
    <svg
      className={`app-icon ${className}`}
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient
          id={id}
          x1="10"
          y1="4"
          x2="38"
          y2="45"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor={gradient[0]} />
          <stop offset="1" stopColor={gradient[1]} />
        </linearGradient>
      </defs>
      {artwork}
    </svg>
  );
}
