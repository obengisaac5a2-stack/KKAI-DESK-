import { useEffect, useRef, useState, type PointerEvent } from "react";
import {
  AppWindow,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  ChevronDown,
  FolderSearch,
  Keyboard,
  LoaderCircle,
  Monitor,
  Mouse,
  MousePointer2,
  Move,
  Send,
  Smartphone,
  Volume2,
  X,
} from "lucide-react";
import { BrandMark } from "./icons";
import {
  chooseFolderForDesktop,
  getAndroidVolume,
  getDisplayStatus,
  getInstalledApps,
  launchInstalledApp,
  nativeAvailable,
  setAndroidVolume,
} from "./android/native";
import type {
  AndroidDisplayStatus,
  InputMessage,
  InstalledAndroidApp,
} from "./types";

export default function Controller() {
  const [text, setText] = useState("");
  const [keyboard, setKeyboard] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [modifiers, setModifiers] = useState({
    ctrl: false,
    alt: false,
    shift: false,
    meta: false,
  });
  const [notice, setNotice] = useState("");
  const [touching, setTouching] = useState(false);
  const [display, setDisplay] = useState<AndroidDisplayStatus | null>(null);
  const [volume, setVolume] = useState(65);
  const [appsOpen, setAppsOpen] = useState(false);
  const [androidApps, setAndroidApps] = useState<InstalledAndroidApp[]>([]);
  const [appsBusy, setAppsBusy] = useState(false);
  const [transferBusy, setTransferBusy] = useState(false);
  const points = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({ x: 0, y: 0, time: 0, moved: false, fingers: 1 });
  const lastTap = useRef(0);
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const connected = !!window.KKDexControllerBridge?.sendInput;
  const native = nativeAvailable();

  const send = (message: InputMessage) => {
    if (window.KKDexControllerBridge?.sendInput)
      window.KKDexControllerBridge.sendInput(JSON.stringify(message));
    else
      setNotice(
        "No external display transport is connected. Open this controller inside the installed KK DEX Android application.",
      );
  };

  useEffect(() => {
    if (!native) return;
    void getDisplayStatus().then(setDisplay).catch(() => undefined);
    void getAndroidVolume().then(setVolume).catch(() => undefined);
    const update = (event: Event) =>
      setDisplay((event as CustomEvent<AndroidDisplayStatus>).detail);
    window.addEventListener("kkdex:display-status", update);
    return () => window.removeEventListener("kkdex:display-status", update);
  }, [native]);

  const loadApps = async () => {
    setAppsOpen(true);
    if (!native) return;
    setAppsBusy(true);
    try {
      setAndroidApps(await getInstalledApps());
    } catch (error) {
      setNotice(
        error instanceof Error
          ? error.message
          : "Android did not return installed applications.",
      );
    } finally {
      setAppsBusy(false);
    }
  };

  const transferFolder = async () => {
    if (!native) {
      setNotice(
        "File transfer requires the installed KK DEX Android application. The browser preview cannot open Android's folder picker.",
      );
      return;
    }
    setTransferBusy(true);
    try {
      const root = await chooseFolderForDesktop();
      setNotice(
        `Android authorized "${root.name}". The desktop is opening that folder in Android Storage.`,
      );
    } catch (error) {
      setNotice(
        error instanceof Error
          ? error.message
          : "Android did not return an authorized folder.",
      );
    } finally {
      setTransferBusy(false);
    }
  };

  const changeVolume = (value: number) => {
    setVolume(value);
    if (native)
      void setAndroidVolume(value).catch((error) =>
        setNotice(
          error instanceof Error ? error.message : "Could not set Android volume.",
        ),
      );
    else
      setNotice(
        "Hardware volume control requires the KK DEX Android application.",
      );
  };

  const pressKey = (key: string) => send({ type: "pressKey", key, modifiers });
  const down = (e: PointerEvent) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (points.current.size === 1)
      gesture.current = {
        x: e.clientX,
        y: e.clientY,
        time: Date.now(),
        moved: false,
        fingers: 1,
      };
    else
      gesture.current.fingers = Math.max(
        gesture.current.fingers,
        points.current.size,
      );
    setTouching(true);
  };
  const move = (e: PointerEvent) => {
    const previous = points.current.get(e.pointerId);
    if (!previous) return;
    const dx = e.clientX - previous.x,
      dy = e.clientY - previous.y;
    if (
      Math.hypot(e.clientX - gesture.current.x, e.clientY - gesture.current.y) >
      5
    )
      gesture.current.moved = true;
    points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (points.current.size > 1)
      send({ type: "scrollDesktop", dx: -dx * 1.5, dy: -dy * 1.5 });
    else
      send({ type: "movePointer", dx: dx * 1.6, dy: dy * 1.6, relative: true });
  };
  const up = (e: PointerEvent) => {
    points.current.delete(e.pointerId);
    if (!points.current.size) setTouching(false);
    if (gesture.current.moved || points.current.size) return;
    if (gesture.current.fingers > 1 || Date.now() - gesture.current.time > 550)
      send({ type: "pointerRightClick" });
    else if (Date.now() - lastTap.current < 300) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      send({ type: "pointerDoubleClick" });
      lastTap.current = 0;
    } else {
      lastTap.current = Date.now();
      tapTimer.current = setTimeout(() => send({ type: "pointerClick" }), 300);
    }
  };

  return (
    <div className="controller-page">
      <header className="controller-header">
        <div>
          <BrandMark size={25} />
          <strong>KK DEX</strong>
          <span>CONTROLLER</span>
        </div>
        <span className={`controller-connection ${connected ? "connected" : ""}`}>
          <span />
          {connected
            ? display?.connected
              ? "Desktop connected to TV"
              : "Android · no external display"
            : "Not connected"}
        </span>
      </header>
      <main className="controller-main">
        <div className="controller-title">
          <span className="eyebrow">SMALL SCREEN. BIG POSSIBILITIES.</span>
          <h1>
            Your desktop,
            <br />
            at your fingertips.
          </h1>
          <p>Your phone is the controller. Your television is the workspace.</p>
        </div>

        <div className={`controller-display ${display?.connected ? "connected" : ""}`}>
          <div>
            {display?.presentationActive ? (
              <Monitor size={18} />
            ) : (
              <Smartphone size={18} />
            )}
          </div>
          <span>
            <strong>
              {display?.connected
                ? display.displayName
                : native
                  ? "No external display detected"
                  : "External display status unavailable"}
            </strong>
            <small>
              {display?.connected
                ? `${display.width} × ${display.height} · ${display.presentationActive ? "KK DEX presentation active" : "presentation stopped"}`
                : native
                  ? "Connect HDMI, DisplayPort, or a supported external-display path. The phone never renders the desktop."
                  : "Open the controller inside the installed KK DEX Android app."}
            </small>
          </span>
          {display?.connected && <i>LIVE</i>}
        </div>

        <div className="controller-tools">
          <span>
            <MousePointer2 size={15} />
            Touchpad
          </span>
          <button
            className={dragging ? "active" : ""}
            onClick={() => {
              send({ type: dragging ? "pointerUp" : "pointerDown" });
              setDragging(!dragging);
            }}
          >
            <Move size={15} />
            {dragging ? "Release drag" : "Drag mode"}
          </button>
        </div>
        <div
          className={`touchpad ${touching ? "touching" : ""}`}
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerCancel={(e) => {
            points.current.delete(e.pointerId);
            setTouching(false);
          }}
        >
          <div>
            <MousePointer2 size={30} strokeWidth={1.2} />
            <strong>A natural connection.</strong>
            <span>Slide to move. Tap to click.</span>
            <small>Two fingers to scroll. Hold for right-click.</small>
          </div>
          <span className="touchpad-corner top-left" />
          <span className="touchpad-corner top-right" />
          <span className="touchpad-corner bottom-left" />
          <span className="touchpad-corner bottom-right" />
        </div>
        <div className="controller-mouse-buttons">
          <button
            onPointerDown={() => send({ type: "pointerDown" })}
            onPointerUp={() => send({ type: "pointerUp" })}
            onPointerCancel={() => send({ type: "pointerUp" })}
          >
            <Mouse size={18} />
            Left click
          </button>
          <button onClick={() => send({ type: "pointerRightClick" })}>
            <Mouse size={18} />
            Right click
          </button>
        </div>

        <div className="controller-android-tools">
          <button onClick={() => void loadApps()} disabled={!native}>
            <AppWindow size={18} />
            <span>
              <strong>Android apps</strong>
              <small>{native ? "Installed launcher activities" : "Native app required"}</small>
            </span>
          </button>
          <button onClick={() => void transferFolder()} disabled={!native || transferBusy}>
            {transferBusy ? <LoaderCircle className="spin" size={18} /> : <FolderSearch size={18} />}
            <span>
              <strong>Send folder to TV</strong>
              <small>{native ? "Authorize with Android SAF" : "Native file picker required"}</small>
            </span>
          </button>
        </div>

        <div className="controller-volume">
          <Volume2 size={17} />
          <input
            aria-label="Android media volume"
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={(event) => changeVolume(Number(event.target.value))}
          />
          <span>{volume}%</span>
        </div>

        <button
          className={`controller-keyboard-toggle ${keyboard ? "active" : ""}`}
          onClick={() => setKeyboard((k) => !k)}
        >
          <Keyboard size={20} />
          <span>Keyboard & shortcuts</span>
          <ChevronDown size={17} />
        </button>
        {keyboard && (
          <div className="controller-keyboard">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (text) {
                  send({ type: "insertText", text });
                  setText("");
                }
              }}
            >
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type for your desktop"
                aria-label="Text to send to desktop"
              />
              <button type="submit" aria-label="Send text">
                <Send size={18} />
              </button>
            </form>
            <div className="controller-modifiers">
              {(["ctrl", "alt", "shift", "meta"] as const).map((key) => (
                <button
                  key={key}
                  className={modifiers[key] ? "active" : ""}
                  onClick={() =>
                    setModifiers((m) => ({ ...m, [key]: !m[key] }))
                  }
                >
                  {key === "meta"
                    ? "Super"
                    : key[0].toUpperCase() + key.slice(1)}
                </button>
              ))}
            </div>
            <div className="controller-key-row">
              {["Escape", "Tab", "Backspace", "Enter", "Delete", "F2", "F5"].map(
                (key) => (
                  <button key={key} onClick={() => pressKey(key)}>
                    {key === "Escape" ? "Esc" : key}
                  </button>
                ),
              )}
            </div>
            <div className="controller-key-row">
              {[
                ["ArrowLeft", ArrowLeft],
                ["ArrowUp", ArrowUp],
                ["ArrowDown", ArrowDown],
                ["ArrowRight", ArrowRight],
              ].map(([key, Icon]) => {
                const KeyIcon = Icon as typeof ArrowLeft;
                return (
                  <button
                    key={key as string}
                    aria-label={key as string}
                    onClick={() => pressKey(key as string)}
                  >
                    <KeyIcon size={16} />
                  </button>
                );
              })}
              <button
                onClick={() =>
                  send({
                    type: "pressKey",
                    key: "e",
                    modifiers: { meta: true },
                  })
                }
              >
                Files
              </button>
              <button
                onClick={() =>
                  send({
                    type: "pressKey",
                    key: "d",
                    modifiers: { meta: true },
                  })
                }
              >
                Desktop
              </button>
            </div>
          </div>
        )}
        {notice && (
          <div className="controller-notice">
            <Monitor size={19} />
            <p>{notice}</p>
            <button aria-label="Dismiss controller notice" onClick={() => setNotice("")}>
              <X size={16} />
            </button>
          </div>
        )}
        <footer className="controller-footer">
          <Smartphone size={15} />
          <span>One phone. A whole new perspective.</span>
        </footer>
      </main>

      {appsOpen && (
        <div className="controller-apps-backdrop" onClick={() => setAppsOpen(false)}>
          <section className="controller-apps-sheet" onClick={(event) => event.stopPropagation()}>
            <header>
              <div>
                <strong>Android apps</strong>
                <small>Names and icons from Android PackageManager</small>
              </div>
              <button aria-label="Close Android apps" onClick={() => setAppsOpen(false)}>
                <X size={18} />
              </button>
            </header>
            {appsBusy ? (
              <div className="controller-apps-loading"><LoaderCircle className="spin" size={20} /> Discovering installed apps…</div>
            ) : androidApps.length ? (
              <div className="controller-apps-list">
                {androidApps.map((app) => (
                  <button
                    key={app.packageName}
                    onClick={() => {
                      void launchInstalledApp(app.packageName, true)
                        .then(setNotice)
                        .catch((error) =>
                          setNotice(
                            error instanceof Error ? error.message : "This app could not be launched.",
                          ),
                        );
                      setAppsOpen(false);
                    }}
                  >
                    <span>{app.iconUrl ? <img src={app.iconUrl} alt="" /> : <AppWindow size={19} />}</span>
                    <div><strong>{app.label}</strong><small>{app.packageName}</small></div>
                    <ArrowRight size={14} />
                  </button>
                ))}
              </div>
            ) : (
              <p className="controller-apps-empty">
                {native
                  ? "Android returned no launchable applications. Package visibility is controlled by Android and the app manifest."
                  : "The Android PackageManager bridge is only available inside the installed KK DEX app."}
              </p>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
