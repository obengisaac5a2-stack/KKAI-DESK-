import {
  useEffect,
  useRef,
  useState,
  type MouseEvent,
  type PointerEvent,
} from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  ArrowDownAZ,
  Gamepad2,
  HardDrive,
  ArrowUpRight,
  Check,
  FolderPlus,
  Info,
  LayoutGrid,
  Monitor,
  Paintbrush,
  RefreshCw,
  Trash2,
} from "lucide-react";
import { AppIcon, BrandMark, FolderIcon } from "./icons";
import { apps, appRegistry, desktopApps, wallpaperPaths } from "./registry";
import { persist, readPersisted } from "./storage";
import { TASKBAR_HEIGHT, useSystem } from "./system";
import { useDesktopBridge } from "./bridge";
import WindowManager from "./WindowManager";
import { SystemOverlays, Taskbar } from "./Panels";
import type { AppId, MenuItem } from "./types";

type Position = { col: number; row: number };
const CELL_X = 94,
  CELL_Y = 96,
  LEFT = 20,
  TOP = 26;
export default function Desktop() {
  const system = useSystem();
  const {
    size,
    preferences,
    windows,
    activeId,
    panel,
    setPanel,
    setContextMenu,
    dialog,
    setDialog,
    openApp,
    focusWindow,
    closeWindow,
    showDesktop,
    snapWindow,
    files,
    openFile,
    createFolder,
    renameFile,
    deleteFiles,
    copyFiles,
    pasteFiles,
    clipboard,
    explain,
    setPreference,
  } = system;
  const pointer = useDesktopBridge();
  const [selected, setSelected] = useState<string[]>([]);
  const [positions, setPositions] = useState<Record<string, Position>>(() =>
    readPersisted("icon-positions", {}),
  );
  const [drag, setDrag] = useState<{ id: string; x: number; y: number } | null>(
    null,
  );
  const [selectionRect, setSelectionRect] = useState<{
    x: number;
    y: number;
    width: number;
    height: number;
  } | null>(null);
  const [revision, setRevision] = useState(0);
  const lastDrag = useRef(0);
  const altCycle = useRef<{ ids: string[]; index: number } | null>(null);
  const rows = Math.max(
    3,
    Math.min(6, Math.floor((size.height - TASKBAR_HEIGHT - TOP - 14) / CELL_Y)),
  );
  const items = [
    ...apps
      .filter((a) => desktopApps.includes(a.id))
      .map((a) => ({
        id: a.id as string,
        label: a.name,
        appId: a.id,
        fileId: undefined as string | undefined,
      })),
    ...files
      .filter((f) => f.parent === "desktop" && !f.deleted)
      .map((f) => ({
        id: `file-${f.id}`,
        label: f.name,
        appId: undefined as AppId | undefined,
        fileId: f.id,
      })),
  ];
  const columns = Math.max(1, Math.floor((size.width - LEFT) / CELL_X));
  const layout: Record<string, Position> = {},
    taken = new Set<string>();
  const prioritized = [
    ...items.filter((i) => positions[i.id]),
    ...items.filter((i) => !positions[i.id]),
  ];
  for (const item of prioritized) {
    const index = items.findIndex((i) => i.id === item.id),
      saved = positions[item.id] || {
        col: Math.floor(index / rows),
        row: index % rows,
      };
    const desired = {
      col: Math.min(columns - 1, saved.col),
      row: Math.min(rows - 1, saved.row),
    };
    const free: Position[] = [];
    for (let col = 0; col < columns; col++)
      for (let row = 0; row < rows; row++)
        if (!taken.has(`${col}:${row}`)) free.push({ col, row });
    free.sort(
      (a, b) =>
        Math.hypot(a.col - desired.col, a.row - desired.row) -
        Math.hypot(b.col - desired.col, b.row - desired.row),
    );
    const position = free[0] || desired;
    layout[item.id] = position;
    taken.add(`${position.col}:${position.row}`);
  }
  const getPosition = (id: string, index: number): Position =>
    layout[id] || { col: Math.floor(index / rows), row: index % rows };
  useEffect(() => {
    persist("icon-positions", positions);
  }, [positions]);
  useEffect(() => {
    const reset = () => setPositions({});
    window.addEventListener("kkdex:reset-desktop", reset);
    return () => window.removeEventListener("kkdex:reset-desktop", reset);
  }, []);
  const launch = (item: (typeof items)[number]) => {
    if (item.appId) openApp(item.appId);
    else if (item.fileId) openFile(item.fileId);
  };
  const sortIcons = (by: "name" | "type") => {
    const sorted = [...items].sort((a, b) =>
      by === "name"
        ? a.label.localeCompare(b.label)
        : Number(!!b.appId) - Number(!!a.appId) ||
          a.label.localeCompare(b.label),
    );
    setPositions(
      Object.fromEntries(
        sorted.map((item, i) => [
          item.id,
          { col: Math.floor(i / rows), row: i % rows },
        ]),
      ),
    );
  };
  const refresh = () => {
    setRevision((r) => r + 1);
    window.dispatchEvent(new CustomEvent("kkdex:refresh"));
  };
  const desktopMenu = (e: MouseEvent) => {
    if (
      (e.target as Element).closest(
        "[data-window], .taskbar, .system-panel, .context-menu, .system-dialog",
      )
    )
      return;
    e.preventDefault();
    setPanel(null);
    const viewItems: MenuItem[] = [
      {
        label: "Medium icons",
        icon:
          preferences.iconSize === "medium" ? <Check size={15} /> : undefined,
        action: () => setPreference("iconSize", "medium"),
      },
      {
        label: "Small icons",
        icon:
          preferences.iconSize === "small" ? <Check size={15} /> : undefined,
        action: () => setPreference("iconSize", "small"),
      },
      {
        label: "Show desktop icons",
        icon: preferences.showIcons ? <Check size={15} /> : undefined,
        divider: true,
        action: () => setPreference("showIcons", !preferences.showIcons),
      },
    ];
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      items: [
        { label: "View", icon: <LayoutGrid size={15} />, children: viewItems },
        {
          label: "Sort by",
          icon: <ArrowDownAZ size={15} />,
          children: [
            { label: "Name", action: () => sortIcons("name") },
            { label: "Item type", action: () => sortIcons("type") },
          ],
        },
        {
          label: "Refresh",
          icon: <RefreshCw size={15} />,
          shortcut: "F5",
          action: refresh,
        },
        {
          label: "Gaming Centre",
          icon: <Gamepad2 size={15} />,
          divider: true,
          action: () => openApp("gaming"),
        },
        {
          label: "Storage",
          icon: <HardDrive size={15} />,
          action: () => openApp("storagemanager"),
        },
        {
          label: "New folder",
          icon: <FolderPlus size={15} />,
          action: () => createFolder("desktop"),
        },
        {
          label: "Paste",
          disabled: !clipboard,
          shortcut: "Ctrl+V",
          action: () => pasteFiles("desktop"),
        },
        {
          label: "Display settings",
          icon: <Monitor size={15} />,
          divider: true,
          action: () => openApp("settings", "display"),
        },
        {
          label: "Personalize",
          icon: <Paintbrush size={15} />,
          action: () => openApp("settings", "appearance"),
        },
      ],
    });
  };
  const iconMenu = (e: MouseEvent, item: (typeof items)[number]) => {
    e.preventDefault();
    e.stopPropagation();
    setSelected([item.id]);
    setPanel(null);
    const menu: MenuItem[] = [
      {
        label: "Open",
        icon: <ArrowUpRight size={15} />,
        shortcut: "Enter",
        action: () => launch(item),
      },
    ];
    if (item.fileId)
      menu.push(
        {
          label: "Rename",
          shortcut: "F2",
          action: () => renameFile(item.fileId!),
          divider: true,
        },
        {
          label: "Copy",
          shortcut: "Ctrl+C",
          action: () => copyFiles([item.fileId!]),
        },
        {
          label: "Move to Recycle Bin",
          icon: <Trash2 size={15} />,
          danger: true,
          action: () => deleteFiles([item.fileId!]),
        },
      );
    else
      menu.push({
        label: "Find in App Center",
        icon: <LayoutGrid size={15} />,
        action: () => openApp("store"),
      });
    menu.push({
      label: "Properties",
      icon: <Info size={15} />,
      divider: true,
      action: () =>
        explain(
          item.label,
          item.appId
            ? `${appRegistry[item.appId].description}\n\nCategory: ${appRegistry[item.appId].category}\nIncluded with KK DEX Desktop 1.0\nLaunch behavior: single independent window\nYour workspace data is preserved when this window closes.`
            : `Managed workspace item\nLocation: Desktop\n\nSaved locally in this WebView.`,
        ),
    });
    setContextMenu({ x: e.clientX, y: e.clientY, items: menu });
  };
  const beginIconDrag = (
    e: PointerEvent,
    item: (typeof items)[number],
    index: number,
  ) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    const start = { x: e.clientX, y: e.clientY },
      pos = getPosition(item.id, index);
    let moved = false,
      endX = pos.col * CELL_X + LEFT,
      endY = pos.row * CELL_Y + TOP;
    const move = (event: globalThis.PointerEvent) => {
      if (
        !moved &&
        Math.hypot(event.clientX - start.x, event.clientY - start.y) < 6
      )
        return;
      moved = true;
      endX = Math.max(
        LEFT,
        Math.min(
          size.width - 84,
          pos.col * CELL_X + LEFT + event.clientX - start.x,
        ),
      );
      endY = Math.max(
        TOP,
        Math.min(
          size.height - TASKBAR_HEIGHT - 80,
          pos.row * CELL_Y + TOP + event.clientY - start.y,
        ),
      );
      setDrag({ id: item.id, x: endX, y: endY });
    };
    const end = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
      setDrag(null);
      if (!moved) return;
      lastDrag.current = Date.now();
      const candidate = {
        col: Math.max(0, Math.round((endX - LEFT) / CELL_X)),
        row: Math.max(0, Math.min(rows - 1, Math.round((endY - TOP) / CELL_Y))),
      };
      const occupied = new Set(
        items
          .filter((i) => i.id !== item.id)
          .map((i) => {
            const p = getPosition(
              i.id,
              items.findIndex((a) => a.id === i.id),
            );
            return `${p.col}:${p.row}`;
          }),
      );
      const slots: Position[] = [];
      for (let col = 0; col < Math.floor((size.width - LEFT) / CELL_X); col++)
        for (let row = 0; row < rows; row++)
          if (!occupied.has(`${col}:${row}`)) slots.push({ col, row });
      slots.sort(
        (a, b) =>
          Math.hypot(a.col - candidate.col, a.row - candidate.row) -
          Math.hypot(b.col - candidate.col, b.row - candidate.row),
      );
      setPositions((p) => ({ ...p, [item.id]: slots[0] || pos }));
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
  };
  const beginSelection = (e: PointerEvent<HTMLDivElement>) => {
    if (
      e.button !== 0 ||
      (e.target as Element).closest(
        "button, [data-window], .taskbar, .system-panel, .context-menu, .system-dialog",
      )
    )
      return;
    setPanel(null);
    setContextMenu(null);
    setSelected([]);
    focusWindow("");
    const start = { x: e.clientX, y: e.clientY };
    const move = (event: globalThis.PointerEvent) => {
      const rect = {
        x: Math.min(start.x, event.clientX),
        y: Math.min(start.y, event.clientY),
        width: Math.abs(event.clientX - start.x),
        height: Math.abs(event.clientY - start.y),
      };
      setSelectionRect(rect);
      setSelected(
        items
          .filter((item, i) => {
            const p = getPosition(item.id, i),
              x = LEFT + p.col * CELL_X,
              y = TOP + p.row * CELL_Y;
            return (
              x < rect.x + rect.width &&
              x + 82 > rect.x &&
              y < rect.y + rect.height &&
              y + 82 > rect.y
            );
          })
          .map((i) => i.id),
      );
    };
    const end = () => {
      setSelectionRect(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
  };
  useEffect(() => {
    const keydown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      const typing =
        e.target instanceof Element &&
        !!e.target.closest('input,textarea,[contenteditable="true"]');
      if (e.key === "Escape") {
        setPanel(null);
        setContextMenu(null);
        if (dialog) setDialog(null);
        return;
      }
      if (dialog) return;
      if (e.key === "Meta" && !typing) {
        e.preventDefault();
        setPanel((p) => (p === "start" ? null : "start"));
        return;
      }
      if (e.metaKey && ["d", "e", "arrowleft", "arrowright"].includes(key)) {
        e.preventDefault();
        if (key === "d") showDesktop();
        if (key === "e") openApp("files");
        if (activeId && (key === "arrowleft" || key === "arrowright"))
          snapWindow(activeId, key === "arrowleft" ? "left" : "right");
        return;
      }
      if (e.altKey && e.key === "F4") {
        e.preventDefault();
        if (activeId) closeWindow(activeId);
        return;
      }
      if (e.altKey && e.key === "Tab") {
        e.preventDefault();
        if (!altCycle.current)
          altCycle.current = {
            ids: [...windows].sort((a, b) => b.z - a.z).map((w) => w.id),
            index: 0,
          };
        const cycle = altCycle.current;
        if (cycle.ids.length) {
          cycle.index =
            (cycle.index + (e.shiftKey ? -1 : 1) + cycle.ids.length) %
            cycle.ids.length;
          focusWindow(cycle.ids[cycle.index]);
        }
        return;
      }
      if (
        typing ||
        (e.target instanceof Element && e.target.closest("[data-window]"))
      )
        return;
      if (e.key === "Enter" && selected[0] && !panel) {
        e.preventDefault();
        const item = items.find((i) => i.id === selected[0]);
        if (item) launch(item);
      }
      if ((e.ctrlKey || e.metaKey) && key === "a") {
        e.preventDefault();
        setSelected(items.map((i) => i.id));
      }
      if (e.key === "F2") {
        const item = items.find((i) => i.id === selected[0]);
        if (item?.fileId) {
          e.preventDefault();
          renameFile(item.fileId);
        }
      }
      if (e.key === "Delete") {
        const ids = items
          .filter((i) => selected.includes(i.id) && i.fileId)
          .map((i) => i.fileId!);
        if (ids.length) {
          e.preventDefault();
          deleteFiles(ids);
          setSelected([]);
        }
      }
      if ((e.ctrlKey || e.metaKey) && ["c", "x"].includes(key)) {
        const ids = items
          .filter((i) => selected.includes(i.id) && i.fileId)
          .map((i) => i.fileId!);
        if (ids.length) {
          e.preventDefault();
          copyFiles(ids, key === "x");
        }
      }
      if ((e.ctrlKey || e.metaKey) && key === "v") {
        e.preventDefault();
        pasteFiles("desktop");
      }
      if (e.key === "F5") {
        e.preventDefault();
        refresh();
      }
    };
    const keyup = (e: KeyboardEvent) => {
      if (e.key === "Alt") altCycle.current = null;
    };
    window.addEventListener("keydown", keydown);
    window.addEventListener("keyup", keyup);
    return () => {
      window.removeEventListener("keydown", keydown);
      window.removeEventListener("keyup", keyup);
    };
  });
  return (
    <div
      className={`desktop ${pointer.visible ? "remote-input" : ""} ${preferences.reducedMotion ? "reduce-motion" : ""}`}
      style={{ "--text-scale": preferences.textScale } as React.CSSProperties}
      onContextMenu={desktopMenu}
      onPointerDown={beginSelection}
    >
      <AnimatePresence mode="sync">
        <motion.div
          key={preferences.wallpaper}
          className={`desktop-wallpaper wallpaper-${preferences.wallpaper}`}
          style={{
            backgroundImage: `url(${wallpaperPaths[preferences.wallpaper]})`,
          }}
          initial={{ opacity: 0, scale: 1.025 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: preferences.reducedMotion ? 0 : 1.1 }}
        />
      </AnimatePresence>
      <div className="wallpaper-shade" />
      <div className="desktop-brand">
        <div>
          <BrandMark size={26} />
          <span>KK DEX</span>
        </div>
        <p>A bigger perspective.</p>
      </div>
      {preferences.showIcons && (
        <div className={`desktop-icons ${preferences.iconSize}`} key={revision}>
          {items.map((item, index) => {
            const pos = getPosition(item.id, index),
              dragging = drag?.id === item.id;
            return (
              <button
                key={item.id}
                data-desktop-icon={item.id}
                className={`desktop-icon ${selected.includes(item.id) ? "selected" : ""} ${dragging ? "dragging-icon" : ""}`}
                style={{
                  left: dragging ? drag.x : LEFT + pos.col * CELL_X,
                  top: dragging ? drag.y : TOP + pos.row * CELL_Y,
                }}
                onPointerDown={(e) => beginIconDrag(e, item, index)}
                onClick={(e) => {
                  e.stopPropagation();
                  if (Date.now() - lastDrag.current < 100) return;
                  setPanel(null);
                  setContextMenu(null);
                  focusWindow("");
                  setSelected((s) =>
                    e.ctrlKey || e.metaKey
                      ? s.includes(item.id)
                        ? s.filter((x) => x !== item.id)
                        : [...s, item.id]
                      : [item.id],
                  );
                }}
                onDoubleClick={() => {
                  if (Date.now() - lastDrag.current > 250) launch(item);
                }}
                onContextMenu={(e) => iconMenu(e, item)}
                title={item.label}
              >
                {item.appId ? (
                  <AppIcon
                    app={item.appId}
                    size={preferences.iconSize === "small" ? 36 : 45}
                  />
                ) : (
                  <FolderIcon size={45} />
                )}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
      {selectionRect && (
        <div
          className="desktop-selection"
          style={{
            left: selectionRect.x,
            top: selectionRect.y,
            width: selectionRect.width,
            height: selectionRect.height,
          }}
        />
      )}
      <WindowManager />
      <Taskbar />
      <SystemOverlays />
      {preferences.brightness < 100 && (
        <div
          className="brightness-overlay"
          style={{ opacity: (100 - preferences.brightness) / 100 }}
        />
      )}
      {pointer.visible &&
        (pointer.cursor && pointer.cursor !== "text" ? (
          <svg
            className="remote-pointer"
            style={{
              left: pointer.x - 12,
              top: pointer.y - 12,
              rotate:
                pointer.cursor === "n" || pointer.cursor === "s"
                  ? "90deg"
                  : pointer.cursor === "ne" || pointer.cursor === "sw"
                    ? "-45deg"
                    : pointer.cursor === "nw" || pointer.cursor === "se"
                      ? "45deg"
                      : "0deg",
            }}
            width="24"
            height="24"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              d="m1 12 6-6v4h10V6l6 6-6 6v-4H7v4l-6-6Z"
              fill="white"
              stroke="#263c37"
              strokeWidth="1.2"
              strokeLinejoin="round"
            />
          </svg>
        ) : pointer.cursor === "text" ? (
          <svg
            className="remote-pointer"
            style={{ left: pointer.x - 5, top: pointer.y - 10 }}
            width="10"
            height="20"
            viewBox="0 0 10 20"
            fill="none"
            aria-hidden="true"
          >
            <path d="M2 1h6M5 1v18M2 19h6" stroke="white" strokeWidth="3" />
            <path d="M2 1h6M5 1v18M2 19h6" stroke="#263c37" strokeWidth="1" />
          </svg>
        ) : (
          <svg
            className="remote-pointer"
            style={{ left: pointer.x - 2, top: pointer.y - 2 }}
            width="20"
            height="27"
            viewBox="0 0 20 27"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M3 2v20l5.3-5 3.5 7.6 3-1.4-3.5-7.3H18L3 2Z"
              fill="#fff"
              stroke="#263c37"
              strokeWidth="1.35"
              strokeLinejoin="round"
            />
          </svg>
        ))}
    </div>
  );
}
