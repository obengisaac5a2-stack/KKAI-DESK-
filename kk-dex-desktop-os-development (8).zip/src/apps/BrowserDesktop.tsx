import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bookmark,
  ChevronDown,
  Clock3,
  Download,
  ExternalLink,
  Globe,
  History,
  Home,
  Info,
  LockKeyhole,
  Monitor,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Smartphone,
  Trash2,
  X,
} from "lucide-react";
import {
  clearBrowserData,
  getBrowserHistory,
  nativeAvailable,
  openBrowserWindow,
} from "../android/native";
import { AppIcon } from "../icons";
import { readPersisted, persist } from "../storage";
import { useSystem } from "../system";
import { EmptyState, IconButton } from "../ui";
import type { AndroidBrowserHistoryItem, DesktopWindow } from "../types";

type Bookmark = { id: string; name: string; url: string };
type Launch = { url: string; title: string; at: number };

const defaults: Bookmark[] = [
  { id: "youtube", name: "YouTube", url: "https://www.youtube.com" },
  { id: "duck", name: "DuckDuckGo", url: "https://duckduckgo.com" },
  { id: "wikipedia", name: "Wikipedia", url: "https://www.wikipedia.org" },
  { id: "mdn", name: "MDN Web Docs", url: "https://developer.mozilla.org" },
];

const normalizeUrl = (raw: string, searchUrl = "https://duckduckgo.com/?q=") => {
  const value = raw.trim();
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (/^[\w-]+(\.[\w-]+)+(?::\d+)?(\/.*)?$/.test(value) || value.startsWith("localhost"))
    return `https://${value}`;
  return `${searchUrl}${encodeURIComponent(value)}`;
};
const siteName = (url: string) => {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "Browser";
  }
};
const timeAgo = (timestamp: number) => {
  const seconds = Math.max(1, Math.round((Date.now() - timestamp) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.round(seconds / 3600)}h ago`;
  return new Date(timestamp).toLocaleDateString();
};

export function BrowserApp({ win }: { win: DesktopWindow }) {
  const system = useSystem();
  const native = nativeAvailable();
  const [address, setAddress] = useState(() => readPersisted("browser-last-address", ""));
  const [mode, setMode] = useState<"home" | "preview" | "native">("home");
  const [previewUrl, setPreviewUrl] = useState("");
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => readPersisted("browser-bookmarks", defaults));
  const [history, setHistory] = useState<Launch[]>(() => readPersisted("browser-history", []));
  const [nativeHistory, setNativeHistory] = useState<AndroidBrowserHistoryItem[]>([]);
  const [desktopMode, setDesktopMode] = useState(() => readPersisted("browser-desktop-mode", true));
  const [panel, setPanel] = useState<"history" | "bookmarks" | "settings" | null>(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [status, setStatus] = useState("");
  const addressRef = useRef<HTMLInputElement>(null);
  const previewTab = useRef({ history: [] as string[], index: -1 });
  const active = win.id;

  useEffect(() => { persist("browser-bookmarks", bookmarks); }, [bookmarks]);
  useEffect(() => { persist("browser-history", history); }, [history]);
  useEffect(() => { persist("browser-desktop-mode", desktopMode); }, [desktopMode]);
  useEffect(() => {
    if (!native) return;
    void getBrowserHistory()
      .then(setNativeHistory)
      .catch(() => setNativeHistory([]));
  }, [native, panel]);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (system.activeId !== active) return;
      const target = event.target as Element;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "l") {
        event.preventDefault();
        addressRef.current?.focus();
        addressRef.current?.select();
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "t") {
        event.preventDefault();
        startHome();
      }
      if (event.key === "F5" && mode === "preview") {
        event.preventDefault();
        setReloadKey((key) => key + 1);
        setLoading(true);
      }
      if (event.altKey && event.key === "ArrowLeft" && mode === "preview") {
        event.preventDefault();
        goPreview(-1);
      }
      if (event.altKey && event.key === "ArrowRight" && mode === "preview") {
        event.preventDefault();
        goPreview(1);
      }
      if (event.key === "Escape" && panel) {
        event.preventDefault();
        setPanel(null);
      }
      void target;
    };
    window.addEventListener("keydown", keydown);
    return () => window.removeEventListener("keydown", keydown);
  });

  const record = (url: string, title = siteName(url)) => {
    setAddress(url);
    persist("browser-last-address", url);
    setHistory((items) => [{ url, title, at: Date.now() }, ...items.filter((item) => item.url !== url)].slice(0, 100));
  };

  const startHome = () => {
    setMode("home");
    setPanel(null);
    setAddress("");
    setStatus("");
  };

  const go = (raw = address) => {
    const url = normalizeUrl(raw);
    if (!url) return;
    record(url);
    if (native) {
      setLoading(true);
      setMode("native");
      setStatus("Launching the native KKDex browser on the external display…");
      void openBrowserWindow(url, desktopMode)
        .then((message) => {
          setStatus(message);
          setLoading(false);
          system.notify("KKDex Browser", message, "browser");
        })
        .catch((error) => {
          setLoading(false);
          setStatus(error instanceof Error ? error.message : "Android could not open the native browser.");
          system.explain("The native browser could not open", error instanceof Error ? error.message : "Android rejected the browser launch.");
        });
      return;
    }
    if (!/^https?:\/\//i.test(url)) {
      system.explain("Invalid address", "Use a valid HTTP or HTTPS address.");
      return;
    }
    previewTab.current = { history: [...previewTab.current.history.slice(0, previewTab.current.index + 1), url], index: previewTab.current.index + 1 };
    setPreviewUrl(url);
    setMode("preview");
    setLoading(true);
  };

  const goPreview = (direction: number) => {
    const tab = previewTab.current;
    const index = tab.index + direction;
    if (index < 0 || index >= tab.history.length) return;
    tab.index = index;
    setPreviewUrl(tab.history[index]);
    setAddress(tab.history[index]);
    setLoading(true);
  };

  const openExternal = () => {
    if (!address) return;
    if (window.KKDexServices?.openBrowser)
      void Promise.resolve(window.KKDexServices.openBrowser(normalizeUrl(address))).catch((error) =>
        system.explain("Browser unavailable", error instanceof Error ? error.message : "Android could not open a browser."),
      );
    else {
      const opened = window.open("about:blank", "_blank", "noopener");
      if (opened) {
        opened.opener = null;
        opened.location.href = normalizeUrl(address);
      } else system.explain("Popup blocked", "The preview could not open a new window. Use the native KK DEX browser in the Android app for full navigation.");
    }
  };

  const toggleBookmark = () => {
    const url = normalizeUrl(address);
    if (!url) return;
    const found = bookmarks.find((bookmark) => bookmark.url === url);
    if (found) setBookmarks((items) => items.filter((item) => item.id !== found.id));
    else setBookmarks((items) => [{ id: `${Date.now()}`, name: siteName(url), url }, ...items]);
  };

  const clearEverything = () => {
    system.setDialog({
      title: "Clear browser data?",
      message: "This removes KK DEX browser history and bookmarks stored in the workspace. In the Android app it also asks the native engine to clear cookies, WebStorage, cache and form data. Site accounts will be signed out.",
      confirmLabel: "Clear browser data",
      danger: true,
      onConfirm: () => {
        setHistory([]);
        setBookmarks(defaults);
        setNativeHistory([]);
        setPanel(null);
        if (!native) {
          system.notify("Browser data cleared", "Local KK DEX history and bookmarks were cleared. Browser-preview site storage belongs to the preview browser and may need its own settings.", "browser");
          return;
        }
        void clearBrowserData()
          .then((message) => system.notify("Browser data cleared", message, "browser"))
          .catch((error) => system.explain("Some browser data was not cleared", error instanceof Error ? error.message : "Android could not clear the native browser data."));
      },
    });
  };

  const isBookmarked = bookmarks.some((bookmark) => bookmark.url === normalizeUrl(address));
  const panelItems: { id: string; name: string; url: string; at: number }[] = panel === "bookmarks"
    ? bookmarks.map((bookmark) => ({ ...bookmark, at: 0 }))
    : panel === "history"
      ? history.map((launch) => ({ id: `history-${launch.at}`, name: launch.title, ...launch }))
      : [];
  const filteredPanelItems = panelItems.filter((item) => `${item.name || siteName(item.url)} ${item.url}`.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="browser-app gaming-browser">
      <div className="browser-engine-strip">
        <span className={native ? "native" : "preview"}>{native ? <ShieldCheck size={11}/> : <Smartphone size={11}/>}{native ? "NATIVE ANDROID WEBVIEW ENGINE" : "WEB PREVIEW ONLY"}</span>
        <p>{native ? `Desktop mode ${desktopMode ? "on" : "off"} · cookies · JavaScript · video · downloads` : "YouTube and many sites block embedding. The installed APK uses a full native browser engine."}</p>
        <button onClick={() => setPanel("settings")}><Settings2 size={13}/> Browser settings</button>
      </div>
      <div className="browser-tabs native-tabs">
        <div className="browser-tab active"><Globe size={12}/><span>KKDex Browser</span><span className="browser-tab-count">Tabs live in native window</span></div>
        <button className="browser-tab-new" onClick={startHome}><Plus size={16}/></button>
        <div className="toolbar-spacer"/>
        <button className="browser-native-action" onClick={() => { setMode("native"); go(native ? (address || "https://www.youtube.com") : ""); }} disabled={loading}><PlayNatively/> {native ? "Open native browser" : "Native required"}</button>
      </div>
      <div className="browser-toolbar gaming-browser-toolbar">
        <IconButton label="Back in embedded preview" disabled={mode !== "preview" || previewTab.current.index <= 0} onClick={() => goPreview(-1)}><ArrowLeft size={16}/></IconButton>
        <IconButton label="Forward in embedded preview" disabled={mode !== "preview" || previewTab.current.index >= previewTab.current.history.length - 1} onClick={() => goPreview(1)}><ArrowRight size={16}/></IconButton>
        <IconButton label="Reload page" disabled={mode !== "preview"} onClick={() => { setReloadKey((key) => key + 1); setLoading(true); }}><RefreshCw size={15} className={loading ? "spin" : ""}/></IconButton>
        <IconButton label="Browser home" onClick={startHome}><Home size={15}/></IconButton>
        <form className="browser-address gaming-address" onSubmit={(event: FormEvent) => { event.preventDefault(); go(); }}>
          <LockKeyhole size={14}/>
          <input ref={addressRef} aria-label="Browser address" value={address} onChange={(event) => setAddress(event.target.value)} onFocus={(event) => event.target.select()} placeholder="Search the web or enter an address"/>
          <button type="submit" aria-label="Go"><ArrowRight size={15}/></button>
        </form>
        <IconButton label={isBookmarked ? "Remove bookmark" : "Bookmark this address"} className={isBookmarked ? "chosen" : ""} onClick={toggleBookmark}><Bookmark size={15}/></IconButton>
        <IconButton label="Browsing history" onClick={() => setPanel("history")}><History size={15}/></IconButton>
        <IconButton label="Open in system browser" disabled={!address} onClick={openExternal}><ExternalLink size={15}/></IconButton>
        <IconButton label="Browser settings" onClick={() => setPanel("settings")}><MoreHorizontal size={17}/></IconButton>
      </div>
      {panel && <div className="browser-popover">
        <div className="browser-popover-head"><strong>{panel === "history" ? "Browsing history" : panel === "bookmarks" ? "Bookmarks" : "Browser settings"}</strong><IconButton label="Close browser panel" onClick={() => setPanel(null)}><X size={15}/></IconButton></div>
        {panel !== "settings" ? <>
          <div className="browser-popover-search"><Search size={13}/><input aria-label="Search browser history or bookmarks" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={`Search ${panel}`}/></div>
          <div className="browser-popover-list">{filteredPanelItems.length ? filteredPanelItems.map((item, index) => <div key={`${item.url}-${index}`}><Globe size={14}/><button onClick={() => { setPanel(null); go(item.url); }}><strong>{item.name}</strong><small>{item.url}</small></button><small>{new Date(item.at || Date.now()).toLocaleDateString()}</small>{panel === "bookmarks" ? <button aria-label={`Remove ${item.name}`} onClick={() => setBookmarks((items) => items.filter((bookmark) => bookmark.id !== item.id))}><X size={12}/></button> : <DeleteLaunch onDelete={() => setHistory((items) => items.filter((launch) => launch.at !== item.at))}/>}</div>) : <EmptyState icon={panel === "history" ? <Clock3 size={27}/> : <Bookmark size={27}/>} title={panel === "history" ? "Your history starts here" : "No bookmarks yet"} description={panel === "history" ? "Pages you launch through KK DEX will appear here." : "Bookmark the address in the toolbar."}/>}</div>
          {native && panel === "history" && <div className="native-history"><span><Monitor size={12}/> Native browser history</span>{nativeHistory.length ? nativeHistory.slice(0, 8).map((entry) => <button key={`${entry.url}-${entry.visitedAt}`} onClick={() => { setPanel(null); go(entry.url); }}><strong>{entry.title || siteName(entry.url)}</strong><small>{entry.url}</small><span>{timeAgo(entry.visitedAt)}</span></button>) : <p>No native history yet.</p>}</div>}
        </> : <div className="browser-settings-panel">
          <div><span><Monitor size={15}/><strong>Desktop website mode</strong><small>Requests a desktop user agent from the native browser. Some sites still serve mobile layouts.</small></span><BrowserToggle checked={desktopMode} onChange={setDesktopMode}/></div>
          <div><span><Download size={15}/><strong>Downloads</strong><small>Native DownloadManager saves browser downloads to Android Downloads. Configure the subfolder and see APK installs.</small></span><button onClick={() => { setPanel(null); system.openApp("downloads"); }}>Open <ArrowUpRight size={12}/></button></div>
          <div><span><Globe size={15}/><strong>Website permissions</strong><small>Android controls camera, microphone, location, notifications and protected media. The native browser asks before granting web permissions; unavailable features are reported.</small></span><button onClick={() => system.explain("Website permissions", "The KKDex native browser handles Android WebView permission requests rather than silently granting them. Camera, microphone and location require the matching Android permission and WebView support. Protected media requiring DRM support may be unavailable.")}><Info size={12}/> Details</button></div>
          <div><span><ShieldCheck size={15}/><strong>Search engine</strong><small>Address-bar searches use DuckDuckGo. Direct domains and full http(s) URLs navigate directly.</small></span><span className="browser-setting-value">DuckDuckGo</span></div>
          <div><span><Trash2 size={15}/><strong>Clear browsing data</strong><small>Clear KK DEX history, bookmarks, native cookies, local storage and cache.</small></span><button className="danger-link" onClick={clearEverything}>Clear</button></div>
          <div><span><LockKeyhole size={15}/><strong>Private browsing</strong><small>Not offered in this WebView build. KK DEX will not present a fake incognito switch. Use Clear browsing data after a session instead.</small></span><span className="browser-setting-value">Unavailable</span></div>
        </div>}
      </div>}
      {mode === "home" ? <div className="browser-home gaming-browser-home">
        <div className="browser-home-brand"><AppIcon app="browser" size={59}/><span className="eyebrow">A DESKTOP BROWSER, BUILT TO GO FURTHER</span><h1>Where to next?</h1><p>{native ? "Real WebView browsing with tabs, cookies, keyboard and media." : "Explore the KK DEX browser preview. Use the Android app for full browser-engine compatibility."}</p></div>
        <form className="browser-home-search" onSubmit={(event) => { event.preventDefault(); go(); }}><Search size={18}/><input aria-label="Search the web" value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Search the web or enter a website"/><button type="submit" aria-label="Search"><ArrowRight size={18}/></button></form>
        <div className="browser-shortcuts gaming-shortcuts">{bookmarks.slice(0, 6).map((bookmark) => <button key={bookmark.id} onClick={() => go(bookmark.url)}><span className={`website-mark ${bookmark.id === "youtube" ? "youtube" : ""}`}>{bookmark.id === "youtube" ? <YoutubeMark/> : <Globe size={21}/>}</span><span>{bookmark.name}</span></button>)}<button onClick={() => setPanel("bookmarks")}><span className="website-mark"><Plus size={19}/></span><span>Bookmarks</span></button></div>
        <div className="browser-quick-row">
          <button onClick={() => setPanel("history")}><History size={16}/><span><strong>History</strong><small>{history.length} visited</small></span><ChevronDown size={12}/></button>
          <button onClick={() => system.openApp("downloads")}><Download size={16}/><span><strong>Downloads</strong><small>Android DownloadManager</small></span><ChevronDown size={12}/></button>
          <button onClick={() => setPanel("settings")}><Settings2 size={16}/><span><strong>Browser settings</strong><small>Desktop mode and privacy</small></span><ChevronDown size={12}/></button>
        </div>
        <div className="native-browser-capabilities"><span><ShieldCheck size={13}/>Persistent cookies</span><span><Globe size={13}/>JavaScript</span><span><Monitor size={13}/>Full-screen video</span><span><ArrowUpRight size={13}/>Popup windows</span><span><Download size={13}/>Downloads</span></div>
        <div className="browser-privacy"><LockKeyhole size={13}/>{native ? "Remote web content never receives the KK DEX native bridge." : "A restricted embedded preview. Not the primary Android browser."}</div>
      </div> : mode === "native" ? <div className="native-browser-state">
        <div className="native-browser-orb"><Globe size={40}/></div>
        <span className="eyebrow">NATIVE WEBVIEW SESSION</span>
        <h2>{loading ? "Opening the real browser…" : "The desktop browser is active."}</h2>
        <p>{status || (native ? "Use the KKDex native browser toolbar on the television for address navigation, tabs, back, forward, reload, video, cookies and downloads. The phone touchpad controller continues to send desktop input, while physical keyboard/mouse operate the focused website." : "The native Android browser is unavailable in this preview.")}</p>
        {address && <div className="native-browser-address"><LockKeyhole size={13}/>{address}</div>}
        <div><button className="primary-button" onClick={() => go(address)} disabled={!native}><ExternalLink size={14}/> Reopen native browser</button><button className="secondary-button" onClick={startHome}>Browser home</button></div>
        <small><Info size={12}/> YouTube playback, logins and keyboard input inside websites are provided by Android System WebView. DRM, codecs and site policy still apply.</small>
      </div> : <div className="browser-web-content">
        <div className="browser-embed-notice"><Info size={13}/><span>Embedded preview mode — many sites refuse framing. For YouTube and full keyboard/mouse input, use the native KK DEX browser in the Android app.</span><button onClick={openExternal}>Open externally <ArrowUpRight size={12}/></button></div>
        <iframe key={`${previewUrl}-${reloadKey}`} title={`Web page: ${previewUrl}`} src={previewUrl} sandbox="allow-scripts allow-forms allow-popups allow-same-origin" referrerPolicy="no-referrer" onLoad={() => setLoading(false)} onError={() => { setLoading(false); system.explain("Page unavailable", "This site refused the embedded preview. The native KK DEX browser can load it with Android WebView."); }}/>
      </div>}
      <div className="browser-status-bar"><span>{native ? <><ShieldCheck size={11}/> Native bridge ready</> : <><Info size={11}/> Preview only</>}</span><span>{history.length} history entries · {bookmarks.length} bookmarks · {loading ? "loading" : "ready"}</span></div>
    </div>
  );
}

function PlayNatively() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m9 6 9 6-9 6V6Z" fill="currentColor"/><path d="M4 5v14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
}
function YoutubeMark() {
  return <svg width="23" height="17" viewBox="0 0 28 20" fill="none" aria-hidden="true"><rect width="28" height="20" rx="5" fill="#e04b4b"/><path d="m12 6 8 4-8 4V6Z" fill="white"/></svg>;
}
function BrowserToggle({ checked, onChange }: { checked: boolean; onChange: (checked: boolean) => void }) {
  return <button className={`toggle ${checked ? "checked" : ""}`} role="switch" aria-checked={checked} aria-label="Desktop website mode" onClick={() => onChange(!checked)}><span/></button>;
}
function DeleteLaunch({ onDelete }: { onDelete: () => void }) {
  return <button aria-label="Delete history entry" onClick={onDelete}><X size={12}/></button>;
}
