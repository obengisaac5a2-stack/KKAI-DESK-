import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type ReactNode,
} from "react";
import JSZip from "jszip";
import {
  AlertTriangle,
  AppWindow,
  Archive,
  ArrowLeft,
  ArrowRight,
  ChevronRight,
  Copy,
  Download,
  ExternalLink,
  File,
  FileImage,
  FileMusic,
  FileText,
  FileVideo,
  RotateCcw,
  Package,
  Folder,
  FolderInput,
  FolderPlus,
  FolderSearch,
  Share2,
  HardDrive,
  Info,
  LoaderCircle,
  Monitor,
  Music2,
  Pencil,
  Play,
  RefreshCw,
  Save,
  Search,
  ShieldCheck,
  Smartphone,
  Trash2,
  Upload,
  Video,
  X,
} from "lucide-react";
import {
  androidMediaKind,
  base64ToBytes,
  base64ToText,
  bytesToBase64,
  contentUrl,
  copyDocument,
  createDirectory,
  deleteDocument,
  encodeAndroidPayload,
  exportBase64,
  exportExistingFile,
  formatAndroidBytes,
  formatAndroidDate,
  getDisplayStatus,
  getDownloads,
  getInstalledApps,
  getSystemInfo,
  launchInstalledApp,
  listDirectory,
  listRoots,
  nativeAvailable,
  openDocument,
  openDownload,
  installApkUri,
  shareDocument,
  cancelDownload,
  retryDownload,
  installDownloadedApk,
  getStorageOverview,
  parseAndroidPayload,
  pdfInfo,
  pdfRenderPage,
  pickFiles,
  pickFolder,
  readFile,
  renameDocument,
  requestMediaPermissions,
  writeFile,
} from "../android/native";
import { useSystem } from "../system";
import { EmptyState, IconButton } from "../ui";
import type {
  AndroidDisplayStatus,
  AndroidDownload,
  AndroidFileEntry,
  AndroidRoot,
  AndroidSystemInfo,
  DesktopWindow,
  InstalledAndroidApp,
} from "../types";

function NativeRequired({
  title,
  description,
  icon,
}: {
  title: string;
  description: string;
  icon?: ReactNode;
}) {
  return (
    <div className="native-required">
      <div className="native-required-icon">{icon || <Smartphone size={34} />}</div>
      <h2>{title}</h2>
      <p>{description}</p>
      <div className="native-required-note">
        <ShieldCheck size={14} /> This browser preview has no Android device
        authority. Nothing was simulated or granted.
      </div>
    </div>
  );
}

function useAndroidError() {
  const { explain } = useSystem();
  return (title: string, error: unknown) =>
    explain(
      title,
      error instanceof Error
        ? error.message
        : "Android could not complete this operation.",
    );
}

function entryIcon(entry: AndroidFileEntry, size = 19) {
  if (entry.isDirectory) return <Folder size={size} />;
  switch (androidMediaKind(entry.mime, entry.name)) {
    case "image":
      return <FileImage size={size} />;
    case "video":
      return <FileVideo size={size} />;
    case "audio":
      return <FileMusic size={size} />;
    case "text":
      return <FileText size={size} />;
    case "archive":
      return <Archive size={size} />;
    default:
      return <File size={size} />;
  }
}

function pathError(title: string, error: unknown) {
  return (
    <div className="native-error">
      <AlertTriangle size={16} />
      <div>
        <strong>{title}</strong>
        <p>{error instanceof Error ? error.message : String(error)}</p>
      </div>
    </div>
  );
}

export function AndroidStorageApp() {
  const system = useSystem();
  const report = useAndroidError();
  const available = nativeAvailable();
  const [roots, setRoots] = useState<AndroidRoot[]>([]);
  const [root, setRoot] = useState<AndroidRoot | null>(null);
  const [treeUri, setTreeUri] = useState("");
  const [folderUri, setFolderUri] = useState<string | undefined>();
  const [entries, setEntries] = useState<AndroidFileEntry[]>([]);
  const [trail, setTrail] = useState<AndroidRoot[]>([]);
  const [parents, setParents] = useState<{ name: string; uri: string }[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [permissionState, setPermissionState] = useState<string>("");
  const currentRoot = useRef<AndroidRoot | null>(null);
  currentRoot.current = root;

  const refreshRoots = async () => {
    try {
      setRoots(await listRoots());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  };

  const load = async (targetRoot: AndroidRoot, parentUri?: string) => {
    setLoading(true);
    setError(null);
    try {
      const list = await listDirectory(targetRoot.uri, parentUri);
      setRoot(targetRoot);
      setTreeUri(targetRoot.uri);
      setFolderUri(parentUri);
      setEntries(list);
      setSelected([]);
      if (!parentUri) {
        setParents([]);
        setTrail([targetRoot]);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!available) return;
    void refreshRoots();
    const open = (event: Event) => {
      const next = (event as CustomEvent<AndroidRoot>).detail;
      if (next?.uri) {
        void refreshRoots();
        void load(next);
      }
    };
    window.addEventListener("kkdex:android-folder", open);
    return () => window.removeEventListener("kkdex:android-folder", open);
  }, [available]);

  const chooseFolder = async () => {
    try {
      const next = await pickFolder();
      await refreshRoots();
      await load(next);
    } catch (cause) {
      report("Could not open the Android folder picker", cause);
    }
  };

  const chooseFiles = async () => {
    try {
      const picked = await pickFiles("*/*");
      setEntries(picked);
      setTrail([{ id: "picked", uri: "picked://files", kind: "tree", name: "Picked files" }]);
      setRoot({ id: "picked", uri: "picked://files", kind: "tree", name: "Picked files" });
      setTreeUri("");
      setFolderUri(undefined);
      setParents([]);
      setSelected(picked[0] ? [picked[0].uri] : []);
      setError(null);
    } catch (cause) {
      report("Could not select Android files", cause);
    }
  };

  const refresh = async () => {
    if (!root || root.uri === "picked://files") return;
    setLoading(true);
    try {
      setEntries(await listDirectory(treeUri, folderUri));
      await refreshRoots();
      setError(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setLoading(false);
    }
  };

  const open = async (entry: AndroidFileEntry) => {
    if (entry.isDirectory) {
      try {
        const list = await listDirectory(treeUri, entry.uri);
        const nextParents = [...parents, { name: entry.name, uri: entry.uri }];
        setEntries(list);
        setFolderUri(entry.uri);
        setParents(nextParents);
        if (root) {
          setTrail([
            root,
            ...nextParents.map((parent) => ({
              id: parent.uri,
              uri: treeUri,
              kind: "tree" as const,
              name: parent.name,
            })),
          ]);
        }
        setSelected([]);
      } catch (cause) {
        report("Could not open this Android folder", cause);
      }
      return;
    }
    const kind = androidMediaKind(entry.mime, entry.name);
    const payload = encodeAndroidPayload({ ...entry, treeUri });
    if (kind === "image") system.openApp("gallery", payload);
    else if (kind === "video") system.openApp("video", payload);
    else if (kind === "audio") system.openApp("music", payload);
    else if (kind === "pdf") system.openApp("pdf", payload);
    else if (kind === "text") system.openApp("editor", payload);
    else if (kind === "archive") system.openApp("archives", payload);
    else if (entry.mime === "application/vnd.android.package-archive" || entry.name.toLowerCase().endsWith(".apk")) {
      system.setDialog({
        title: "Install this Android APK?",
        message: `Android will open its official package installer for ${entry.name}. KK DEX cannot install silently or bypass unknown-source, signature or Play Protect checks.`,
        confirmLabel: "Open Android installer",
        onConfirm: () => { void installApkUri(entry.uri).then((message) => system.notify("Android installer", message, "storage")).catch((cause) => report("APK installation could not start", cause)); },
      });
    }
    else {
      try {
        const result = await openDocument(treeUri, entry.uri, entry.mime || "*/*");
        system.notify("Android file opened", result, "storage");
      } catch (cause) {
        report("No compatible Android viewer", cause);
      }
    }
  };

  const doCreateFolder = (name: string) => {
    if (!root || !treeUri) return;
    void createDirectory(treeUri, folderUri || root.uri, name)
      .then(refresh)
      .catch((cause) => report("Could not create the folder", cause));
  };

  const newFolder = () =>
    system.setDialog({
      title: "New Android folder",
      message: "This creates a real folder in the authorized Android location.",
      input: true,
      initialValue: "New folder",
      confirmLabel: "Create folder",
      onConfirm: doCreateFolder,
    });

  const selectedEntries = entries.filter((entry) => selected.includes(entry.uri));
  const selectedEntry = selectedEntries[0] || null;
  const rename = () => {
    if (!selectedEntry || !treeUri) return;
    system.setDialog({
      title: "Rename Android item",
      input: true,
      initialValue: selectedEntry.name,
      confirmLabel: "Rename",
      onConfirm: (name) => {
        if (!name.trim()) return;
        void renameDocument(treeUri, selectedEntry.uri, name.trim())
          .then(refresh)
          .catch((cause) => report("Android did not rename the item", cause));
      },
    });
  };

  const remove = () => {
    if (!selectedEntries.length || !treeUri) return;
    system.setDialog({
      title: selectedEntries.length === 1 ? `Delete ${selectedEntries[0].name}?` : `Delete ${selectedEntries.length} Android items?`,
      message: "Android's document provider will delete the selected item(s) permanently. This does not use the KK DEX workspace Recycle Bin.",
      confirmLabel: selectedEntries.length === 1 ? "Delete from Android" : `Delete ${selectedEntries.length} items`,
      danger: true,
      onConfirm: () => {
        void Promise.allSettled(selectedEntries.map((entry) => deleteDocument(treeUri, entry.uri)))
          .then((results) => {
            const failed = results.filter((result) => result.status === "rejected").length;
            if (failed) report("Some Android items were not deleted", new Error(`${failed} of ${selectedEntries.length} items were refused or could not be found. Android's provider error is authoritative; refresh the folder to see what remains.`));
            return refresh();
          })
          .catch((cause) => report("Android refused to delete the items", cause));
      },
    });
  };

  const transfer = async (move: boolean) => {
    if (!selectedEntry || !treeUri) return;
    try {
      const destination = await pickFolder();
      await copyDocument(
        treeUri,
        selectedEntry.uri,
        destination.uri,
        move,
      );
      system.notify(
        move ? "Android item moved" : "Android item copied",
        `${selectedEntry.name} was ${move ? "moved" : "copied"} into ${destination.name}.`,
        "storage",
      );
      await refresh();
    } catch (cause) {
      report(move ? "Could not move the Android item" : "Could not copy the Android item", cause);
    }
  };

  const exportItem = () => {
    if (!selectedEntry || !treeUri) return;
    void exportExistingFile(treeUri, selectedEntry.uri, selectedEntry.name)
      .then((name) =>
        system.notify(
          "Exported to Android",
          `${name} was saved through Android's document picker.`,
          "storage",
        ),
      )
      .catch((cause) => report("Android export was not completed", cause));
  };

  const importToWorkspace = async () => {
    if (!selectedEntry || selectedEntry.isDirectory) return;
    if (selectedEntry.size > 2 * 1024 * 1024) {
      report(
        "File is too large for the workspace",
        new Error(
          "The persistent browser workspace has a 2 MB per-file limit. Open this file directly with its Android viewer instead, or export it through Android.",
        ),
      );
      return;
    }
    try {
      const file = await readFile(selectedEntry.uri);
      const kind = androidMediaKind(selectedEntry.mime, selectedEntry.name);
      let content: string;
      if (kind === "text") content = base64ToText(file.base64);
      else if (kind === "image")
        content = `data:${selectedEntry.mime || "image/*"};base64,${file.base64}`;
      else {
        report(
          "Open this type directly",
          new Error(
            "Only text and images can be copied into the small persistent browser workspace. Use Android export for documents, video, audio, and archives.",
          ),
        );
        return;
      }
      system.setFiles((files) => [
        ...files,
        {
          id: `android-${Date.now().toString(36)}`,
          name: selectedEntry.name,
          parent: "downloads",
          kind: kind === "image" ? "image" : "text",
          content,
          size: selectedEntry.size || file.size,
          modified: new Date().toISOString(),
        },
      ]);
      system.notify(
        "Imported into KK DEX",
        `${selectedEntry.name} is now in Files > Downloads. Android's origin was read with permission and the content was copied.`,
        "storage",
      );
    } catch (cause) {
      report("Could not read the Android file", cause);
    }
  };

  const askMediaAccess = async () => {
    try {
      const result = await requestMediaPermissions();
      setPermissionState(result.explanation);
    } catch (cause) {
      report("Could not request Android media access", cause);
    }
  };

  const goUp = () => {
    if (root && parents.length) {
      const nextParents = parents.slice(0, -1);
      const parentUri = nextParents[nextParents.length - 1]?.uri;
      setParents(nextParents);
      setFolderUri(parentUri);
      if (root) {
        setTrail([
          root,
          ...nextParents.map((parent) => ({
            id: parent.uri,
            uri: treeUri,
            kind: "tree" as const,
            name: parent.name,
          })),
        ]);
      }
      void listDirectory(treeUri, parentUri)
        .then(setEntries)
        .catch((cause) => report("Could not return to the parent folder", cause));
    } else {
      setRoot(null);
      setEntries([]);
      setTrail([]);
      setParents([]);
      setSelected([]);
      void refreshRoots();
    }
  };

  if (!available)
    return (
      <NativeRequired
        title="Files need their Android connection."
        description="Android Storage reads the real files you authorize through Storage Access Framework. In the installed Android app, choose a folder to grant access and its URI is persisted securely."
        icon={<HardDrive size={36} />}
      />
    );

  const visible = entries
    .filter((entry) => !query || entry.name.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => Number(b.isDirectory) - Number(a.isDirectory) || a.name.localeCompare(b.name));

  return (
    <div className="android-storage">
      <div className="android-storage-bar">
        <IconButton label="Android storage locations" onClick={goUp}>
          <ArrowLeft size={16} />
        </IconButton>
        <IconButton label="Refresh Android folder" onClick={() => void refresh()}>
          <RefreshCw size={15} className={loading ? "spin" : ""} />
        </IconButton>
        <div className="android-breadcrumb">
          <Smartphone size={13} />
          <span>Android</span>
          <ChevronRight size={11} />
          <strong>{root?.name || "Storage locations"}</strong>
          {trail.length > 1 && <span>/ {trail[trail.length - 1].name}</span>}
        </div>
        <div className="file-search">
          <Search size={13} />
          <input
            aria-label="Search Android storage"
            placeholder="Search this folder"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </div>
      </div>
      <div className="android-storage-toolbar">
        <button className="secondary-button" onClick={() => void chooseFolder()}>
          <FolderSearch size={14} /> Open folder…
        </button>
        <button className="text-tool" onClick={() => void chooseFiles()}>
          <FolderInput size={14} /> Select files
        </button>
        {root && root.uri !== "picked://files" && (
          <>
            <span className="toolbar-divider" />
            <button className="text-tool" disabled={!treeUri} onClick={newFolder}>
              <FolderPlus size={14} /> New folder
            </button>
            <button className="text-tool" disabled={!selectedEntry} onClick={rename}>
              <Pencil size={14} /> Rename
            </button>
            <button className="text-tool" disabled={!selectedEntry} onClick={() => void transfer(false)}>
              <Copy size={14} /> Copy
            </button>
            <button className="text-tool" disabled={!selectedEntry} onClick={() => void transfer(true)}>
              <FolderInput size={14} /> Move
            </button>
            <button className="text-tool" disabled={!selectedEntry} onClick={remove}>
              <Trash2 size={14} /> Delete
            </button>
            <button className="text-tool" disabled={!selectedEntry} onClick={exportItem}>
              <Download size={14} /> Export
            </button>
            <button className="text-tool" disabled={!selectedEntry} onClick={() => { if (!selectedEntry) return; void shareDocument(selectedEntry.uri, selectedEntry.mime).then((message) => system.notify("Android share sheet", message, "storage")).catch((cause) => report("Could not share this Android item", cause)); }}>
              <Share2 size={14} /> Share
            </button>
            <button className="text-tool" disabled={!selectedEntry || selectedEntry.isDirectory} onClick={() => void importToWorkspace()}>
              <Upload size={14} /> Import
            </button>
          </>
        )}
        <div className="toolbar-spacer" />
        <button className="text-tool" onClick={() => void askMediaAccess()}>
          <ShieldCheck size={14} /> Media permissions
        </button>
      </div>
      {permissionState && (
        <div className="android-inline-note">
          <Info size={13} /> {permissionState}
        </div>
      )}
      {error && <div className="android-error-banner">{pathError("Android storage error", error)}</div>}
      {!root ? (
        <div className="android-roots">
          <div className="android-roots-heading">
            <span className="eyebrow">STORAGE ACCESS FRAMEWORK</span>
            <h1>Your phone. Your permission.</h1>
            <p>
              KK DEX can only list files inside folders you authorize. Opening a
              folder uses Android's native picker and retains read/write access
              when Android allows it.
            </p>
          </div>
          <div className="android-root-actions">
            <button onClick={() => void chooseFolder()}>
              <div className="android-root-icon tree"><FolderSearch size={23} /></div>
              <span><strong>Authorize a folder</strong><small>Open Android's folder picker</small></span>
              <ChevronRight size={16} />
            </button>
            <button onClick={() => void chooseFiles()}>
              <div className="android-root-icon picked"><File size={23} /></div>
              <span><strong>Pick specific files</strong><small>Pictures, videos, audio, documents, APKs or archives</small></span>
              <ChevronRight size={16} />
            </button>
          </div>
          <h3 className="section-heading">Authorized and media locations</h3>
          <div className="android-root-list">
            {roots.length ? roots.map((item) => (
              <button key={item.id} onClick={() => void load(item)}>
                <div className={`android-root-icon ${item.kind === "tree" ? "tree" : "media"}`}>
                  {item.kind === "tree" ? <Folder size={21} /> : item.mediaType === "images" ? <FileImage size={21} /> : item.mediaType === "videos" ? <FileVideo size={21} /> : item.mediaType === "audio" ? <FileMusic size={21} /> : <Download size={21} />}
                </div>
                <span><strong>{item.name}</strong><small>{item.description || (item.kind === "tree" ? "Authorized Android folder" : "Android MediaStore collection")}</small></span>
                <ChevronRight size={15} />
              </button>
            )) : (
              <div className="android-empty-inline">
                <ShieldCheck size={20} />
                <p>No folder is authorized yet. Choose a folder to begin. Media collections appear only when Android exposes them to this app.</p>
              </div>
            )}
          </div>
        </div>
      ) : loading && !entries.length ? (
        <div className="native-loading"><LoaderCircle className="spin" size={22} /> Reading Android storage…</div>
      ) : visible.length ? (
        <div className="android-file-list">
          <div className="android-file-head"><span>Name</span><span>Type</span><span>Modified</span><span>Size</span><span /></div>
          {visible.map((entry) => (
            <div
              key={entry.uri}
              className={`android-file-row ${selected.includes(entry.uri) ? "selected" : ""}`}
              onClick={(event) => setSelected((value) => event.ctrlKey || event.metaKey ? value.includes(entry.uri) ? value.filter((item) => item !== entry.uri) : [...value, entry.uri] : [entry.uri])}
              onDoubleClick={() => void open(entry)}
              onContextMenu={(event) => {
                event.preventDefault();
                setSelected([entry.uri]);
                system.setContextMenu({
                  x: event.clientX,
                  y: event.clientY,
                  items: [
                    { label: "Open", icon: <ExternalLink size={15} />, action: () => void open(entry) },
                    { label: "Rename", icon: <Pencil size={15} />, action: rename },
                    { label: "Delete from Android", icon: <Trash2 size={15} />, danger: true, action: remove },
                    { label: "Export through Android", icon: <Download size={15} />, action: exportItem },
                  ],
                });
              }}
            >
              <span className="android-file-name">
                <span className="android-file-icon">{entryIcon(entry)}</span>
                <span><strong>{entry.name}</strong><small>{entry.source === "saf" ? "SAF document" : "MediaStore"}</small></span>
              </span>
              <span>{entry.isDirectory ? "Folder" : entry.mime || "Unknown"}</span>
              <span>{formatAndroidDate(entry.modified)}</span>
              <span>{entry.isDirectory ? "—" : formatAndroidBytes(entry.size)}</span>
              <button aria-label={`Open ${entry.name}`} onClick={(event) => { event.stopPropagation(); void open(entry); }}><ChevronRight size={15} /></button>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState icon={<Folder size={40} />} title="This authorized folder is empty" description="Android returned no readable children. Use the picker to add files, or refresh after changing access.">
          <button className="secondary-button" onClick={() => void refresh()}><RefreshCw size={14} /> Refresh</button>
        </EmptyState>
      )}
      <div className="android-storage-footer">
        <span><ShieldCheck size={12} /> Access is limited to Android-authorized URIs</span>
        <span>{visible.length} visible items{selectedEntries.length > 0 ? ` · ${selectedEntries.length} selected${selectedEntry ? ` · ${formatAndroidBytes(selectedEntry.size)} ${selectedEntry.mime || ""}` : ""}` : ""}</span>
      </div>
    </div>
  );
}

export function TextEditorApp({ win }: { win: DesktopWindow }) {
  const system = useSystem();
  const report = useAndroidError();
  const [document, setDocument] = useState<AndroidFileEntry | null>(() =>
    parseAndroidPayload(win.payload),
  );
  const [text, setText] = useState("");
  const [savedText, setSavedText] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("No Android document open");
  const loadedUri = useRef<string | null>(null);
  const available = nativeAvailable();
  const dirty = text !== savedText;

  const openAndroidText = async () => {
    if (!available) return;
    try {
      const entries = await pickFiles("text/*");
      if (!entries[0]) return;
      await loadEntry(entries[0]);
    } catch (cause) {
      report("Could not open text from Android", cause);
    }
  };

  const loadEntry = async (entry: AndroidFileEntry) => {
    setBusy(true);
    try {
      const file = await readFile(entry.uri);
      const content = base64ToText(file.base64);
      setDocument(entry);
      setText(content);
      setSavedText(content);
      setStatus(`Opened ${entry.name} with Android read permission`);
    } catch (cause) {
      report("Android could not read this text file", cause);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    const entry = parseAndroidPayload(win.payload);
    if (entry && loadedUri.current !== entry.uri) {
      loadedUri.current = entry.uri;
      void loadEntry(entry);
    }
  }, [win.payload]);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (system.activeId !== win.id || !(event.ctrlKey || event.metaKey)) return;
      if (event.key.toLowerCase() === "s") {
        event.preventDefault();
        void save();
      }
      if (event.key.toLowerCase() === "o") {
        event.preventDefault();
        void openAndroidText();
      }
    };
    window.addEventListener("keydown", keydown);
    return () => window.removeEventListener("keydown", keydown);
  });

  const save = async () => {
    if (!document) {
      await saveAs();
      return;
    }
    if (!available) {
      report("Android storage unavailable", new Error("The Android app is required to write this document in place."));
      return;
    }
    setBusy(true);
    try {
      await writeFile(document.uri, text);
      setSavedText(text);
      setStatus(`Saved ${document.name} through Android at ${new Date().toLocaleTimeString()}`);
      system.notify("Android text saved", `${document.name} was written through its authorized document URI.`, "editor");
    } catch (cause) {
      report("Android refused the write", cause);
    } finally {
      setBusy(false);
    }
  };

  const saveAs = async () => {
    try {
      const base64 = bytesToBase64(new TextEncoder().encode(text));
      if (available) {
        const name = await exportBase64(document?.name || "KK DEX note.txt", "text/plain", base64);
        setStatus(`Exported ${name} through Android's document picker`);
        system.notify("Text exported", `${name} was saved to your chosen Android location.`, "editor");
      } else {
        const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
        const anchor = window.document.createElement("a");
        anchor.href = url;
        anchor.download = document?.name || "KK DEX note.txt";
        anchor.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        setStatus("Downloaded a real copy. Native Android save requires the Android app.");
      }
    } catch (cause) {
      report("Could not export the text", cause);
    }
  };

  return (
    <div className="text-editor-app">
      <div className="editor-toolbar">
        <button className="secondary-button" disabled={!available || busy} onClick={() => void openAndroidText()}>
          <FolderSearch size={14} /> Open from Android
        </button>
        <button className="primary-button" disabled={busy} onClick={() => void save()}>
          {busy ? <LoaderCircle size={14} className="spin" /> : <Save size={14} />}
          {document ? "Save in place" : "Save as…"}
        </button>
        <button className="text-tool" disabled={busy} onClick={() => void saveAs()}>
          <Download size={14} /> Save as
        </button>
        <div className="toolbar-spacer" />
        <span className={`editor-dirty ${dirty ? "active" : ""}`}>
          <span className="status-dot" /> {dirty ? "Unsaved changes" : "In sync"}
        </span>
      </div>
      <div className="editor-document-head">
        <div>
          <strong>{document?.name || "Untitled Android text"}</strong>
          <small>{status}</small>
        </div>
        <span>{document ? formatAndroidDate(document.modified) : "Not connected to a document URI"}</span>
      </div>
      <textarea
        className="android-textarea"
        aria-label="Android text editor content"
        spellCheck={false}
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder="Open a text document from Android, or start writing here. Save as uses Android's real document picker."
      />
      <div className="editor-footer">
        <span>{text.length.toLocaleString()} characters</span>
        <span>{available ? "Android native write adapter available" : "Browser preview · native write unavailable"}</span>
      </div>
    </div>
  );
}

export function MediaPlayerApp({ win, mode }: { win: DesktopWindow; mode: "video" | "music" }) {
  const system = useSystem();
  const report = useAndroidError();
  const [entry, setEntry] = useState<AndroidFileEntry | null>(() =>
    parseAndroidPayload(win.payload),
  );
  const [source, setSource] = useState("");
  const [status, setStatus] = useState("Choose a file from authorized Android storage");
  const [busy, setBusy] = useState(false);
  const available = nativeAvailable();

  const load = async (next: AndroidFileEntry) => {
    setBusy(true);
    try {
      const url = await contentUrl(next.treeUri || "", next.uri, next.mime);
      setEntry(next);
      setSource(url);
      setStatus(`Streaming ${next.name} from its authorized Android URI`);
    } catch (cause) {
      report("Android could not open this media file", cause);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    const payload = parseAndroidPayload(win.payload);
    if (payload) void load(payload);
  }, [win.payload]);

  const choose = async () => {
    try {
      const files = await pickFiles(mode === "video" ? "video/*" : "audio/*");
      if (files[0]) await load(files[0]);
    } catch (cause) {
      report("Could not choose Android media", cause);
    }
  };

  if (!available)
    return (
      <NativeRequired
        title={`${mode === "video" ? "Video" : "Audio"} playback needs Android storage.`}
        description="The native adapter streams authorized content URIs through a read-only token URL. A browser preview cannot access your Android MediaStore or SAF files."
        icon={mode === "video" ? <Video size={34} /> : <Music2 size={34} />}
      />
    );

  return (
    <div className={`media-player-app ${mode}`}>
      <div className="media-toolbar">
        <button className="secondary-button" onClick={() => void choose()} disabled={busy}>
          <FolderSearch size={14} /> Open {mode} from Android
        </button>
        {entry && (
          <button className="text-tool" onClick={() => void contentUrl(entry.treeUri!, entry.uri, entry.mime).then(setSource).catch((cause) => report("Could not refresh stream", cause))}>
            <RefreshCw size={14} /> Reload stream
          </button>
        )}
        <div className="toolbar-spacer" />
        <span className="android-media-badge"><ShieldCheck size={12} /> ContentResolver stream</span>
      </div>
      <div className={`media-stage ${source ? "has-media" : ""}`}>
        {mode === "video" && source ? (
          <video src={source} controls autoPlay playsInline onError={() => setStatus("Android could not stream this video. Open it with an Android viewer instead.")} />
        ) : mode === "music" && source ? (
          <div className="music-stage">
            <div className="music-art"><Music2 size={53} /></div>
            <strong>{entry?.name || "Android audio"}</strong>
            <span>{entry?.mime || "Audio stream"}</span>
            <audio src={source} controls autoPlay onError={() => setStatus("Android could not stream this audio file.")} />
          </div>
        ) : (
          <div className="media-empty">
            {mode === "video" ? <Video size={48} /> : <Music2 size={48} />}
            <h2>{mode === "video" ? "A bigger picture." : "A little more atmosphere."}</h2>
            <p>{busy ? "Opening Android content…" : status}</p>
            <button className="primary-button" onClick={() => void choose()}>
              <Play size={14} /> Choose {mode}
            </button>
          </div>
        )}
      </div>
      <div className="media-footer">
        <div>{entry ? <><strong>{entry.name}</strong><small>{formatAndroidBytes(entry.size)} · {entry.mime || "Media"}</small></> : <span>{status}</span>}</div>
        {entry && (
          <button className="text-tool" onClick={() => void openDocument(entry.treeUri || "", entry.uri, entry.mime).then((result) => system.notify("Opened in Android", result, mode)).catch((cause) => report("No Android viewer available", cause))}>
            <ExternalLink size={14} /> Open in Android player
          </button>
        )}
      </div>
    </div>
  );
}

export function PdfViewerApp({ win }: { win: DesktopWindow }) {
  const report = useAndroidError();
  const system = useSystem();
  const [entry, setEntry] = useState<AndroidFileEntry | null>(() => parseAndroidPayload(win.payload));
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(0);
  const [image, setImage] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("Select a PDF using Android's document picker.");
  const available = nativeAvailable();

  const openPdf = async (next: AndroidFileEntry) => {
    setBusy(true);
    setImage("");
    try {
      const info = await pdfInfo(next.treeUri || "", next.uri);
      setEntry(next);
      setPages(info.pageCount);
      setPage(1);
      const rendered = await pdfRenderPage(next.treeUri || "", next.uri, 1, Math.min(1400, Math.max(700, window.innerWidth - 250)));
      setImage(rendered.image);
      setStatus(`Rendered page 1 of ${info.pageCount} with Android PdfRenderer`);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    const payload = parseAndroidPayload(win.payload);
    if (payload) void openPdf(payload).catch((cause) => report("Android could not render this PDF", cause));
  }, [win.payload]);

  const choose = async () => {
    try {
      const files = await pickFiles("application/pdf");
      if (!files[0]) return;
      await openPdf(files[0]);
    } catch (cause) {
      report("Could not open the PDF", cause);
    }
  };

  const showPage = async (nextPage: number) => {
    if (!entry?.treeUri || nextPage < 1 || nextPage > pages) return;
    setBusy(true);
    try {
      const rendered = await pdfRenderPage(entry.treeUri || "", entry.uri, nextPage, Math.min(1400, Math.max(700, window.innerWidth - 250)));
      setPage(nextPage);
      setImage(rendered.image);
      setStatus(`Rendered page ${nextPage} of ${pages} with Android PdfRenderer`);
    } catch (cause) {
      report("Android could not render this page", cause);
    } finally {
      setBusy(false);
    }
  };

  if (!available)
    return (
      <NativeRequired
        title="PDF rendering needs Android."
        description="KK DEX uses Android's PdfRenderer through the native bridge and displays each real page on the television. This preview has no authorized PDF file."
        icon={<FileText size={34} />}
      />
    );

  return (
    <div className="pdf-app">
      <div className="pdf-toolbar">
        <button className="secondary-button" onClick={() => void choose()}>
          <FolderSearch size={14} /> Open PDF from Android
        </button>
        {pages > 0 && (
          <>
            <IconButton label="Previous PDF page" disabled={page <= 1 || busy} onClick={() => void showPage(page - 1)}><ArrowLeft size={15} /></IconButton>
            <span>Page {page} of {pages}</span>
            <IconButton label="Next PDF page" disabled={page >= pages || busy} onClick={() => void showPage(page + 1)}><ArrowRight size={15} /></IconButton>
          </>
        )}
        <div className="toolbar-spacer" />
        <span className="android-media-badge"><ShieldCheck size={12} /> Android PdfRenderer</span>
      </div>
      <div className="pdf-stage">
        {busy ? <div className="native-loading"><LoaderCircle size={22} className="spin" /> Rendering on Android…</div> : image ? <img src={image} alt={`${entry?.name || "PDF"} page ${page}`} /> : (
          <EmptyState icon={<FileText size={40} />} title="Read it on the big screen." description={status}>
            <button className="primary-button" onClick={() => void choose()}><FolderSearch size={14} /> Choose PDF</button>
          </EmptyState>
        )}
      </div>
      <div className="pdf-footer">
        <span>{entry?.name || status}{entry ? ` · ${formatAndroidBytes(entry.size)}` : ""}</span>
        {entry && (
          <button className="text-tool" onClick={() => void openDocument(entry.treeUri || "", entry.uri, "application/pdf").then((result) => system.notify("Opened in Android", result, "pdf")).catch((cause) => report("No Android PDF viewer", cause))}>
            <ExternalLink size={13} /> Open with Android app
          </button>
        )}
      </div>
    </div>
  );
}

export function DownloadsApp() {
  const [downloads, setDownloads] = useState<AndroidDownload[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [location, setLocation] = useState("Internal storage/Download/KK DEX");
  const samples = useRef(new Map<number, { bytes: number; at: number; speed: number }>());
  const system = useSystem();
  const report = useAndroidError();
  const available = nativeAvailable();

  const load = async (quiet = false) => {
    if (!available) return;
    if (!quiet) setBusy(true);
    try {
      const items = await getDownloads();
      const now = Date.now();
      items.forEach((item) => {
        const previous = samples.current.get(item.id);
        const speed = previous && now > previous.at
          ? Math.max(0, (item.downloaded - previous.bytes) / ((now - previous.at) / 1000))
          : previous?.speed || 0;
        samples.current.set(item.id, { bytes: item.downloaded, at: now, speed });
        item.speed = speed;
      });
      setDownloads(items);
      setError(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      if (!quiet) setBusy(false);
    }
  };

  useEffect(() => {
    if (!available) return;
    void load();
    void getStorageOverview().then((overview) => setLocation(overview.downloadFolder)).catch(() => undefined);
    const timer = window.setInterval(() => {
      void getDownloads().then((items) => {
        const now = Date.now();
        items.forEach((item) => {
          const previous = samples.current.get(item.id);
          item.speed = previous && now > previous.at
            ? Math.max(0, (item.downloaded - previous.bytes) / ((now - previous.at) / 1000))
            : previous?.speed || 0;
          samples.current.set(item.id, { bytes: item.downloaded, at: now, speed: item.speed || 0 });
        });
        setDownloads(items);
      }).catch(() => undefined);
    }, 2000);
    return () => window.clearInterval(timer);
  }, [available]);

  if (!available)
    return (
      <NativeRequired
        title="Downloads live in Android."
        description="The native KDex browser and Android DownloadManager save real files under Internal storage/Download. A browser preview cannot access DownloadManager progress, pause/resume, storage or APK installation."
        icon={<Download size={34} />}
      />
    );

  const act = (promise: Promise<unknown>, title: string) => {
    void promise.then(() => load(true)).catch((cause) => report(title, cause));
  };

  return (
    <div className="downloads-app gaming-downloads">
      <div className="panel-heading">
        <div>
          <span className="eyebrow">ANDROID DOWNLOADMANAGER</span>
          <h1>Downloads</h1>
          <p>Real persistent files, Android-managed transfer state and APK installation.</p>
        </div>
        <button className="secondary-button" onClick={() => void load()} disabled={busy}>
          <RefreshCw size={14} className={busy ? "spin" : ""} /> Refresh
        </button>
      </div>
      <div className="download-location"><HardDrive size={13}/><span>Saved to</span><strong>{location}</strong><span style={{ marginLeft: "auto" }}>Change the subfolder in Storage</span></div>
      {error && pathError("Could not list Android downloads", error)}
      {downloads.length ? (
        <div className="downloads-list">
          {downloads.map((item) => {
            const percent = item.size > 0 ? Math.min(100, Math.round((item.downloaded / item.size) * 100)) : 0;
            const isApk = item.mime === "application/vnd.android.package-archive" || item.title.toLowerCase().endsWith(".apk");
            return (
              <div key={item.id} className="download-row">
                <span className={`download-icon ${isApk ? "apk" : ""}`}>{isApk ? <Package size={21}/> : <Download size={20}/>}</span>
                <div>
                  <strong>{item.title || "Unnamed download"}</strong>
                  <small>{formatAndroidBytes(item.downloaded)}{item.size > 0 ? ` of ${formatAndroidBytes(item.size)} · ${percent}%` : ""}{item.status === "running" && item.speed ? ` · ${formatAndroidBytes(item.speed)}/s` : ""}</small>
                  {(item.status === "running" || item.status === "paused" || item.status === "pending") && <div className="download-progress"><span style={{ width: `${Math.max(percent, 2)}%` }}/></div>}
                  {item.reasonText && <small>{item.reasonText}</small>}
                  {isApk && <span className="download-warning"><AlertTriangle size={10}/>APK · Android installer and Play Protect confirmation required</span>}
                </div>
                <span className={`download-status ${item.status}`}>{item.status}</span>
                <div className="download-actions">
                  {(item.status === "running" || item.status === "paused") && <button aria-label={`Pause/resume unavailable for ${item.title}`} title="Android DownloadManager does not expose public pause/resume. Cancel and Retry instead." disabled><Play size={13}/></button>}
                  {item.status === "failed" && <button aria-label={`Retry ${item.title}`} title="Retry" onClick={() => act(retryDownload(item.id), "Could not retry this download")}><RotateCcw size={13}/></button>}
                  {(item.status === "running" || item.status === "paused" || item.status === "pending" || item.status === "failed") && <button aria-label={`Cancel ${item.title}`} title="Cancel" onClick={() => system.setDialog({ title: "Cancel this download?", message: "Android DownloadManager will cancel the transfer and remove its partial data. This cannot be undone.", confirmLabel: "Cancel download", danger: true, onConfirm: () => act(cancelDownload(item.id), "Could not cancel this download") })}><X size={13}/></button>}
                  {isApk && item.status === "successful" ? (
                    <button aria-label={`Install ${item.title}`} title="Open Android installer" onClick={() => system.setDialog({ title: "Install this APK?", message: `Android will open its official package installer for ${item.title}. KK DEX cannot install silently or bypass unknown-source, signature or Play Protect checks.`, confirmLabel: "Open Android installer", onConfirm: () => { void installDownloadedApk(item.id).then((message) => system.notify("Android installer", message, "downloads")).catch((cause) => report("APK installation could not start", cause)); } })}><Package size={13}/></button>
                  ) : (
                    <button aria-label={`Open ${item.title}`} title="Open with Android" disabled={!item.localUri || item.status !== "successful"} onClick={() => void openDownload(item.id).then((result) => system.notify("Download opened", result, "downloads")).catch((cause) => report("Could not open this download", cause))}><ExternalLink size={13}/></button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState icon={<Download size={38} />} title="No Android downloads yet" description="Download a file from the KK DEX browser, then refresh. Only DownloadManager entries returned by Android are shown.">
          <button className="primary-button" onClick={() => system.openApp("browser")}>Open Browser</button>
        </EmptyState>
      )}
      <div className="gaming-limits" style={{ margin: "0 26px" }}><ShieldCheck size={14}/><span>Downloads survive closing KK DEX because Android stores them, not temporary web memory. Android's public DownloadManager API does not expose pause/resume, so KK DEX does not fake those controls. Cancel and Retry are real; a failed or paused transfer can be restarted if the server supports it. APK installation always requires Android's own confirmation.</span></div>
    </div>
  );
}

export function SystemInfoApp() {
  const [info, setInfo] = useState<AndroidSystemInfo | null>(null);
  const [display, setDisplay] = useState<AndroidDisplayStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const available = nativeAvailable();
  const load = async () => {
    try {
      setInfo(await getSystemInfo());
      setDisplay(await getDisplayStatus());
      setError(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  };
  useEffect(() => {
    if (available) void load();
    const update = (event: Event) => setDisplay((event as CustomEvent<AndroidDisplayStatus>).detail);
    window.addEventListener("kkdex:display-status", update);
    return () => window.removeEventListener("kkdex:display-status", update);
  }, [available]);

  if (!available)
    return (
      <NativeRequired
        title="Device details require Android."
        description="KK DEX reads the actual display connection, device model, WebView version, storage capacity, and installed runtime availability from the native application."
        icon={<Monitor size={34} />}
      />
    );

  return (
    <div className="system-info-app">
      <div className="panel-heading">
        <div><span className="eyebrow">REAL DEVICE INFORMATION</span><h1>System Information</h1><p>Values reported by Android, not by a simulated device profile.</p></div>
        <button className="secondary-button" onClick={() => void load()}><RefreshCw size={14} /> Refresh</button>
      </div>
      {error && pathError("Could not read system information", error)}
      {info && (
        <>
          <div className="system-connection-card">
            <div className={display?.connected ? "connected" : ""}><Monitor size={26} /></div>
            <span><strong>{display?.connected ? display.displayName : "No external display connected"}</strong><small>{display?.connected ? `${display.width} × ${display.height} @ ${display.densityDpi} dpi · display ${display.displayId} · presentation ${display.presentationActive ? "active" : "inactive"}` : "Connect a television through HDMI, DisplayPort, or a supported casting/DeX path."}</small></span>
          </div>
          <div className="system-info-grid">
            <section><h3>Device</h3><div><span>Manufacturer</span><strong>{info.manufacturer}</strong></div><div><span>Model</span><strong>{info.model}</strong></div><div><span>Android</span><strong>{info.androidRelease} (SDK {info.sdkInt})</strong></div><div><span>ABIs</span><strong>{info.supportedAbis.join(", ") || "Unknown"}</strong></div></section>
            <section><h3>Runtime</h3><div><span>KK DEX</span><strong>{info.appVersion}</strong></div><div><span>Android WebView</span><strong>{info.webViewVersion}</strong></div>{Object.entries(info.runtimes).map(([name, version]) => <div key={name}><span>{name}</span><strong>{version || "Not found"}</strong></div>)}</section>
            <section><h3>App storage</h3><div><span>Data directory</span><strong>{info.dataPath}</strong></div><div><span>Total</span><strong>{formatAndroidBytes(info.totalStorage)}</strong></div><div><span>Available</span><strong>{formatAndroidBytes(info.freeStorage)}</strong></div></section>
            <section><h3>Display</h3><div><span>External screen</span><strong>{display?.connected ? "Connected" : "Not connected"}</strong></div><div><span>Presentation</span><strong>{display?.presentationActive ? "Running on TV" : "Stopped"}</strong></div><div><span>Phone surface</span><strong>Controller only</strong></div></section>
          </div>
        </>
      )}
    </div>
  );
}

export function AppManagerApp() {
  const system = useSystem();
  const report = useAndroidError();
  const [apps, setApps] = useState<InstalledAndroidApp[]>([]);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [launching, setLaunching] = useState<string | null>(null);
  const available = nativeAvailable();

  const load = async () => {
    if (!available) return;
    setBusy(true);
    try { setApps(await getInstalledApps()); setError(null); }
    catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
    finally { setBusy(false); }
  };
  useEffect(() => void load(), [available]);
  const visible = apps.filter((app) => `${app.label} ${app.packageName}`.toLowerCase().includes(query.toLowerCase()));

  if (!available)
    return (
      <NativeRequired
        title="Installed apps come from Android."
        description="The native app discovers only launcher activities that Android exposes to KK DEX, using PackageManager. Icons and names are read from the real installed packages."
        icon={<AppWindow size={34} />}
      />
    );

  return (
    <div className="app-manager">
      <div className="panel-heading">
        <div><span className="eyebrow">ANDROID PACKAGE MANAGER</span><h1>Installed apps</h1><p>Android controls which applications are visible and where they can launch.</p></div>
        <button className="secondary-button" onClick={() => void load()} disabled={busy}><RefreshCw size={14} className={busy ? "spin" : ""} /> Refresh</button>
      </div>
      <div className="app-manager-toolbar"><div className="app-search"><Search size={14} /><input aria-label="Search installed Android apps" placeholder="Search installed apps" value={query} onChange={(event) => setQuery(event.target.value)} /></div><span>{visible.length} launcher activities visible</span></div>
      {error && pathError("Android did not return installed apps", error)}
      <div className="installed-app-grid">
        {visible.map((app) => (
          <div className="installed-app" key={app.packageName}>
            <div className="installed-icon">{app.iconUrl ? <img src={app.iconUrl} alt="" /> : <AppWindow size={24} />}</div>
            <div><strong>{app.label}</strong><small>{app.packageName}</small>{app.system && <span>System app</span>}</div>
            <button
              className="secondary-button"
              disabled={launching === app.packageName}
              onClick={() => {
                setLaunching(app.packageName);
                void launchInstalledApp(app.packageName, true)
                  .then((message) => system.notify(`Launch request: ${app.label}`, message, "appmanager"))
                  .catch((cause) => report(`${app.label} could not be launched`, cause))
                  .finally(() => setLaunching(null));
              }}
            >
              {launching === app.packageName ? <LoaderCircle size={13} className="spin" /> : <ExternalLink size={13} />} Launch
            </button>
          </div>
        ))}
      </div>
      <div className="app-manager-note"><Info size={14} /><span>KK DEX requests that Android launch the app on the external display. Many phone apps ignore secondary-display launches or force themselves onto the phone. The notification reports exactly which launch path Android accepted.</span></div>
    </div>
  );
}

export function ArchiveManagerApp({ win }: { win: DesktopWindow }) {
  const system = useSystem();
  const report = useAndroidError();
  const payload = parseAndroidPayload(win.payload);
  const [zip, setZip] = useState<JSZip | null>(null);
  const [name, setName] = useState("No archive open");
  const [entries, setEntries] = useState<{ path: string; size: number; directory: boolean; date: Date }[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const available = nativeAvailable();

  const parse = async (bytes: Uint8Array | ArrayBuffer, archiveName: string) => {
    setBusy(true); setError(null);
    try {
      const loaded = await JSZip.loadAsync(bytes);
      const list = Object.entries(loaded.files).map(([path, item]) => ({ path, size: (item as unknown as { _data?: { uncompressedSize?: number } })._data?.uncompressedSize || 0, directory: item.dir, date: item.date }));
      setZip(loaded); setEntries(list); setName(archiveName);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "This is not a readable ZIP archive.");
    } finally { setBusy(false); }
  };

  const openAndroid = async () => {
    try {
      const files = await pickFiles("application/zip");
      if (!files[0]) return;
      if (files[0].size > 40 * 1024 * 1024) throw new Error("Archive exceeds the 40 MB safe import limit for this viewer. Export it or use an Android archive application.");
      const file = await readFile(files[0].uri);
      await parse(base64ToBytes(file.base64), files[0].name);
      void files[0];
    } catch (cause) { report("Could not read this Android archive", cause); }
  };

  const openBrowser = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 40 * 1024 * 1024) { setError("Archive exceeds the 40 MB viewer limit."); return; }
    await parse(await file.arrayBuffer(), file.name);
    event.target.value = "";
  };

  useEffect(() => {
    if (payload) {
      void (async () => {
        try {
          const file = await readFile(payload.uri);
          await parse(base64ToBytes(file.base64), payload.name);
        } catch (cause) { report("Could not read the shared archive", cause); }
      })();
    }
  }, [win.payload]);

  const extract = async (entryPath: string) => {
    if (!zip) return;
    const entry = zip.file(entryPath);
    if (!entry) return;
    setBusy(true);
    try {
      const bytes = await entry.async("uint8array");
      const fileName = entryPath.split("/").pop() || "extracted.bin";
      if (available) {
        const saved = await exportBase64(fileName, "application/octet-stream", bytesToBase64(bytes));
        system.notify("Archive entry exported", `${saved} was written to your chosen Android folder.`, "archives");
      } else {
        const url = URL.createObjectURL(new Blob([new Uint8Array(bytes).buffer], { type: "application/octet-stream" }));
        const anchor = document.createElement("a"); anchor.href = url; anchor.download = fileName; anchor.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        system.notify("Archive entry downloaded", "A real local download was created. Native Android export requires the KK DEX Android app.", "archives");
      }
    } catch (cause) { report("Could not extract the archive entry", cause); }
    finally { setBusy(false); }
  };

  return (
    <div className="archive-app">
      <div className="archive-toolbar">
        <button className="secondary-button" disabled={!available} onClick={() => void openAndroid()}><FolderSearch size={14} /> Open from Android</button>
        <button className="secondary-button" onClick={() => input.current?.click()}><Archive size={14} /> Open local ZIP</button>
        <input ref={input} hidden type="file" accept=".zip,application/zip" onChange={(event) => void openBrowser(event)} />
        <div className="toolbar-spacer" />
        <span className="archive-cap">ZIP · 40 MB viewer limit</span>
      </div>
      <div className="archive-heading"><Archive size={21} /><div><strong>{name}</strong><small>{entries.length ? `${entries.filter((entry) => !entry.directory).length} files · ${entries.filter((entry) => entry.directory).length} folders` : "Inspect archive contents without silently extracting files."}</small></div></div>
      {error && pathError("Archive could not be read", error)}
      {busy && <div className="native-loading"><LoaderCircle size={20} className="spin" /> Processing archive in this WebView…</div>}
      {entries.length ? (
        <div className="archive-list">
          {entries.map((entry) => (
            <div key={entry.path} className={`archive-row ${selected === entry.path ? "selected" : ""}`} onClick={() => setSelected(entry.path)} onDoubleClick={() => !entry.directory && void extract(entry.path)}>
              {entry.directory ? <Folder size={16} /> : <File size={16} />}
              <span>{entry.path}</span><small>{entry.directory ? "Folder" : formatAndroidBytes(entry.size)}</small>
              {!entry.directory && <button aria-label={`Extract ${entry.path}`} disabled={busy} onClick={(event) => { event.stopPropagation(); void extract(entry.path); }}><Download size={14} /></button>}
            </div>
          ))}
        </div>
      ) : (
        <EmptyState icon={<Archive size={38} />} title="Open an archive." description="Choose a ZIP through Android's picker or a local browser file. KK DEX lists real entries and writes extracted files through an actual download or Android document picker." />
      )}
      <div className="archive-footer"><span>{zip ? "ZIP archive loaded" : "No archive loaded"}</span><span>{available ? "Android export available" : "Local download fallback"}</span></div>
    </div>
  );
}
