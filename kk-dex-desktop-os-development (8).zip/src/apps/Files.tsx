import { useEffect, useRef, useState, type MouseEvent } from "react";
import {
  ArrowDown,
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  Copy,
  FileText,
  FolderPlus,
  Grid2X2,
  HardDrive,
  Home,
  Image,
  Info,
  LayoutGrid,
  List,
  Monitor,
  MoreHorizontal,
  Music2,
  Network,
  Smartphone,
  Pencil,
  Pin,
  Plus,
  RefreshCw,
  Search,
  Scissors,
  SlidersHorizontal,
  Trash2,
  Upload,
  Video,
  X,
} from "lucide-react";
import { AppIcon, FolderIcon } from "../icons";
import { useSystem } from "../system";
import { formatBytes, uid } from "../storage";
import { EmptyState, IconButton } from "../ui";
import type { DesktopWindow, FileEntry, MenuItem } from "../types";

const locations = [
  { id: "desktop", label: "Desktop", icon: Monitor },
  { id: "downloads", label: "Downloads", icon: ArrowDownToLine },
  { id: "documents", label: "Documents", icon: FileText },
  { id: "pictures", label: "Pictures", icon: Image },
  { id: "music", label: "Music", icon: Music2 },
  { id: "videos", label: "Videos", icon: Video },
];

export function FileArtwork({
  file,
  size = 32,
}: {
  file: FileEntry;
  size?: number;
}) {
  if (file.kind === "folder") return <FolderIcon size={size} />;
  if (file.kind === "image")
    return (
      <span
        className="file-artwork image-file"
        style={{ width: size, height: size }}
      >
        <Image size={size * 0.56} />
      </span>
    );
  return (
    <span
      className={`file-artwork ${file.name.endsWith(".md") ? "markdown-file" : "text-file"}`}
      style={{ width: size, height: size }}
    >
      <FileText size={size * 0.56} />
    </span>
  );
}

export default function FilesApp({ win }: { win: DesktopWindow }) {
  const system = useSystem();
  const {
    files,
    activeId,
    openApp,
    openFile,
    setContextMenu,
    createFolder,
    renameFile,
    deleteFiles,
    copyFiles,
    pasteFiles,
    clipboard,
    explain,
    setFiles,
    undoFiles,
    redoFiles,
  } = system;
  const [history, setHistory] = useState({
    paths: [win.payload || (win.appId === "pc" ? "pc" : "home")],
    index: 0,
  });
  const current = history.paths[history.index];
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [view, setView] = useState<"list" | "grid">("list");
  const [sort, setSort] = useState<"name" | "modified" | "kind">("modified");
  const [ascending, setAscending] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const uploadRef = useRef<HTMLInputElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const navigate = (id: string) => {
    setHistory((h) => ({
      paths: [...h.paths.slice(0, h.index + 1), id],
      index: h.index + 1,
    }));
    setSearch("");
    setSelected([]);
  };
  useEffect(() => {
    if (win.payload && win.payload !== current) navigate(win.payload);
  }, [win.payload]);

  const visibleFiles = files
    .filter(
      (f) =>
        !f.deleted &&
        (current === "home" || current === "pc"
          ? !!search || f.kind !== "folder"
          : f.parent === current),
    )
    .filter(
      (f) => !search || f.name.toLowerCase().includes(search.toLowerCase()),
    )
    .sort((a, b) => {
      if (a.kind === "folder" && b.kind !== "folder") return -1;
      if (b.kind === "folder" && a.kind !== "folder") return 1;
      const comparison =
        sort === "name"
          ? a.name.localeCompare(b.name)
          : sort === "kind"
            ? a.kind.localeCompare(b.kind)
            : a.modified.localeCompare(b.modified);
      return ascending ? comparison : -comparison;
    });
  const recentFiles =
    current === "home" ? visibleFiles.slice(0, search ? 50 : 4) : visibleFiles;
  const currentFolder = files.find((f) => f.id === current);
  const currentLabel =
    current === "home"
      ? "Home"
      : current === "pc"
        ? "This PC"
        : currentFolder?.name || "Folder";
  const parent = current === "home" || current === "pc" ? "documents" : current;
  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 500);
  };
  const properties = (file: FileEntry) =>
    explain(
      `${file.name} - Properties`,
      `Type: ${file.kind === "folder" ? "Folder" : file.kind === "image" ? "Image" : "Text document"}\nLocation: KK DEX Workspace / ${files.find((f) => f.id === file.parent)?.name || "Home"}\n${file.kind === "folder" ? `Contains: ${files.filter((f) => f.parent === file.id && !f.deleted).length} items` : `Size: ${formatBytes(file.size)}${file.size === 0 ? " (bundled asset)" : ""}`}\nModified: ${new Date(file.modified).toLocaleString()}\n\nThis item is managed by KK DEX, not Android system storage.`,
    );
  const exportFile = (file: FileEntry) => {
    if (file.kind === "folder") {
      explain(
        "Export folder",
        "Folder export is not available. Open the folder and export individual files.",
      );
      return;
    }
    const link = document.createElement("a");
    const localUrl =
      file.kind === "text"
        ? URL.createObjectURL(
            new Blob([file.content || ""], { type: "text/plain" }),
          )
        : null;
    link.href = localUrl || file.content || "";
    link.download = file.name;
    link.click();
    if (localUrl) setTimeout(() => URL.revokeObjectURL(localUrl), 1000);
  };
  const fileMenu = (e: MouseEvent, file: FileEntry) => {
    e.preventDefault();
    e.stopPropagation();
    setSelected([file.id]);
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      items: [
        {
          label: "Open",
          icon: <ArrowUp size={15} />,
          shortcut: "Enter",
          action: () =>
            file.kind === "folder" ? navigate(file.id) : openFile(file.id),
        },
        {
          label: "Cut",
          icon: <Scissors size={15} />,
          shortcut: "Ctrl+X",
          action: () => copyFiles([file.id], true),
          divider: true,
        },
        {
          label: "Copy",
          icon: <Copy size={15} />,
          shortcut: "Ctrl+C",
          action: () => copyFiles([file.id]),
        },
        {
          label: "Rename",
          icon: <Pencil size={15} />,
          shortcut: "F2",
          action: () => renameFile(file.id),
        },
        {
          label: "Move to Recycle Bin",
          icon: <Trash2 size={15} />,
          shortcut: "Del",
          action: () => deleteFiles([file.id]),
          danger: true,
        },
        {
          label: "Export file",
          icon: <ArrowDownToLine size={15} />,
          action: () => exportFile(file),
          divider: true,
        },
        {
          label: "Properties",
          icon: <Info size={15} />,
          action: () => properties(file),
        },
      ],
    });
  };
  const backgroundMenu = (e: MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      items: [
        {
          label: "New folder",
          icon: <FolderPlus size={15} />,
          action: () => createFolder(parent),
        },
        {
          label: "Import files",
          icon: <Upload size={15} />,
          action: () => uploadRef.current?.click(),
        },
        {
          label: "Paste",
          icon: <Copy size={15} />,
          shortcut: "Ctrl+V",
          action: () => pasteFiles(parent),
          disabled: !clipboard,
        },
        {
          label: "Refresh",
          icon: <RefreshCw size={15} />,
          shortcut: "F5",
          action: refresh,
          divider: true,
        },
      ],
    });
  };
  useEffect(() => {
    const keydown = (e: KeyboardEvent) => {
      if (activeId !== win.id) return;
      const typing =
        e.target instanceof Element &&
        !!e.target.closest('input, textarea, [contenteditable="true"]');
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        searchRef.current?.focus();
        return;
      }
      if (typing) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") {
        e.preventDefault();
        setSelected(recentFiles.map((f) => f.id));
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c") {
        e.preventDefault();
        copyFiles(selected);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "x") {
        e.preventDefault();
        copyFiles(selected, true);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") {
        e.preventDefault();
        pasteFiles(parent);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redoFiles();
        else undoFiles();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redoFiles();
      }
      if (e.key === "F2" && selected[0]) {
        e.preventDefault();
        renameFile(selected[0]);
      }
      if (e.key === "Delete" && selected.length) {
        e.preventDefault();
        deleteFiles(selected);
        setSelected([]);
      }
      if (e.key === "Enter" && selected[0]) {
        e.preventDefault();
        const file = files.find((f) => f.id === selected[0]);
        if (file?.kind === "folder") navigate(file.id);
        else openFile(selected[0]);
      }
      if (e.key === "F5") {
        e.preventDefault();
        refresh();
      }
      if (e.altKey && e.key === "ArrowLeft") {
        e.preventDefault();
        setHistory((h) => ({ ...h, index: Math.max(0, h.index - 1) }));
      }
      if (e.altKey && e.key === "ArrowRight") {
        e.preventDefault();
        setHistory((h) => ({
          ...h,
          index: Math.min(h.paths.length - 1, h.index + 1),
        }));
      }
    };
    window.addEventListener("keydown", keydown);
    return () => window.removeEventListener("keydown", keydown);
  });
  const sortingMenu = (e: MouseEvent<HTMLButtonElement>) =>
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      items: [
        ...(["name", "modified", "kind"] as const).map((key) => ({
          label:
            key === "name"
              ? "Name"
              : key === "modified"
                ? "Date modified"
                : "File type",
          icon: sort === key ? <Check size={15} /> : undefined,
          action: () => setSort(key),
        })),
        {
          label: ascending ? "Sort descending" : "Sort ascending",
          icon: <ArrowDown size={15} />,
          divider: true,
          action: () => setAscending((a) => !a),
        },
      ],
    });
  const breadcrumbs: FileEntry[] = [];
  let ancestor = currentFolder;
  while (ancestor && breadcrumbs.length < 12) {
    breadcrumbs.unshift(ancestor);
    ancestor = files.find((f) => f.id === ancestor!.parent);
  }
  const selectFile = (e: MouseEvent, id: string) => {
    e.stopPropagation();
    root.current?.focus();
    setSelected((s) =>
      e.ctrlKey || e.metaKey
        ? s.includes(id)
          ? s.filter((x) => x !== id)
          : [...s, id]
        : [id],
    );
  };
  const moreMenu = (e: MouseEvent<HTMLButtonElement>) => {
    const items: MenuItem[] = [
      {
        label: "Import files",
        icon: <Upload size={15} />,
        action: () => uploadRef.current?.click(),
      },
      { label: "Refresh", icon: <RefreshCw size={15} />, action: refresh },
      {
        label: "About workspace storage",
        icon: <CircleHelp size={15} />,
        action: () =>
          explain(
            "Your KK DEX workspace",
            "Files in this workspace are saved in this WebView on this device. You can import real files with the system file picker and export them again. Direct Android storage access requires an authorized native storage provider.",
          ),
      },
    ];
    if (selected[0]) {
      const f = files.find((x) => x.id === selected[0]);
      if (f)
        items.unshift({
          label: "Export selected file",
          icon: <ArrowDownToLine size={15} />,
          action: () => exportFile(f),
        });
    }
    setContextMenu({ x: e.clientX, y: e.clientY, items });
  };

  return (
    <div
      className="file-app"
      ref={root}
      tabIndex={-1}
      onContextMenu={backgroundMenu}
    >
      <div className="file-navigation">
        <div className="navigation-buttons">
          <IconButton
            label="Back"
            disabled={history.index === 0}
            onClick={() => setHistory((h) => ({ ...h, index: h.index - 1 }))}
          >
            <ArrowLeft size={16} />
          </IconButton>
          <IconButton
            label="Forward"
            disabled={history.index >= history.paths.length - 1}
            onClick={() => setHistory((h) => ({ ...h, index: h.index + 1 }))}
          >
            <ArrowRight size={16} />
          </IconButton>
          <IconButton
            label="Up one level"
            disabled={!currentFolder}
            onClick={() =>
              navigate(
                currentFolder?.parent === "root"
                  ? "home"
                  : currentFolder?.parent || "home",
              )
            }
          >
            <ArrowUp size={16} />
          </IconButton>
          <IconButton label="Refresh files" onClick={refresh}>
            <RefreshCw className={refreshing ? "spin" : ""} size={14} />
          </IconButton>
        </div>
        <div className="breadcrumbs">
          <Home size={14} />
          <ChevronRight size={12} />
          {breadcrumbs.length ? (
            breadcrumbs.map((f, i) => (
              <span key={f.id}>
                <button onClick={() => navigate(f.id)}>{f.name}</button>
                {i < breadcrumbs.length - 1 && <ChevronRight size={12} />}
              </span>
            ))
          ) : (
            <span>{currentLabel}</span>
          )}
        </div>
        <div className="file-search">
          <Search size={14} />
          <input
            ref={searchRef}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Search ${currentLabel.toLowerCase()}`}
            aria-label="Search files"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              aria-label="Clear file search"
            >
              <X size={12} />
            </button>
          )}
        </div>
      </div>
      <div className="file-layout">
        <aside className="file-sidebar">
          <button
            className={`sidebar-item ${current === "home" ? "active" : ""}`}
            onClick={() => navigate("home")}
          >
            <Home size={16} />
            <span>Home</span>
          </button>
          <div className="sidebar-caption">
            Quick access <Pin size={10} />
          </div>
          {locations.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`sidebar-item ${current === id ? "active" : ""}`}
              onClick={() => navigate(id)}
            >
              <Icon size={16} />
              <span>{label}</span>
              <Pin className="sidebar-pin" size={10} />
            </button>
          ))}
          <div className="sidebar-line" />
          <button
            className={`sidebar-item ${current === "pc" ? "active" : ""}`}
            onClick={() => navigate("pc")}
          >
            <Monitor size={16} />
            <span>This PC</span>
            <ChevronDown size={11} />
          </button>
          <button
            className="sidebar-item storage-child"
            onClick={() => navigate("root")}
          >
            <HardDrive size={15} />
            <span>Workspace</span>
          </button>
          <button
            className="sidebar-item"
            onClick={() => openApp("storage")}
          >
            <Smartphone size={15} />
            <span>Android storage</span>
          </button>
          <button
            className="sidebar-item"
            onClick={() =>
              explain(
                "Network locations",
                "Network file shares are not connected. A native SMB or network storage provider is required to browse other devices.",
              )
            }
          >
            <Network size={16} />
            <span>Network</span>
          </button>
          <div className="sidebar-bottom">
            <span className="storage-label">
              <span className="status-dot" />
              KK DEX Workspace
            </span>
            <span>Stored on this device</span>
            <div className="storage-meter">
              <span
                style={{
                  width: `${Math.max(8, Math.min(100, JSON.stringify(files).length / 50000))}%`,
                }}
              />
            </div>
            <small>
              {formatBytes(new Blob([JSON.stringify(files)]).size)} used
            </small>
          </div>
        </aside>
        <div className="file-main">
          <div className="file-toolbar">
            <button className="new-button" onClick={() => createFolder(parent)}>
              <Plus size={15} />
              <span>New</span>
              <ChevronDown size={11} />
            </button>
            <span className="toolbar-divider" />
            <IconButton
              label="Cut selected"
              disabled={!selected.length}
              onClick={() => copyFiles(selected, true)}
            >
              <Scissors size={15} />
            </IconButton>
            <IconButton
              label="Copy selected"
              disabled={!selected.length}
              onClick={() => copyFiles(selected)}
            >
              <Copy size={15} />
            </IconButton>
            <IconButton
              label="Paste files"
              disabled={!clipboard}
              onClick={() => pasteFiles(parent)}
            >
              <span className="paste-icon">
                <Copy size={15} />
              </span>
            </IconButton>
            <IconButton
              label="Rename selected"
              disabled={selected.length !== 1}
              onClick={() => renameFile(selected[0])}
            >
              <Pencil size={15} />
            </IconButton>
            <IconButton
              label="Delete selected"
              disabled={!selected.length}
              onClick={() => {
                deleteFiles(selected);
                setSelected([]);
              }}
            >
              <Trash2 size={15} />
            </IconButton>
            <span className="toolbar-divider" />
            <button className="text-tool" onClick={sortingMenu}>
              <SlidersHorizontal size={14} />
              <span>Sort</span>
              <ChevronDown size={10} />
            </button>
            <div className="toolbar-spacer" />
            <IconButton
              label={
                view === "list" ? "Switch to grid view" : "Switch to list view"
              }
              onClick={() => setView((v) => (v === "list" ? "grid" : "list"))}
            >
              {view === "list" ? <LayoutGrid size={15} /> : <List size={15} />}
            </IconButton>
            <IconButton label="More file options" onClick={moreMenu}>
              <MoreHorizontal size={18} />
            </IconButton>
          </div>
          <main className="file-content" onClick={() => setSelected([])}>
            {current === "pc" && !search ? (
              <>
                <div className="file-page-heading">
                  <h1>This PC</h1>
                  <p>Your space, connected.</p>
                </div>
                <h3 className="section-heading">Devices and drives</h3>
                <button className="drive-item" onClick={() => navigate("root")}>
                  <AppIcon app="pc" size={44} />
                  <span>
                    <strong>KK DEX Workspace</strong>
                    <small>
                      {formatBytes(new Blob([JSON.stringify(files)]).size)} of
                      managed files
                    </small>
                    <span className="drive-meter">
                      <span />
                    </span>
                    <small>Local WebView storage</small>
                  </span>
                  <ChevronRight size={17} />
                </button>
                <button
                  className="native-storage"
                  onClick={() => openApp("storage")}
                >
                  <Smartphone size={26} />
                  <span>
                    <strong>Android device storage</strong>
                    <small>
                      {window.KKDexHost?.available
                        ? "Open authorized SAF folders and MediaStore collections"
                        : "Requires the installed KK DEX Android application"}
                    </small>
                  </span>
                  <ChevronRight size={16} />
                </button>
              </>
            ) : (
              <>
                <div className="file-page-heading">
                  <h1>
                    {search
                      ? "Search results"
                      : current === "home"
                        ? "Welcome home."
                        : currentLabel}
                  </h1>
                  <p>
                    {search
                      ? `Results for "${search}"`
                      : current === "home"
                        ? "Everything you need, right where you left it."
                        : `${visibleFiles.length} items in your workspace`}
                  </p>
                </div>
                {current === "home" && !search && (
                  <section className="quick-access">
                    <h3 className="section-heading">Quick access</h3>
                    <div className="quick-folders">
                      {["documents", "downloads", "pictures", "projects"].map(
                        (id) => (
                          <button key={id} onClick={() => navigate(id)}>
                            <FolderIcon size={46} />
                            <strong>
                              {files.find((f) => f.id === id)?.name}
                            </strong>
                            <small>
                              {
                                files.filter(
                                  (f) => f.parent === id && !f.deleted,
                                ).length
                              }{" "}
                              items
                            </small>
                          </button>
                        ),
                      )}
                    </div>
                  </section>
                )}
                <section className="file-list-section">
                  <div className="file-section-heading">
                    <h3 className="section-heading">
                      {current === "home" ? (
                        <>
                          <Clock3 size={14} />
                          Recent files
                        </>
                      ) : (
                        <>
                          <FolderIcon size={18} />
                          All files
                        </>
                      )}
                    </h3>
                    {current === "home" && (
                      <span className="muted">From your local workspace</span>
                    )}
                  </div>
                  {recentFiles.length ? (
                    view === "list" ? (
                      <div
                        className="files-table"
                        role="grid"
                        aria-label="Files"
                      >
                        <div className="files-table-head">
                          <button
                            onClick={() => {
                              setSort("name");
                              setAscending((a) => !a);
                            }}
                          >
                            Name <ChevronDown size={10} />
                          </button>
                          <span>Location</span>
                          <button
                            onClick={() => {
                              setSort("modified");
                              setAscending((a) => !a);
                            }}
                          >
                            Modified
                          </button>
                          <span>Size</span>
                        </div>
                        {recentFiles.map((file) => (
                          <div
                            key={file.id}
                            className={`file-row ${selected.includes(file.id) ? "selected" : ""}`}
                            role="row"
                            aria-selected={selected.includes(file.id)}
                            onClick={(e) => selectFile(e, file.id)}
                            onDoubleClick={() =>
                              file.kind === "folder"
                                ? navigate(file.id)
                                : openFile(file.id)
                            }
                            onContextMenu={(e) => fileMenu(e, file)}
                          >
                            <span className="file-name">
                              <FileArtwork file={file} size={30} />
                              <span>{file.name}</span>
                            </span>
                            <span>
                              {files.find((f) => f.id === file.parent)?.name ||
                                "Workspace"}
                            </span>
                            <span>
                              {new Date(file.modified).toLocaleDateString(
                                undefined,
                                { month: "short", day: "numeric" },
                              )}
                            </span>
                            <span>
                              {file.kind === "folder"
                                ? "--"
                                : formatBytes(file.size)}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="files-grid">
                        {recentFiles.map((file) => (
                          <button
                            key={file.id}
                            className={
                              selected.includes(file.id) ? "selected" : ""
                            }
                            onClick={(e) => selectFile(e, file.id)}
                            onDoubleClick={() =>
                              file.kind === "folder"
                                ? navigate(file.id)
                                : openFile(file.id)
                            }
                            onContextMenu={(e) => fileMenu(e, file)}
                          >
                            <FileArtwork file={file} size={52} />
                            <span>{file.name}</span>
                            <small>
                              {file.kind === "folder"
                                ? "Folder"
                                : formatBytes(file.size)}
                            </small>
                          </button>
                        ))}
                      </div>
                    )
                  ) : (
                    <EmptyState
                      icon={<FolderIcon size={58} />}
                      title={
                        search
                          ? "Nothing found just yet"
                          : "A little room for something new"
                      }
                      description={
                        search
                          ? "Try a different file or folder name."
                          : "Create a folder or import a file to get started."
                      }
                    >
                      <button
                        className="primary-button"
                        onClick={() => uploadRef.current?.click()}
                      >
                        <Upload size={14} />
                        Import files
                      </button>
                    </EmptyState>
                  )}
                </section>
              </>
            )}
          </main>
          <div className="file-statusbar">
            <span>
              {current === "pc"
                ? "1 local workspace"
                : `${recentFiles.length} items`}
              {selected.length > 0 && `  /  ${selected.length} selected`}
            </span>
            <span className="statusbar-right">
              <span className="status-dot" />
              Local workspace
              <span className="toolbar-divider" />
              <IconButton
                label="List view"
                className={view === "list" ? "chosen" : ""}
                onClick={() => setView("list")}
              >
                <List size={14} />
              </IconButton>
              <IconButton
                label="Grid view"
                className={view === "grid" ? "chosen" : ""}
                onClick={() => setView("grid")}
              >
                <Grid2X2 size={13} />
              </IconButton>
            </span>
          </div>
        </div>
      </div>
      <input
        type="file"
        ref={uploadRef}
        hidden
        multiple
        onChange={async (e) => {
          const input = e.currentTarget;
          try {
            for (const file of Array.from(e.target.files || [])) {
              if (file.size > 2 * 1024 * 1024) {
                explain(
                  "File too large for local storage",
                  `${file.name} exceeds the 2 MB per-file workspace limit. Use a native storage provider for larger files.`,
                );
                continue;
              }
              const kind = file.type.startsWith("image/")
                ? "image"
                : file.type.startsWith("text/") ||
                    /\.(md|txt|json|csv|js|ts|css|html)$/i.test(file.name)
                  ? "text"
                  : "file";
              const content =
                kind === "text"
                  ? await file.text()
                  : await new Promise<string>((resolve, reject) => {
                      const reader = new FileReader();
                      reader.onload = () => resolve(String(reader.result));
                      reader.onerror = reject;
                      reader.readAsDataURL(file);
                    });
              setFiles((fs) => [
                ...fs,
                {
                  id: uid(),
                  name: file.name,
                  parent,
                  kind,
                  content,
                  size: file.size,
                  modified: new Date().toISOString(),
                },
              ]);
            }
          } catch {
            explain(
              "Could not import file",
              "The file could not be read. Check its permissions and try the system picker again.",
            );
          } finally {
            input.value = "";
          }
        }}
      />
    </div>
  );
}
