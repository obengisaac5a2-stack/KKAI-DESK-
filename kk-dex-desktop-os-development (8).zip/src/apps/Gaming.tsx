import { useEffect, useState } from "react";
import {
  AlertTriangle,
  AppWindow,
  BarChart3,
  Check,
  Cpu,
  Download,
  ExternalLink,
  Gauge,
  Gamepad2,
  Globe,
  HardDrive,
  Image,
  Info,
  LoaderCircle,
  MemoryStick,
  Monitor,
  Music2,
  Package,
  Play,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  Video,
  Zap,
} from "lucide-react";
import {
  formatAndroidBytes,
  getDownloads,
  getInstalledApps,
  getStorageOverview,
  getSystemInfo,
  installDownloadedApk,
  launchInstalledApp,
  nativeAvailable,
  openBrowserWindow,
  requestMediaPermissions,
  setDownloadSubfolder,
} from "../android/native";
import { readPersisted, persist } from "../storage";
import { useSystem } from "../system";
import { EmptyState } from "../ui";
import type {
  AndroidDownload,
  AndroidStorageOverview,
  AndroidSystemInfo,
  InstalledAndroidApp,
} from "../types";

type WebGame = { id: string; name: string; url: string; kind: "web" | "cloud" };

export function GamingCentreApp() {
  const system = useSystem();
  const available = nativeAvailable();
  const [tab, setTab] = useState<"library" | "performance" | "downloads">("library");
  const [apps, setApps] = useState<InstalledAndroidApp[]>([]);
  const [downloads, setDownloads] = useState<AndroidDownload[]>([]);
  const [info, setInfo] = useState<AndroidSystemInfo | null>(null);
  const [webGames, setWebGames] = useState<WebGame[]>(() => readPersisted("web-games", []));
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [newGameName, setNewGameName] = useState("");
  const [newGameUrl, setNewGameUrl] = useState("");
  const [newGameKind, setNewGameKind] = useState<"web" | "cloud">("web");

  useEffect(() => {
    persist("web-games", webGames);
  }, [webGames]);

  const load = async () => {
    if (!available) return;
    setBusy(true);
    setError(null);
    try {
      const [nextApps, nextDownloads, nextInfo] = await Promise.all([
        getInstalledApps(),
        getDownloads(),
        getSystemInfo(),
      ]);
      setApps(nextApps);
      setDownloads(nextDownloads);
      setInfo(nextInfo);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => void load(), []);

  const games = apps.filter(
    (app) =>
      app.isGame ||
      app.category?.toLowerCase() === "game" ||
      /(^|\s)(game|gaming|arena|racing|football|puzzle|quest|clash|craft|royale)(\s|$)/i.test(app.label),
  );
  const visibleGames = games.filter((app) => `${app.label} ${app.packageName}`.toLowerCase().includes(query.toLowerCase()));
  const apkDownloads = downloads.filter((download) => download.mime === "application/vnd.android.package-archive" || /\.apk($|\?)/i.test(download.title));

  const launchGame = (app: InstalledAndroidApp) => {
    void launchInstalledApp(app.packageName, true)
      .then((message) => system.notify(`Launch request: ${app.label}`, message, "gaming"))
      .catch((cause) =>
        system.explain(
          `${app.label} could not launch`,
          cause instanceof Error ? cause.message : "Android rejected the launch.",
        ),
      );
  };

  const launchWebGame = (game: WebGame) => {
    if (!available) {
      system.explain("Web game shortcut unavailable", "The native browser is only available in the installed KK DEX Android app.");
      return;
    }
    void openBrowserWindow(game.url, true)
      .then((message) => system.notify(`${game.name} opened`, message, "gaming"))
      .catch((cause) => system.explain("Browser could not open", cause instanceof Error ? cause.message : "Android rejected the browser launch."));
  };

  const addWebGame = () => {
    if (!newGameName.trim() || !/^https?:\/\//i.test(newGameUrl)) {
      setError("Add a game name and a complete http(s) address.");
      return;
    }
    setWebGames((games) => [{ id: `${Date.now()}`, name: newGameName.trim(), url: newGameUrl, kind: newGameKind }, ...games]);
    setAdding(false);
    setNewGameName("");
    setNewGameUrl("");
    setError(null);
  };

  if (!available) {
    return (
      <div className="gaming-app">
        <div className="native-required">
          <div className="native-required-icon"><Gamepad2 size={36}/></div>
          <h2>Gaming Centre needs Android hardware.</h2>
          <p>Installed games, real launch routing, device RAM/GPU information, downloads and performance modes are read from the KK DEX Android app. This browser preview cannot discover or launch Android games.</p>
          <div className="native-required-note"><ShieldCheck size={14}/> No fake game library, compatibility claim or hardware capability has been generated.</div>
          <button className="primary-button" style={{ marginTop: 20 }} onClick={() => setTab("performance")}><Gauge size={14}/> Read performance limitations</button>
        </div>
        {tab === "performance" && <PerformanceDetails info={null}/>}
      </div>
    );
  }

  return (
    <div className="gaming-app">
      <div className="gaming-hero">
        <div>
          <span className="gaming-eyebrow"><Sparkles size={12}/> KK DEX GAMING</span>
          <h1>Play without limits.</h1>
          <p>Your Android games. A bigger screen. The same real hardware.</p>
          <div className="gaming-hero-actions">
            <button className="gaming-primary" onClick={() => setTab("library")}><Play size={14} fill="currentColor"/> Game library</button>
            <button className="gaming-secondary" onClick={() => setTab("performance")}><Gauge size={15}/> Performance</button>
          </div>
        </div>
        <div className="gaming-hero-art" aria-hidden="true"><div className="gaming-orbit"/><Gamepad2 size={72} strokeWidth={1}/></div>
      </div>
      <div className="gaming-tabs">
        {([
          ["library", "Library", Gamepad2],
          ["performance", "Performance", Gauge],
          ["downloads", "Game files", Download],
        ] as const).map(([id, label, Icon]) => (
          <button key={id} className={tab === id ? "active" : ""} onClick={() => setTab(id)}><Icon size={14}/>{label}</button>
        ))}
        <div className="toolbar-spacer"/>
        <button className="gaming-refresh" disabled={busy} onClick={() => void load()} title="Refresh Android game data"><RefreshCw size={15} className={busy ? "spin" : ""}/></button>
      </div>
      {error && <div className="gaming-error"><AlertTriangle size={15}/>{error}<button onClick={() => setError(null)}>Dismiss</button></div>}
      {tab === "library" && (
        <div className="gaming-library">
          <div className="gaming-section-head">
            <div><span className="eyebrow">REAL INSTALLED PACKAGES</span><h2>Installed games</h2><p>Android PackageManager exposes {games.length} game application{games.length === 1 ? "" : "s"} to KK DEX.</p></div>
            <div className="app-search"><Search size={14}/><input aria-label="Search installed games" placeholder="Search games" value={query} onChange={(e) => setQuery(e.target.value)}/></div>
          </div>
          {visibleGames.length ? (
            <div className="game-grid">
              {visibleGames.map((game) => (
                <div className="game-card" key={game.packageName}>
                  <div className="game-art">{game.iconUrl ? <img src={game.iconUrl} alt=""/> : <Gamepad2 size={33}/>}<span>ANDROID</span></div>
                  <div className="game-card-info"><strong>{game.label}</strong><small>{game.packageName}</small></div>
                  <button onClick={() => launchGame(game)} aria-label={`Launch ${game.label}`}><Play size={15} fill="currentColor"/></button>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState icon={<Gamepad2 size={39}/>} title="No games discovered" description="Android exposes only launcher activities visible to KK DEX. Install a game, or tell Android it belongs to the Game category, then refresh."><button className="primary-button" onClick={() => system.openApp("appmanager")}><AppWindow size={14}/> Open Android Apps</button></EmptyState>
          )}
          <div className="gaming-section-head web-games-head"><div><span className="eyebrow">BROWSER-BASED PLAY</span><h2>Web & cloud games</h2><p>Only addresses you add are shown. KK DEX does not invent game listings.</p></div><button className="gaming-secondary" onClick={() => setAdding(true)}><Plus size={14}/> Add shortcut</button></div>
          {webGames.length ? <div className="web-game-grid">{webGames.map((game) => <div key={game.id}><div className="web-game-icon">{game.kind === "cloud" ? <CloudIcon/> : <Globe size={19}/>}</div><span><strong>{game.name}</strong><small>{game.kind === "cloud" ? "Cloud gaming · requires a service you choose" : "Web game · real native browser"}</small></span><button aria-label={`Open ${game.name}`} onClick={() => launchWebGame(game)}><ExternalLink size={14}/></button><button aria-label={`Remove ${game.name}`} onClick={() => setWebGames((games) => games.filter((item) => item.id !== game.id))}><Trash2 size={14}/></button></div>)}</div> : <div className="web-games-empty"><Globe size={20}/><p>Add a legitimate web game or an existing cloud gaming URL. It will open in the native KKDex browser, subject to that service's compatibility.</p></div>}
          <div className="gaming-section-head pc-head"><div><span className="eyebrow">COMPATIBILITY, NOT GUESSWORK</span><h2>PC game files</h2></div></div>
          <div className="compatibility-grid">
            <div className="compatibility-card good"><strong>Android compatible</strong><p>Runs through the Android launcher. Display support is reported after the launch attempt.</p><span>SUPPORTED</span></div>
            <div className="compatibility-card good"><strong>Web game</strong><p>Runs in the native WebView browser with cookies, JavaScript and media support where the site permits it.</p><span>SUPPORTED</span></div>
            <div className="compatibility-card warn"><strong>Cloud gaming</strong><p>Requires an existing service, account, network quality and app/browser that supports your region.</p><span>USER SERVICE</span></div>
            <div className="compatibility-card bad"><strong>Windows .exe</strong><p>Not natively executable. No Wine, Box64 or Windows compatibility runtime is bundled in this build.</p><span>REQUIRES RUNTIME</span></div>
          </div>
          <div className="gaming-limits"><Info size={15}/><span>KK DEX does not bundle games, offer unlicensed downloads, bypass Android signature checks, or claim that touch/controller mapping improves a game's physical frame rate.</span></div>
        </div>
      )}
      {tab === "performance" && <PerformanceDetails info={info} embedded={false}/>}
      {tab === "downloads" && (
        <div className="game-files">
          <div className="gaming-section-head"><div><span className="eyebrow">FROM ANDROID DOWNLOADMANAGER</span><h2>Downloaded game files</h2><p>APK files detected in your real Android downloads.</p></div><button className="gaming-secondary" onClick={() => system.openApp("downloads")}><Download size={14}/> All downloads</button></div>
          {apkDownloads.length ? apkDownloads.map((download) => (
            <div className="game-download-row" key={download.id}>
              <div className="game-download-icon"><Package size={22}/></div>
              <div><strong>{download.title}</strong><small>{download.status === "successful" ? formatAndroidBytes(download.size) : `${download.status} · ${formatAndroidBytes(download.downloaded)}`}</small></div>
              <span className={`download-status ${download.status}`}>{download.status}</span>
              {download.status === "successful" ? <button className="gaming-primary" onClick={() => {
                system.setDialog({ title: "Install this APK?", message: `Android will open its package installer for ${download.title}. KK DEX cannot install it silently or bypass unknown-source, signature, or Play Protect checks.`, confirmLabel: "Open Android installer", onConfirm: () => { void installDownloadedApk(download.id).then((message) => system.notify("Android installer", message, "gaming")).catch((cause) => system.explain("APK installation could not start", cause instanceof Error ? cause.message : "Android rejected the installer request.")); } });
              }}><Package size={14}/> Install</button> : <span className="game-download-pending">Waiting for Android</span>}
            </div>
          )) : <EmptyState icon={<Package size={37}/>} title="No downloaded APKs" description="Download a valid APK in the native browser, then refresh. KK DEX only shows files Android DownloadManager actually reports."><button className="primary-button" onClick={() => system.openApp("browser")}>Open Browser</button></EmptyState>}
          <div className="gaming-limits"><ShieldCheck size={15}/><span>Installing unknown APKs carries security risk. Android shows its own confirmation and may require you to grant “Install unknown apps” for KK DEX in system settings. The result comes from Android's package installer, not a KK DEX simulation.</span></div>
        </div>
      )}
      {adding && <div className="gaming-add-backdrop" onPointerDown={(event) => { if (event.target === event.currentTarget) setAdding(false); }}>
        <form className="gaming-add-card" onSubmit={(event) => { event.preventDefault(); addWebGame(); }}>
          <span className="eyebrow">REAL BROWSER SHORTCUT</span><h2>Add a web game</h2><p>Use a legitimate site or a cloud service you already subscribe to.</p>
          <label>Name<input value={newGameName} onChange={(event) => setNewGameName(event.target.value)} placeholder="Game or service name"/></label>
          <label>URL<input value={newGameUrl} onChange={(event) => setNewGameUrl(event.target.value)} placeholder="https://…"/></label>
          <div className="gaming-kind"><button type="button" className={newGameKind === "web" ? "active" : ""} onClick={() => setNewGameKind("web")}>Web game</button><button type="button" className={newGameKind === "cloud" ? "active" : ""} onClick={() => setNewGameKind("cloud")}>Cloud gaming</button></div>
          <div><button type="button" className="gaming-secondary" onClick={() => setAdding(false)}>Cancel</button><button className="gaming-primary" type="submit"><Plus size={14}/> Add shortcut</button></div>
        </form>
      </div>}
    </div>
  );
}

function CloudIcon() {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 18h10.5a4 4 0 0 0 .5-8 6 6 0 0 0-11.6-1A4.5 4.5 0 0 0 7 18Z" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/><path d="m10 13 2 2 2-2M12 9v6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
}

function PerformanceDetails({ info }: { info: AndroidSystemInfo | null; embedded?: boolean }) {
  const { preferences: p, setPreference, explain, openApp } = useSystem();
  const modes = [
    { id: "performance", label: "Performance", icon: Zap, description: "Fewer blur effects and animations. Prioritizes input stability." },
    { id: "balanced", label: "Balanced", icon: Gauge, description: "A calm default for desktop work, browsing and play." },
    { id: "visual", label: "Visual", icon: Sparkles, description: "Richer wallpaper transitions and interface motion where permitted." },
  ] as const;
  return (
    <div className="performance-tab">
      <div className="gaming-section-head"><div><span className="eyebrow">REAL HARDWARE, HONEST TUNING</span><h2>Performance mode</h2><p>Changes KK DEX interface work only. A software mode cannot overclock or add physical CPU/GPU power.</p></div></div>
      <div className="performance-modes">{modes.map(({ id, label, icon: Icon, description }) => <button key={id} className={p.performanceMode === id ? "active" : ""} onClick={() => { setPreference("performanceMode", id); explain(`${label} mode enabled`, `${description}\n\nThis setting changes desktop rendering and animation policy. A software mode cannot overclock the CPU or GPU. Android still controls thermal limits, CPU scheduling, GPU frequency and available RAM.`); }}><Icon size={21}/><strong>{label}</strong><span>{description}</span>{p.performanceMode === id && <Check size={15}/>}</button>)}</div>
      {info ? <>
        <div className="gaming-section-head"><div><span className="eyebrow">ANDROID / BUILD REPORTED</span><h2>Device capability</h2></div><button className="gaming-secondary" onClick={() => openApp("sysinfo")}><BarChart3 size={14}/> Full system report</button></div>
        <div className="hardware-grid">
          <div><span><Cpu size={16}/> Processor</span><strong>{info.supportedAbis[0] || info.cpuAbi || "Unknown"} · {info.cpuCores || "?"} cores</strong></div>
          <div><span><MemoryStick size={16}/> Memory</span><strong>{formatAndroidBytes(info.availableRam)} available of {formatAndroidBytes(info.totalRam)}</strong></div>
          <div><span><Monitor size={16}/> Display</span><strong>{info.externalDisplay.connected ? `${info.externalDisplay.width} × ${info.externalDisplay.height} · ${info.refreshRate ? `${info.refreshRate.toFixed(0)} Hz` : "refresh unknown"}` : "No external display"}</strong></div>
          <div><span><HardDrive size={16}/> App storage</span><strong>{formatAndroidBytes(info.freeStorage)} available of {formatAndroidBytes(info.totalStorage)}</strong></div>
          <div><span><Sparkles size={16}/> Graphics</span><strong>{info.gpuRenderer || "Renderer not exposed"}{info.webglAvailable ? " · WebGL available" : " · WebGL unavailable"}</strong></div>
          <div><span><ShieldCheck size={16}/> Runtime</span><strong>Android {info.androidRelease} · SDK {info.sdkInt}</strong></div>
        </div>
        <div className="gaming-limits"><Info size={15}/><span>{info.lowMemory ? "Android currently reports low memory. Close unused windows or games before starting another." : "Android did not report a low-memory condition at this refresh."} RAM, GPU and refresh-rate fields may be restricted by the device; unknown values are never replaced with invented ones.</span></div>
      </> : <div className="gaming-limits"><Info size={15}/><span>Hardware details are unavailable in this browser preview. Open the Gaming Centre in the KK DEX Android app.</span></div>}
    </div>
  );
}

const categoryIcons: Record<string, typeof Image> = {
  apps: Package,
  images: Image,
  videos: Video,
  audio: Music2,
  documents: AppWindow,
  downloads: Download,
  apk: Package,
  games: Gamepad2,
  other: HardDrive,
};

export function StorageManagerApp() {
  const system = useSystem();
  const available = nativeAvailable();
  const [overview, setOverview] = useState<AndroidStorageOverview | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [folder, setFolder] = useState("");
  const [savedLocation, setSavedLocation] = useState("");
  const [folderBusy, setFolderBusy] = useState(false);

  const load = async () => {
    if (!available) return;
    setBusy(true);
    setError(null);
    try {
      const result = await getStorageOverview();
      setOverview(result);
      setFolder(result.downloadFolder.replace(/^Download\/?/, ""));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => void load(), []);

  if (!available) return <div className="storage-manager-app"><div className="native-required"><div className="native-required-icon"><HardDrive size={36}/></div><h2>Real storage needs Android.</h2><p>KK DEX reads total, used and available bytes from Android's StatFs and calculates accessible media categories through MediaStore. These values cannot be invented in a browser preview.</p><div className="native-required-note"><ShieldCheck size={14}/>No sample capacity numbers are shown.</div></div></div>;

  const usedPercent = overview ? Math.max(0, Math.min(100, (overview.used / overview.total) * 100)) : 0;
  return (
    <div className="storage-manager-app">
      <div className="panel-heading"><div><span className="eyebrow">ANDROID STORAGE</span><h1>Room to play.</h1><p>Actual capacity and accessible file categories from this phone.</p></div><button className="secondary-button" disabled={busy} onClick={() => void load()}><RefreshCw size={14} className={busy ? "spin" : ""}/> Refresh</button></div>
      {error && <div className="gaming-error"><AlertTriangle size={15}/>{error}</div>}
      {overview && <>
        <div className="storage-overview-card">
          <div className="storage-ring" style={{ "--used": `${usedPercent * 3.6}deg` } as React.CSSProperties}><div><strong>{Math.round(usedPercent)}%</strong><small>used</small></div></div>
          <div className="storage-capacity"><span className="eyebrow">DEVICE CAPACITY</span><strong>{formatAndroidBytes(overview.used)} <small>of {formatAndroidBytes(overview.total)}</small></strong><p>{formatAndroidBytes(overview.free)} available</p><div className="storage-bar"><span style={{ width: `${usedPercent}%` }}/></div><small>Updated {new Date(overview.updatedAt).toLocaleTimeString()}</small></div>
          <button className="gaming-primary" onClick={() => system.openApp("storage")}><HardDrive size={14}/> Browse files</button>
        </div>
        <div className="storage-category-grid">{overview.categories.map((category) => {
          const Icon = categoryIcons[category.id] || HardDrive;
          const percent = overview.used ? (category.bytes / overview.used) * 100 : 0;
          return <div key={category.id} className={!category.accessible ? "inaccessible" : ""}><div className={`storage-cat-icon cat-${category.id}`}><Icon size={18}/></div><div><strong>{category.label}</strong><span>{category.accessible ? formatAndroidBytes(category.bytes) : "Access not granted"}</span><div className="storage-cat-bar"><span style={{ width: `${Math.max(1, Math.min(100, percent))}%` }}/></div>{category.note && <small>{category.note}</small>}</div>{category.accessible ? <span className="cat-percent">{Math.round(percent)}%</span> : <button className="cat-grant" onClick={() => void requestMediaPermissions().then((result) => system.notify("Media access", result.explanation, "storagemanager")).catch((cause) => system.explain("Permission request failed", cause instanceof Error ? cause.message : "Android did not complete the permission request."))}>Grant</button>}</div>;
        })}</div>
        <div className="storage-actions">
          {savedLocation && <div className="inline-notice" role="status"><Check size={14}/><span>Download location updated: {savedLocation}</span></div>}
          <div className="setting-row"><div><strong>Download location</strong><small>Android DownloadManager saves under Internal storage / Download. This subfolder is configurable and persists.</small></div><div className="storage-folder-edit"><span>Download /</span><input aria-label="Download subfolder" value={folder} onChange={(event) => setFolder(event.target.value.replace(/[\\/:*?"<>|]/g, ""))} placeholder="KK DEX"/><button disabled={folderBusy || !folder.trim() || !overview} onClick={() => { setFolderBusy(true); void setDownloadSubfolder(folder).then(async (label) => { setSavedLocation(label); system.notify("Download location updated", label, "storagemanager"); await load(); }).catch((cause) => system.explain("Location was not changed", cause instanceof Error ? cause.message : "Android could not update the download folder.")).finally(() => setFolderBusy(false)); }}>{folderBusy ? <LoaderCircle className="spin" size={13}/> : <Check size={13}/>}</button></div></div>
          <div className="setting-row"><div><strong>Media permissions</strong><small>Android 13+ separates images, video and audio. Partial visual access is separate from SAF folder grants.</small></div><button className="secondary-button" onClick={() => void requestMediaPermissions().then((result) => system.notify("Media access", result.explanation, "storagemanager")).catch((cause) => system.explain("Permission request failed", cause instanceof Error ? cause.message : "Android rejected the request."))}><ShieldCheck size={13}/> Request access</button></div>
          <div className="setting-row"><div><strong>Detailed storage limitations</strong><small>What KK DEX can and cannot calculate.</small></div><button className="secondary-button" onClick={() => system.explain("Android storage calculation", overview.limitations.join("\n\n"))}><Info size={13}/> Explain</button></div>
        </div>
        <div className="storage-limitations">{overview.limitations.map((limitation) => <p key={limitation}><Info size={12}/>{limitation}</p>)}</div>
      </>}
    </div>
  );
}
