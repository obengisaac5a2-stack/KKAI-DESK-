package com.kkdex.desktop

import android.app.ActivityOptions
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.Base64
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale

class AndroidAppLauncher(private val context: Context) {
    fun installedApps(): JSONArray {
        val packageManager = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = packageManager.queryIntentActivities(
            intent,
            PackageManager.MATCH_ALL,
        )
        val seen = mutableSetOf<String>()
        val result = JSONArray()
        activities
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
            .forEach { info ->
                val packageName = info.activityInfo.packageName
                if (!seen.add(packageName)) return@forEach
                val applicationInfo = runCatching {
                    packageManager.getApplicationInfo(packageName, 0)
                }.getOrNull()
                val label = applicationInfo?.loadLabel(packageManager)?.toString()
                    ?: info.loadLabel(packageManager).toString()
                val icon = applicationInfo?.loadIcon(packageManager)
                val iconUrl = runCatching {
                    val bitmap = icon?.toBitmap(72, 72) ?: return@runCatching null
                    val output = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.PNG, 88, output)
                    if (!bitmap.isRecycled) bitmap.recycle()
                    "data:image/png;base64," +
                        Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                }.getOrNull()
                result.put(
                    JSONObject()
                        .put("packageName", packageName)
                        .put("label", label)
                        .put("iconUrl", iconUrl ?: JSONObject.NULL)
                        .put(
                            "system",
                            applicationInfo?.flags?.and(android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0,
                        )
                        .put(
                            "category",
                            when (applicationInfo?.category) {
                                android.content.pm.ApplicationInfo.CATEGORY_GAME -> "game"
                                android.content.pm.ApplicationInfo.CATEGORY_AUDIO -> "audio"
                                android.content.pm.ApplicationInfo.CATEGORY_VIDEO -> "video"
                                android.content.pm.ApplicationInfo.CATEGORY_IMAGE -> "image"
                                android.content.pm.ApplicationInfo.CATEGORY_SOCIAL -> "social"
                                android.content.pm.ApplicationInfo.CATEGORY_NEWS -> "news"
                                android.content.pm.ApplicationInfo.CATEGORY_MAPS -> "maps"
                                android.content.pm.ApplicationInfo.CATEGORY_PRODUCTIVITY -> "productivity"
                                else -> "other"
                            },
                        )
                        .put(
                            "isGame",
                            applicationInfo?.category == android.content.pm.ApplicationInfo.CATEGORY_GAME,
                        ),
                )
            }
        return result
    }

    fun launch(
        packageName: String,
        preferExternal: Boolean,
        externalDisplayId: Int,
    ): String {
        if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) {
            throw IllegalArgumentException("Invalid Android package name.")
        }
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: throw ActivityNotFoundException(
                "Android exposes no launcher activity for $packageName. It may be disabled, uninstalled, or hidden by package visibility.",
            )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (preferExternal && externalDisplayId > 0) {
            try {
                val options = ActivityOptions.makeBasic()
                    .setLaunchDisplayId(externalDisplayId)
                    .toBundle()
                context.startActivity(intent, options)
                return "Android accepted a launch request for $packageName on display $externalDisplayId. Some apps ignore external-display routing and still open on the phone. If it appeared on the phone only, the app or device does not support this launch path."
            } catch (error: Exception) {
                // Fall through to the honest phone fallback.
            }
        }
        try {
            context.startActivity(intent)
            return if (preferExternal && externalDisplayId <= 0) {
                "No external display is connected, so Android launched $packageName on the phone."
            } else {
                "Android launched $packageName on the phone because the external-display request was not supported. KK DEX does not move or mirror that app."
            }
        } catch (error: Exception) {
            throw ActivityNotFoundException(
                "Android refused to launch $packageName: ${error.message ?: "unknown launch failure"}",
            )
        }
    }

}
