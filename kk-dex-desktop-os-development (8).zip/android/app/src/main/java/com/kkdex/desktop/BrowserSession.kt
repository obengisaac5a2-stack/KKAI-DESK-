package com.kkdex.desktop

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewDatabase
import org.json.JSONArray
import org.json.JSONObject

/**
 * Shared browser history and controller-input target.
 *
 * The browser runs as a native WebView activity on the external display. This
 * registry lets the trusted phone controller deliver validated pointer and text
 * gestures to the real page when no desktop presentation is foreground.
 */
object BrowserSessionStore {
    private const val PREFS = "kkdex_browser"
    private const val KEY_HISTORY = "history"
    private const val MAX_HISTORY = 250

    fun record(context: Context, url: String, title: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = runCatching {
            JSONArray(preferences.getString(KEY_HISTORY, "[]"))
        }.getOrDefault(JSONArray())
        val updated = JSONArray()
        updated.put(
            JSONObject()
                .put("url", url)
                .put("title", title.ifBlank { Uri.parse(url).host ?: url })
                .put("visitedAt", System.currentTimeMillis()),
        )
        for (index in 0 until existing.length()) {
            val item = existing.optJSONObject(index) ?: continue
            if (item.optString("url") == url) continue
            if (updated.length() >= MAX_HISTORY) break
            updated.put(item)
        }
        preferences.edit().putString(KEY_HISTORY, updated.toString()).apply()
    }

    fun history(context: Context): JSONArray =
        runCatching {
            JSONArray(
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_HISTORY, "[]"),
            )
        }.getOrDefault(JSONArray())

    fun clear(context: Context): String {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_HISTORY).apply()
        return try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            WebViewDatabase.getInstance(context).clearHttpAuthUsernamePassword()
            WebViewDatabase.getInstance(context).clearFormData()
            "Android WebView cookies, WebStorage, form data, HTTP auth and the KK DEX browser history were cleared."
        } catch (error: Exception) {
            "KK DEX history was cleared, but Android could not clear every WebView store: ${error.message}"
        }
    }
}

object BrowserInputRouter {
    @Volatile
    var handler: ((JSONObject) -> String)? = null

    fun dispatch(message: JSONObject): String? {
        val target = handler ?: return null
        return target(message)
    }
}

object BrowserActivityIntents {
    fun external(url: String): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse(url))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
