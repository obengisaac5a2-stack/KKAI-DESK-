package com.kkdex.desktop

import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Origin-isolated native bridge for KK DEX.
 *
 * Security properties:
 * - Only the local WebViewAssetLoader origin is accepted by the WebKit
 *   WebMessage listener. Remote sites and third-party iframes are rejected.
 * - No addJavascriptInterface is used.
 * - Only content:// URIs returned by Android pickers, persisted trees, or
 *   MediaStore queries are accepted. JavaScript cannot submit arbitrary paths.
 * - The controller role receives a deliberately smaller method allowlist.
 * - All native work runs off the UI thread and errors are returned explicitly.
 */
class NativeBridge(
    private val activity: MainActivity,
    private val appVersion: String,
) {
    enum class Role { DESKTOP, CONTROLLER }

    private data class ContentSource(val uri: Uri, val mime: String)
    private data class PendingExport(
        val id: String,
        val reply: JavaScriptReplyProxy,
        val bytes: ByteArray,
        val mime: String,
    )

    private val storage = StorageController(activity)
    private val installedApps = AndroidAppLauncher(activity)
    private val downloads = DownloadController(activity)
    private val terminal = TerminalController(activity)
    private val pdf = PdfController(activity)
    private val executor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val contentSources = ConcurrentHashMap<String, ContentSource>()
    private var pendingExport: PendingExport? = null

    private var desktopWebView: WebView? = null
    private var controllerWebView: WebView? = null

    private val assetLoader: WebViewAssetLoader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(activity))
        .build()

    fun attachDesktop(webView: WebView) {
        desktopWebView = webView
        configureWebView(webView, Role.DESKTOP)
        pushDisplayStatus()
    }

    fun attachController(webView: WebView) {
        controllerWebView = webView
        configureWebView(webView, Role.CONTROLLER)
        pushDisplayStatus()
    }

    fun detachDesktop(webView: WebView) {
        if (desktopWebView === webView) {
            desktopWebView = null
        }
    }

    fun presentationStarting() {
        pushDisplayStatus()
    }

    fun presentationStopped() {
        pushDisplayStatus()
    }

    fun destroy() {
        desktopWebView = null
        controllerWebView = null
        pendingExport = null
        contentSources.clear()
        executor.shutdownNow()
    }

    fun pushDisplayStatus() {
        val status = activity.displayStatus().toString()
        val script = "window.KKDexNativeEvents && window.KKDexNativeEvents.onDisplayChanged(JSON.parse(${JSONObject.quote(status)}));"
        controllerWebView?.post {
            controllerWebView?.evaluateJavascript(script, null)
        }
        desktopWebView?.post {
            desktopWebView?.evaluateJavascript(script, null)
        }
    }

    fun pushControllerMessage(message: String) {
        controllerWebView?.post {
            controllerWebView?.evaluateJavascript(
                "window.KKDexNativeEvents && window.KKDexNativeEvents.onNativeMessage(${JSONObject.quote(message)});",
                null,
            )
        }
    }

    fun persistDocumentGrants(flags: Int, uris: List<Uri>) {
        val readWrite = flags and (
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        val takeFlags = if (readWrite == 0) Intent.FLAG_GRANT_READ_URI_PERMISSION else readWrite
        uris.forEach { uri ->
            runCatching {
                activity.contentResolver.takePersistableUriPermission(uri, takeFlags)
            }
        }
    }

    private fun configureWebView(webView: WebView, role: Role) {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)
        CookieManager.getInstance().setAcceptCookie(false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = "$userAgentString KKDex/${BuildConfig.VERSION_NAME}"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest,
            ): WebResourceResponse? {
                if (request.url.host == ASSET_HOST && request.url.path?.startsWith("/native-content/") == true) {
                    val token = request.url.pathSegments.getOrNull(1)
                    return respondWithContent(request, token)
                }
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest,
            ): Boolean {
                val target = request.url
                if (target.scheme == "about") return false
                if (target.host == ASSET_HOST) return false
                if (!request.isForMainFrame) return false
                return openExternalNavigation(target)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError,
            ) {
                if (request.isForMainFrame) {
                    activity.showToast("KK DEX could not load its local desktop assets: ${error.description}")
                }
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                val target = Uri.parse(url)
                if (target.scheme == "about" || target.host == ASSET_HOST) return false
                if (url.isNotBlank()) return openExternalNavigation(target)
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams,
            ): Boolean {
                return activity.showDocumentChooser(
                    filePathCallback,
                    fileChooserParams.acceptTypes,
                    fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE,
                )
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                request.deny()
            }

            override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                android.util.Log.d(
                    "KKDexWeb",
                    "${message.message()} (${message.sourceId()}:${message.lineNumber()})",
                )
                return true
            }
        }

        if (role == Role.DESKTOP) {
            webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                executor.execute {
                    try {
                        downloads.enqueue(url, userAgent, contentDisposition, mimeType, contentLength)
                        activity.showToast("Android DownloadManager accepted the download. Find it in Downloads > Android Downloads.")
                    } catch (error: Exception) {
                        activity.showToast("Download was not started: ${error.message}")
                    }
                }
            })
        }

        installMessageListener(webView, role)
    }

    private fun installMessageListener(webView: WebView, role: Role) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            activity.showToast(activity.getString(R.string.webview_required))
            return
        }
        WebViewCompat.addWebMessageListener(
            webView,
            BRIDGE_NAME,
            setOf(ASSET_ORIGIN),
            object : WebViewCompat.WebMessageListener {
                override fun onPostMessage(
                    view: WebView,
                    message: WebMessageCompat,
                    sourceOrigin: Uri,
                    isMainFrame: Boolean,
                    replyProxy: JavaScriptReplyProxy,
                ) {
                    if (!isMainFrame) return
                    if (sourceOrigin.scheme != "https" || sourceOrigin.host != ASSET_HOST) return
                    val data = message.data ?: return
                    if (data.length > MAX_MESSAGE_SIZE) {
                        activity.showToast("Native bridge message exceeded the safety limit.")
                        return
                    }
                    processMessage(role, data, replyProxy)
                }
            },
        )
    }

    private fun processMessage(role: Role, raw: String, reply: JavaScriptReplyProxy) {
        val request = try {
            JSONObject(raw)
        } catch (_: Exception) {
            activity.showToast("Native bridge rejected malformed JSON.")
            return
        }
        val id = request.optString("id", "")
        val method = request.optString("method", "")
        if (id.isBlank() || method.isBlank()) return
        val args = request.optJSONObject("args") ?: JSONObject()

        if (role == Role.CONTROLLER && method !in CONTROLLER_METHODS) {
            sendError(reply, id, "The phone controller is not permitted to call $method.", "ROLE_DENIED")
            return
        }

        if (method == "controllerInput") {
            mainHandler.post {
                try {
                    val incoming = JSONObject(args.optString("message"))
                    val browserResult = BrowserInputRouter.dispatch(incoming)
                    if (browserResult != null) {
                        sendResult(reply, id, browserResult)
                    } else {
                        dispatchControllerInput(args)
                        sendResult(reply, id, "Desktop touchpad input dispatched.")
                    }
                } catch (error: Exception) {
                    sendError(reply, id, error.message ?: "Controller input failed.", "INPUT_FAILED")
                }
            }
            return
        }
        if (method == "pickFiles" || method == "pickFolder" || method == "chooseFolderForDesktop") {
            mainHandler.post { startPicker(method, args, id, reply) }
            return
        }
        if (method == "requestMediaPermissions") {
            mainHandler.post {
                if (!activity.requestMediaPermissions { grants ->
                        val accessible = grants.filterValues { it }.keys.toList()
                        val explanation = if (accessible.isEmpty()) {
                            "No media permission was granted. KK DEX can still use the Android Storage Access Framework to read folders and files that you explicitly authorize."
                        } else {
                            "Android granted: ${accessible.joinToString(", ")}. Only MediaStore collections covered by these grants are visible; SAF folder authorization remains independent."
                        }
                        val permissionJson = JSONObject()
                        grants.forEach { (name, granted) -> permissionJson.put(name, granted) }
                        sendResult(
                            reply,
                            id,
                            JSONObject()
                                .put("permissions", permissionJson)
                                .put("explanation", explanation),
                        )
                    }
                ) {
                    sendError(reply, id, "Another Android permission request is already active.", "PERMISSION_BUSY")
                }
            }
            return
        }

        if (method == "exportFile" || method == "exportExistingFile") {
            executor.execute {
                try {
                    val bytes: ByteArray
                    val name: String
                    val mime: String
                    if (method == "exportFile") {
                        bytes = Base64.decode(args.optString("base64"), Base64.DEFAULT)
                        name = args.optString("name", "KK DEX export")
                        mime = args.optString("mime", "application/octet-stream")
                    } else {
                        val source = args.optString("uri")
                        bytes = storage.readBytes(source, StorageController.MAX_FILE_BYTES)
                        name = args.optString("name", storage.exportName(source))
                        mime = activity.contentResolver.getType(Uri.parse(source))
                            ?: "application/octet-stream"
                    }
                    if (bytes.size > StorageController.MAX_FILE_BYTES) {
                        throw IOException("Export exceeds the 50 MB bridge limit.")
                    }
                    mainHandler.post { startExport(id, reply, bytes, name, mime) }
                } catch (error: Exception) {
                    sendError(reply, id, error.message ?: "Could not prepare export.", "EXPORT_PREPARE_FAILED")
                }
            }
            return
        }

        executor.execute {
            try {
                val data = dispatch(role, method, args)
                sendResult(reply, id, data)
            } catch (error: Exception) {
                sendError(
                    reply,
                    id,
                    error.message ?: "Android could not complete $method.",
                    if (error is SecurityException) "ANDROID_PERMISSION_DENIED" else "ANDROID_OPERATION_FAILED",
                )
            }
        }
    }

    private fun dispatch(role: Role, method: String, args: JSONObject): Any? {
        return when (method) {
            "ping" -> JSONObject()
                .put("ok", true)
                .put("version", 1)
                .put("appVersion", appVersion)
                .put("role", role.name.lowercase())
            "displayStatus" -> activity.displayStatus()
            "listRoots" -> storage.mediaRoots()
            "listDirectory" -> storage.listDirectory(
                args.optString("treeUri").takeIf { it.isNotBlank() },
                args.optString("documentUri").takeIf { it.isNotBlank() },
            )
            "readFile" -> {
                val uri = args.optString("uri")
                val bytes = storage.readBytes(uri)
                JSONObject()
                    .put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    .put("name", storage.exportName(uri))
                    .put("mime", activity.contentResolver.getType(Uri.parse(uri)) ?: "application/octet-stream")
                    .put("size", bytes.size)
            }
            "writeFile" -> {
                val uri = args.optString("uri")
                if (uri.isBlank()) throw IOException("A writable Android document URI is required.")
                val bytes = Base64.decode(args.optString("base64"), Base64.DEFAULT)
                storage.writeBytes(uri, bytes)
                true
            }
            "createDirectory" -> storage.createDirectory(
                args.optString("treeUri"),
                args.optString("parentUri"),
                args.optString("name"),
            )
            "renameDocument" -> storage.rename(
                args.optString("treeUri"),
                args.optString("uri"),
                args.optString("name"),
            )
            "deleteDocument" -> {
                storage.delete(args.optString("uri"))
                true
            }
            "copyDocument" -> storage.copyOrMove(
                args.optString("treeUri"),
                args.optString("sourceUri"),
                args.optString("destinationUri"),
                false,
            )
            "moveDocument" -> storage.copyOrMove(
                args.optString("treeUri"),
                args.optString("sourceUri"),
                args.optString("destinationUri"),
                true,
            )
            "contentUrl" -> contentUrlFor(
                args.optString("uri"),
                args.optString("mime", "application/octet-stream"),
            )
            "openDocument" -> openContentDocument(
                args.optString("uri"),
                args.optString("mime", "application/octet-stream"),
            )
            "openUrl" -> openUrl(args.optString("url"))
            "getInstalledApps" -> installedApps.installedApps()
            "launchApp" -> installedApps.launch(
                args.optString("packageName"),
                args.optBoolean("preferExternal", true),
                activity.externalDisplayId(),
            )
            "getDownloads" -> downloads.list()
            "openDownload" -> {
                val id = args.optLong("id")
                val uri = downloads.open(id)
                val intent = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(
                        uri,
                        activity.contentResolver.getType(uri) ?: "application/octet-stream",
                    )
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                activity.openExternalIntent(intent)
            }
            "cancelDownload" -> {
                downloads.cancel(args.optLong("id"))
                true
            }
            "retryDownload" -> downloads.retry(args.optLong("id"))
            "installApk" -> installDownloadedApk(args.optLong("id"))
            "installApkUri" -> installApkAtUri(args.optString("uri"))
            "setDownloadSubfolder" -> downloads.setDownloadSubfolder(args.optString("folder"))
            "getStorageOverview" -> storage.storageOverview(downloads.downloadLocation())
            "shareDocument" -> shareDocument(args.optString("uri"), args.optString("mime"))
            "openBrowser" -> activity.openNativeBrowser(
                args.optString("url"),
                args.optBoolean("desktopMode", true),
            )
            "getBrowserHistory" -> BrowserSessionStore.history(activity)
            "clearBrowserData" -> {
                val webViewCleared = desktopWebView?.let { view ->
                    runCatching { view.clearCache(true); view.clearFormData(); true }.getOrDefault(false)
                } ?: false
                BrowserSessionStore.clear(activity) + if (webViewCleared) " Desktop WebView cache was also cleared." else ""
            }
            "getSystemInfo" -> systemInfo()
            "setVolume" -> setVolume(args.optInt("percent", 50))
            "getVolume" -> getMediaVolume()
            "runCommand" -> terminal.run(args.optString("command"))
            "openSystemSettings" -> {
                activity.openSystemSettings()
                "Android Settings opened on the phone."
            }
            "openSystemPanel" -> {
                val panel = args.optString("panel")
                val action = when (panel) {
                    "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> android.provider.Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> android.provider.Settings.ACTION_SOUND_SETTINGS
                    "storage" -> android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                    "apps" -> android.provider.Settings.ACTION_APPLICATION_SETTINGS
                    "unknown_sources" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                    } else {
                        android.provider.Settings.ACTION_SECURITY_SETTINGS
                    }
                    else -> android.provider.Settings.ACTION_SETTINGS
                }
                val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (panel == "unknown_sources" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    intent.data = Uri.parse("package:${activity.packageName}")
                }
                activity.startActivity(intent)
                "Android's real ${if (panel.isBlank()) "system" else panel} settings screen opened on the phone. Android does not allow an ordinary app to silently change protected Wi-Fi, Bluetooth or system policy state."
            }
            "pdfInfo" -> pdf.info(args.optString("uri"))
            "pdfRenderPage" -> pdf.renderPage(
                args.optString("uri"),
                args.optInt("page", 1),
                args.optInt("width", 1000),
            )
            else -> throw IllegalArgumentException("Unknown native bridge method: $method")
        }
    }

    private fun startPicker(method: String, args: JSONObject, id: String, reply: JavaScriptReplyProxy) {
        if (method == "chooseFolderForDesktop" && desktopWebView == null) {
            sendError(
                reply,
                id,
                "No external-display desktop is active. Connect the television or monitor before sending a folder to the desktop.",
                "DESKTOP_DISCONNECTED",
            )
            return
        }
        when (method) {
            "pickFiles" -> {
                val mime = args.optString("mime", "*/*").let {
                    if (ITEMS.matches(it)) it else "*/*"
                }
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(mime)
                    .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    .addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION,
                    )
                val launched = activity.launchSaf(intent) { resultCode, data ->
                    if (resultCode != android.app.Activity.RESULT_OK || data == null) {
                        sendError(reply, id, "The Android picker was cancelled. No files were selected.", "PICKER_CANCELLED")
                        return@launchSaf
                    }
                    val uris = collectUris(data)
                    if (uris.isEmpty()) {
                        sendError(reply, id, "Android returned no readable file URIs.", "PICKER_EMPTY")
                        return@launchSaf
                    }
                    persistDocumentGrants(data.flags, uris)
                    executor.execute {
                        try {
                            val result = JSONArray()
                            uris.forEach { result.put(storage.describePicked(it)) }
                            sendResult(reply, id, result)
                        } catch (error: Exception) {
                            sendError(reply, id, error.message ?: "Could not inspect selected files.", "PICKED_FILE_FAILED")
                        }
                    }
                }
                if (!launched) sendError(reply, id, "Android could not open the document picker.", "PICKER_LAUNCH_FAILED")
            }
            "pickFolder", "chooseFolderForDesktop" -> {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PREFIX_URI_PERMISSION,
                    )
                val launched = activity.launchSaf(intent) { resultCode, data ->
                    if (resultCode != android.app.Activity.RESULT_OK || data?.data == null) {
                        sendError(reply, id, "The Android folder picker was cancelled. No folder permission was changed.", "PICKER_CANCELLED")
                        return@launchSaf
                    }
                    val tree = data.data!!
                    try {
                        val granted = data.flags and (
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            )
                        val readable = granted and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0
                        val writable = granted and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0
                        val takeFlags = when {
                            readable && writable -> Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            writable -> Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            else -> Intent.FLAG_GRANT_READ_URI_PERMISSION
                        }
                        activity.contentResolver.takePersistableUriPermission(tree, takeFlags)
                    } catch (error: Exception) {
                        sendError(
                            reply,
                            id,
                            "Android did not retain this folder permission. ${error.message ?: "The grant is session-only or was refused."}",
                            "PERSIST_PERMISSION_FAILED",
                        )
                        return@launchSaf
                    }
                    storage.saveTree(tree)
                    val root = storage.treeRoot(tree)
                    if (method == "chooseFolderForDesktop") activity.openFolderOnDesktop(root)
                    sendResult(reply, id, root)
                }
                if (!launched) sendError(reply, id, "Android could not open the folder picker.", "PICKER_LAUNCH_FAILED")
            }
        }
    }

    private fun startExport(
        id: String,
        reply: JavaScriptReplyProxy,
        bytes: ByteArray,
        requestedName: String,
        requestedMime: String,
    ) {
        if (pendingExport != null) {
            sendError(reply, id, "Another Android export picker is already active.", "EXPORT_BUSY")
            return
        }
        val name = safeName(requestedName)
        val mime = requestedMime.ifBlank { "application/octet-stream" }
        pendingExport = PendingExport(id, reply, bytes, mime)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mime)
            .putExtra(Intent.EXTRA_TITLE, name)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val launched = activity.launchSaf(intent) { resultCode, data ->
            val pending = pendingExport
            pendingExport = null
            if (resultCode != android.app.Activity.RESULT_OK || data?.data == null || pending == null) {
                sendError(reply, id, "The Android save picker was cancelled. No file was written.", "EXPORT_CANCELLED")
                return@launchSaf
            }
            executor.execute {
                try {
                    activity.contentResolver.openOutputStream(data.data!!, "w")?.use {
                        it.write(pending.bytes)
                        it.flush()
                    } ?: throw IOException("Android could not open the chosen destination for writing.")
                    persistDocumentGrants(data.flags, listOf(data.data!!))
                    sendResult(reply, id, safeName(storage.displayName(data.data!!) ?: name))
                } catch (error: Exception) {
                    sendError(reply, id, error.message ?: "Android did not write the export.", "EXPORT_FAILED")
                }
            }
        }
        if (!launched) {
            pendingExport = null
            sendError(reply, id, "Android could not open the save picker.", "EXPORT_LAUNCH_FAILED")
        }
    }

    private fun dispatchControllerInput(args: JSONObject) {
        val target = desktopWebView
            ?: throw IllegalStateException("No external-display desktop is active. Connect a TV or monitor before using the touchpad.")
        val incoming = JSONObject(args.optString("message"))
        val type = incoming.optString("type")
        val normalized = JSONObject().put("type", type)
        when (type) {
            "movePointer" -> {
                normalized.put("dx", finite(incoming.optDouble("dx", 0.0)))
                normalized.put("dy", finite(incoming.optDouble("dy", 0.0)))
                normalized.put("relative", incoming.optBoolean("relative", true))
            }
            "pointerDown", "pointerUp" -> {
                normalized.put("button", incoming.optInt("button", 0).coerceIn(0, 2))
            }
            "pointerClick", "pointerDoubleClick", "pointerRightClick" -> Unit
            "scrollDesktop" -> {
                normalized.put("dx", finite(incoming.optDouble("dx", 0.0)))
                normalized.put("dy", finite(incoming.optDouble("dy", 0.0)))
            }
            "insertText" -> {
                normalized.put("text", incoming.optString("text").take(20_000))
            }
            "pressKey" -> {
                val key = incoming.optString("key")
                if (key.isBlank() || key.length > 32) throw IllegalArgumentException("Invalid key.")
                normalized.put("key", key)
                val modifiers = incoming.optJSONObject("modifiers") ?: JSONObject()
                normalized.put(
                    "modifiers",
                    JSONObject()
                        .put("ctrl", modifiers.optBoolean("ctrl"))
                        .put("alt", modifiers.optBoolean("alt"))
                        .put("shift", modifiers.optBoolean("shift"))
                        .put("meta", modifiers.optBoolean("meta")),
                )
            }
            else -> throw IllegalArgumentException("Unsupported controller input type: $type")
        }
        val script = "window.dispatchEvent(new CustomEvent('kkdex:input',{detail:${normalized.toString()}}));"
        target.post {
            target.evaluateJavascript(script, null)
        }
    }

    private fun contentUrlFor(uriValue: String, mimeValue: String): String {
        val uri = Uri.parse(uriValue)
        if (uri.scheme != "content") {
            throw IOException("Only Android content:// URIs can be streamed to the desktop.")
        }
        val mime = mimeValue.ifBlank { "application/octet-stream" }
        val token = UUID.randomUUID().toString()
        contentSources[token] = ContentSource(uri, mime)
        return "$ASSET_ORIGIN/native-content/$token"
    }

    private fun respondWithContent(
        request: WebResourceRequest,
        token: String?,
    ): WebResourceResponse {
        val source = token?.let { contentSources[it] }
            ?: return textResponse(404, "Not Found", "Unknown or expired KK DEX content token.")
        return try {
            val descriptor = activity.contentResolver.openAssetFileDescriptor(source.uri, "r")
                ?: return textResponse(404, "Not Found", "Android could not open this content URI.")
            val length = descriptor.length
            val range = request.requestHeaders.entries
                .firstOrNull { it.key.equals("Range", ignoreCase = true) }
                ?.value
            val responseHeaders = HashMap<String, String>()
            responseHeaders["Accept-Ranges"] = "bytes"
            responseHeaders["Cache-Control"] = "no-store, no-cache"
            responseHeaders["Content-Disposition"] = "inline"
            if (request.method.equals("HEAD", ignoreCase = true)) {
                descriptor.close()
                if (length >= 0) responseHeaders["Content-Length"] = length.toString()
                return WebResourceResponse(
                    source.mime,
                    "UTF-8",
                    200,
                    "OK",
                    responseHeaders,
                    ByteArrayInputStream(ByteArray(0)),
                )
            }
            if (!range.isNullOrBlank() && length >= 0) {
                val match = Regex("bytes=(\\d+)-(\\d*)").find(range)
                if (match != null) {
                    val start = match.groupValues[1].toLongOrNull()?.coerceAtLeast(0) ?: 0
                    val requestedEnd = match.groupValues[2].toLongOrNull() ?: (length - 1)
                    val end = requestedEnd.coerceAtMost(length - 1).coerceAtLeast(start)
                    val stream = descriptor.createInputStream()
                    skipFully(stream, start)
                    val limited = BoundedInputStream(stream, end - start + 1)
                    responseHeaders["Content-Range"] = "bytes $start-$end/$length"
                    responseHeaders["Content-Length"] = (end - start + 1).toString()
                    return WebResourceResponse(
                        source.mime,
                        "UTF-8",
                        206,
                        "Partial Content",
                        responseHeaders,
                        ManagedInputStream(limited, descriptor),
                    )
                }
            }
            val stream: InputStream = descriptor.createInputStream()
            if (length >= 0) responseHeaders["Content-Length"] = length.toString()
            WebResourceResponse(
                source.mime,
                "UTF-8",
                200,
                "OK",
                responseHeaders,
                ManagedInputStream(stream, descriptor),
            )
        } catch (error: Exception) {
            textResponse(403, "Forbidden", "Android denied or revoked access to this content URI: ${error.message}")
        }
    }

    private fun openContentDocument(uriValue: String, mimeValue: String): String {
        val uri = Uri.parse(uriValue)
        if (uri.scheme != "content") throw IOException("Only Android content:// documents can be opened.")
        val mime = mimeValue.ifBlank { activity.contentResolver.getType(uri) ?: "*/*" }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return activity.openExternalIntent(intent)
    }

    private fun openUrl(urlValue: String): String {
        val uri = Uri.parse(urlValue)
        if (uri.scheme != "http" && uri.scheme != "https") {
            throw IllegalArgumentException("Only HTTP and HTTPS addresses can open in the system browser.")
        }
        val intent = Intent(Intent.ACTION_VIEW, uri)
        return activity.openExternalIntent(intent)
    }

    private fun installDownloadedApk(id: Long): String {
        if (id <= 0) throw IllegalArgumentException("Invalid Android download ID.")
        val uri = downloads.installApk(id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !activity.packageManager.canRequestPackageInstalls()
        ) {
            try {
                activity.startActivity(
                    Intent(
                        android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${activity.packageName}"),
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
                return "Android requires you to allow installs from KK DEX first. Android Settings was opened for that exact permission. No APK was installed or simulated."
            } catch (error: Exception) {
                throw IOException("Android requires the Install unknown apps permission for KK DEX, but this device did not open the settings screen: ${error.message}", error)
            }
        }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
            return "Android's package installer was opened on the phone. KK DEX has not installed anything; review the signature, permissions and Play Protect result in Android's official confirmation dialog."
        } catch (error: Exception) {
            throw IOException(
                "Android could not open its package installer. Check that the downloaded file is a valid APK, that Install unknown apps is allowed for KK DEX, and that storage access is still valid. ${error.message ?: ""}",
                error,
            )
        }
    }

    private fun installApkAtUri(uriValue: String): String {
        val uri = Uri.parse(uriValue)
        if (uri.scheme != "content") throw IOException("Only an Android content:// APK can be installed.")
        val name = storage.displayName(uri).orEmpty()
        val mime = activity.contentResolver.getType(uri).orEmpty()
        val isApk = mime == "application/vnd.android.package-archive" || name.endsWith(".apk", true)
        if (!isApk) throw IOException("Android did not identify this file as an APK. Installation was not started.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            activity.startActivity(
                Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return "Android requires Install unknown apps permission for KK DEX. Android Settings was opened. No app was installed."
        }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
        return "Android's official package installer was opened. KK DEX did not bypass the signature or Play Protect confirmation."
    }

    private fun shareDocument(uriValue: String, mimeValue: String): String {
        val uri = Uri.parse(uriValue)
        if (uri.scheme != "content") throw IOException("Only Android content:// files can be shared.")
        val mime = mimeValue.ifBlank {
            activity.contentResolver.getType(uri) ?: "application/octet-stream"
        }
        val intent = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(intent, "Share Android file"))
        return "Android's share sheet opened for this content URI. KK DEX does not upload the file itself."
    }

    private fun systemInfo(): JSONObject {
        val packageInfo = if (Build.VERSION.SDK_INT >= 33) {
            activity.packageManager.getPackageInfo(
                activity.packageName,
                PackageManager.PackageInfoFlags.of(0),
            )
        } else {
            @Suppress("DEPRECATION")
            activity.packageManager.getPackageInfo(activity.packageName, 0)
        }
        val webViewPackage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WebView.getCurrentWebViewPackage()
        } else {
            null
        }
        val activityManager = activity.getSystemService(android.app.ActivityManager::class.java)
        val memory = android.app.ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memory)
        val gpuRenderer = runCatching {
            android.opengl.GLES20.glGetString(android.opengl.GLES20.GL_RENDERER)
        }.getOrNull() ?: "GPU renderer not exposed"
        val gpuVendor = runCatching {
            android.opengl.GLES20.glGetString(android.opengl.GLES20.GL_VENDOR)
        }.getOrNull() ?: "GPU vendor not exposed"
        val stat = StatFs(activity.filesDir.absolutePath)
        val total = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            stat.totalBytes
        } else {
            stat.blockCountLong * stat.blockSizeLong
        }
        val free = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            stat.availableBytes
        } else {
            stat.availableBlocksLong * stat.blockSizeLong
        }
        return JSONObject()
            .put("appVersion", appVersion)
            .put("manufacturer", Build.MANUFACTURER)
            .put("brand", Build.BRAND)
            .put("model", Build.MODEL)
            .put("device", Build.DEVICE)
            .put("androidRelease", Build.VERSION.RELEASE)
            .put("sdkInt", Build.VERSION.SDK_INT)
            .put(
                "webViewVersion",
                webViewPackage?.let { "${it.packageName} ${it.versionName}" }
                    ?: WebSettings.getDefaultUserAgent(activity),
            )
            .put("externalDisplay", activity.displayStatus())
            .put("runtimes", terminal.detectRuntimes())
            .put("supportedAbis", JSONArray(Build.SUPPORTED_ABIS.toList()))
            .put("dataPath", activity.filesDir.absolutePath)
            .put("totalStorage", total)
            .put("freeStorage", free)
            .put("cpuCores", Runtime.getRuntime().availableProcessors())
            .put("cpuAbi", Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown")
            .put("totalRam", memory.totalMem)
            .put("availableRam", memory.availMem)
            .put("lowMemory", memory.lowMemory)
            .put("refreshRate", activity.displayStatus().optDouble("refreshRate", 0.0))
            .put("gpuRenderer", gpuRenderer)
            .put("gpuVendor", gpuVendor)
            .put("webglAvailable", JSONObject.NULL)
    }

    private fun getMediaVolume(): Int {
        val audio = activity.getSystemService(AudioManager::class.java)
            ?: throw IllegalStateException("Android audio service is unavailable.")
        val maximum = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (maximum <= 0) return 0
        return (audio.getStreamVolume(AudioManager.STREAM_MUSIC).toDouble() / maximum * 100).roundToInt()
    }

    private fun setVolume(percent: Int): Int {
        val audio = activity.getSystemService(AudioManager::class.java)
            ?: throw IllegalStateException("Android audio service is unavailable.")
        val maximum = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (maximum <= 0) throw IllegalStateException("Android reported no controllable media volume stream.")
        val target = (percent.coerceIn(0, 100) / 100.0 * maximum).roundToInt()
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        } catch (error: SecurityException) {
            throw IOException("Android denied modification of device media volume. MODIFY_AUDIO_SETTINGS may be restricted by the device.", error)
        }
        return (target.toDouble() / maximum * 100).roundToInt()
    }

    private fun collectUris(data: Intent): List<Uri> {
        val clip = data.clipData
        if (clip != null) {
            return (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
        }
        return listOfNotNull(data.data)
    }

    private fun sendResult(reply: JavaScriptReplyProxy, id: String, data: Any?) {
        val payload = JSONObject().put("id", id).put("ok", true)
        when (data) {
            null -> payload.put("data", JSONObject.NULL)
            is JSONObject, is JSONArray, is String, is Number, is Boolean -> payload.put("data", data)
            else -> payload.put("data", data.toString())
        }
        mainHandler.post {
            runCatching { reply.postMessage(payload.toString()) }
        }
    }

    private fun sendError(reply: JavaScriptReplyProxy, id: String, message: String, code: String) {
        val payload = JSONObject()
            .put("id", id)
            .put("ok", false)
            .put("error", message)
            .put("code", code)
        mainHandler.post {
            runCatching { reply.postMessage(payload.toString()) }
        }
    }

    private fun textResponse(status: Int, reason: String, message: String): WebResourceResponse =
        WebResourceResponse(
            "text/plain",
            "UTF-8",
            status,
            reason,
            mapOf("Cache-Control" to "no-store"),
            ByteArrayInputStream(message.toByteArray(Charsets.UTF_8)),
        )

    private fun openExternalNavigation(uri: Uri): Boolean {
        if (uri.scheme != "http" && uri.scheme != "https" && uri.scheme != "mailto" && uri.scheme != "tel") {
            activity.showToast("KK DEX blocked an unsupported navigation scheme (${uri.scheme ?: "none"}).")
            return true
        }
        return try {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            activity.showToast("Opened this address in an Android application. Remote pages never receive the native KK DEX bridge.")
            true
        } catch (error: Exception) {
            activity.showToast("No Android application handled this address: ${error.message}")
            true
        }
    }

    private fun finite(value: Double): Double =
        if (value.isFinite()) value.coerceIn(-100_000.0, 100_000.0) else 0.0

    private fun skipFully(stream: InputStream, bytesToSkip: Long) {
        var remaining = bytesToSkip
        while (remaining > 0) {
            val skipped = stream.skip(remaining)
            if (skipped > 0) remaining -= skipped
            else if (stream.read() == -1) break
            else remaining -= 1
        }
    }

    private fun safeName(value: String): String {
        val name = value.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_")
            .trim()
            .take(160)
        return name.ifBlank { "KK DEX export" }
    }

    private class ManagedInputStream(
        input: InputStream,
        private val descriptor: java.io.Closeable,
    ) : FilterInputStream(input) {
        override fun close() {
            try {
                super.close()
            } finally {
                runCatching { descriptor.close() }
            }
        }
    }

    private class BoundedInputStream(
        input: InputStream,
        private var remaining: Long,
    ) : FilterInputStream(input) {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val value = super.read()
            if (value >= 0) remaining--
            return value
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (remaining <= 0) return -1
            val read = super.read(buffer, offset, minOf(length.toLong(), remaining).toInt())
            if (read > 0) remaining -= read
            return read
        }
    }

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
        const val ASSET_ORIGIN = "https://appassets.androidplatform.net"
        const val DESKTOP_URL = "$ASSET_ORIGIN/assets/kkdex/index.html"
        const val CONTROLLER_URL = "$ASSET_ORIGIN/assets/kkdex/index.html?controller"
        private const val BRIDGE_NAME = "KKDexNative"
        private const val MAX_MESSAGE_SIZE = 80_000_000
        private val ITEMS = Regex("([a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+|\\*/\\*)")
        private val CONTROLLER_METHODS = setOf(
            "ping",
            "displayStatus",
            "controllerInput",
            "setVolume",
            "getVolume",
            "getInstalledApps",
            "launchApp",
            "chooseFolderForDesktop",
            "openUrl",
            "getDownloads",
            "shareDocument",
            "getStorageOverview",
        )
    }
}
