package com.kkdex.desktop

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

/**
 * Downloads are enqueued in Android's real DownloadManager and survive process
 * death. The public destination is Internal storage/Download/<subfolder>.
 * DownloadManager owns pause/resume/cancel behavior and reports unsupported
 * server resume through its real pause/status reason.
 */
class DownloadController(private val context: Context) {
    private val manager =
        context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val preferences =
        context.getSharedPreferences("kkdex_downloads", Context.MODE_PRIVATE)

    fun enqueue(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?,
        contentLength: Long,
        requestedName: String? = null,
    ): Long {
        val uri = Uri.parse(url)
        if (uri.scheme != "http" && uri.scheme != "https") {
            throw IllegalArgumentException(
                "Android DownloadManager can save HTTP(S) downloads. This link uses ${uri.scheme}; blob/data downloads must be saved by their originating page or through a native share flow.",
            )
        }
        val name = safeFileName(
            requestedName ?: contentDisposition?.let { parseFileName(it) }
                ?: uri.lastPathSegment
                ?: "KK DEX download",
        )
        val freeBytes = runCatching { java.io.File(Environment.DIRECTORY_DOWNLOADS.let { context.filesDir }).usableSpace }.getOrDefault(0L)
        if (contentLength > 0 && freeBytes in 1 until contentLength + MIN_FREE_MARGIN) {
            throw IllegalArgumentException(
                "Android reports insufficient free space for this download. Required: ${contentLength} bytes; available app data space: $freeBytes bytes. KK DEX did not enqueue the download.",
            )
        }
        val subfolder = downloadSubfolder()
        val relativePath = if (subfolder.isBlank()) name else "$subfolder/$name"
        val request = DownloadManager.Request(uri)
            .setTitle(name)
            .setDescription("Downloaded through KK DEX")
            .setMimeType(mimeType ?: "application/octet-stream")
            .setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED,
            )
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, relativePath)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
        CookieManager.getInstance().getCookie(url)?.let {
            request.addRequestHeader("Cookie", it)
        }
        val id = manager.enqueue(request)
        rememberRequest(id, url, userAgent, contentDisposition, mimeType, contentLength, name)
        return id
    }

    fun list(): JSONArray {
        val downloads = JSONArray()
        manager.query(DownloadManager.Query()).use { value ->
            while (value.moveToNext()) {
                val id = value.getLong(value.getColumnIndexOrThrow(DownloadManager.COLUMN_ID))
                val status = value.getInt(value.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val localUri = runCatching { manager.getUriForDownloadedFile(id)?.toString() }
                    .getOrNull()
                val reason = value.getIntOrZero(DownloadManager.COLUMN_REASON)
                downloads.put(
                    JSONObject()
                        .put("id", id)
                        .put("title", value.getStringOrNull(DownloadManager.COLUMN_TITLE))
                        .put("description", value.getStringOrNull(DownloadManager.COLUMN_DESCRIPTION))
                        .put("mime", value.getStringOrNull(DownloadManager.COLUMN_MEDIA_TYPE))
                        .put("size", value.getLongOrZero(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        .put("downloaded", value.getLongOrZero(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        .put("status", statusName(status))
                        .put("localUri", localUri ?: JSONObject.NULL)
                        .put("timestamp", value.getLongOrZero(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP))
                        .put("reason", reason)
                        .put("reasonText", reasonText(status, reason)),
                )
            }
        }
        val sorted = mutableListOf<JSONObject>()
        for (index in 0 until downloads.length()) sorted.add(downloads.getJSONObject(index))
        sorted.sortByDescending { it.optLong("timestamp") }
        return JSONArray(sorted)
    }

    fun open(id: Long): Uri {
        val uri = manager.getUriForDownloadedFile(id)
            ?: throw IllegalArgumentException("This download is incomplete or Android removed the local file.")
        return uri
    }

    fun cancel(id: Long) {
        require(id > 0) { "Invalid Android download ID." }
        manager.remove(id)
        preferences.edit().remove(key(id)).apply()
    }

    fun retry(id: Long): Long {
        val cursor = manager.query(DownloadManager.Query().setFilterById(id))
        cursor.use { value ->
            if (!value.moveToFirst()) {
                throw IllegalArgumentException("Android no longer has this download's history. Start the download again from the browser.")
            }
            val uri = value.getStringOrNull(DownloadManager.COLUMN_URI)
                ?: throw IllegalArgumentException("Android did not retain the original download URL.")
            val stored = runCatching { JSONObject(preferences.getString(key(id), "{}")!!) }
                .getOrDefault(JSONObject())
            val result = enqueue(
                url = uri,
                userAgent = stored.optString("userAgent").ifBlank { null },
                contentDisposition = stored.optString("contentDisposition").ifBlank { null },
                mimeType = stored.optString("mime").ifBlank {
                    value.getStringOrNull(DownloadManager.COLUMN_MEDIA_TYPE)
                },
                contentLength = stored.optLong("contentLength", 0),
                requestedName = stored.optString("name").ifBlank {
                    value.getStringOrNull(DownloadManager.COLUMN_TITLE)
                },
            )
            manager.remove(id)
            return result
        }
    }

    fun installApk(id: Long): Uri {
        val uri = manager.getUriForDownloadedFile(id)
            ?: throw IllegalArgumentException("This APK is incomplete or Android removed the downloaded file.")
        val cursor = manager.query(DownloadManager.Query().setFilterById(id))
        var mime: String? = null
        var title: String? = null
        cursor.use {
            if (it.moveToFirst()) {
                mime = it.getStringOrNull(DownloadManager.COLUMN_MEDIA_TYPE)
                title = it.getStringOrNull(DownloadManager.COLUMN_TITLE)
            }
        }
        if (mime != "application/vnd.android.package-archive" && !title.orEmpty().endsWith(".apk", ignoreCase = true)) {
            throw IllegalArgumentException("This file is not an APK. Use the normal Android viewer for this file type.")
        }
        return uri
    }

    fun downloadSubfolder(): String =
        preferences.getString(KEY_SUBFOLDER, "KK DEX").orEmpty()

    fun setDownloadSubfolder(value: String): String {
        val cleaned = sanitizeFolder(value)
        preferences.edit().putString(KEY_SUBFOLDER, cleaned).apply()
        return downloadLocation()
    }

    fun downloadLocation(): String =
        "Internal storage/Download/${downloadSubfolder()}"

    private fun rememberRequest(
        id: Long,
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mime: String?,
        contentLength: Long,
        name: String,
    ) {
        preferences.edit().putString(
            key(id),
            JSONObject()
                .put("url", url)
                .put("userAgent", userAgent ?: "")
                .put("contentDisposition", contentDisposition ?: "")
                .put("mime", mime ?: "application/octet-stream")
                .put("contentLength", contentLength)
                .put("name", name)
                .toString(),
        ).apply()
    }

    private fun key(id: Long) = "request_$id"

    private fun sanitizeFolder(value: String): String {
        val cleaned = value.trim()
            .replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim('.', ' ')
            .take(80)
        if (cleaned.isEmpty() || cleaned == "." || cleaned == "..") return "KK DEX"
        return cleaned
    }

    private fun android.database.Cursor.getStringOrNull(column: String): String? {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) null else getString(index)
    }

    private fun android.database.Cursor.getLongOrZero(column: String): Long {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) 0L else getLong(index)
    }

    private fun android.database.Cursor.getIntOrZero(column: String): Int {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) 0 else getInt(index)
    }

    private fun statusName(status: Int): String = when (status) {
        DownloadManager.STATUS_PENDING -> "pending"
        DownloadManager.STATUS_RUNNING -> "running"
        DownloadManager.STATUS_PAUSED -> "paused"
        DownloadManager.STATUS_SUCCESSFUL -> "successful"
        DownloadManager.STATUS_FAILED -> "failed"
        else -> "other"
    }

    private fun reasonText(status: Int, reason: Int): String = when {
        status == DownloadManager.STATUS_SUCCESSFUL -> "Android saved this file successfully."
        status == DownloadManager.STATUS_RUNNING -> "Android DownloadManager is transferring this file."
        status == DownloadManager.STATUS_PENDING -> "Waiting for Android DownloadManager."
        status == DownloadManager.STATUS_PAUSED -> when (reason) {
            DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "Paused by Android while waiting for Wi-Fi."
            DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "Paused by Android while waiting for a network."
            DownloadManager.PAUSED_WAITING_TO_RETRY -> "Android paused this transfer and will retry."
            DownloadManager.PAUSED_UNKNOWN -> "Paused by Android DownloadManager. The public DownloadManager API does not expose a resume control; cancel and retry to start again."
            else -> "Paused by Android DownloadManager."
        }
        status == DownloadManager.STATUS_FAILED -> when (reason) {
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Android reports insufficient storage."
            DownloadManager.ERROR_HTTP_DATA_ERROR, DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "The server returned an HTTP transfer error."
            DownloadManager.ERROR_CANNOT_RESUME -> "The server could not resume this download. Retry from the beginning."
            DownloadManager.ERROR_FILE_ERROR -> "Android could not write the destination file."
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "The server redirected too many times."
            DownloadManager.ERROR_UNKNOWN -> "Android DownloadManager reported an unknown failure."
            else -> "Android DownloadManager failed with reason $reason."
        }
        else -> "Android DownloadManager status changed."
    }

    private fun parseFileName(disposition: String): String {
        val encoded = disposition.substringAfter("filename*=", "")
        if (encoded.isNotBlank()) {
            return runCatching {
                val value = encoded.substringAfter("''", encoded).substringBefore(';').trim()
                URLDecoder.decode(value, "UTF-8")
            }.getOrDefault(encoded.trim())
        }
        return disposition.substringAfter("filename=", "download")
            .substringBefore(';')
            .trim()
            .trim('"')
    }

    private fun safeFileName(value: String): String {
        val name = value.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim('.', ' ')
            .take(160)
        return if (name.isBlank() || name == "." || name == "..") {
            "KK DEX download ${System.currentTimeMillis()}"
        } else name
    }

    companion object {
        private const val KEY_SUBFOLDER = "subfolder"
        private const val MIN_FREE_MARGIN = 20L * 1024L * 1024L
    }
}
