package com.kkdex.desktop

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Real desktop-style Android WebView browser.
 *
 * This is deliberately not an iframe. It supports cookies, DOM storage,
 * JavaScript, website logins, HTML5 media, full-screen video, popup windows,
 * downloads, file uploads, a desktop user agent, multiple tabs, history, site
 * permission prompts and phone-controller/pointer input.
 *
 * It opens on the external display when Android supports allocating an
 * activity there. Otherwise it opens on the phone and reports the fallback.
 */
class BrowserActivity : AppCompatActivity() {
    private data class Tab(
        val id: Long,
        val webView: WebView,
        var title: String = "New tab",
        var url: String = HOME_URL,
    )

    private val tabs = mutableListOf<Tab>()
    private var activeId: Long = 0L
    private var nextId = 1L
    private var desktopMode = true
    private val mainHandler = Handler(Looper.getMainLooper())
    private val downloads by lazy { DownloadController(this) }

    private lateinit var root: FrameLayout
    private lateinit var chrome: LinearLayout
    private lateinit var tabStrip: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var pageTitle: TextView
    private lateinit var tabCount: TextView
    private lateinit var exitFullscreen: TextView
    private var fileChooser: ValueCallback<Array<Uri>>? = null
    private var sitePermission: PermissionRequest? = null
    private var pendingSiteResources: Array<String>? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingGeoGrant: Array<String>? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var chromeManuallyHidden = false
    private var pointerX = 0f
    private var pointerY = 0f

    private val activeTab: Tab?
        get() = tabs.firstOrNull { it.id == activeId }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(8, 18, 13)
        window.navigationBarColor = Color.rgb(8, 18, 13)
        buildUi()
        restoreState(intent, savedInstanceState)
        registerInputRouter()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        desktopMode = intent.getBooleanExtra(EXTRA_DESKTOP_MODE, desktopMode)
        applyUserAgent()
        intent.getStringExtra(EXTRA_URL)?.let { navigate(it) }
    }

    override fun onResume() {
        super.onResume()
        registerInputRouter()
        CookieManager.getInstance().flush()
    }

    override fun onPause() {
        saveState()
        CookieManager.getInstance().flush()
        if (BrowserInputRouter.handler != null) BrowserInputRouter.handler = null
        super.onPause()
    }

    override fun onDestroy() {
        saveState()
        fileChooser?.onReceiveValue(null)
        fileChooser = null
        tabs.forEach { tab ->
            tab.webView.stopLoading()
            tab.webView.loadUrl("about:blank")
            (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
            tab.webView.destroy()
        }
        tabs.clear()
        if (BrowserInputRouter.handler != null) BrowserInputRouter.handler = null
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (customView != null) {
            activeTab?.webView?.let { (it.webChromeClient as? WebChromeClient)?.onHideCustomView() }
            hideCustomView()
            return
        }
        if (chromeManuallyHidden) {
            setChromeVisible(true)
            return
        }
        val tab = activeTab
        if (tab?.webView?.canGoBack() == true) tab.webView.goBack()
        else if (tabs.size > 1) closeTab(tab?.id ?: activeId)
        else super.onBackPressed()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_FILE_CHOOSER) {
            val callback = fileChooser
            fileChooser = null
            if (resultCode != Activity.RESULT_OK || data == null || callback == null) {
                callback?.onReceiveValue(null)
                return
            }
            val clip = data.clipData
            val uris = if (clip != null) {
                (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
            } else listOfNotNull(data.data)
            val flags = data.flags and (
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            uris.forEach { uri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        if (flags == 0) Intent.FLAG_GRANT_READ_URI_PERMISSION else flags,
                    )
                }
            }
            callback.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_GEOLOCATION) {
            val origin = pendingGeoOrigin
            val callback = pendingGeoCallback
            val grantedResources = pendingGeoGrant
            pendingGeoOrigin = null
            pendingGeoCallback = null
            pendingGeoGrant = null
            if (origin != null && callback != null) {
                val granted = grantedResources?.all {
                    ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
                } == true
                callback.invoke(origin, granted, false)
                toast(if (granted) "Android granted location to the website." else "Android location permission was not granted; the website was denied.")
            }
            return
        }
        if (requestCode != REQUEST_SITE_PERMISSIONS) return
        val request = sitePermission
        val resources = pendingSiteResources
        sitePermission = null
        pendingSiteResources = null
        if (request == null || resources == null) return
        val required = requiredAndroidPermissions(resources)
        val granted = required.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (granted) {
            request.grant(resources)
            toast("Website permission granted for this secure origin.")
        } else {
            request.deny()
            toast("Android permission was denied. The website was not granted camera/microphone access.")
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        chrome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(CHROME_BG)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(5), dp(9), dp(3))
        }
        top.addView(brand())
        val tabScroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tabScroller.addView(tabStrip, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(31)))
        chrome.addView(top, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(35)))
        chrome.addView(tabScroller, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(33)))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), 0, dp(7), dp(4))
        }
        nav.addView(toolButton("‹", "Back") { if (activeTab?.webView?.canGoBack() == true) activeTab?.webView?.goBack() })
        nav.addView(toolButton("›", "Forward") { if (activeTab?.webView?.canGoForward() == true) activeTab?.webView?.goForward() })
        nav.addView(toolButton("↻", "Reload") { activeTab?.webView?.reload() })
        nav.addView(toolButton("⌂", "Home") { navigate(HOME_URL) })
        address = EditText(this).apply {
            hint = "Search the web or enter an address"
            setSingleLine(true)
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            textSize = 13f
            background = roundedRect(INPUT_BG, dp(7), BORDER)
            setPadding(dp(13), 0, dp(9), 0)
            setSelectAllOnFocus(true)
            isFocusableInTouchMode = true
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO) {
                    navigate(text.toString())
                    clearBrowserFocus()
                    true
                } else false
            }
            setOnKeyListener { _, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) {
                    navigate(text.toString())
                    clearBrowserFocus()
                    true
                } else false
            }
        }
        nav.addView(address, LinearLayout.LayoutParams(0, dp(36), 1f).apply {
            marginStart = dp(5); marginEnd = dp(5)
        })
        nav.addView(toolButton("＋", "New tab") { addTab(HOME_URL) })
        nav.addView(toolButton("☰", "Browser menu") { showMenu() })
        chrome.addView(nav, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        pageTitle = TextView(this).apply {
            setTextColor(MUTED)
            textSize = 9f
            maxLines = 1
            setPadding(dp(13), 0, dp(13), dp(4))
            text = "KKDEX BROWSER · real Android WebView"
        }
        chrome.addView(pageTitle)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressDrawable = android.graphics.drawable.ClipDrawable(android.graphics.drawable.ColorDrawable(ACCENT), Gravity.START, android.graphics.drawable.ClipDrawable.HORIZONTAL)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2))
        }
        chrome.addView(progress)
        outer.addView(chrome)
        content = FrameLayout(this).apply {
            setBackgroundColor(BG)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        outer.addView(content)
        root.addView(outer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        exitFullscreen = TextView(this).apply {
            text = "⤡ Exit full screen"
            setTextColor(TEXT)
            textSize = 11f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundedRect(0xE61A2A21.toInt(), dp(7), BORDER)
            visibility = View.GONE
            setOnClickListener { setChromeVisible(true) }
        }
        root.addView(exitFullscreen, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(14); marginEnd = dp(14)
        })
        setContentView(root)
        window.decorView.isFocusableInTouchMode = true
    }

    private fun brand(): TextView = TextView(this).apply {
        text = "KKDEX"
        setTextColor(ACCENT)
        textSize = 13f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.08f
        setPadding(dp(4), 0, dp(16), 0)
        contentDescription = "KK DEX browser"
    }

    private fun toolButton(label: String, description: String, click: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(TEXT)
            textSize = 21f
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            contentDescription = description
            background = rippleBackground()
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(dp(39), dp(36))
        }

    private fun restoreState(intent: Intent, bundle: Bundle?) {
        desktopMode = intent.getBooleanExtra(EXTRA_DESKTOP_MODE, true)
        val initialUrl = intent.getStringExtra(EXTRA_URL)?.takeIf { isWebAddress(it) }
        val preferences = getSharedPreferences(PREFS, MODE_PRIVATE)
        val remembered = if (bundle == null) runCatching {
            JSONArray(preferences.getString(KEY_OPEN_TABS, "[]"))
        }.getOrDefault(JSONArray()) else JSONArray()
        val urls = mutableListOf<String>()
        for (index in 0 until remembered.length()) {
            remembered.optString(index).takeIf { isWebAddress(it) }?.let { urls.add(it) }
        }
        if (initialUrl != null) {
            if (urls.isEmpty()) urls.add(initialUrl) else urls[0] = initialUrl
        }
        if (urls.isEmpty()) urls.add(HOME_URL)
        urls.take(8).forEach { addTab(it, activate = false) }
        activeId = tabs.first().id
        showTab(tabs.first())
        toast("Real WebView browser · cookies and downloads enabled. External-display routing is reported by Android.")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val webView = WebView(this).apply {
            setBackgroundColor(BG)
            isFocusable = true
            isFocusableInTouchMode = true
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString = USER_AGENT
            safeBrowsingEnabled = true
        }
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            try {
                downloads.enqueue(url, userAgent, contentDisposition, mimeType, contentLength)
                toast("Android DownloadManager accepted the download. Find it in KK DEX Downloads.")
            } catch (error: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Download not started")
                    .setMessage(error.message ?: "Android DownloadManager rejected this download.")
                    .setPositiveButton("Okay", null)
                    .show()
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val target = request.url
                return when (target.scheme?.lowercase(Locale.US)) {
                    "http", "https" -> false
                    "about" -> false
                    else -> {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            toast("Opened ${target.scheme} link with Android. Remote content receives no KK DEX native bridge.")
                        } catch (error: Exception) {
                            toast("Android has no app for this link type: ${target.scheme}")
                        }
                        true
                    }
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                updateTabForWebView(view, url)
                if (view === activeTab?.webView) {
                    progress.visibility = View.VISIBLE
                    progress.progress = 0
                    address.setText(url)
                    address.setSelection(address.text.length)
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                updateTabForWebView(view, url)
                progress.visibility = View.GONE
                view.requestFocus()
                if (view === activeTab?.webView) {
                    address.setText(url)
                    address.setSelection(address.text.length)
                    renderTabs()
                }
                val title = view.title?.takeIf { it.isNotBlank() } ?: Uri.parse(url).host ?: url
                updateTabForWebView(view, url, title)
                BrowserSessionStore.record(this@BrowserActivity, url, title)
                if (view === activeTab?.webView) pageTitle.text = "$title · ${Uri.parse(url).host ?: "Android WebView"}"
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    progress.visibility = View.GONE
                    AlertDialog.Builder(this@BrowserActivity)
                        .setTitle("Page could not load")
                        .setMessage("Android WebView reported: ${error.description} (${request.url})\n\nA slow network, a blocked redirect, site security policy or unavailable codec can cause this. KK DEX does not replace the failed page with fake content.")
                        .setPositiveButton("Try again") { _, _ -> view.reload() }
                        .setNegativeButton("Close", null)
                        .show()
                }
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                if (request.isForMainFrame && response.statusCode >= 400) {
                    toast("Website returned HTTP ${response.statusCode}. The server's real error page is shown.")
                }
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: android.net.http.SslError) {
                handler.cancel()
                AlertDialog.Builder(this@BrowserActivity)
                    .setTitle("Insecure certificate")
                    .setMessage("KK DEX refuses to bypass Android's TLS validation. This website's certificate is invalid, expired or not trusted for this host.")
                    .setPositiveButton("Close", null)
                    .show()
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                toast("Android terminated this page renderer. KK DEX will close the affected tab rather than pretend it is still running.")
                val tab = tabs.firstOrNull { it.webView === view } ?: return true
                closeTab(tab.id)
                return true
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (view === activeTab?.webView) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView, title: String) {
                updateTabForWebView(view, view.url ?: HOME_URL, title)
                if (view === activeTab?.webView) pageTitle.text = "$title · ${Uri.parse(view.url ?: HOME_URL).host ?: "WebView"}"
            }

            override fun onShowFileChooser(
                view: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams,
            ): Boolean {
                fileChooser?.onReceiveValue(null)
                fileChooser = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    fileChooserParams.acceptTypes.filter { it.isNotBlank() }.let {
                        if (it.isNotEmpty()) putExtra(Intent.EXTRA_MIME_TYPES, it.toTypedArray())
                    }
                }
                return try {
                    startActivityForResult(intent, REQUEST_FILE_CHOOSER)
                    true
                } catch (error: Exception) {
                    fileChooser = null
                    filePathCallback.onReceiveValue(null)
                    toast("Android could not open the upload picker: ${error.message}")
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                decideSitePermission(request)
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                AlertDialog.Builder(this@BrowserActivity)
                    .setTitle("Website location request")
                    .setMessage("$origin requests your exact location. Android will ask for the real location permission. Allow only if you trust this secure site.")
                    .setPositiveButton("Request location") { _, _ ->
                        val needed = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                        val missing = needed.filter {
                            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
                        }
                        if (missing.isEmpty()) {
                            callback.invoke(origin, true, false)
                        } else {
                            pendingGeoOrigin = origin
                            pendingGeoCallback = callback
                            pendingGeoGrant = missing.toTypedArray()
                            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_GEOLOCATION)
                        }
                    }
                    .setNegativeButton("Deny") { _, _ -> callback.invoke(origin, false, false) }
                    .setOnCancelListener { callback.invoke(origin, false, false) }
                    .show()
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                val popup = createWebView()
                val tab = Tab(nextId++, popup, "Popup", view.url ?: HOME_URL)
                tabs.add(tab)
                content.addView(popup, 0)
                showTab(tab)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = popup
                mainHandler.postDelayed({
                    resultMsg.sendToTarget()
                    renderTabs()
                    popup.requestFocus()
                }, 80)
                toast("Website popup opened in a real new browser tab.")
                return true
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                setChromeVisible(false)
                content.visibility = View.INVISIBLE
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                root.bringChildToFront(exitFullscreen)
                exitFullscreen.visibility = View.VISIBLE
                root.keepScreenOn = true
                enterImmersive()
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }
        return webView
    }

    private fun addTab(url: String, activate: Boolean = true): Tab {
        val webView = createWebView()
        val tab = Tab(nextId++, webView, "New tab", url)
        tabs.add(tab)
        content.addView(webView, 0)
        webView.loadUrl(url)
        if (activate) showTab(tab) else webView.visibility = View.GONE
        renderTabs()
        return tab
    }

    private fun showTab(tab: Tab) {
        activeId = tab.id
        tabs.forEach { it.webView.visibility = if (it === tab) View.VISIBLE else View.GONE }
        address.setText(tab.url)
        address.setSelection(address.text.length)
        pageTitle.text = "${tab.title} · ${Uri.parse(tab.url).host ?: "WebView"}"
        tab.webView.requestFocus()
        renderTabs()
    }

    private fun closeTab(id: Long) {
        if (tabs.size <= 1) {
            finish()
            return
        }
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val tab = tabs.removeAt(index)
        content.removeView(tab.webView)
        tab.webView.stopLoading()
        tab.webView.destroy()
        if (activeId == id) showTab(tabs[index.coerceAtMost(tabs.lastIndex)])
        renderTabs()
    }

    private fun updateTabForWebView(view: WebView, url: String, title: String? = null) {
        val tab = tabs.firstOrNull { it.webView === view } ?: return
        tab.url = url
        if (!title.isNullOrBlank()) tab.title = title
        if (view === activeTab?.webView) {
            if (address.text.toString() != url) {
                address.setText(url)
                address.setSelection(address.text.length)
            }
            tabCount.text = "${tabs.size} tab${if (tabs.size == 1) "" else "s"}"
        }
    }

    private fun renderTabs() {
        tabStrip.removeAllViews()
        tabs.forEach { tab ->
            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(3), 0)
                background = roundedRect(
                    if (tab.id == activeId) ACTIVE_TAB else TAB_BG,
                    dp(6),
                    if (tab.id == activeId) ACCENT_DIM else BORDER,
                )
                setOnClickListener { showTab(tab) }
            }
            val label = TextView(this).apply {
                text = tab.title.take(22)
                textSize = 10f
                setTextColor(if (tab.id == activeId) TEXT else MUTED)
                maxLines = 1
                setPadding(0, 0, dp(7), 0)
            }
            val close = TextView(this).apply {
                text = "×"
                textSize = 15f
                setTextColor(MUTED)
                gravity = Gravity.CENTER
                contentDescription = "Close ${tab.title}"
                setOnClickListener { closeTab(tab.id) }
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
            }
            holder.addView(label)
            holder.addView(close)
            tabStrip.addView(holder, LinearLayout.LayoutParams(dp(155), dp(27)).apply { marginEnd = dp(4) })
        }
        tabStrip.addView(toolButton("＋", "New tab") { addTab(HOME_URL) }, LinearLayout.LayoutParams(dp(32), dp(27)))
        tabCount = TextView(this).apply {
            text = "${tabs.size} tab${if (tabs.size == 1) "" else "s"}"
            setTextColor(MUTED)
            textSize = 8f
            gravity = Gravity.CENTER
        }
        tabStrip.addView(tabCount, LinearLayout.LayoutParams(dp(42), dp(27)))
    }

    private fun navigate(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = normalize(value)
        if (!isWebAddress(url)) {
            toast("Only HTTP and HTTPS addresses can open in the KKDex browser.")
            return
        }
        val tab = activeTab ?: addTab(url).also { return }
        tab.webView.loadUrl(url)
        tab.webView.requestFocus()
        address.clearFocus()
    }

    private fun normalize(value: String): String {
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        if (value.contains(" ") || !value.contains(".")) {
            return "https://duckduckgo.com/?q=${Uri.encode(value)}"
        }
        return if (value.startsWith("localhost")) "http://$value" else "https://$value"
    }

    private fun isWebAddress(url: String): Boolean =
        url.startsWith("http://") || url.startsWith("https://")

    private fun showMenu() {
        val popup = PopupMenu(this, findViewById(android.R.id.content))
        popup.menu.add(0, 1, 0, if (desktopMode) "Use mobile website mode" else "Use desktop website mode")
        popup.menu.add(0, 2, 1, if (chromeManuallyHidden) "Show browser toolbar" else "Full-screen browsing")
        popup.menu.add(0, 3, 2, "New tab")
        popup.menu.add(0, 4, 3, "Open current address in Android browser")
        popup.menu.add(0, 5, 4, "Clear cookies, storage and history")
        popup.menu.add(0, 6, 5, "Close browser")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { desktopMode = !desktopMode; applyUserAgent(); activeTab?.webView?.reload(); true }
                2 -> { setChromeVisible(chromeManuallyHidden); true }
                3 -> { addTab(HOME_URL); true }
                4 -> {
                    activeTab?.url?.let { url ->
                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                    }
                    true
                }
                5 -> {
                    AlertDialog.Builder(this)
                        .setTitle("Clear browser data?")
                        .setMessage("This clears Android WebView cookies, local storage, cache, form data and KK DEX browser history. Existing account sessions will end.")
                        .setPositiveButton("Clear") { _, _ ->
                            BrowserSessionStore.clear(this)
                            CookieManager.getInstance().removeAllCookies(null)
                            CookieManager.getInstance().flush()
                            WebStorage.getInstance().deleteAllData()
                            activeTab?.webView?.clearCache(true)
                            activeTab?.webView?.clearFormData()
                            toast("Android confirmed the browser clear requests. Website session state may still be controlled by the live page.")
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    true
                }
                6 -> { finish(); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun applyUserAgent() {
        tabs.forEach { tab ->
            tab.webView.settings.userAgentString = if (desktopMode) USER_AGENT else MOBILE_USER_AGENT
            tab.webView.reload()
        }
    }

    private fun decideSitePermission(request: PermissionRequest) {
        val labels = request.resources.joinToString(", ")
        AlertDialog.Builder(this)
            .setTitle("Website permission")
            .setMessage("${request.origin}\n\nThis secure website requests: $labels\n\nGrant only if you trust the site. Android still controls the underlying device permissions.")
            .setPositiveButton("Request & allow") { _, _ ->
                val required = requiredAndroidPermissions(request.resources)
                val missing = required.filter {
                    ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
                }
                if (missing.isEmpty()) {
                    request.grant(request.resources)
                } else {
                    sitePermission = request
                    pendingSiteResources = request.resources
                    ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_SITE_PERMISSIONS)
                }
            }
            .setNegativeButton("Deny") { _, _ -> request.deny() }
            .setOnCancelListener { request.deny() }
            .show()
    }

    private fun requiredAndroidPermissions(resources: Array<String>): List<String> {
        val result = mutableSetOf<String>()
        resources.forEach { resource ->
            when (resource) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> result.add(Manifest.permission.CAMERA)
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> result.add(Manifest.permission.RECORD_AUDIO)
            }
        }
        return result.toList()
    }

    private fun registerInputRouter() {
        BrowserInputRouter.handler = input@{ message ->
            val tab = activeTab ?: return@input "No browser tab is active."
            val webView = tab.webView
            when (message.optString("type")) {
                "movePointer" -> {
                    if (pointerX == 0f && pointerY == 0f) {
                        pointerX = webView.width / 2f
                        pointerY = webView.height / 2f
                    }
                    pointerX = (pointerX + message.optDouble("dx", 0.0).toFloat() * 1.6f)
                        .coerceIn(0f, webView.width.toFloat().coerceAtLeast(1f))
                    pointerY = (pointerY + message.optDouble("dy", 0.0).toFloat() * 1.6f)
                        .coerceIn(0f, webView.height.toFloat().coerceAtLeast(1f))
                    dispatchPointer(webView, MotionEvent.ACTION_MOVE, pointerX, pointerY)
                    "Browser pointer moved."
                }
                "pointerClick" -> {
                    dispatchPointer(webView, MotionEvent.ACTION_DOWN, pointerX, pointerY)
                    dispatchPointer(webView, MotionEvent.ACTION_UP, pointerX, pointerY)
                    "Browser click dispatched to Android WebView."
                }
                "pointerDown" -> {
                    dispatchPointer(webView, MotionEvent.ACTION_DOWN, pointerX, pointerY)
                    "Browser pointer down."
                }
                "pointerUp" -> {
                    dispatchPointer(webView, MotionEvent.ACTION_UP, pointerX, pointerY)
                    "Browser pointer up."
                }
                "pointerDoubleClick" -> {
                    repeat(2) {
                        dispatchPointer(webView, MotionEvent.ACTION_DOWN, pointerX, pointerY)
                        dispatchPointer(webView, MotionEvent.ACTION_UP, pointerX, pointerY)
                    }
                    "Browser double-click dispatched."
                }
                "pointerRightClick" -> {
                    webView.evaluateJavascript(
                        "(function(){const e=document.elementFromPoint(${pointerX},${pointerY});if(e)e.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:${pointerX},clientY:${pointerY},button:2}));})()",
                        null,
                    )
                    "Browser right-click event dispatched."
                }
                "scrollDesktop" -> {
                    val dx = -message.optDouble("dx", 0.0)
                    val dy = -message.optDouble("dy", 0.0)
                    webView.evaluateJavascript(
                        "window.scrollBy({left:${dx},top:${dy},behavior:'instant'});",
                        null,
                    )
                    "Browser scroll dispatched."
                }
                "insertText" -> {
                    val text = message.optString("text").take(20_000)
                    webView.evaluateJavascript(
                        "(function(t){const e=document.activeElement;if(!e)return;if(e.isContentEditable){document.execCommand('insertText',false,t);return;}if(e.tagName==='INPUT'||e.tagName==='TEXTAREA'){const p=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;const s=e.selectionStart??e.value.length;const n=e.value.slice(0,s)+t+e.value.slice(e.selectionEnd??s);Object.getOwnPropertyDescriptor(p,'value').set.call(e,n);e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:t}));e.setSelectionRange(s+t.length,s+t.length);}})(JSON.parse(${JSONObject.quote(JSONObject.quote(text))}))",
                        null,
                    )
                    "Text inserted into the focused website field."
                }
                "pressKey" -> {
                    val key = message.optString("key").take(32)
                    val modifiers = message.optJSONObject("modifiers") ?: JSONObject()
                    val script = "(function(){const e=document.activeElement||document.body;const o={key:${JSONObject.quote(key)},bubbles:true,cancelable:true,ctrlKey:${modifiers.optBoolean("ctrl")},altKey:${modifiers.optBoolean("alt")},shiftKey:${modifiers.optBoolean("shift")},metaKey:${modifiers.optBoolean("meta")}};const d=new KeyboardEvent('keydown',o);e.dispatchEvent(d);if(!d.defaultPrevented&&(e.tagName==='INPUT'||e.tagName==='TEXTAREA')){if(o.key==='Backspace'){const s=e.selectionStart??e.value.length;e.setRangeText('',Math.max(0,s-1),e.selectionEnd??s,'end');e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'deleteContentBackward'}));}else if(o.key==='Enter'&&e.tagName==='INPUT'){e.form?.requestSubmit?.();}}e.dispatchEvent(new KeyboardEvent('keyup',o));})()";
                    webView.evaluateJavascript(script, null)
                    "Keyboard event dispatched to the active website."
                }
                else -> throw IllegalArgumentException("Unsupported browser input.")
            }
        }
    }

    private fun dispatchPointer(webView: WebView, action: Int, x: Float, y: Float) {
        val event = MotionEvent.obtain(android.os.SystemClock.uptimeMillis(), android.os.SystemClock.uptimeMillis(), action, x, y, 0)
        webView.dispatchTouchEvent(event)
        event.recycle()
    }

    private fun hideCustomView() {
        customView?.let { root.removeView(it) }
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        content.visibility = View.VISIBLE
        exitFullscreen.visibility = View.GONE
        root.keepScreenOn = true
        setChromeVisible(true)
        exitImmersive()
    }

    private fun setChromeVisible(visible: Boolean) {
        chrome.visibility = if (visible) View.VISIBLE else View.GONE
        exitFullscreen.visibility = if (visible) View.GONE else View.VISIBLE
        chromeManuallyHidden = !visible
        if (visible) exitImmersive() else enterImmersive()
    }

    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
            window.insetsController?.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    private fun exitImmersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.show(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    private fun clearBrowserFocus() {
        address.clearFocus()
        activeTab?.webView?.requestFocus()
    }

    private fun saveState() {
        val urls = JSONArray(tabs.map { it.url })
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OPEN_TABS, urls.toString()).apply()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun roundedRect(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(1, strokeColor)
        }

    private fun rippleBackground(): android.graphics.drawable.Drawable {
        val ripple = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33FFFFFF),
            null,
            null,
        )
        return ripple
    }

    companion object {
        const val EXTRA_URL = "kkdex.browser.url"
        const val EXTRA_DESKTOP_MODE = "kkdex.browser.desktopMode"
        private const val HOME_URL = "https://duckduckgo.com/"
        private const val PREFS = "kkdex_browser_tabs"
        private const val KEY_OPEN_TABS = "open_tabs"
        private const val REQUEST_FILE_CHOOSER = 7101
        private const val REQUEST_SITE_PERMISSIONS = 7102
        private const val REQUEST_GEOLOCATION = 7103
        private const val BG = 0xFF0C1711.toInt()
        private const val CHROME_BG = 0xFF111F18.toInt()
        private const val TAB_BG = 0xFF17271E.toInt()
        private const val ACTIVE_TAB = 0xFF263C2D.toInt()
        private const val ACCENT = 0xFF9ED3AE.toInt()
        private const val ACCENT_DIM = 0xFF5B8C6C.toInt()
        private const val TEXT = 0xFFE3EADF.toInt()
        private const val MUTED = 0xFF93A38F.toInt()
        private const val INPUT_BG = 0xFF0A130E.toInt()
        private const val BORDER = 0xFF354A3C.toInt()
        private const val USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 KKDex/1.1"
        private const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; KKDex) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
    }
}
