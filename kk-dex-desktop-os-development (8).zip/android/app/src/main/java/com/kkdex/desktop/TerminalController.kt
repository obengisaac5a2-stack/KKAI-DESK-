package com.kkdex.desktop

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/**
 * Genuine execution in the KK DEX application sandbox.
 *
 * Android applications do not have root access. This controller invokes
 * /system/bin/sh as the application UID and reports exactly what happened.
 * Python, Node and Git are never advertised unless their executable is present.
 */
class TerminalController(private val context: Context) {
    private val runtimeNames = listOf("python3", "python", "node", "git", "toybox", "unzip")

    fun run(commandValue: String): JSONObject {
        val command = commandValue.trim()
        if (command.isEmpty()) throw IllegalArgumentException("No command was provided.")
        if (command.length > MAX_COMMAND_LENGTH) {
            throw IllegalArgumentException("Command exceeds the ${MAX_COMMAND_LENGTH} character limit.")
        }
        val started = System.currentTimeMillis()
        val process = ProcessBuilder("/system/bin/sh", "-c", command)
            .directory(context.filesDir)
            .redirectErrorStream(false)
            .start()

        val stdout = ByteArrayOutputStream()
        val stderr = ByteArrayOutputStream()
        val outThread = Thread {
            drain(process.inputStream, stdout)
        }.apply { isDaemon = true; start() }
        val errThread = Thread {
            drain(process.errorStream, stderr)
        }.apply { isDaemon = true; start() }

        val finished = process.waitFor(COMMAND_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        if (!finished) {
            process.destroy()
            if (process.isAlive) process.destroyForcibly()
            outThread.join(500)
            errThread.join(500)
            throw IllegalStateException(
                "Command exceeded the ${COMMAND_TIMEOUT_SECONDS}s timeout and was terminated. Partial output:\n${stdout.text()}",
            )
        }
        outThread.join(2000)
        errThread.join(2000)
        return JSONObject()
            .put("stdout", stdout.text())
            .put("stderr", stderr.text())
            .put("exitCode", process.exitValue())
            .put("backend", "Android app UID shell · not root")
            .put("durationMs", System.currentTimeMillis() - started)
            .put("workingDirectory", context.filesDir.absolutePath)
    }

    fun detectRuntimes(): JSONObject {
        val result = JSONObject()
        runtimeNames.forEach { name ->
            val located = runCatching {
                run("command -v $name 2>/dev/null")
            }.getOrNull()
            val path = located
                ?.getString("stdout")
                ?.trim()
                ?.lineSequence()
                ?.firstOrNull { it.isNotBlank() }
            if (path.isNullOrBlank()) {
                result.put(name, JSONObject.NULL)
            } else {
                val version = runCatching {
                    val command = if (name == "toybox") "toybox --version" else "$name --version 2>/dev/null"
                    run(command).getString("stdout").trim().lineSequence().firstOrNull()
                }.getOrNull()
                result.put(name, if (version.isNullOrBlank()) path else "$path · $version")
            }
        }
        return result
    }

    private fun drain(input: java.io.InputStream, target: ByteArrayOutputStream) {
        input.use { stream ->
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val read = stream.read(buffer)
                if (read <= 0) break
                if (total < MAX_OUTPUT_BYTES) {
                    val accepted = minOf(read, MAX_OUTPUT_BYTES - total)
                    target.write(buffer, 0, accepted)
                    total += accepted
                }
            }
        }
    }

    private fun ByteArrayOutputStream.text(): String =
        toString(StandardCharsets.UTF_8.name())

    companion object {
        private const val COMMAND_TIMEOUT_SECONDS = 25L
        private const val MAX_OUTPUT_BYTES = 512 * 1024
        private const val MAX_COMMAND_LENGTH = 8192
    }
}
