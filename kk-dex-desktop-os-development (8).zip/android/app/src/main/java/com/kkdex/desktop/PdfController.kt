package com.kkdex.desktop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * Real PDF rendering through Android's PdfRenderer.
 *
 * A page is rendered to a PNG in memory and returned as a data URL for the
 * trusted desktop WebView. The PDF itself remains a content:// URI authorized
 * by the user; KK DEX never reads an unrestricted filesystem path.
 */
class PdfController(private val context: Context) {
    fun info(uriValue: String): JSONObject {
        open(uriValue).use { document ->
            return JSONObject()
                .put("pageCount", document.pageCount)
                .put("name", uriValue.substringAfterLast('/'))
        }
    }

    fun renderPage(uriValue: String, requestedPage: Int, requestedWidth: Int): JSONObject {
        val width = requestedWidth.coerceIn(320, 1800)
        open(uriValue).use { document ->
            if (document.pageCount < 1) throw IOException("This PDF has no renderable pages.")
            val pageNumber = requestedPage.coerceIn(1, document.pageCount)
            document.openPage(pageNumber - 1).use { page ->
                val aspect = page.height.toFloat() / page.width.toFloat()
                val bitmap = Bitmap.createBitmap(
                    width,
                    (width * aspect).toInt().coerceAtLeast(1),
                    Bitmap.Config.ARGB_8888,
                )
                try {
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val output = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.PNG, 92, output)
                    val image = "data:image/png;base64," +
                        Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                    return JSONObject()
                        .put("image", image)
                        .put("page", pageNumber)
                        .put("pageCount", document.pageCount)
                        .put("width", bitmap.width)
                        .put("height", bitmap.height)
                } finally {
                    bitmap.recycle()
                }
            }
        }
    }

    private fun open(uriValue: String): PdfRenderer {
        val uri = Uri.parse(uriValue)
        if (uri.scheme != "content") throw IOException("Only Android content:// PDF URIs are accepted.")
        val descriptor: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IOException("Android could not open the authorized PDF. The grant may have expired.")
        return try {
            PdfRenderer(descriptor)
        } catch (error: Exception) {
            runCatching { descriptor.close() }
            throw IOException(
                "Android PdfRenderer could not read this document. It may be password protected, damaged, or not a valid PDF.",
                error,
            )
        }
    }
}
