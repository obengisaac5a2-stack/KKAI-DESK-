package com.kkdex.desktop

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView

/**
 * The actual television desktop.
 *
 * This Presentation is attached to an external display and creates a desktop
 * WebView there. The phone activity's controller WebView is a separate,
 * unprivileged surface. No screen mirroring is used.
 */
class DesktopPresentation(
    outerContext: Context,
    display: Display,
    private val bridge: NativeBridge,
) : Presentation(outerContext, display) {
    lateinit var webView: WebView
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.BLACK))
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                setDecorFitsSystemWindows(false)
            } else {
                @Suppress("DEPRECATION")
                decorView.systemUiVisibility =
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                        android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        }
        webView = WebView(context).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            isFocusable = true
            isFocusableInTouchMode = true
        }
        setContentView(webView)
        bridge.attachDesktop(webView)
        webView.loadUrl(NativeBridge.DESKTOP_URL)
    }

    override fun onStart() {
        super.onStart()
        bridge.presentationStarting()
    }

    override fun onStop() {
        bridge.detachDesktop(webView)
        webView.stopLoading()
        webView.loadUrl("about:blank")
        webView.destroy()
        bridge.presentationStopped()
        super.onStop()
    }
}
