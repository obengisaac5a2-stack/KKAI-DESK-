# KK DEX uses AndroidX WebKit's WebMessage listener. No JavaScript
# interface is registered with addJavascriptInterface.
-keepclassmembers class com.kkdex.desktop.** { *; }
