# KK DEX Android Host

## Project

`android/` is a complete Android Studio-compatible Gradle project using Kotlin 2.0, AGP 8.7.3 and Gradle 8.9.

- Application ID: `com.kkdex.desktop`
- Min SDK: 26 (Android 8.0)
- Compile/target SDK: 35
- External display: Android `Presentation` containing its own desktop WebView
- Phone: a separate `MainActivity` controller WebView
- Web assets: `assets/kkdex/`, copied from the production Vite `dist/`
- Native bridge: AndroidX WebKit `addWebMessageListener`, origin allowlisted
- Legacy `addJavascriptInterface`: **not used**

## Build

Requirements: JDK 17, Android SDK platform 35, build tools 35.0.0, Node 20+, npm.

```bash
npm ci
npm run build
node scripts/sync-android-assets.mjs
cd android
./gradlew :app:assembleDebug
./gradlew :app:lintDebug
```

Outputs:

- `android/app/build/outputs/apk/debug/app-debug.apk`
- Lint report: `android/app/build/reports/lint-results-debug.html`

Install on a connected device:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.kkdex.desktop/.MainActivity
```

The APK workflow at `.github/workflows/android.yml` builds and uploads the installable APK. The debug APK is signed with Android's debug certificate; use a private release keystore for production distribution.

## Two-screen lifecycle

1. `MainActivity` creates the phone controller WebView and loads `index.html?controller`.
2. `DisplayManager` tracks `DISPLAY_CATEGORY_PRESENTATION`.
3. When an external display appears, `DesktopPresentation` is shown on that display and creates a second WebView loading `index.html`.
4. The phone never renders the desktop. There is no display mirroring.
5. Disconnecting the display dismisses the presentation and tells the controller.
6. Reconnecting creates a new presentation. Desktop window state is restored from persistent web storage.
7. Android lifecycle and configuration changes are handled; picker/result callbacks are retained by the host.

Some devices cannot create secondary presentations at all. Android prohibits an ordinary app from forcing external rendering on unsupported hardware. The controller reports the absence instead of faking a TV connection.

## Permissions

Declared and used:

- `INTERNET`, `ACCESS_NETWORK_STATE`
- `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO` on Android 13+
- `READ_MEDIA_VISUAL_USER_SELECTED` on Android 14+ for partial photo/video access
- `READ_EXTERNAL_STORAGE` on Android 12 and lower
- `WRITE_EXTERNAL_STORAGE` on Android 8/9 for legacy DownloadManager writes
- `MODIFY_AUDIO_SETTINGS` for real media volume
- `POST_NOTIFICATIONS` declared for DownloadManager completion notifications
- Launcher-activity package queries for installed app discovery; `QUERY_ALL_PACKAGES` is **not** requested

SAF (`ACTION_OPEN_DOCUMENT`, `ACTION_OPEN_DOCUMENT_TREE`) does not require broad storage permission. The app retains only user-selected URI permissions. MediaStore listing is separate and requires the relevant runtime media grant. A folder grant does not grant unrelated files.

## Native bridge and security

The bridge object is `KKDexNative`. It is added only to the local asset origin:

`https://appassets.androidplatform.net`

The desktop and controller are served with `WebViewAssetLoader`. The listener rejects subframes and any other source origin. Remote iframe content cannot call Android.

- JavaScript can only supply `content://` URIs. Raw filesystem paths are rejected.
- File reads/writes are bounded to 50 MB.
- URI grants are enforced by Android's ContentResolver, not by trusting JavaScript.
- The controller role allowlist is limited to input, display status, volume, app discovery/launch and a desktop folder picker.
- Native file/network/application errors are returned as `{ok:false,error,code}`.
- `file://` access and universal file URL access are disabled.
- Third-party cookies and unsafe mixed content are disabled.
- Remote main-frame navigation is sent to an external Android handler; it never takes over the trusted desktop WebView.
- WebView debugging is enabled only in debug builds.
- App backups are disabled and data extraction excludes app data.

The bridge supports picker requests, persisted tree roots, directory listing, reads/writes, create/rename/delete/copy/move, export, content streaming with HTTP Range support, media/PDF viewing, installed apps, external-display launch requests, DownloadManager listing/opening, media volume, runtime detection, system information and controller input.

## SAF behavior

- **Open folder:** Android native `ACTION_OPEN_DOCUMENT_TREE`.
- **Pick files:** Android native `ACTION_OPEN_DOCUMENT` with multiple selection and explicit MIME filter.
- **Save/export:** Android native `ACTION_CREATE_DOCUMENT`.
- `takePersistableUriPermission` is required before a tree is saved. If Android refuses to retain access, the UI reports failure and does not pretend the folder is available later.
- Files are read through `ContentResolver`; folders are queried with child-document URIs.
- Copy and move read real bytes, create a real destination document and optionally delete the source.
- Mutations are attempted through the provider APIs. Error cases—read-only folders, unsupported MediaStore deletion, expired grants, recursive-folder limits—are surfaced.
- Viewing large images/video/audio uses a random token and range-capable streamed path within the trusted WebView; a third-party page cannot guess a token.

## Android applications

`PackageManager` discovers launcher activities exposed by Android. KK DEX shows real labels, package names and icons and calls the actual launch intent.

When an external display exists, KK DEX first requests `ActivityOptions.setLaunchDisplayId` and reports that Android accepted the request. Android may ignore it or the target app may force itself to the phone. In that case the fallback is a normal phone launch and an explicit message. The UI never claims an app appeared on the TV when it did not.

## Terminal

The native backend starts `/system/bin/sh -c <command>` as the **application UID** in the app sandbox. It captures real stdout/stderr, exit code, timeout, and output size. It is not root, not Android `su`, and cannot bypass scoped storage.

Runtime detection probes `python3`, `python`, `node`, `git`, `toybox` and `unzip` and reports paths/versions only when executable. No language runtime is bundled. To use Python/Node/Git, the device must already make those executables available to this app. A future extension can bundle a runtime or integrate a terminal emulator/native library; that is not claimed today.

## Downloads and browser

The desktop WebView has a real `DownloadListener` backed by Android `DownloadManager`, saved under Android's public Downloads directory. The Downloads application queries and opens real DownloadManager entries. HTTP(S) downloads are supported; `blob:`/`data:` links cannot always be captured by WebView's DownloadListener and are reported as a limitation.

The Browser uses a sandboxed iframe for actual web content. Many sites refuse framing. The “open in system browser” action uses an Android `ACTION_VIEW` handler and is a real fallback.

## Physical test checklist

These require the target phone and TV. They are **not reported as executed** in this environment.

| Test | Status |
| --- | --- |
| Install APK on device | Not run — no device available |
| Connect HDMI/USB-C/TV presentation display | Not run |
| Desktop fills the TV | Not run on hardware; responsive browser tests pass |
| Phone controller controls TV pointer | Native path compiled; not run on hardware |
| Disconnect/reconnect TV | Lifecycle implemented; not run on hardware |
| Open native SAF folder picker | Implemented; not run on hardware |
| Persist folder permission across app restart | Implemented; not run on hardware |
| Display picture via ContentResolver | Implemented; browser bridge fixture test passes |
| Play video/audio from content URI | Implemented; hardware codec matrix not tested |
| Render PDF with PdfRenderer | Implemented; fixture test passes |
| Create/rename/delete/copy/move | Implemented through provider APIs; provider matrix not tested |
| Discover installed apps and icons | Implemented; fixture test passes |
| Launch app on TV and report routing | Implemented; actual app/device behavior varies |
| Native shell command | Implemented; not run on hardware |
| Python/Node/Git availability | Detected at runtime; not bundled |
| Browser download via DownloadManager | Implemented; not run on hardware |
| MediaStore permissions Android 13/14 | Request flow compiles/lints; not run on hardware |

Before deploying, run these on the target device and record provider/app/TV behavior. Do not treat an unimplemented hardware path as tested.
