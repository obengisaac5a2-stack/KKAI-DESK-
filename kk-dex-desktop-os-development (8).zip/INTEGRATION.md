# KK DEX Integration Contract

## Surfaces

| Surface | URL | Android WebView |
| --- | --- | --- |
| External desktop | `https://appassets.androidplatform.net/assets/kkdex/index.html` | WebView inside `DesktopPresentation` on the TV/monitor display |
| Phone controller | `https://appassets.androidplatform.net/assets/kkdex/index.html?controller` | MainActivity WebView on the phone |

These WebViews are independent. The controller screen is not a mirrored desktop. Assets are served by AndroidX `WebViewAssetLoader` from `android/app/src/main/assets/kkdex/`.

## Existing JavaScript compatibility bridge

The original desktop input API remains available and existing methods are never overwritten:

`movePointer`, `pointerDown`, `pointerUp`, `pointerClick`, `pointerDoubleClick`, `pointerRightClick`, `scrollDesktop`, `insertText`, `pressKey`, `getState`, `openApp`, `setTheme`, `setWallpaper`.

The typed current implementation is also exposed as `window.KKDexDesktop`. The adapter preserves any pre-existing `window.KKDexAPI` methods, including a read-only native object. `getState()` reports the actual viewport, windows, active app, pointer, theme, wallpaper and connected native capabilities.

Pointer coordinates are CSS pixels inside the current desktop WebView. Relative movement is supported as:

```js
window.KKDexDesktop.movePointer(dx, dy, true)
window.KKDexDesktop.movePointer({ dx, dy })
```

The input path dispatches real hit-tested DOM pointer, mouse, click, context menu, wheel, keyboard, input and selection events. A small visual cursor is shown only after remote movement. It disappears when a physical mouse moves.

## Native bridge

The Android host attaches an origin-allowlisted WebKit message object named:

`window.KKDexNative`

The only allowed origin is `https://appassets.androidplatform.net`. The listener rejects subframes and remote origins. No `addJavascriptInterface` bridge is registered.

`src/android/native.ts` installs:

- `window.KKDexHost.call(method, args)` → Promise
- `window.KKDexControllerBridge.sendInput(json)` → native relay to the desktop WebView
- `window.KKDexServices` adapters for actual shell, system browser, volume and storage
- `window.KKDexNativeEvents` callbacks for display status and native messages
- `window.KKDexAndroidNavigation.openFolder(root)` for controller-to-desktop folder transfer

Wire messages use:

```json
{ "id": "unique-request-id", "method": "methodName", "args": {} }
```

Native replies:

```json
{ "id": "unique-request-id", "ok": true, "data": {} }
{ "id": "unique-request-id", "ok": false, "error": "Human-readable Android error", "code": "ERROR_CODE" }
```

Missing native bridge, denied permissions, cancelled pickers, expired grants, unavailable viewers, missing files and unsupported operations are explicit errors. They are never converted into fake successful results.

## Desktop methods

| Method | Behavior |
| --- | --- |
| `ping` | Bridge version and role |
| `displayStatus` | Actual external display dimensions, name, ID, density and presentation state |
| `pickFiles(mime)` | Android `ACTION_OPEN_DOCUMENT`, multiple real files |
| `pickFolder()` | Android `ACTION_OPEN_DOCUMENT_TREE`, retains permission |
| `listRoots()` | Persisted authorized trees plus available MediaStore roots |
| `listDirectory(treeUri, documentUri?)` | Real provider child-document listing |
| `readFile(uri)` | Real content bytes, base64, 50 MB maximum |
| `writeFile(uri, base64)` | Writes to an Android-authorized document |
| `createDirectory(treeUri, parentUri, name)` | Provider document creation |
| `renameDocument(treeUri, uri, name)` | Provider rename |
| `deleteDocument(treeUri, uri)` | Provider deletion after UI confirmation |
| `copyDocument` / `moveDocument` | Create destination and copy real bytes; optional source delete |
| `exportExistingFile` / `exportFile` | Android `ACTION_CREATE_DOCUMENT` |
| `contentUrl(uri, mime)` | Random-token, same-origin, range-capable stream URL |
| `openDocument(uri, mime)` | Explicit Android viewer request with routing result |
| `openUrl(url)` | Real system browser intent |
| `getInstalledApps()` | PackageManager launcher activities and icons |
| `launchApp(packageName, preferExternal)` | Real intent with external-display request and honest fallback |
| `getDownloads()` / `openDownload(id)` | Real Android DownloadManager entries |
| `getSystemInfo()` | Build, WebView, storage, display and runtime data |
| `setVolume(percent)` / `getVolume()` | Actual Android media volume |
| `runCommand(command)` | Real `/system/bin/sh` app-sandbox execution |
| `requestMediaPermissions()` | Android 13/14 image/video/audio/partial-visual grants |
| `pdfInfo(uri)` / `pdfRenderPage(uri,page,width)` | Android PdfRenderer, real page images |
| `openSystemSettings()` | Android Settings |
| `controllerInput(message)` | Controller-only; relays validated input to the desktop |

## Controller input allowlist

The controller role may call only:

`ping`, `displayStatus`, `controllerInput`, `setVolume`, `getVolume`, `getInstalledApps`, `launchApp`, `chooseFolderForDesktop`, `openUrl`.

Controller input messages are parsed and rewritten to an allowlisted JSON shape before being injected:

```json
{ "type": "movePointer", "dx": 12, "dy": -4, "relative": true }
{ "type": "pointerDown", "button": 0 }
{ "type": "pointerUp", "button": 0 }
{ "type": "pointerClick" }
{ "type": "pointerDoubleClick" }
{ "type": "pointerRightClick" }
{ "type": "scrollDesktop", "dx": 0, "dy": 38 }
{ "type": "insertText", "text": "Hello" }
{ "type": "pressKey", "key": "e", "modifiers": { "meta": true } }
```

The native bridge posts an equivalent `kkdex:input` CustomEvent into the desktop WebView. Remote input never gains native file-system methods on the phone controller surface.

## File and content security

- Android accepts only `content://` document/media URIs.
- JavaScript never supplies raw `/sdcard` paths.
- The OS enforces persisted picker grants. `takePersistableUriPermission` failure is reported and the tree is not claimed as persistently available.
- Large media is streamed through a random token path under the trusted asset origin. Tokens can only be created through the native bridge.
- HTTP Range requests are supported for video/audio.
- `file://`, universal file access, content auto-access, third-party cookies and mixed content are disabled.
- Remote/non-asset main-frame navigation is handed to Android; the trusted desktop page is not replaced.
- Debug builds enable WebView inspection; release builds do not.
- Backups and Android data extraction exclude app data.

## WebView integration requirements

Keep the existing Android external-display lifecycle if one exists. This repository supplies a complete replacement host because no Android source was present in the initial project.

Requirements:

1. Build the web assets: `npm run build`.
2. Sync: `node scripts/sync-android-assets.mjs`.
3. Keep the complete asset directory, including `wallpaper-*.jpg` and `inter-latin.woff2`.
4. Use HTTPS `WebViewAssetLoader` for the trusted local origin.
5. Do not enable universal file access.
6. Do not add the native bridge to an internet-content WebView.
7. Keep the phone controller and external desktop WebViews separate.
8. Verify external display support on the target hardware.

## Optional/native-dependent behavior

- AI backend connectivity is not bundled. KK AI remains unavailable until a genuine service is adapted.
- Native permission to read all internal storage is intentionally absent. SAF and MediaStore are the legitimate Android paths.
- Many apps cannot launch on a secondary display. The result message distinguishes an accepted external launch request from a phone fallback.
- Python/Node/Git are not bundled. The shell backend detects and reports only real executables.
- MediaStore mutation may require a separate system consent flow on newer Android versions; SAF operations are the primary supported document path.
- Recursive folder copy and root-level system file access are not offered.

See [ANDROID.md](./ANDROID.md) and [TESTING.md](./TESTING.md).
