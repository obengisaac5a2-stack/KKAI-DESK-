import { cpSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { resolve } from "node:path";

const source = resolve("dist");
const target = resolve("android/app/src/main/assets/kkdex");
if (!existsSync(source)) {
  console.error("dist/ does not exist. Run `npm run build` before syncing Android assets.");
  process.exit(1);
}
rmSync(target, { recursive: true, force: true });
mkdirSync(target, { recursive: true });
cpSync(source, target, { recursive: true });
console.log(`Copied ${source} -> ${target}`);
