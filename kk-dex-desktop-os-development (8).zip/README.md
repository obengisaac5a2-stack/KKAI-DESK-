# KK DEX

KK DEX is a two-surface Android desktop environment:

- **Television/monitor:** the actual floating-window desktop, rendered by a WebView inside an Android `Presentation` attached to the external display.
- **Phone:** a separate touchpad, keyboard, volume, installed-app and Storage Access Framework controller. The phone WebView never displays the desktop.

This repository contains the React desktop/controller frontend, the Kotlin Android host, the native bridge, the Gradle project, tests, build automation, and a successfully built debug APK.

## Built APK

- **File:** `deliverables/kkdex-debug.apk`
- **Package:** `com.kkdex.desktop`
- **Version:** `1.0.0` (`versionCode` 1)
- **Minimum Android:** 8.0 / API 26
- **Target/compile SDK:** 35
- **Signature:** Android debug certificate, installable for device testing. It is not a production-signed release.
- **Checksum:** `deliverables/kkdex-debug.apk.sha256`

The APK was compiled in this environment with JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3 and Gradle 8.9. See [TESTING.md](./TESTING.md) for the actual build, lint and test records.

## Run the web surfaces

```bash
npm install
npm run dev
```

- Desktop: `http://localhost:5173/`
- Phone controller: `http://localhost:5173/?controller`

The browser has no Android permissions. Android-only applications clearly report that they are unavailable and never fabricate storage, application, shell or hardware results.

## Build the Android APK

```bash
npm ci
npm run build
node scripts/sync-android-assets.mjs
cd android
./gradlew :app:assembleDebug
```

Output:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

The [APK workflow](./.github/workflows/android.yml) performs the complete web build, asset sync, Android SDK setup, debug APK build, lint, APK existence check and artifact upload. See [ANDROID.md](./ANDROID.md) for installation and device requirements.

## Source layout

| Path | Purpose |
| --- | --- |
| `src/` | React desktop, phone controller, applications, windows, taskbar and native service adapter |
| `src/android/native.ts` | Typed adapter for the trusted `KKDexNative` WebMessage bridge |
| `src/apps/AndroidApps.tsx` | SAF file manager, Android text editor, media and PDF viewers, downloads, system information, app manager and archive manager |
| `android/` | Complete Android Studio/Gradle project |
| `android/app/src/main/java/com/kkdex/desktop/MainActivity.kt` | Phone controller activity, external-display discovery, picker and permission plumbing |
| `android/.../DesktopPresentation.kt` | TV presentation and independent desktop WebView |
| `android/.../NativeBridge.kt` | Origin-isolated WebMessage bridge and command allowlist |
| `android/.../StorageController.kt` | Persisted SAF grants, MediaStore and real document operations |
| `android/.../AndroidAppLauncher.kt` | Installed launcher activities and external-display launch attempts |
| `android/.../DownloadController.kt` | Android DownloadManager integration |
| `android/.../TerminalController.kt` | Real app-sandbox shell execution and runtime detection |
| `android/.../PdfController.kt` | Android PdfRenderer pages |
| `tests/` | Real browser interaction tests and native-adapter fixture tests |
| `deliverables/` | Built, signed debug APK and checksum |

## Implemented applications

Files, Android Storage, Browser, Text Editor, Image Viewer, Video Player, Music Player, PDF Viewer, Downloads, Settings, System Information, Android Apps, Notes, Calculator, Terminal, Archive Manager, App Center, KK AI and Recycle Bin.

Android applications open in independent desktop windows. Multiple windows can be dragged, resized, minimized, maximized, restored, snapped and switched from the taskbar. Desktop window state is persisted and restored after the TV WebView is recreated.

## Security model

- No `addJavascriptInterface`.
- AndroidX WebKit `WebMessage` listener allowlisted to the local `https://appassets.androidplatform.net` origin.
- Remote web content and third-party iframes do not receive the native bridge.
- JavaScript cannot submit raw filesystem paths. File access is restricted to persisted `content://` grants, picker results and MediaStore collections.
- The phone controller has a separate, smaller bridge method allowlist.
- `file://` and universal file access are disabled.
- Backups are disabled and Android data extraction excludes app data.
- Native errors are returned to JavaScript and shown; there is no simulated success.

## Important limitations

- A physical Android device, TV/monitor and controller were **not available in this build environment**. APK construction and lint were verified, but physical display/compatibility testing is still required.
- External display support depends on the device. The Android `Presentation` API works only when the device exposes a secondary presentation display (for example USB-C DisplayPort/HDMI phones, desktop modes such as Samsung DeX, or supported casting routes). KK DEX does not claim that every phone can do this, and it does not mirror the phone UI.
- Internal storage access follows Android scoped storage. Unrestricted access to all files is intentionally not requested. Users authorize folders/files through SAF. MediaStore is used only when the matching Android permission is granted.
- Rename, delete, move and copy are supported where the document provider allows them. Unsupported provider or MediaStore mutations display the real error. Recursive folder copy is not implemented by the provider bridge.
- Many Android applications ignore external-display launches. The UI reports whether Android accepted the external request or fell back to the phone.
- The terminal is a genuine non-root shell in the KK DEX app sandbox. Python, Node.js and Git work only if their executables are actually available to that sandbox. None are bundled.
- Embedded browser pages can refuse framing. KK DEX reports this and offers a genuine system-browser action. Input inside cross-origin iframe content cannot be controlled by the parent desktop.
- AI requires a real backend adapter; none is bundled or implied.
- Debug APK signing is for testing, not Play Store distribution.

Detailed architecture, permissions, device test checklist and known limits: [ANDROID.md](./ANDROID.md). Bridge contract: [INTEGRATION.md](./INTEGRATION.md). Test record: [TESTING.md](./TESTING.md).
