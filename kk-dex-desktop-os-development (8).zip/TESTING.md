# KK DEX Verification Record

Last verified in this build environment: 2026-11-13.

## What was actually built

- Frontend: `npm run build` succeeded.
- Strict TypeScript: `npx tsc --noEmit` succeeded.
- Android Kotlin compilation: `./gradlew :app:assembleDebug` succeeded.
- Android Lint: `./gradlew :app:lintDebug` succeeded with **0 errors** and 15 non-blocking warnings.
- APK produced and copied to `deliverables/kkdex-debug.apk`.
- APK size: approximately 4.9 MB.
- APK SHA-256: `719cdef463b050448f04f6f9f0b2c9316bdc8740fe27b2b3160b9331021962cb`.
- Package: `com.kkdex.desktop`, versionCode 1, versionName 1.0.0, minSdk 26, target/compileSdk 35.
- APK signature verification: v2 signature valid, signed by the Android debug certificate.
- Packaged asset inspection confirmed `index.html`, Inter font, and all three local wallpapers.

## Browser and native-adapter tests

Automated Playwright suite: **48 passed, 0 failed, 0 skipped** at the final run before the last documentation-only change.

Covered:

- Desktop fills the viewport; icons are SVG; no page scroll at 16:9.
- Single/double/right click, drag selection, grid-safe persistent icon positions.
- Multi-window app launch, focus, stacking, titlebar drag, eight-way resize, minimize, taskbar restore, maximize, restore, close, snapping, double-click titlebar.
- Taskbar indicators and taskbar/titlebar/desktop/file context menus.
- Start search, app launch, on-outside-click close, shortcut ownership.
- Files navigation, search, actual file import/export, new folder, rename, copy/move, recycle/restore/permanent delete and undo/redo.
- Notes editing/export/persistence; text-size and theme/wallpaper settings with persistence.
- Calculator precedence, percent and divide-by-zero.
- Workspace terminal commands and honest missing native backend behavior.
- Browser tabs/history/reload and real iframe fixture navigation.
- AI no-backend errors and connected backend fixture response.
- Gallery real images, zoom, navigation and export/download.
- Calendar, notifications, task view and quick settings.
- Session restoration of desktop windows after reload/WebView recreation.
- Responsive layouts at 1920×1080, 1440×900, 1280×720, 1024×768, 800×600.
- Pointer, keyboard, selection, undo/redo and window drag through `KKDexDesktop`/`KKDexAPI`.
- Existing/read-only `KKDexAPI` object preservation.
- Phone controller remains independent; real click/double-click/relative movement messages and unavailable-transport errors.
- Native bridge absence: Android-only apps show explicit unavailable states and no fake results.
- Mock native-adapter fixtures: SAF folder list, Android image/text/video metadata, file open, Android text read/save, read failure, installed app discovery/launch routing, actual display/system fields, PDF page rendering, DownloadManager list, shell output, real ZIP archive listing/extraction, controller folder transfer/app launch, media and storage volume.
- Storage quota failure remains visible and is never labelled as saved.

The native-adapter tests use a controlled in-browser fixture implementing the documented message protocol. They verify frontend handling and error transparency; they are **not** evidence that Android hardware storage or a physical TV was tested.

## Android build/lint record

Commands used:

```bash
export ANDROID_HOME="$HOME/android-sdk"
export JAVA_HOME=<JDK 17>
cd android
./gradlew :app:lintDebug :app:assembleDebug
```

Observed:

- `:app:compileDebugKotlin` successful.
- `:app:lintDebug` successful after fixing API-26 resource and URI-grant lint errors.
- `:app:assembleDebug` successful.
- APK `aapt` package metadata, min/target SDK and permissions inspected.
- `apksigner verify` reports a valid v2 signature.
- APK ZIP contains the synchronized web assets.

Lint warnings are non-blocking and include expected JavaScript-enabled WebView scanning, optional newer dependency notices, and standard deprecation warnings. They were not hidden; the full report is generated at `android/app/build/reports/lint-results-debug.html`.

## Physical device tests

No Android device, external TV/monitor, HDMI/DisplayPort adapter or Android controller hardware was available in this environment. Therefore the following are **not reported as tested**:

- Installation/launch on a physical Android device.
- Actual TV presentation display discovery or full-screen rendering on hardware.
- Physical touchpad → native bridge → TV pointer behavior.
- Display disconnect/reconnect on hardware.
- SAF picker return/persistence across a real device reboot.
- Real picture/video/audio codec playback through a content URI.
- Real provider-specific create/rename/delete/copy/move behavior.
- Actual Android installed-app discovery with manufacturer package visibility.
- Whether a target Android app honors external-display launching.
- Actual shell availability and Python/Node/Git on the device.
- DownloadManager write and notification behavior on each Android version.
- Browser download capture from real third-party sites.

These are implementation-complete where noted but must be verified on the target device before claiming hardware success. See the checklist in [ANDROID.md](./ANDROID.md).

## Definition of accepted limitations

KK DEX does not claim:

- Root or unrestricted filesystem access.
- Access to files that the user has not authorized or Android does not expose.
- Successful deletes where a provider refuses.
- That every Android phone supports a secondary presentation display.
- That every Android app can run on TV.
- That Python/Node/Git are bundled.
- That all websites allow iframe embedding.
- That downloaded browser `blob:` links can always be intercepted.
- That physical device behavior has been tested here.
