import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto('http://127.0.0.1:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(600);
// empty desktop context menu
await page.mouse.click(1180, 620, { button: 'right' });
await page.waitForTimeout(400);
console.log('desktop context menu visible:', await page.getByRole('menu').isVisible());
console.log('menu items:', (await page.getByRole('menuitem').allInnerTexts().catch(()=>[])).join('|').slice(0,120));
await page.screenshot({ path: '/tmp/qa-menu.png' });
await page.keyboard.press('Escape');
// open Files, Settings, Browser, AI
await page.locator('[aria-label="Files"]').first().dblclick();
await page.waitForTimeout(500);
await page.locator('[aria-label="Settings"]').first().dblclick();
await page.waitForTimeout(500);
await page.locator('[aria-label="Browser"]').first().dblclick();
await page.waitForTimeout(900);
await page.locator('[aria-label="KK AI"]').first().dblclick();
await page.waitForTimeout(600);
await page.screenshot({ path: '/tmp/qa-multi.png' });
// Files internal operations
const files = page.locator('[aria-label="Files window"]');
await page.locator('footer [aria-label="Files"]').click();
await page.waitForTimeout(300);
await files.getByText('Documents').first().click();
await page.waitForTimeout(300);
console.log('documents files:', await files.getByText('Project brief.md').count());
await files.getByText('Project brief.md').first().click();
await page.screenshot({ path: '/tmp/qa-files.png' });
// taskbar context menu
await page.locator('footer [aria-label="Files"]').click({ button: 'right' });
await page.waitForTimeout(300);
console.log('taskbar context menu title:', await page.getByRole('menu').innerText().catch(()=>'none'));
await page.keyboard.press('Escape');
// settings interactions: theme light
await page.locator('footer [aria-label="Settings"]').click();
await page.waitForTimeout(300);
const settingsWin = page.locator('[aria-label="Settings window"]');
await settingsWin.getByText('Display', { exact: true }).first().click();
await page.waitForTimeout(300);
await settingsWin.getByText('Keyboard', { exact: true }).first().click();
await page.waitForTimeout(200);
await page.screenshot({ path: '/tmp/qa-settings.png' });
// AI interaction
await page.locator('footer [aria-label="KK AI"]').click();
await page.waitForTimeout(300);
const aiWin = page.locator('[aria-label="KK AI window"]');
await aiWin.getByText('Show my workspace summary').click();
await page.waitForTimeout(1400);
console.log('AI responded:', await aiWin.getByText('Workspace summary').count());
await page.screenshot({ path: '/tmp/qa-ai.png' });
// terminal
await page.evaluate(() => window.KKDexAPI.openApp('terminal'));
await page.waitForTimeout(500);
const term = page.locator('[aria-label="Terminal window"]');
await term.locator('input').fill('help');
await term.locator('input').press('Enter');
await page.waitForTimeout(400);
console.log('terminal help:', await term.getByText('Available commands:').count());
await page.screenshot({ path: '/tmp/qa-terminal.png' });
// bridge API
const state = await page.evaluate(() => window.KKDexAPI.getState());
console.log('bridge state:', state.ready, state.resolution?.width, state.windows?.length);
const moved = await page.evaluate(() => { window.KKDexAPI.movePointer(400,400); window.KKDexAPI.pointerClick(); return window.KKDexAPI.getState().pointer; });
console.log('bridge pointer:', JSON.stringify(moved));
const theme = await page.evaluate(() => window.KKDexAPI.setTheme('light'));
console.log('setTheme ok:', theme, await page.evaluate(() => document.documentElement.dataset.theme));
console.log('ERRORS:', JSON.stringify(errors));
await browser.close();
