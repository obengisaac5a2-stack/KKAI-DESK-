import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errs=[]; page.on('pageerror', e=>errs.push(e.message));
await page.goto('http://127.0.0.1:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(500);
// open windows via bridge so we get deterministic positions
await page.evaluate(() => { window.KKDexAPI.openApp('files'); window.KKDexAPI.openApp('browser'); window.KKDexAPI.openApp('settings'); });
await page.waitForTimeout(1200);
await page.screenshot({ path: '/tmp/multi2.png' });
// light theme + dunes
await page.evaluate(() => { window.KKDexAPI.setTheme('light'); window.KKDexAPI.setWallpaper('dunes'); });
await page.waitForTimeout(700);
await page.screenshot({ path: '/tmp/light.png' });
console.log('theme', await page.evaluate(()=>document.documentElement.dataset.theme), 'errs', errs.length);
// smaller desktop
await page.setViewportSize({ width: 1024, height: 768 });
await page.waitForTimeout(600);
await page.screenshot({ path: '/tmp/small.png' });
console.log('windows within viewport:', await page.evaluate(()=> {
  return [...document.querySelectorAll('.os-window')].map(w=>{const r=w.getBoundingClientRect();return {x:Math.round(r.x),y:Math.round(r.y),r:Math.round(r.right),b:Math.round(r.bottom),vw:innerWidth,vh:innerHeight};});
}));
await browser.close();
