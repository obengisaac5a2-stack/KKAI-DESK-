import { chromium } from 'playwright';
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const desktop = await context.newPage();
const errs=[]; desktop.on('pageerror', e=>errs.push(e.message));
await desktop.goto('http://127.0.0.1:4173/?desktop=1', { waitUntil: 'networkidle' });
await desktop.waitForTimeout(700);

// open Notes and focus title input
await desktop.evaluate(() => window.KKDexAPI.openApp('notes'));
await desktop.waitForTimeout(600);
const notes = desktop.locator('[aria-label="Notes window"]');
await notes.locator('input[placeholder="Note title"]').click();
await desktop.waitForTimeout(200);

const controller = await context.newPage();
await controller.setViewportSize({ width: 430, height: 900 });
await controller.goto('http://127.0.0.1:4173/?controller=1', { waitUntil: 'networkidle' });
await controller.waitForTimeout(1500);
console.log('controller linked:', await controller.getByText('Linked to TV').count() > 0);

// move pointer and click via controller touchpad, then send text through keyboard UI
const pad = controller.locator('[aria-label^="Touchpad"]');
const pb = await pad.boundingBox();
await controller.mouse.move(pb.x + pb.width/2, pb.y + pb.height/2);
await controller.mouse.down();
await controller.mouse.move(pb.x + pb.width/2 + 30, pb.y + pb.height/2 + 20, { steps: 8 });
await controller.mouse.up();
await controller.waitForTimeout(400);
console.log('pointer moved on desktop:', await desktop.evaluate(()=>window.KKDexAPI.getState().pointer.visible));

// keyboard: live type sends insertText to focused desktop input
await controller.locator('nav button').filter({ hasText: 'Keyboard' }).click();
await controller.waitForTimeout(300);
await controller.getByRole('button', { name: 'Send manually' }).click();
await controller.locator('textarea').fill('Controller note');
await controller.getByRole('button', { name: 'Send to TV' }).click();
await controller.waitForTimeout(600);
console.log('desktop title value:', await notes.locator('input[placeholder="Note title"]').inputValue());

// launch from controller
await controller.locator('nav button').filter({ hasText: 'Apps' }).click();
await controller.waitForTimeout(300);
await controller.locator('button').filter({ hasText: 'Calculator' }).click();
await controller.waitForTimeout(700);
console.log('desktop windows now:', await desktop.locator('.os-window').count());
await controller.screenshot({ path: '/tmp/qa-controller-linked.png' });
console.log('desktop windows state from bridge:', await desktop.evaluate(()=>window.KKDexAPI.getState().windows));
console.log('errors:', errs);
await browser.close();
