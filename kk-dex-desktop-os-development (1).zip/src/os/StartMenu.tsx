import { useEffect, useMemo, useRef, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  CircleUserRound,
  Command,
  Lock,
  Monitor,
  Moon,
  Power,
  RotateCcw,
  Search,
  Settings,
  UserRound,
  X,
} from "lucide-react";
import { ALL_APP_IDS, APP_METAS, DESKTOP_APPS } from "./appMeta";
import { AppIcon } from "./icons";
import { useOS } from "./OSContext";
import type { AppId } from "./types";
import { cn } from "@/utils/cn";

const QUICK_SETTINGS = [
  { label: "Display settings", section: "display" },
  { label: "Personalization", section: "personalization" },
  { label: "Sound settings", section: "sound" },
  { label: "About KK DEX", section: "system" },
];

export function StartMenu() {
  const {
    startOpen,
    setStartOpen,
    startQuery,
    setStartQuery,
    launch,
    launchHistory,
    lock,
    restartDesktop,
    showInfo,
    setTaskViewOpen,
  } = useOS();
  const [allApps, setAllApps] = useState(false);
  const [powerOpen, setPowerOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (startOpen) {
      setAllApps(false);
      setPowerOpen(false);
      window.setTimeout(() => searchRef.current?.focus(), 50);
    }
  }, [startOpen]);

  useEffect(() => {
    if (!startOpen) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        setStartOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [startOpen, setStartOpen]);

  const filteredApps = useMemo(() => {
    const q = startQuery.trim().toLowerCase();
    if (!q) return [];
    return ALL_APP_IDS.filter((id) => {
      const meta = APP_METAS[id];
      return (
        meta.name.toLowerCase().includes(q) ||
        meta.description.toLowerCase().includes(q) ||
        meta.category.toLowerCase().includes(q) ||
        meta.keywords?.some((keyword) => keyword.includes(q))
      );
    });
  }, [startQuery]);

  const filteredSettings = useMemo(() => {
    const q = startQuery.trim().toLowerCase();
    if (!q) return [];
    return QUICK_SETTINGS.filter((item) => item.label.toLowerCase().includes(q));
  }, [startQuery]);

  const recentIds = useMemo(() => {
    const unique = Array.from(new Set(launchHistory)).filter((id) => ALL_APP_IDS.includes(id));
    const base = unique.length ? unique : (["files", "browser", "notes", "settings"] as AppId[]);
    return base.slice(0, 4);
  }, [launchHistory]);

  if (!startOpen) return null;

  const openApp = (id: AppId) => launch(id);

  const pinned = DESKTOP_APPS;
  const query = startQuery.trim();

  return (
    <div
      ref={panelRef}
      className="start-anim fixed z-[9100] flex flex-col overflow-hidden rounded-xl"
      style={{
        bottom: "calc(var(--taskbar-h) + 8px)",
        left: "50%",
        transform: "translateX(-50%)",
        width: "min(648px, calc(100vw - 20px))",
        height: "min(610px, calc(100vh - var(--taskbar-h) - 22px))",
        background: "var(--surface)",
        border: "1px solid var(--border-strong)",
        boxShadow: "var(--shadow-menu)",
        backdropFilter: "blur(34px) saturate(1.45)",
      }}
      role="dialog"
      aria-label="Start menu"
      onContextMenu={(event) => event.preventDefault()}
    >
      <div className="shrink-0 px-4 pt-4 pb-2.5">
        <div className="flex items-center gap-2 rounded-lg px-2.5" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
          <Search size={14} style={{ color: "var(--accent)" }} />
          <input
            ref={searchRef}
            value={startQuery}
            onChange={(event) => setStartQuery(event.target.value)}
            placeholder="Search apps, settings and files"
            className="h-9 min-w-0 flex-1 border-0 bg-transparent text-[11.5px] outline-none placeholder:text-[var(--faint)]"
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                if (filteredApps[0]) launch(filteredApps[0]);
                else if (filteredSettings[0]) launch("settings", { payload: { section: filteredSettings[0].section } });
              }
            }}
          />
          {startQuery ? (
            <button className="icon-btn h-6 w-6" aria-label="Clear search" onClick={() => setStartQuery("")}><X size={12} /></button>
          ) : (
            <span className="hidden items-center gap-1 sm:flex">
              <span className="badge">Ctrl K</span>
            </span>
          )}
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4">
        {query ? (
          <div className="fade-in pb-3">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Search results</span>
              <span className="text-[8.5px]" style={{ color: "var(--faint)" }}>{filteredApps.length + filteredSettings.length} results</span>
            </div>
            {filteredApps.length + filteredSettings.length === 0 ? (
              <div className="py-10 text-center">
                <Search size={24} className="mx-auto mb-2" style={{ color: "var(--faint)" }} />
                <div className="text-[12px] font-medium">No results for “{startQuery}”</div>
                <div className="mt-1 text-[10px]" style={{ color: "var(--muted)" }}>Search application names, categories or settings.</div>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-0.5 sm:grid-cols-2">
                {filteredApps.map((id) => (
                  <button key={id} className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-left row-hover" onClick={() => openApp(id)}>
                    <AppIcon id={id} size={30} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[11px] font-medium">{APP_METAS[id].name}</div>
                      <div className="truncate text-[9px]" style={{ color: "var(--muted)" }}>{APP_METAS[id].description}</div>
                    </div>
                    <ChevronRight size={12} style={{ color: "var(--faint)" }} />
                  </button>
                ))}
                {filteredSettings.map((item) => (
                  <button key={item.label} className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-left row-hover" onClick={() => launch("settings", { payload: { section: item.section } })}>
                    <div className="flex h-[30px] w-[30px] items-center justify-center rounded-lg" style={{ background: "var(--field)", color: "var(--muted)" }}><Settings size={15} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[11px] font-medium">{item.label}</div>
                      <div className="truncate text-[9px]" style={{ color: "var(--muted)" }}>Settings</div>
                    </div>
                    <ChevronRight size={12} style={{ color: "var(--faint)" }} />
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : allApps ? (
          <div className="fade-in pb-3">
            <div className="mb-2 flex items-center gap-2">
              <button className="icon-btn h-7 w-7" onClick={() => setAllApps(false)} aria-label="Back to Start"><ChevronLeft size={14} /></button>
              <div className="text-[11px] font-semibold">All applications</div>
              <span className="ml-auto text-[8.5px]" style={{ color: "var(--faint)" }}>{ALL_APP_IDS.length} installed</span>
            </div>
            <div className="grid grid-cols-2 gap-0.5">
              {ALL_APP_IDS.slice().sort((a, b) => APP_METAS[a].name.localeCompare(APP_METAS[b].name)).map((id) => (
                <button key={id} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left row-hover" onClick={() => openApp(id)}>
                  <AppIcon id={id} size={25} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[10.5px]">{APP_METAS[id].name}</div>
                    <div className="truncate text-[8.5px]" style={{ color: "var(--faint)" }}>{APP_METAS[id].category}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="fade-in">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Pinned</span>
              <button className="flex items-center gap-0.5 rounded px-1.5 py-0.5 text-[9.5px] hover:bg-[var(--hover)]" style={{ color: "var(--muted)" }} onClick={() => setAllApps(true)}>
                All apps <ChevronRight size={10} />
              </button>
            </div>
            <div className="grid grid-cols-6 gap-1">
              {pinned.map((id) => (
                <button key={id} className="flex flex-col items-center gap-1.5 rounded-lg px-1 py-2 transition-colors hover:bg-[var(--hover)]" onClick={() => openApp(id)} title={APP_METAS[id].name}>
                  <AppIcon id={id} size={34} />
                  <span className="line-clamp-2 min-h-[22px] text-center text-[9px] leading-[1.15]" style={{ color: "var(--text)" }}>{APP_METAS[id].name}</span>
                </button>
              ))}
            </div>
            <div className="my-3 h-px" style={{ background: "var(--border)" }} />
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Recommended</span>
              <button className="text-[9px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => launch("files", { payload: { folderId: "desktop" } })}>More</button>
            </div>
            <div className="grid grid-cols-2 gap-1">
              {recentIds.map((id) => (
                <button key={id} className="flex items-center gap-2 rounded-lg p-1.5 text-left row-hover" onClick={() => openApp(id)}>
                  <AppIcon id={id} size={29} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[10px] font-medium">{APP_METAS[id].name}</div>
                    <div className="truncate text-[8.5px]" style={{ color: "var(--muted)" }}>Recently opened · {APP_METAS[id].category}</div>
                  </div>
                </button>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-2 rounded-lg p-2" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
              <div className="flex h-6 w-6 items-center justify-center rounded-md" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><Command size={12} /></div>
              <div className="text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>
                Tip: use <span className="kbd">Win</span> to open Start and <span className="kbd">Alt</span> + <span className="kbd">Tab</span> to switch windows.
              </div>
              <button className="ml-auto text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setTaskViewOpen(true)}>Task view</button>
            </div>
          </div>
        )}
      </div>

      <div className="relative flex h-11 shrink-0 items-center gap-2 px-3" style={{ borderTop: "1px solid var(--border)", background: "var(--titlebar)" }}>
        <button
          className="flex items-center gap-2 rounded-md px-1.5 py-1 text-left hover:bg-[var(--hover)]"
          onClick={() => launch("thispc")}
        >
          <span className="flex h-6 w-6 items-center justify-center rounded-full" style={{ background: "linear-gradient(145deg,#4f8cff,#8b7cff)", color: "#fff" }}>
            <CircleUserRound size={15} />
          </span>
          <div className="min-w-0">
            <div className="truncate text-[10px] font-medium">KK DEX Operator</div>
            <div className="truncate text-[8px]" style={{ color: "var(--muted)" }}>Local workspace</div>
          </div>
        </button>
        <div className="ml-auto flex items-center gap-1">
          <button className="icon-btn h-7 w-7" title="Task view" aria-label="Task view" onClick={() => setTaskViewOpen(true)}><Monitor size={13} /></button>
          <button className="icon-btn h-7 w-7" title="Settings" aria-label="Settings" onClick={() => launch("settings")}><Settings size={13} /></button>
          <button className={cn("icon-btn h-7 w-7", powerOpen && "bg-[var(--active)]")} title="Power" aria-label="Power options" onClick={() => setPowerOpen((v) => !v)}><Power size={13} /></button>
        </div>
        {powerOpen ? (
          <div
            className="menu-anim absolute right-2 bottom-10 z-10 w-[176px] rounded-lg p-1"
            style={{ background: "var(--surface)", border: "1px solid var(--border-strong)", boxShadow: "var(--shadow-menu)" }}
          >
            <div className="px-2 pt-1 pb-1.5 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Session</div>
            <button className="menu-item" onClick={() => { setPowerOpen(false); setStartOpen(false); lock(); }}><Lock size={13} /> Lock</button>
            <button className="menu-item" onClick={() => { setPowerOpen(false); setStartOpen(false); restartDesktop(); }}><RotateCcw size={13} /> Restart desktop</button>
            <button className="menu-item" onClick={() => showInfo("Sleep not available", "Sleep and display power are controlled by the Android host's display manager. The web interface cannot put the TV panel to sleep.", <Moon size={22} />)}><Moon size={13} /> Sleep</button>
            <div className="my-1 h-px" style={{ background: "var(--border)" }} />
            <button className="menu-item" onClick={() => showInfo("Signed in locally", "This KK DEX desktop runs a local workspace identity. Account sign-out is managed by the Android host app.", <UserRound size={22} />)}><UserRound size={13} /> Sign out</button>
          </div>
        ) : null}
      </div>
    </div>
  );
}
