import { useRef } from "react";
import { Copy, Minus, Square, X } from "lucide-react";
import { APP_METAS } from "./appMeta";
import { AppIcon } from "./icons";
import { TASKBAR_SPACE, useOS } from "./OSContext";
import { REGISTRY } from "./registry";
import type { WindowState } from "./types";

const MIN_WIDTH_FLOOR = 300;
const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), Math.max(min, max));

export function WindowFrame({ win }: { win: WindowState }) {
  const {
    activeWindow,
    focusWindow,
    closeWindow,
    minimizeWindow,
    toggleMaximize,
    updateWindowRect,
    openMenu,
    snapWindow,
  } = useOS();
  const meta = APP_METAS[win.appId];
  const App = REGISTRY[win.appId].Component;
  const minimized = win.minimized;
  const active = activeWindow?.id === win.id && !minimized;
  const dragState = useRef<{
    mode: "move" | "resize";
    direction?: string;
    startX: number;
    startY: number;
    rect: { x: number; y: number; w: number; h: number };
  } | null>(null);

  const workW = () => window.innerWidth;
  const workH = () => window.innerHeight - TASKBAR_SPACE;

  const attach = (
    event: React.PointerEvent,
    mode: "move" | "resize",
    direction?: string,
  ) => {
    if (event.button !== 0) return;
    const inControl = (event.target as HTMLElement).closest("[data-window-control]");
    if (mode === "move" && (inControl || win.maximized)) return;
    event.preventDefault();
    event.stopPropagation();
    focusWindow(win.id);
    document.body.style.userSelect = "none";
    document.body.style.cursor = mode === "move" ? "grabbing" : `${direction}-resize`;
    dragState.current = {
      mode,
      direction,
      startX: event.clientX,
      startY: event.clientY,
      rect: { x: win.x, y: win.y, w: win.w, h: win.h },
    };

    const move = (moveEvent: PointerEvent) => {
      const state = dragState.current;
      if (!state) return;
      const dx = moveEvent.clientX - state.startX;
      const dy = moveEvent.clientY - state.startY;
      const maxW = workW();
      const maxH = workH();
      if (state.mode === "move") {
        updateWindowRect(win.id, {
          x: clamp(state.rect.x + dx, Math.min(0, maxW - state.rect.w), Math.max(0, maxW - state.rect.w)),
          y: clamp(state.rect.y + dy, 0, Math.max(0, maxH - 42)),
        });
        return;
      }
      const minW = Math.max(MIN_WIDTH_FLOOR, Math.min(meta.minSize[0], maxW));
      const minH = Math.max(220, Math.min(meta.minSize[1], maxH));
      let { x, y, w, h } = state.rect;
      const dir = state.direction ?? "se";
      if (dir.includes("e")) w = clamp(state.rect.w + dx, minW, Math.max(minW, maxW - state.rect.x));
      if (dir.includes("s")) h = clamp(state.rect.h + dy, minH, Math.max(minH, maxH - state.rect.y));
      if (dir.includes("w")) {
        const proposed = clamp(state.rect.w - dx, minW, Math.max(minW, state.rect.x + state.rect.w));
        x = state.rect.x + (state.rect.w - proposed);
        w = proposed;
      }
      if (dir.includes("n")) {
        const proposed = clamp(state.rect.h - dy, minH, Math.max(minH, state.rect.y + state.rect.h));
        y = state.rect.y + (state.rect.h - proposed);
        h = proposed;
      }
      updateWindowRect(win.id, { x: Math.max(0, x), y: Math.max(0, y), w, h });
    };

    const up = () => {
      dragState.current = null;
      document.body.style.userSelect = "";
      document.body.style.cursor = "";
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const titlebarMenu = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    openMenu(event.clientX, event.clientY, [
      ...(win.maximized
        ? [{ label: "Restore", icon: <Copy size={14} />, action: () => toggleMaximize(win.id) }]
        : [{ label: "Maximize", icon: <Square size={14} />, action: () => toggleMaximize(win.id) }]),
      { label: "Minimize", icon: <Minus size={14} />, action: () => minimizeWindow(win.id) },
      { separator: true },
      { label: "Snap left", icon: <Square size={13} />, disabled: win.maximized, action: () => snapWindow(win.id, "left"), shortcut: "Win+←" },
      { label: "Snap right", icon: <Square size={13} />, disabled: win.maximized, action: () => snapWindow(win.id, "right"), shortcut: "Win+→" },
      { separator: true },
      { label: "Close", icon: <X size={14} />, danger: true, shortcut: "Alt+F4", action: () => closeWindow(win.id) },
    ], meta.name);
  };

  return (
    <div
      className={`os-window window-opening pointer-events-auto absolute ${minimized ? "window-minimized" : ""} ${active ? "" : "os-window-inactive"}`}
      style={{
        left: win.x,
        top: win.y,
        width: win.w,
        height: win.h,
        zIndex: win.z,
        borderRadius: win.maximized ? 0 : 10,
        outline: active ? "1px solid rgba(var(--accent-rgb),.28)" : "none",
        outlineOffset: -1,
      }}
      onPointerDown={() => focusWindow(win.id)}
      onContextMenu={(event) => {
        event.preventDefault();
        event.stopPropagation();
      }}
      aria-label={`${meta.name} window`}
      role="dialog"
      aria-modal={false}
    >
      <div
        className="titlebar flex shrink-0 select-none items-center gap-2 pl-2.5"
        onPointerDown={(event) => attach(event, "move")}
        onDoubleClick={(event) => {
          if ((event.target as HTMLElement).closest("[data-window-control]")) return;
          toggleMaximize(win.id);
        }}
        onContextMenu={titlebarMenu}
        style={{ borderRadius: win.maximized ? 0 : "9px 9px 0 0", cursor: win.maximized ? "default" : "grab" }}
      >
        <AppIcon id={win.appId} size={17} />
        <span className={`min-w-0 flex-1 truncate text-[11.5px] font-medium ${active ? "" : "opacity-60"}`}>{meta.name}</span>
        {active ? <span className="mr-1.5 hidden items-center gap-1 text-[8px] sm:flex" style={{ color: "var(--faint)" }}>ACTIVE</span> : null}
        <div className="flex h-full items-stretch" data-window-control>
          <button
            className="flex w-[42px] items-center justify-center transition-colors hover:bg-[var(--hover)]"
            style={{ color: "var(--muted)" }}
            aria-label="Minimize window"
            title="Minimize"
            onClick={() => minimizeWindow(win.id)}
          >
            <Minus size={14} />
          </button>
          <button
            className="flex w-[42px] items-center justify-center transition-colors hover:bg-[var(--hover)]"
            style={{ color: "var(--muted)" }}
            aria-label={win.maximized ? "Restore window" : "Maximize window"}
            title={win.maximized ? "Restore" : "Maximize"}
            onClick={() => toggleMaximize(win.id)}
          >
            {win.maximized ? <Copy size={12} /> : <Square size={11} />}
          </button>
          <button
            className="flex w-[42px] items-center justify-center transition-colors hover:bg-[#e5484d] hover:text-white"
            style={{ color: "var(--muted)", borderRadius: win.maximized ? 0 : "0 9px 0 0" }}
            aria-label="Close window"
            title="Close"
            onClick={() => closeWindow(win.id)}
          >
            <X size={14} />
          </button>
        </div>
      </div>
      <div className="relative min-h-0 flex-1 overflow-hidden" style={{ background: "var(--surface-solid)" }}>
        <App windowId={win.id} payload={win.payload} />
      </div>
      {!win.maximized && !minimized ? (
        <>
          {(["n", "s", "e", "w", "ne", "nw", "se", "sw"] as const).map((direction) => (
            <div
              key={direction}
              className={`resize-handle rh-${direction}`}
              onPointerDown={(event) => attach(event, "resize", direction)}
              style={{ touchAction: "none" }}
            />
          ))}
        </>
      ) : null}
    </div>
  );
}
