import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  BatteryCharging,
  Bell,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Info,
  Lock,
  Monitor,
  Moon,
  Network,
  Smartphone,
  Sun,
  Trash2,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  X,
  Zap,
} from "lucide-react";
import { AppIcon } from "./icons";
import { formatTime, useOS } from "./OSContext";
import { cn } from "@/utils/cn";

function roundRect(x: number, y: number, w: number, h: number, r: number) {
  return `M${x + r},${y} h${w - 2 * r} a${r},${r} 0 0 1 ${r},${r} v${h - 2 * r} a${r},${r} 0 0 1 ${-r},${r} h${-(w - 2 * r)} a${r},${r} 0 0 1 ${-r},${-r} v${-(h - 2 * r)} a${r},${r} 0 0 1 ${r},${-r} z`;
}

function PanelShell({ title, subtitle, children, icon, width = 344 }: { title: string; subtitle?: string; children: ReactNode; icon?: ReactNode; width?: number }) {
  const { setPanel } = useOS();
  return (
    <div
      className="panel-anim fixed z-[9100] flex max-h-[calc(100vh-var(--taskbar-h)-18px)] flex-col overflow-hidden rounded-xl"
      style={{
        right: 8,
        bottom: "calc(var(--taskbar-h) + 8px)",
        width: `min(${width}px, calc(100vw - 16px))`,
        background: "var(--surface)",
        border: "1px solid var(--border-strong)",
        boxShadow: "var(--shadow-menu)",
        backdropFilter: "blur(34px) saturate(1.4)",
      }}
      onContextMenu={(event) => event.preventDefault()}
    >
      <div className="flex shrink-0 items-center gap-2 px-3 pt-2.5 pb-2">
        {icon}
        <div className="min-w-0 flex-1">
          <div className="text-[11.5px] font-semibold leading-tight">{title}</div>
          {subtitle ? <div className="truncate text-[8.5px]" style={{ color: "var(--muted)" }}>{subtitle}</div> : null}
        </div>
        <button className="icon-btn h-6 w-6" aria-label="Close panel" onClick={() => setPanel(null)}><X size={12} /></button>
      </div>
      {children}
    </div>
  );
}

function relativeTime(ts: number) {
  const diff = Date.now() - ts;
  if (diff < 60_000) return "Just now";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function NotificationsPanel() {
  const { notifications, dismissNotification, clearNotifications, launch, setPanel, settings, updateSettings, markNotificationsRead } = useOS();
  useEffect(() => {
    markNotificationsRead();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <PanelShell
      title="Notifications"
      subtitle={`${notifications.length} notification${notifications.length === 1 ? "" : "s"}`}
      icon={<span className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><Bell size={15} /></span>}
    >
      <div className="flex items-center gap-2 border-y px-3 py-1.5" style={{ borderColor: "var(--border)" }}>
        <button
          className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[9px]"
          style={{ background: settings.doNotDisturb ? "var(--accent)" : "var(--field)", color: settings.doNotDisturb ? "#fff" : "var(--muted)", border: "1px solid var(--border)" }}
          onClick={() => updateSettings({ doNotDisturb: !settings.doNotDisturb })}
        >
          <Moon size={10} /> Do not disturb
        </button>
        <button className="ml-auto flex items-center gap-1 text-[9px] hover:underline" style={{ color: "var(--muted)" }} onClick={clearNotifications} disabled={!notifications.length}>
          <Trash2 size={10} /> Clear all
        </button>
      </div>
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-2">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center py-10 text-center">
            <Bell size={22} style={{ color: "var(--faint)" }} />
            <div className="mt-2 text-[11px] font-medium">No new notifications</div>
            <div className="mt-0.5 text-[9px]" style={{ color: "var(--muted)" }}>Desktop alerts will appear here.</div>
          </div>
        ) : (
          notifications.map((notification) => (
            <div key={notification.id} className="group mb-1 flex items-start gap-2 rounded-lg p-2 row-hover" style={{ border: "1px solid transparent" }}>
              {notification.appId ? <AppIcon id={notification.appId} size={25} /> : (
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md" style={{ background: "var(--field)", color: "var(--accent)" }}>
                  <Bell size={12} />
                </span>
              )}
              <div className="min-w-0 flex-1">
                <div className="flex items-start gap-1">
                  <div className="min-w-0 flex-1 text-[10.5px] font-medium leading-tight">{notification.title}</div>
                  {!notification.read ? <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: "var(--accent)" }} /> : null}
                </div>
                <div className="mt-0.5 line-clamp-3 text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>{notification.body}</div>
                <div className="mt-1 flex items-center gap-2 text-[8.5px]" style={{ color: "var(--faint)" }}>
                  <span>{relativeTime(notification.time)}</span>
                  {notification.appId ? (
                    <button className="hover:underline" style={{ color: "var(--accent)" }} onClick={() => { launch(notification.appId!); setPanel(null); }}>Open</button>
                  ) : null}
                </div>
              </div>
              <button className="icon-btn h-5 w-5 opacity-0 group-hover:opacity-100" aria-label="Dismiss notification" onClick={() => dismissNotification(notification.id)}>
                <X size={10} />
              </button>
            </div>
          ))
        )}
      </div>
      <div className="flex h-8 shrink-0 items-center justify-between border-t px-3" style={{ borderColor: "var(--border)", background: "var(--titlebar)" }}>
        <button className="flex items-center gap-1 text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => { launch("settings", { payload: { section: "sound" } }); setPanel(null); }}>
          <Bell size={9} /> Notification settings
        </button>
        <span className="text-[8px]" style={{ color: "var(--faint)" }}>Stored locally</span>
      </div>
    </PanelShell>
  );
}

function QuickSettingsPanel() {
  const { settings, updateSettings, launch, openPhoneController, setPanel, showInfo, lock } = useOS();
  const [networkRefresh, networkRefreshSet] = useState(0);
  const online = useMemo(() => {
    void networkRefresh;
    return navigator.onLine;
  }, [networkRefresh]);

  const tiles = [
    { label: "Night light", icon: Sun, active: settings.nightLight, onClick: () => updateSettings({ nightLight: !settings.nightLight }) },
    { label: "Dark mode", icon: Moon, active: settings.theme === "dark", onClick: () => updateSettings({ theme: settings.theme === "dark" ? "light" : "dark" }) },
    { label: "Do not disturb", icon: Bell, active: settings.doNotDisturb, onClick: () => updateSettings({ doNotDisturb: !settings.doNotDisturb }) },
    { label: settings.muted ? "Muted" : "System sound", icon: settings.muted ? VolumeX : Volume2, active: !settings.muted && settings.sound, onClick: () => updateSettings({ muted: !settings.muted, sound: true }) },
    {
      label: "Bluetooth",
      icon: Wifi,
      active: false,
      onClick: () => showInfo("Bluetooth is host-managed", "Bluetooth pairing and radio state are controlled by the Android device. The desktop interface does not emulate a Bluetooth stack, so no device list is fabricated here.", <Wifi size={24} />),
    },
    { label: "Phone controller", icon: Smartphone, active: false, onClick: () => { setPanel(null); openPhoneController(); } },
  ];

  return (
    <PanelShell
      title="Quick settings"
      subtitle={online ? "Host network online" : "Host network offline"}
      icon={<span className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><Zap size={15} /></span>}
    >
      <div className="grid grid-cols-3 gap-1.5 px-3 pb-2.5">
        {tiles.map((tile) => {
          const Icon = tile.icon;
          return (
            <button
              key={tile.label}
              className="flex flex-col items-center gap-1.5 rounded-lg px-1 py-2 transition-colors hover:brightness-110"
              style={{ background: tile.active ? "var(--accent)" : "var(--field)", border: "1px solid var(--border)", color: tile.active ? "#fff" : "var(--text)" }}
              onClick={tile.onClick}
            >
              <Icon size={16} />
              <span className="line-clamp-2 min-h-[20px] text-center text-[8.5px] leading-tight">{tile.label}</span>
            </button>
          );
        })}
      </div>
      <div className="mx-3 mb-2 rounded-lg p-2.5" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
        <div className="flex items-center gap-2">
          <Sun size={12} style={{ color: "var(--muted)" }} />
          <input type="range" min={45} max={100} value={settings.brightness} onChange={(event) => updateSettings({ brightness: Number(event.target.value) })} aria-label="Brightness" className="w-full" />
          <span className="w-7 text-right font-mono text-[9px]" style={{ color: "var(--muted)" }}>{settings.brightness}</span>
        </div>
        <div className="mt-1 flex items-center gap-2">
          {settings.muted ? <VolumeX size={12} style={{ color: "var(--muted)" }} /> : <Volume2 size={12} style={{ color: "var(--muted)" }} />}
          <input
            type="range"
            min={0}
            max={100}
            value={settings.muted ? 0 : settings.volume}
            onChange={(event) => updateSettings({ volume: Number(event.target.value), muted: Number(event.target.value) === 0 })}
            aria-label="Volume"
            className="w-full"
          />
          <button className="text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => updateSettings({ muted: !settings.muted })}>{settings.muted ? "Unmute" : "Mute"}</button>
        </div>
      </div>
      <div className="mx-3 mb-2 flex items-center gap-2 rounded-lg p-2" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
        <span className="flex h-6 w-6 items-center justify-center rounded-md" style={{ background: online ? "rgba(44,201,160,.15)" : "rgba(239,68,68,.13)", color: online ? "var(--success)" : "var(--danger)" }}>
          {online ? <Wifi size={12} /> : <WifiOff size={12} />}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[9.5px] font-medium">KK DEX network</div>
          <div className="truncate text-[8px]" style={{ color: "var(--muted)" }}>{online ? "Online · host-managed connection" : "No host connection"}</div>
        </div>
        <button className="text-[8px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => networkRefreshSet((n) => n + 1)}>Refresh</button>
        <button className="text-[8px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setPanel({ kind: "network" })}>Details</button>
      </div>
      <div className="flex h-8 shrink-0 items-center gap-2 border-t px-3" style={{ borderColor: "var(--border)", background: "var(--titlebar)" }}>
        <button className="flex items-center gap-1 text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => launch("settings", { payload: { section: "display" } })}><Monitor size={9} /> Display</button>
        <button className="flex items-center gap-1 text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => launch("settings")}><Info size={9} /> All settings</button>
        <button className="ml-auto flex items-center gap-1 text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => { setPanel(null); lock(); }}><Lock size={9} /> Lock</button>
      </div>
    </PanelShell>
  );
}

function CalendarPanel() {
  const { notifications, launch, setPanel } = useOS();
  const [today, setToday] = useState(new Date());
  const [viewMonth, setViewMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [selected, setSelected] = useState(() => new Date());

  useEffect(() => {
    const timer = window.setInterval(() => setToday(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leading = new Date(year, month, 1).getDay();
  const cells: (number | null)[] = [...Array.from({ length: leading }, () => null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
  while (cells.length % 7 !== 0) cells.push(null);
  const selectedEvents = notifications.filter((notification) => {
    const date = new Date(notification.time);
    return date.getFullYear() === selected.getFullYear() && date.getMonth() === selected.getMonth() && date.getDate() === selected.getDate();
  });

  return (
    <PanelShell
      title="Calendar"
      subtitle="Local date & notifications"
      icon={<span className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><CalendarDays size={15} /></span>}
      width={356}
    >
      <div className="px-3 pb-2">
        <div className="rounded-xl p-2.5 text-center" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
          <div className="font-mono text-[24px] font-light leading-none tracking-tight">
            {today.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit", second: "2-digit" })}
          </div>
          <div className="mt-1 text-[9px]" style={{ color: "var(--muted)" }}>
            {today.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
          </div>
        </div>
      </div>
      <div className="px-3">
        <div className="mb-1.5 flex items-center justify-between">
          <button className="icon-btn h-6 w-6" aria-label="Previous month" onClick={() => setViewMonth(new Date(year, month - 1, 1))}><ChevronLeft size={13} /></button>
          <div className="text-[10.5px] font-semibold">{viewMonth.toLocaleDateString(undefined, { month: "long", year: "numeric" })}</div>
          <button className="icon-btn h-6 w-6" aria-label="Next month" onClick={() => setViewMonth(new Date(year, month + 1, 1))}><ChevronRight size={13} /></button>
        </div>
        <div className="grid grid-cols-7 gap-0.5 text-center text-[8px] font-medium" style={{ color: "var(--faint)" }}>
          {["S", "M", "T", "W", "T", "F", "S"].map((day, index) => <div key={`${day}-${index}`} className="py-1">{day}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-0.5 pb-2">
          {cells.map((day, index) => {
            if (day === null) return <div key={`empty-${index}`} />;
            const date = new Date(year, month, day);
            const isToday = date.toDateString() === today.toDateString();
            const isSelected = date.toDateString() === selected.toDateString();
            const hasEvent = notifications.some((notification) => new Date(notification.time).toDateString() === date.toDateString());
            return (
              <button
                key={`day-${day}`}
                className="relative flex h-6 items-center justify-center rounded text-[9px] transition-colors hover:bg-[var(--hover)]"
                style={{
                  background: isSelected ? "var(--accent)" : isToday ? "var(--accent-soft)" : "transparent",
                  color: isSelected ? "#fff" : isToday ? "var(--accent)" : "var(--text)",
                  fontWeight: isSelected || isToday ? 600 : 400,
                }}
                onClick={() => setSelected(date)}
              >
                {day}
                {hasEvent && !isSelected ? <span className="absolute bottom-0.5 h-0.5 w-0.5 rounded-full" style={{ background: "var(--accent)" }} /> : null}
              </button>
            );
          })}
        </div>
      </div>
      <div className="border-t px-3 py-2" style={{ borderColor: "var(--border)" }}>
        <div className="mb-1 flex items-center justify-between">
          <span className="text-[9.5px] font-medium">
            {selected.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}
          </span>
          <span className="text-[8px]" style={{ color: "var(--faint)" }}>{selectedEvents.length} item{selectedEvents.length === 1 ? "" : "s"}</span>
        </div>
        {selectedEvents.length ? (
          selectedEvents.slice(0, 2).map((event) => (
            <div key={event.id} className="flex items-center gap-1.5 rounded p-1 text-[8.5px]" style={{ color: "var(--muted)" }}>
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
              <span className="truncate">{event.title}</span>
              <span className="ml-auto shrink-0" style={{ color: "var(--faint)" }}>{formatTime(event.time)}</span>
            </div>
          ))
        ) : (
          <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>No notifications on this day.</div>
        )}
      </div>
      <div className="flex h-8 shrink-0 items-center justify-between border-t px-3" style={{ borderColor: "var(--border)", background: "var(--titlebar)" }}>
        <button className="text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setSelected(new Date())}>Today</button>
        <button className="flex items-center gap-1 text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => { launch("settings", { payload: { section: "sound" } }); setPanel(null); }}>
          <Bell size={9} /> Notifications
        </button>
      </div>
    </PanelShell>
  );
}

function VolumePanel() {
  const { settings, updateSettings, soundClick, setPanel, launch } = useOS();
  return (
    <PanelShell title="Volume" subtitle="KK DEX interface audio" icon={<Volume2 size={15} style={{ color: "var(--accent)" }} />}>
      <div className="px-4 pt-2 pb-4">
        <div className="flex items-center gap-3">
          <button className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "var(--field)", border: "1px solid var(--border)" }} aria-label={settings.muted ? "Unmute" : "Mute"} onClick={() => updateSettings({ muted: !settings.muted })}>
            {settings.muted ? <VolumeX size={16} style={{ color: "var(--muted)" }} /> : <Volume2 size={16} style={{ color: "var(--accent)" }} />}
          </button>
          <div className="flex-1">
            <input
              type="range"
              min={0}
              max={100}
              value={settings.muted ? 0 : settings.volume}
              aria-label="Volume level"
              onChange={(event) => updateSettings({ volume: Number(event.target.value), muted: Number(event.target.value) === 0 })}
              className="w-full"
            />
            <div className="mt-0.5 text-right font-mono text-[9px]" style={{ color: "var(--muted)" }}>{settings.muted ? "Muted" : `${settings.volume}%`}</div>
          </div>
        </div>
        <div className="mt-2 rounded-lg p-2 text-[8.5px] leading-relaxed" style={{ background: "var(--field)", color: "var(--faint)" }}>
          These levels control KK DEX UI sounds only. The browser cannot change the Android host's speaker volume.
        </div>
        <div className="mt-2 flex gap-2">
          <button className="btn btn-sm" disabled={settings.muted} onClick={soundClick}><Volume2 size={11} /> Test sound</button>
          <button className="btn btn-sm" onClick={() => { updateSettings({ muted: !settings.muted }); }}>{settings.muted ? "Unmute" : "Mute"}</button>
          <button className="btn btn-sm ml-auto !px-2" aria-label="Volume settings" title="Open sound settings" onClick={() => { setPanel(null); launch("settings", { payload: { section: "sound" } }); }}><Info size={11} /></button>
        </div>
      </div>
    </PanelShell>
  );
}

function NetworkPanel() {
  const { launch, showInfo } = useOS();
  const [tick, setTick] = useState(0);
  const online = navigator.onLine;
  void tick;
  return (
    <PanelShell title="Network" subtitle="Host network status" icon={online ? <Wifi size={15} style={{ color: "var(--success)" }} /> : <WifiOff size={15} style={{ color: "var(--danger)" }} />}>
      <div className="px-3 pb-3">
        <div className="rounded-lg p-2.5" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: online ? "rgba(44,201,160,.14)" : "rgba(239,68,68,.13)", color: online ? "var(--success)" : "var(--danger)" }}>
              {online ? <Wifi size={17} /> : <WifiOff size={17} />}
            </span>
            <div>
              <div className="text-[11px] font-medium">{online ? "Connected" : "No network"}</div>
              <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>Host-managed browser connection</div>
            </div>
            <span className={cn("badge ml-auto", online && "badge-accent")}>{online ? "ONLINE" : "OFFLINE"}</span>
          </div>
        </div>
        <dl className="mt-2 space-y-1.5 text-[9.5px]">
          {[
            ["Interface", "Android host network"],
            ["Adapter", "Managed outside the WebView"],
            ["Bridge", "KKDexAPI-compatible receiver"],
            ["Web status", online ? "Navigator reports online" : "Navigator reports offline"],
          ].map(([key, value]) => (
            <div key={key} className="flex justify-between gap-3">
              <dt style={{ color: "var(--muted)" }}>{key}</dt>
              <dd className="text-right">{value}</dd>
            </div>
          ))}
        </dl>
        <div className="mt-2 flex gap-2">
          <button className="btn btn-sm" onClick={() => setTick(tick + 1)}><Network size={11} /> Check again</button>
          <button className="btn btn-sm" onClick={() => showInfo("Wi-Fi controls", "This interface cannot enable or scan Wi-Fi because the browser has no radio control API. Android's Wi-Fi state remains authoritative.", <Wifi size={24} />)}><Info size={11} /> Why?</button>
          <button className="btn btn-sm ml-auto" onClick={() => launch("browser")}><Wifi size={11} /> Browser</button>
        </div>
        <div className="mt-2 text-[8px]" style={{ color: "var(--faint)" }}>Last checked: {new Date().toLocaleTimeString()}</div>
      </div>
    </PanelShell>
  );
}

interface BatteryLike extends EventTarget {
  level: number;
  charging: boolean;
}

function BatteryPanel() {
  const [battery, setBattery] = useState<BatteryLike | null>(null);
  const [checked, setChecked] = useState(false);
  const [refresh, setRefresh] = useState(0);
  useEffect(() => {
    setChecked(false);
    const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryLike> };
    if (!nav.getBattery) {
      setBattery(null);
      setChecked(true);
      return;
    }
    let manager: BatteryLike | null = null;
    const update = () => setBattery(manager);
    nav.getBattery().then((bat) => {
      manager = bat;
      setBattery(bat);
      setChecked(true);
      bat.addEventListener("levelchange", update);
      bat.addEventListener("chargingchange", update);
    }).catch(() => setChecked(true));
    return () => {
      manager?.removeEventListener("levelchange", update);
      manager?.removeEventListener("chargingchange", update);
    };
  }, [refresh]);

  const level = battery ? Math.round(battery.level * 100) : null;
  return (
    <PanelShell title="Power & battery" subtitle="Host power status" icon={<BatteryCharging size={15} style={{ color: "var(--accent)" }} />}>
      <div className="px-3 pb-3">
        <div className="flex items-center gap-3 rounded-xl p-3" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
          <div className="relative flex h-12 w-8 items-center justify-center">
            <div className="absolute inset-0 rounded-md border-2" style={{ borderColor: level ? "var(--success)" : "var(--border-strong)" }} />
            <div className="absolute left-1 bottom-1 right-1 rounded-sm" style={{ height: level ? `${Math.max(8, level)}%` : "0%", background: "var(--success)" }} />
            <div className="absolute -right-[5px] top-3 h-3 w-1 rounded-r" style={{ background: "var(--border-strong)" }} />
            <span className="relative font-mono text-[8px] font-bold" style={{ color: level && level > 45 ? "#04231a" : "var(--muted)" }}>{level !== null ? `${level}%` : ""}</span>
          </div>
          <div className="min-w-0">
            <div className="text-[11.5px] font-medium">{level !== null ? (battery?.charging ? "Charging" : "On battery") : checked ? "Battery status unavailable" : "Checking battery…"}</div>
            <div className="mt-0.5 text-[8.5px] leading-snug" style={{ color: "var(--muted)" }}>
              {level !== null
                ? "Reported by the host Battery Status API."
                : "This browser or external TV WebView does not expose a battery. The TV is likely on AC power."}
            </div>
          </div>
        </div>
        <div className="mt-2 text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>
          Power mode and shutdown are managed by the Android host. No simulated charge level is shown when the host does not report one.
        </div>
        <div className="mt-2 flex gap-2">
          <button className="btn btn-sm" onClick={() => setRefresh((n) => n + 1)}>Refresh status</button>
          <span className="ml-auto flex items-center gap-1 text-[8.5px]" style={{ color: "var(--muted)" }}><Check size={9} /> External display session</span>
        </div>
      </div>
    </PanelShell>
  );
}

export function SystemPanelHost() {
  const { panel } = useOS();
  if (!panel) return null;
  if (panel.kind === "notifications") return <NotificationsPanel />;
  if (panel.kind === "quick") return <QuickSettingsPanel />;
  if (panel.kind === "calendar") return <CalendarPanel />;
  if (panel.kind === "volume") return <VolumePanel />;
  if (panel.kind === "network") return <NetworkPanel />;
  if (panel.kind === "battery") return <BatteryPanel />;
  return null;
}

// Keep SVG path helper referenced for future custom battery artwork without shipping unused code.
void roundRect;
