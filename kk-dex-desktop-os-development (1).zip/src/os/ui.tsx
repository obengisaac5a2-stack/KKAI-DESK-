import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Search, X } from "lucide-react";
import { cn } from "@/utils/cn";

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      data-on={checked}
      className="toggle"
      onClick={() => onChange(!checked)}
    >
      <span className="toggle-knob" />
    </button>
  );
}

export function Slider({
  value,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  className,
  label,
}: {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  className?: string;
  label?: string;
}) {
  return (
    <input
      aria-label={label}
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className={cn("w-full", className)}
    />
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  size = "md",
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (value: T) => void;
  size?: "sm" | "md";
}) {
  return (
    <div
      className="inline-flex items-center gap-0.5 rounded-lg p-0.5"
      style={{ background: "var(--field)", border: "1px solid var(--border)" }}
    >
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onChange(option.value)}
          className={cn(
            "inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors",
            size === "sm" ? "h-6 px-2 text-[10.5px]" : "h-7 px-2.5 text-[11.5px]",
          )}
          style={
            value === option.value
              ? { background: "var(--surface-solid)", color: "var(--text)", boxShadow: "0 1px 4px rgba(0,0,0,.18)" }
              : { color: "var(--muted)" }
          }
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function SearchBox({
  value,
  onChange,
  placeholder = "Search",
  className,
  autoFocus,
  onClear,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
  onClear?: () => void;
}) {
  return (
    <div className={cn("relative flex items-center", className)}>
      <Search size={13} className="pointer-events-none absolute left-2.5" style={{ color: "var(--faint)" }} />
      <input
        autoFocus={autoFocus}
        className="field pl-7 pr-7"
        style={{ height: 30, fontSize: 12 }}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
      {value ? (
        <button
          type="button"
          aria-label="Clear search"
          className="icon-btn absolute right-1 h-6 w-6"
          onClick={() => {
            onChange("");
            onClear?.();
          }}
        >
          <X size={12} />
        </button>
      ) : null}
    </div>
  );
}

export function ToggleRow({
  title,
  description,
  checked,
  onChange,
  icon,
}: {
  title: string;
  description?: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  icon?: ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 py-2.5">
      {icon ? (
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
          style={{ background: "var(--field)", color: "var(--muted)" }}
        >
          {icon}
        </span>
      ) : null}
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-medium leading-tight">{title}</div>
        {description ? <div className="mt-0.5 text-[10.5px] leading-snug os-muted">{description}</div> : null}
      </div>
      <Switch checked={checked} onChange={onChange} label={title} />
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex h-full min-h-[180px] flex-col items-center justify-center gap-3 px-8 text-center">
      <div
        className="flex h-12 w-12 items-center justify-center rounded-xl"
        style={{ background: "var(--field)", color: "var(--muted)" }}
      >
        {icon}
      </div>
      <div>
        <div className="text-[13px] font-medium">{title}</div>
        {description ? <div className="mx-auto mt-1 max-w-[300px] text-[11px] leading-relaxed os-muted">{description}</div> : null}
      </div>
      {action}
    </div>
  );
}

export function IconButton({
  children,
  className,
  active,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      {...props}
      className={cn("icon-btn h-7 w-7", active && "bg-[var(--active)] text-[var(--text)]", className)}
    >
      {children}
    </button>
  );
}

export function AppNotice({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "warn" }) {
  return (
    <div
      className="flex items-start gap-2 rounded-lg px-3 py-2 text-[10.5px] leading-relaxed"
      style={{
        background: tone === "warn" ? "rgba(245,158,11,.1)" : "var(--field)",
        border: `1px solid ${tone === "warn" ? "rgba(245,158,11,.22)" : "var(--border)"}`,
        color: "var(--muted)",
      }}
    >
      {children}
    </div>
  );
}
