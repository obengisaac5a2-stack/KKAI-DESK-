import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  Calculator as CalculatorIcon,
  Copy,
  FolderOpen,
  Info,
  LayoutGrid,
  Lock,
  Monitor,
  Pencil,
  Pin,
  PinOff,
  RefreshCw,
  Smartphone,
  Sparkles,
  Trash2,
  Wifi,
  X,
} from "lucide-react";
import { APP_METAS, DESKTOP_APPS } from "./appMeta";
import { AppIcon, FileGlyph } from "./icons";
import { TASKBAR_SPACE, useOS, wallpaperStyle } from "./OSContext";
import { WindowFrame } from "./Window";
import { Taskbar } from "./Taskbar";
import { ContextMenuHost, DialogHost, ToastHost } from "./ShellMenus";
import {
  installBridge,
  isAppId,
  normalizeKey,
  parseModifiers,
  VALID_WALLPAPERS,
  type ControllerMessage,
  type DesktopMessage,
  type KKDexDesktopHandlers,
} from "./bridge";
import type { AppId, FileKind, FsNode, MenuItemConfig } from "./types";
import { cn } from "@/utils/cn";

const POSITION_KEY = "kkdex.desktopSlots";
const REMOTE_CHANNEL = "kkdex-remote";

type DesktopAppItem = { key: string; type: "app"; appId: AppId; name: string };
type DesktopFileItem = { key: string; type: "file"; node: FsNode; name: string };
type DesktopItem = DesktopAppItem | DesktopFileItem;

const KIND_LABEL: Record<FileKind, string> = {
  folder: "Folder",
  image: "Image",
  document: "Text document",
  audio: "Audio",
  video: "Video",
  archive: "Archive",
  code: "Source file",
  file: "File",
};

function loadSlots(): Record<string, number> {
  try {
    const raw = localStorage.getItem(POSITION_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, number>;
    return typeof parsed === "object" && parsed ? parsed : {};
  } catch {
    return {};
  }
}

function dispatchMouse(type: "pointerdown" | "pointerup" | "pointermove" | "mousedown" | "mouseup" | "mousemove" | "click" | "contextmenu" | "dblclick", element: Element, x: number, y: number, button = 0) {
  const buttonFlag = type === "pointerdown" || type === "mousedown" ? (button === 2 ? 2 : 1) : 0;
  const init = {
    bubbles: true,
    cancelable: true,
    composed: true,
    view: window,
    clientX: x,
    clientY: y,
    screenX: x,
    screenY: y,
    button,
    buttons: buttonFlag,
    pointerId: 7,
    pointerType: "mouse",
    isPrimary: true,
  };
  try {
    if (type.startsWith("pointer")) element.dispatchEvent(new PointerEvent(type, init));
    else element.dispatchEvent(new MouseEvent(type, init));
  } catch {
    element.dispatchEvent(new MouseEvent(type === "pointerdown" ? "mousedown" : type === "pointerup" ? "mouseup" : type, init));
  }
  return element;
}

function findScrollable(start: Element | null): HTMLElement | null {
  let element: Element | null = start;
  while (element && element !== document.body && element !== document.documentElement) {
    const style = window.getComputedStyle(element);
    const overflow = style.overflowY;
    if ((overflow === "auto" || overflow === "scroll") && element.scrollHeight > element.clientHeight + 2) {
      return element as HTMLElement;
    }
    element = element.parentElement;
  }
  const scrolling = document.scrollingElement;
  if (scrolling && scrolling.scrollHeight > scrolling.clientHeight + 2) return scrolling as HTMLElement;
  return null;
}

function isEditable(element: Element | null): element is HTMLInputElement | HTMLTextAreaElement | HTMLElement {
  if (!element) return false;
  return (
    element instanceof HTMLInputElement ||
    element instanceof HTMLTextAreaElement ||
    (element instanceof HTMLElement && element.isContentEditable)
  );
}

function setNativeValue(input: HTMLInputElement | HTMLTextAreaElement, value: string) {
  const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
  if (setter) setter.call(input, value);
  else input.value = value;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

export function Desktop() {
  const os = useOS();
  const {
    windows,
    activeWindow,
    settings,
    launch,
    restoreWindow,
    minimizeWindow,
    closeWindow,
    minimizAll,
    restoreAll,
    snapWindow,
    toggleMaximize,
    switchToNext,
    childrenOf,
    createFolder,
    renameNode,
    deleteNode,
    trash,
    openMenu,
    showPrompt,
    showConfirm,
    showInfo,
    notify,
    startOpen,
    setStartOpen,
    setStartQuery,
    panel,
    setPanel,
    taskViewOpen,
    setTaskViewOpen,
    locked,
    unlock,
    togglePin,
    updateSettings,
    soundClick,
  } = os;

  /* ------------------------------- desktop layout ------------------------------- */
  const [slots, setSlots] = useState<Record<string, number>>(loadSlots);
  const [selected, setSelected] = useState<string | null>(null);
  const [dragging, setDragging] = useState<{ key: string; dx: number; dy: number } | null>(null);
  const suppressClick = useRef(false);
  const hoverRef = useRef<Element | null>(null);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    localStorage.setItem(POSITION_KEY, JSON.stringify(slots));
  }, [slots]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const scriptFiles = childrenOf("desktop");
  const items: DesktopItem[] = useMemo(
    () => [
      ...DESKTOP_APPS.map((appId) => ({ key: `app:${appId}`, type: "app" as const, appId, name: APP_METAS[appId].name })),
      ...scriptFiles.map((node) => ({ key: `file:${node.id}`, type: "file" as const, node, name: node.name })),
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [scriptFiles.map((node) => `${node.id}:${node.name}`).join("|"), trash.length],
  );

  const iconSizes = {
    small: { tile: 36, cellW: 80, cellH: 88 },
    medium: { tile: 44, cellW: 92, cellH: 100 },
    large: { tile: 54, cellW: 102, cellH: 112 },
  } as const;
  const sizes = iconSizes[settings.iconSize];
  const workspaceHeight = Math.max(320, window.innerHeight - TASKBAR_SPACE - 18);
  const rows = Math.max(3, Math.floor(workspaceHeight / sizes.cellH));

  const slotPosition = (slot: number) => ({
    x: 16 + Math.floor(slot / rows) * (sizes.cellW + 6),
    y: 14 + (slot % rows) * sizes.cellH,
  });

  const effectiveSlots = useMemo(() => {
    const occupied = new Set<number>();
    Object.entries(slots).forEach(([key, value]) => {
      if (items.some((item) => item.key === key) && Number.isInteger(value)) occupied.add(value);
    });
    const result: Record<string, number> = {};
    let cursor = 0;
    items.forEach((item) => {
      if (Number.isInteger(slots[item.key]) && !Object.values(result).includes(slots[item.key])) {
        result[item.key] = slots[item.key];
        occupied.add(slots[item.key]);
        return;
      }
      while (occupied.has(cursor)) cursor += 1;
      result[item.key] = cursor;
      occupied.add(cursor);
      cursor += 1;
    });
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, slots, rows, sizes.cellW, sizes.cellH]);

  const occupiedSlots = (except?: string) =>
    Object.entries(effectiveSlots)
      .filter(([key]) => key !== except)
      .map(([, slot]) => slot);

  const nearestFreeSlot = (targetSlot: number, except: string) => {
    const used = new Set(occupiedSlots(except));
    if (!used.has(targetSlot) && targetSlot >= 0) return targetSlot;
    for (let distance = 1; distance < 80; distance += 1) {
      if (!used.has(targetSlot - distance) && targetSlot - distance >= 0) return targetSlot - distance;
      if (!used.has(targetSlot + distance)) return targetSlot + distance;
    }
    return targetSlot + 1;
  };

  const arrange = (nextItems: DesktopItem[]) => {
    const next: Record<string, number> = {};
    nextItems.forEach((item, index) => {
      next[item.key] = index;
    });
    setSlots(next);
    setSelected(null);
  };

  const selectedItem = items.find((item) => item.key === selected);

  /* ------------------------------- item actions -------------------------------- */
  const openDesktopItem = (item: DesktopItem) => {
    soundClick();
    if (item.type === "app") {
      launch(item.appId);
      return;
    }
    const node = item.node;
    if (node.kind === "folder") launch("files", { payload: { folderId: node.id } });
    else if (node.kind === "image") launch("gallery", { payload: { imageSrc: node.src, imageName: node.name } });
    else launch("files", { payload: { folderId: node.parentId ?? "desktop", previewId: node.id } });
  };

  const renameFile = (node: FsNode) => {
    showPrompt({
      title: "Rename item",
      label: "New name",
      value: node.name,
      confirmLabel: "Rename",
      icon: <FileGlyph kind={node.kind} size={24} />,
      onConfirm: (value) => {
        if (value.trim()) renameNode(node.id, value);
      },
    });
  };

  const removeFile = (node: FsNode) => {
    showConfirm(
      `Move “${node.name}” to Recycle Bin?`,
      "You can restore this workspace item later from the Recycle Bin.",
      () => {
        deleteNode(node.id);
        setSelected(null);
      },
      "Move to Recycle Bin",
    );
  };

  const itemMenu = (event: React.MouseEvent, item: DesktopItem) => {
    event.preventDefault();
    event.stopPropagation();
    setSelected(item.key);
    if (item.type === "app") {
      const meta = APP_METAS[item.appId];
      const pinned = settings.taskbarPins.includes(item.appId);
      const open = windows.some((window) => window.appId === item.appId);
      openMenu(event.clientX, event.clientY, [
        { label: `Open ${meta.name}`, icon: <ArrowRight size={14} />, action: () => openDesktopItem(item) },
        { label: "Open new window", icon: <Copy size={14} />, action: () => launch(item.appId, { newInstance: true }), disabled: item.appId === "phone" },
        { separator: true },
        { label: pinned ? "Unpin from taskbar" : "Pin to taskbar", icon: pinned ? <PinOff size={14} /> : <Pin size={14} />, action: () => togglePin(item.appId) },
        { label: open ? "Switch to open window" : "Open on desktop", icon: <Monitor size={14} />, action: () => launch(item.appId), shortcut: open ? "Running" : undefined },
        { separator: true },
        {
          label: "Properties",
          icon: <Info size={14} />,
          action: () =>
            showInfo(
              `${meta.name} — Application`,
              `${meta.description}\n\nCategory: ${meta.category}\nDefault window: ${meta.defaultSize[0]} × ${meta.defaultSize[1]}\nMinimum window: ${meta.minSize[0]} × ${meta.minSize[1]}\nPinned to taskbar: ${pinned ? "Yes" : "No"}\nApplication ID: ${meta.id}`,
              <AppIcon id={item.appId} size={32} />,
            ),
        },
      ], meta.name);
      return;
    }
    const node = item.node;
    openMenu(event.clientX, event.clientY, [
      { label: node.kind === "folder" ? "Open folder" : "Open", icon: <ArrowRight size={14} />, action: () => openDesktopItem(item) },
      { label: "Open file location", icon: <FolderOpen size={14} />, action: () => launch("files", { payload: { folderId: "desktop" } }) },
      { separator: true },
      { label: "Rename", shortcut: "F2", icon: <Pencil size={14} />, action: () => renameFile(node) },
      {
        label: "Properties",
        icon: <Info size={14} />,
        action: () =>
          showInfo(
            `${node.name} — Properties`,
            `Type: ${KIND_LABEL[node.kind]}\nLocation: Desktop\nSize: ${node.kind === "folder" ? "Folder" : `${Math.max(1, Math.round(node.size / 1024))} KB`}\nModified: ${new Date(node.modified).toLocaleString()}`,
            <FileGlyph kind={node.kind} size={28} />,
          ),
      },
      { separator: true },
      { label: "Move to Recycle Bin", shortcut: "Delete", danger: true, icon: <Trash2 size={14} />, action: () => removeFile(node) },
    ], node.name);
  };

  const startDrag = (event: React.PointerEvent, item: DesktopItem) => {
    if (event.button !== 0) return;
    event.stopPropagation();
    setSelected(item.key);
    const originX = event.clientX;
    const originY = event.clientY;
    let moved = false;
    let latest = { x: 0, y: 0 };
    const move = (moveEvent: PointerEvent) => {
      latest = { x: moveEvent.clientX - originX, y: moveEvent.clientY - originY };
      if (!moved && Math.abs(latest.x) + Math.abs(latest.y) < 5) return;
      moved = true;
      setDragging({ key: item.key, dx: latest.x, dy: latest.y });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setDragging(null);
      if (!moved) return;
      suppressClick.current = true;
      window.setTimeout(() => {
        suppressClick.current = false;
      }, 220);
      const base = slotPosition(effectiveSlots[item.key] ?? 0);
      const targetX = base.x + latest.x;
      const targetY = base.y + latest.y;
      const columns = Math.max(1, Math.floor((window.innerWidth - 20) / (sizes.cellW + 6)));
      const col = Math.max(0, Math.min(columns - 1, Math.round((targetX - 16) / (sizes.cellW + 6))));
      const row = Math.max(0, Math.min(rows - 1, Math.round((targetY - 14) / sizes.cellH)));
      const targetSlot = col * rows + row;
      setSlots((prev) => ({ ...prev, [item.key]: nearestFreeSlot(targetSlot, item.key) }));
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const desktopMenu = (event: React.MouseEvent) => {
    event.preventDefault();
    const viewItems: MenuItemConfig[] = (["large", "medium", "small"] as const).map((size) => ({
      label: size === "large" ? "Large icons" : size === "medium" ? "Medium icons" : "Small icons",
      checked: settings.iconSize === size,
      action: () => updateSettings({ iconSize: size }),
    }));
    const sortItems: MenuItemConfig[] = [
      {
        label: "Name",
        action: () =>
          arrange([...items].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }))),
      },
      {
        label: "Date modified",
        action: () =>
          arrange(
            [...items].sort((a, b) => {
              const aDate = a.type === "file" ? a.node.modified : 0;
              const bDate = b.type === "file" ? b.node.modified : 0;
              return bDate - aDate;
            }),
          ),
      },
      {
        label: "Size",
        action: () =>
          arrange(
            [...items].sort((a, b) => {
              const aSize = a.type === "file" && a.node.kind !== "folder" ? a.node.size : 0;
              const bSize = b.type === "file" && b.node.kind !== "folder" ? b.node.size : 0;
              return bSize - aSize;
            }),
          ),
      },
      {
        label: "Type",
        action: () =>
          arrange(
            [...items].sort((a, b) => {
              const aKind = a.type === "app" ? "Application" : KIND_LABEL[a.node.kind];
              const bKind = b.type === "app" ? "Application" : KIND_LABEL[b.node.kind];
              return aKind.localeCompare(bKind);
            }),
          ),
      },
    ];
    openMenu(event.clientX, event.clientY, [
      { label: "View", icon: <Monitor size={14} />, children: viewItems },
      { label: "Sort by", icon: <LayoutGrid size={14} />, children: sortItems },
      {
        label: "Align icons to grid",
        icon: <LayoutGrid size={14} />,
        action: () => arrange(items),
      },
      { separator: true },
      {
        label: "Refresh",
        shortcut: "F5",
        icon: <RefreshCw size={14} />,
        action: () => {
          window.dispatchEvent(new Event("kkdex:refresh"));
          setSlots({ ...slots });
          notify("Desktop refreshed", "Workspace state is up to date.", { silent: true, tone: "success" });
        },
      },
      {
        label: "New folder",
        icon: <FolderOpen size={14} />,
        shortcut: "Desktop",
        action: () =>
          showPrompt({
            title: "New folder",
            message: "The folder is created on the desktop and appears in Files.",
            label: "Folder name",
            value: "New folder",
            confirmLabel: "Create folder",
            onConfirm: (value) => {
              if (value.trim()) {
                const id = createFolder("desktop", value);
                setSelected(`file:${id}`);
              }
            },
          }),
      },
      { separator: true },
      { label: "Display settings", icon: <Monitor size={14} />, action: () => launch("settings", { payload: { section: "display" } }) },
      { label: "Personalize", icon: <Sparkles size={14} />, action: () => launch("settings", { payload: { section: "personalization" } }) },
      { label: "Open Terminal", icon: <TerminalGlyph />, action: () => launch("terminal") },
      { separator: true },
      { label: "Phone controller", icon: <Smartphone size={14} />, action: () => launch("phone") },
    ], "Desktop");
  };

  /* ---------------------------------- remote ---------------------------------- */
  const [cursor, setCursor] = useState({ x: 0, y: 0, visible: false });
  const [controllerConnected, setControllerConnected] = useState(false);
  const [ripple, setRipple] = useState<{ id: number; x: number; y: number } | null>(null);
  const remotePos = useRef({ x: 0, y: 0 });
  const remoteDown = useRef(false);
  const textTargetRef = useRef<HTMLElement | null>(null);
  const channelRef = useRef<BroadcastChannel | null>(null);
  const seenControllerRef = useRef(false);
  const actionsRef = useRef<KKDexDesktopHandlers | null>(null);
  const remoteVisibleRef = useRef(false);

  const showRipple = (x: number, y: number) => {
    if (!settings.clickEffects) return;
    const id = Date.now();
    setRipple({ id, x, y });
    window.setTimeout(() => setRipple((current) => (current?.id === id ? null : current)), 500);
  };

  const clearHover = () => {
    hoverRef.current?.classList.remove("remote-hover");
    hoverRef.current = null;
  };

  const moveRemote = (x: number, y: number) => {
    const vw = window.innerWidth;
    const vh = window.innerHeight - TASKBAR_SPACE;
    const cx = Math.min(Math.max(Number(x) || 0, 0), vw - 1);
    const cy = Math.min(Math.max(Number(y) || 0, 0), vh - 1);
    remotePos.current = { x: cx, y: cy };
    remoteVisibleRef.current = true;
    setCursor({ x: cx, y: cy, visible: true });
    const target = document.elementFromPoint(cx, cy);
    if (target && target !== hoverRef.current) {
      clearHover();
      target.classList.add("remote-hover");
      hoverRef.current = target;
    }
    if (remoteDown.current && target) {
      dispatchMouse("pointermove", target, cx, cy);
      target.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, cancelable: true, clientX: cx, clientY: cy, buttons: 1 }));
    }
  };

  const clickAt = (x: number, y: number, button = 0, double = false) => {
    const target = document.elementFromPoint(x, y);
    if (!target) return;
    const sequence = () => {
      dispatchMouse("pointerdown", target, x, y, button);
      dispatchMouse("mousedown", target, x, y, button);
      dispatchMouse("pointerup", target, x, y, button);
      dispatchMouse("mouseup", target, x, y, button);
      dispatchMouse("click", target, x, y, button);
    };
    sequence();
    if (double) {
      window.setTimeout(() => {
        const second = document.elementFromPoint(x, y);
        if (second) {
          dispatchMouse("pointerdown", second, x, y, button);
          dispatchMouse("mousedown", second, x, y, button);
          dispatchMouse("pointerup", second, x, y, button);
          dispatchMouse("mouseup", second, x, y, button);
          dispatchMouse("click", second, x, y, button);
          dispatchMouse("dblclick", second, x, y, button);
        }
      }, 40);
    }
    if (isEditable(target)) {
      textTargetRef.current = target;
      if (target instanceof HTMLElement) target.focus();
    } else {
      window.setTimeout(() => {
        if (isEditable(document.activeElement)) textTargetRef.current = document.activeElement;
      }, 70);
    }
    showRipple(x, y);
  };

  const insertRemoteText = (text: string) => {
    const active = isEditable(document.activeElement) ? document.activeElement : null;
    const target = active ?? textTargetRef.current;
    if (!target) {
      notify("Text target missing", "Tap a desktop text field before using the phone keyboard.", { silent: true });
      return false;
    }
    if (target instanceof HTMLElement) target.focus();
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
      setNativeValue(target, `${target.value}${text}`);
      return true;
    }
    if (target.isContentEditable) {
      try {
        document.execCommand("insertText", false, text);
      } catch {
        target.textContent = `${target.textContent ?? ""}${text}`;
        target.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
      }
      return true;
    }
    return false;
  };

  const pressRemoteKey = (key: string, modifiers?: string[] | Record<string, boolean>) => {
    const normalized = normalizeKey(key);
    const mods = parseModifiers(modifiers);
    const active = isEditable(document.activeElement) ? document.activeElement : textTargetRef.current;
    const input = active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? active : null;

    if (input) {
      input.focus();
      const start = input.selectionStart ?? input.value.length;
      const end = input.selectionEnd ?? start;
      const replaceRange = (replacement: string) => {
        const next = `${input.value.slice(0, start)}${replacement}${input.value.slice(end)}`;
        setNativeValue(input, next);
        const caret = start + replacement.length;
        try {
          input.setSelectionRange(caret, caret);
        } catch {
          /* inputs like email may not support selection ranges */
        }
      };

      if (mods.ctrlKey || mods.metaKey) {
        const lower = normalized.toLowerCase();
        if (lower === "a") {
          input.select();
          return true;
        }
        if (lower === "c") {
          const selected = input.value.slice(start, end) || input.value;
          navigator.clipboard?.writeText(selected).catch(() => undefined);
          notify("Copied from desktop", `${selected.length} character${selected.length === 1 ? "" : "s"} copied.`, { silent: true });
          return true;
        }
        if (lower === "x") {
          const selected = input.value.slice(start, end) || input.value;
          navigator.clipboard?.writeText(selected).catch(() => undefined);
          replaceRange("");
          return true;
        }
        if (lower === "v") {
          navigator.clipboard
            ?.readText()
            .then((text) => {
              if (!text) return;
              const currentStart = input.selectionStart ?? input.value.length;
              const currentEnd = input.selectionEnd ?? currentStart;
              const next = `${input.value.slice(0, currentStart)}${text}${input.value.slice(currentEnd)}`;
              setNativeValue(input, next);
              const caret = currentStart + text.length;
              try {
                input.setSelectionRange(caret, caret);
              } catch {
                /* noop */
              }
            })
            .catch(() => notify("Clipboard unavailable", "The host denied clipboard access for paste.", { tone: "error", silent: true }));
          return true;
        }
        if (lower === "z") {
          try {
            document.execCommand("undo");
          } catch {
            /* undo is best effort */
          }
          return true;
        }
        if (lower === "s" && input.tagName === "TEXTAREA") {
          // Let the application's own save handler run with a real synthetic event.
          input.dispatchEvent(new KeyboardEvent("keydown", { key: "s", ctrlKey: true, bubbles: true, cancelable: true }));
          return true;
        }
      }

      if (normalized === "Backspace") {
        if (start !== end) replaceRange("");
        else if (start > 0) {
          setNativeValue(input, `${input.value.slice(0, start - 1)}${input.value.slice(start)}`);
          try {
            input.setSelectionRange(start - 1, start - 1);
          } catch {
            /* noop */
          }
        }
        return true;
      }
      if (normalized === "Delete") {
        if (start !== end) replaceRange("");
        else {
          setNativeValue(input, `${input.value.slice(0, start)}${input.value.slice(start + 1)}`);
          try {
            input.setSelectionRange(start, start);
          } catch {
            /* noop */
          }
        }
        return true;
      }
      if (normalized === "ArrowLeft" || normalized === "ArrowRight" || normalized === "Home" || normalized === "End") {
        const caret =
          normalized === "ArrowLeft"
            ? Math.max(0, start - 1)
            : normalized === "ArrowRight"
              ? Math.min(input.value.length, end + 1)
              : normalized === "Home"
                ? 0
                : input.value.length;
        try {
          input.setSelectionRange(caret, caret);
        } catch {
          /* noop */
        }
        return true;
      }
      if (normalized === "Escape") {
        input.blur();
        return true;
      }
    }

    if (normalized.length === 1 && !mods.ctrlKey && !mods.metaKey && !mods.altKey) {
      return insertRemoteText(normalized);
    }
    const target = active ?? textTargetRef.current ?? document.activeElement ?? document.body;
    const init: KeyboardEventInit = {
      key: normalized,
      code: normalized.length === 1 ? `Key${normalized.toUpperCase()}` : normalized,
      bubbles: true,
      cancelable: true,
      ...mods,
    };
    target.dispatchEvent(new KeyboardEvent("keydown", init));
    target.dispatchEvent(new KeyboardEvent("keyup", init));
    return true;
  };

  const remoteScroll = (deltaY: number) => {
    const target = document.elementFromPoint(remotePos.current.x, remotePos.current.y);
    const scrollable = findScrollable(target);
    if (!scrollable) return;
    scrollable.scrollTop += Number(deltaY) || 0;
  };

  const buildState = () => ({
    ready: true,
    mode: "external-display",
    version: "1.0.0",
    resolution: { width: window.innerWidth, height: window.innerHeight - TASKBAR_SPACE, dpr: window.devicePixelRatio },
    theme: settings.theme,
    wallpaper: settings.wallpaper,
    accent: settings.accent,
    controllerConnected,
    activeApp: activeWindow ? APP_METAS[activeWindow.appId].name : null,
    activeAppId: activeWindow?.appId ?? null,
    windows: windows.map((window) => ({
      appId: window.appId,
      name: APP_METAS[window.appId].name,
      minimized: window.minimized,
      maximized: window.maximized,
    })),
    apps: DESKTOP_APPS.map((id) => ({ id, name: APP_METAS[id].name })),
    pointer: { ...remotePos.current, visible: remoteVisibleRef.current || cursor.visible },
    settings: {
      pointerSpeed: settings.pointerSpeed,
      pointerSize: settings.pointerSize,
      clickEffects: settings.clickEffects,
    },
    bridge: typeof window !== "undefined" && "KKDexAPI" in window ? "KKDexAPI receiver ready" : "local receiver",
    timestamp: Date.now(),
  });

  const openAppByString = (appId: string) => {
    if (isAppId(appId)) {
      launch(appId);
      return true;
    }
    const match = (Object.keys(APP_METAS) as AppId[]).find(
      (id) => APP_METAS[id].name.toLowerCase() === appId.toLowerCase(),
    );
    if (match) {
      launch(match);
      return true;
    }
    return false;
  };

  actionsRef.current = {
    movePointer: moveRemote,
    pointerDown: () => {
      remoteDown.current = true;
      const target = document.elementFromPoint(remotePos.current.x, remotePos.current.y);
      if (target) {
        dispatchMouse("pointerdown", target, remotePos.current.x, remotePos.current.y);
        dispatchMouse("mousedown", target, remotePos.current.x, remotePos.current.y);
      }
    },
    pointerUp: () => {
      remoteDown.current = false;
      const target = document.elementFromPoint(remotePos.current.x, remotePos.current.y);
      if (target) {
        dispatchMouse("pointerup", target, remotePos.current.x, remotePos.current.y);
        dispatchMouse("mouseup", target, remotePos.current.x, remotePos.current.y);
      }
    },
    pointerClick: () => clickAt(remotePos.current.x, remotePos.current.y, 0, false),
    pointerDoubleClick: () => clickAt(remotePos.current.x, remotePos.current.y, 0, true),
    pointerRightClick: () => {
      const target = document.elementFromPoint(remotePos.current.x, remotePos.current.y);
      if (!target) return;
      dispatchMouse("pointerdown", target, remotePos.current.x, remotePos.current.y, 2);
      dispatchMouse("mousedown", target, remotePos.current.x, remotePos.current.y, 2);
      dispatchMouse("contextmenu", target, remotePos.current.x, remotePos.current.y, 2);
      dispatchMouse("pointerup", target, remotePos.current.x, remotePos.current.y, 2);
      dispatchMouse("mouseup", target, remotePos.current.x, remotePos.current.y, 2);
      showRipple(remotePos.current.x, remotePos.current.y);
    },
    scrollDesktop: remoteScroll,
    insertText: insertRemoteText,
    pressKey: pressRemoteKey,
    getState: buildState,
    openApp: openAppByString,
    setTheme: (theme) => {
      if (theme !== "dark" && theme !== "light") return false;
      updateSettings({ theme });
      return true;
    },
    setWallpaper: (wallpaper) => {
      if (!VALID_WALLPAPERS.includes(wallpaper as (typeof VALID_WALLPAPERS)[number])) return false;
      updateSettings({ wallpaper: wallpaper as typeof settings.wallpaper });
      return true;
    },
  };

  useEffect(() => {
    const wrapped: KKDexDesktopHandlers = {
      movePointer: (x, y) => actionsRef.current?.movePointer(x, y),
      pointerDown: (button) => actionsRef.current?.pointerDown(button),
      pointerUp: (button) => actionsRef.current?.pointerUp(button),
      pointerClick: (button) => actionsRef.current?.pointerClick(button),
      pointerDoubleClick: () => actionsRef.current?.pointerDoubleClick(),
      pointerRightClick: () => actionsRef.current?.pointerRightClick(),
      scrollDesktop: (deltaY) => actionsRef.current?.scrollDesktop(deltaY),
      insertText: (text) => actionsRef.current?.insertText(text) ?? false,
      pressKey: (key, modifiers) => actionsRef.current?.pressKey(key, modifiers) ?? false,
      getState: () => actionsRef.current?.getState() ?? { ready: false },
      openApp: (appId) => actionsRef.current?.openApp(appId) ?? false,
      setTheme: (theme) => actionsRef.current?.setTheme(theme) ?? false,
      setWallpaper: (wallpaper) => actionsRef.current?.setWallpaper(wallpaper) ?? false,
    };
    installBridge(wrapped);
    return () => clearHover();
    // The bridge wrappers read through a mutable ref, so they always use current desktop state.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel(REMOTE_CHANNEL);
      channelRef.current = channel;
      channel.postMessage({ type: "hello", role: "desktop", version: "1.0.0" } satisfies DesktopMessage);
      channel.onmessage = (event: MessageEvent<ControllerMessage>) => {
        const data = event.data;
        if (!data?.type) return;
        if ((data as { role?: string }).role === "desktop") return;
        if (data.type === "hello" || data.type === "query-state") {
          setControllerConnected(true);
          if (!seenControllerRef.current) {
            seenControllerRef.current = true;
            notify("Phone controller connected", "Touchpad and keyboard input are linked to this desktop.", { silent: true, tone: "success" });
          }
          channel?.postMessage({ type: "state", state: actionsRef.current?.getState() ?? {} } satisfies DesktopMessage);
          return;
        }
        if (data.type === "disconnect") {
          setControllerConnected(false);
          remoteVisibleRef.current = false;
          setCursor((current) => ({ ...current, visible: false }));
          return;
        }
        if (data.type === "move") actionsRef.current?.movePointer(data.x, data.y);
        else if (data.type === "down") actionsRef.current?.pointerDown(data.button);
        else if (data.type === "up") actionsRef.current?.pointerUp(data.button);
        else if (data.type === "click") actionsRef.current?.pointerClick(data.button);
        else if (data.type === "doubleClick") actionsRef.current?.pointerDoubleClick();
        else if (data.type === "rightClick") actionsRef.current?.pointerRightClick();
        else if (data.type === "scroll") actionsRef.current?.scrollDesktop(data.deltaY);
        else if (data.type === "text") actionsRef.current?.insertText(data.text);
        else if (data.type === "key") actionsRef.current?.pressKey(data.key, data.modifiers);
        else if (data.type === "openApp") {
          const ok = actionsRef.current?.openApp(data.appId) ?? false;
          channel?.postMessage({ type: "ack", action: "openApp", ok } satisfies DesktopMessage);
        } else if (data.type === "setTheme") actionsRef.current?.setTheme(data.theme);
      };
    } catch {
      channelRef.current = null;
    }
    return () => {
      try {
        channel?.postMessage({ type: "disconnect" } satisfies ControllerMessage);
        channel?.close();
      } catch {
        /* BroadcastChannel can be unavailable in some WebViews. */
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    channelRef.current?.postMessage({ type: "state", state: buildState() } satisfies DesktopMessage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [windows, activeWindow?.id, controllerConnected, settings.theme, settings.wallpaper, settings.accent]);

  /* -------------------------------- shortcuts -------------------------------- */
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = Boolean(target && (["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName) || target.isContentEditable));
      if (event.key === "Escape") {
        if (startOpen) setStartOpen(false);
        if (panel) setPanel(null);
        if (taskViewOpen) setTaskViewOpen(false);
        setSelected(null);
        return;
      }
      if (typing) return;
      const win = event.metaKey || event.key === "Meta";
      if (event.key === "Meta" || (event.ctrlKey && event.key === "Escape")) {
        event.preventDefault();
        setStartOpen(!startOpen);
        setPanel(null);
        setStartQuery("");
        return;
      }
      if (win && event.key.toLowerCase() === "e") {
        event.preventDefault();
        launch("files");
        return;
      }
      if (win && event.key.toLowerCase() === "d") {
        event.preventDefault();
        if (windows.some((window) => !window.minimized)) minimizAll();
        else restoreAll();
        return;
      }
      if (win && event.key === "ArrowLeft" && activeWindow) {
        event.preventDefault();
        snapWindow(activeWindow.id, "left");
        return;
      }
      if (win && event.key === "ArrowRight" && activeWindow) {
        event.preventDefault();
        snapWindow(activeWindow.id, "right");
        return;
      }
      if (win && event.key === "ArrowUp" && activeWindow) {
        event.preventDefault();
        if (!activeWindow.maximized) toggleMaximize(activeWindow.id);
        return;
      }
      if (win && event.key === "ArrowDown" && activeWindow) {
        event.preventDefault();
        if (activeWindow.maximized) toggleMaximize(activeWindow.id);
        else minimizeWindow(activeWindow.id);
        return;
      }
      if (event.altKey && event.key === "Tab") {
        event.preventDefault();
        switchToNext();
        return;
      }
      if (event.altKey && event.key === "F4") {
        event.preventDefault();
        if (activeWindow) closeWindow(activeWindow.id);
        return;
      }
      if (event.key === "F5") {
        event.preventDefault();
        window.dispatchEvent(new Event("kkdex:refresh"));
        return;
      }
      if (event.key === "F2" && selectedItem?.type === "file") {
        event.preventDefault();
        renameFile(selectedItem.node);
        return;
      }
      if (event.key === "Delete" && selectedItem?.type === "file") {
        event.preventDefault();
        removeFile(selectedItem.node);
        return;
      }
      if (event.key === "Delete" && selectedItem?.type === "app") {
        event.preventDefault();
        notify("Application shortcut", "System apps cannot be deleted. Unpin it from the taskbar instead.", { silent: true });
        return;
      }
      if (event.key === "Enter" && selectedItem) {
        event.preventDefault();
        openDesktopItem(selectedItem);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startOpen, panel, taskViewOpen, windows, activeWindow, selectedItem, settings.taskbarPins]);

  useEffect(() => {
    if (!locked) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Enter") unlock();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [locked, unlock]);

  /* --------------------------------- lock screen -------------------------------- */
  if (locked) {
    return (
      <div className="fixed inset-0 overflow-hidden" style={wallpaperStyle(settings.wallpaper)}>
        <div className="absolute inset-0" style={{ background: "linear-gradient(145deg, rgba(4,8,18,.68), rgba(4,8,18,.32) 50%, rgba(4,8,18,.72))", backdropFilter: "blur(4px)" }} />
        <div className="relative flex h-full flex-col items-center justify-center gap-5 text-white">
          <div className="flex flex-col items-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl" style={{ background: "rgba(255,255,255,.12)", border: "1px solid rgba(255,255,255,.18)", backdropFilter: "blur(16px)" }}>
              <Sparkles size={30} />
            </div>
            <div className="text-[13px] font-medium tracking-[0.18em] text-white/60">KK DEX</div>
            <div className="mt-2 text-[64px] font-light leading-none tracking-tight tabular-nums">
              {now.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
            </div>
            <div className="mt-2 text-[13px] text-white/75">
              {now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
            </div>
          </div>
          <button
            className="flex items-center gap-2.5 rounded-full py-2 pl-2 pr-5 text-left transition-transform hover:scale-[1.02]"
            style={{ background: "rgba(255,255,255,.13)", border: "1px solid rgba(255,255,255,.2)", backdropFilter: "blur(20px)" }}
            onClick={unlock}
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full" style={{ background: "linear-gradient(145deg,#4f8cff,#8b7cff)" }}>
              <Lock size={15} />
            </span>
            <span>
              <span className="block text-[11.5px] font-medium">KK DEX Operator</span>
              <span className="block text-[9px] text-white/55">Local session · no password configured</span>
            </span>
            <ArrowRight size={14} className="ml-2 text-white/70" />
          </button>
          <div className="text-[9px] text-white/45">Press Enter or select the profile to unlock</div>
        </div>
      </div>
    );
  }

  const greeting = now.getHours() < 12 ? "Good morning" : now.getHours() < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="fixed inset-0 overflow-hidden" style={wallpaperStyle(settings.wallpaper)}>
      <div className="absolute inset-0" style={{ background: "linear-gradient(115deg, rgba(3,7,15,.34) 0%, rgba(3,7,15,.02) 48%, rgba(3,7,15,.24) 100%)" }} />

      <div
        className="absolute inset-x-0 top-0 z-0"
        style={{ bottom: TASKBAR_SPACE }}
        onMouseDown={(event) => {
          if (event.target === event.currentTarget) {
            setSelected(null);
            setStartOpen(false);
            setPanel(null);
          }
        }}
        onContextMenu={desktopMenu}
      >
        {items.map((item) => {
          const slot = effectiveSlots[item.key] ?? 0;
          const position = slotPosition(slot);
          const isSelected = selected === item.key;
          const isDragging = dragging?.key === item.key;
          const isFile = item.type === "file";
          const fileNode = isFile ? item.node : null;
          return (
            <div
              key={item.key}
              role="button"
              tabIndex={0}
              aria-label={item.name}
              className={cn("desk-icon", isSelected && "selected")}
              style={{
                left: position.x,
                top: position.y,
                width: sizes.cellW,
                minHeight: sizes.cellH - 4,
                transform: isDragging ? `translate(${dragging.dx}px, ${dragging.dy}px) scale(1.03)` : undefined,
                zIndex: isDragging ? 50 : isSelected ? 2 : 1,
                transition: isDragging ? "none" : "background 100ms ease, box-shadow 100ms ease",
                cursor: isDragging ? "grabbing" : "default",
                touchAction: "none",
              }}
              onPointerDown={(event) => startDrag(event, item)}
              onClick={() => {
                if (suppressClick.current) return;
                setSelected(item.key);
                setStartOpen(false);
                setPanel(null);
              }}
              onDoubleClick={() => {
                if (suppressClick.current) return;
                openDesktopItem(item);
              }}
              onContextMenu={(event) => itemMenu(event, item)}
              onKeyDown={(event) => {
                if (event.key === "Enter") openDesktopItem(item);
              }}
            >
              {item.type === "app" ? (
                <AppIcon id={item.appId} size={sizes.tile} binFull={item.appId === "recycle" ? trash.length > 0 : undefined} />
              ) : fileNode?.kind === "image" && fileNode.src ? (
                <div className="overflow-hidden rounded-md" style={{ width: sizes.tile, height: sizes.tile, border: "1px solid rgba(255,255,255,.35)", boxShadow: "0 2px 8px rgba(0,0,0,.35)" }}>
                  <img src={fileNode.src} alt="" className="h-full w-full object-cover" draggable={false} />
                </div>
              ) : (
                <div
                  className="flex items-center justify-center rounded-lg"
                  style={{ width: sizes.tile, height: sizes.tile, background: "rgba(255,255,255,.16)", border: "1px solid rgba(255,255,255,.26)", backdropFilter: "blur(8px)", boxShadow: "0 2px 8px rgba(0,0,0,.2)" }}
                >
                  <FileGlyph kind={fileNode?.kind ?? "file"} size={Math.round(sizes.tile * 0.55)} />
                </div>
              )}
              <span className="desk-icon-label">{item.name}</span>
            </div>
          );
        })}

        <div
          className="absolute right-5 top-4 z-0 hidden w-[286px] overflow-hidden rounded-2xl p-4 text-white lg:block"
          style={{ background: "linear-gradient(135deg, rgba(14,20,32,.5), rgba(14,20,32,.28))", border: "1px solid rgba(255,255,255,.15)", boxShadow: "0 16px 40px -24px rgba(0,0,0,.55)", backdropFilter: "blur(22px) saturate(1.2)" }}
          onMouseDown={(event) => event.stopPropagation()}
          onContextMenu={(event) => event.stopPropagation()}
        >
          <div className="flex items-center gap-2 text-[9px] font-medium uppercase tracking-[0.15em] text-white/55">
            <span className="flex h-5 w-5 items-center justify-center rounded-md" style={{ background: "rgba(255,255,255,.14)" }}><Sparkles size={11} /></span>
            KK DEX OS
            <span className="ml-auto flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[8px] normal-case tracking-normal" style={{ background: "rgba(255,255,255,.1)" }}>
              <span className="h-1 w-1 rounded-full" style={{ background: "#5eead4" }} /> External display
            </span>
          </div>
          <div className="mt-4 flex items-end justify-between">
            <div>
              <div className="text-[11px] text-white/60">{greeting}, Operator</div>
              <div className="mt-0.5 text-[38px] font-light leading-none tracking-tight tabular-nums">
                {now.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
              </div>
              <div className="mt-1.5 text-[10px] text-white/65">
                {now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
              </div>
            </div>
            <div className="flex flex-col items-end gap-1.5 text-[8.5px] text-white/55">
              <span className="flex items-center gap-1"><Wifi size={10} /> {navigator.onLine ? "Online" : "Offline"}</span>
              <span className="flex items-center gap-1"><Smartphone size={10} /> {controllerConnected ? "Phone linked" : "Controller ready"}</span>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-4 gap-1.5">
            {[
              { id: "files" as AppId, label: "Files", Icon: FolderOpen },
              { id: "browser" as AppId, label: "Browser", Icon: Wifi },
              { id: "ai" as AppId, label: "KK AI", Icon: Sparkles },
              { id: "calculator" as AppId, label: "Calc", Icon: CalculatorIcon },
            ].map((shortcut) => (
              <button
                key={shortcut.id}
                className="flex flex-col items-center gap-1 rounded-lg py-1.5 text-[8.5px] text-white/75 transition-colors hover:bg-white/15 hover:text-white"
                onClick={() => launch(shortcut.id)}
              >
                <shortcut.Icon size={15} />
                {shortcut.label}
              </button>
            ))}
          </div>
          <div className="mt-2 flex items-center gap-1.5 border-t border-white/10 pt-2 text-[8px] text-white/40">
            <Monitor size={9} />
            <span className="truncate">{window.innerWidth} × {window.innerHeight} · taskbar docked</span>
            <button className="ml-auto underline decoration-white/20 underline-offset-2 hover:text-white/75" onClick={() => showInfo("About this desktop", "KK DEX Desktop 1.0 — a floating window environment built for TV and monitor displays. The phone remains a separate touchpad and keyboard controller. Files, notes and settings are persisted in this workspace.", <Sparkles size={26} />)}>
              About
            </button>
          </div>
        </div>

        <div className="pointer-events-none absolute inset-0 z-20" aria-hidden={false}>
          {windows.map((window) => (
            <WindowFrame key={window.id} win={window} />
          ))}
        </div>
      </div>

      <Taskbar />
      <ContextMenuHost />
      <DialogHost />
      <ToastHost />

      {/* display comfort layers */}
      <div className="pointer-events-none fixed inset-0 z-[9400]" style={{ background: "#000", opacity: Math.max(0, (100 - settings.brightness) / 150) }} />
      {settings.nightLight ? <div className="night-light" style={{ zIndex: 9401 }} /> : null}

      {/* remote controller pointer */}
      {cursor.visible ? (
        <svg
          className="pointer-events-none fixed z-[9450]"
          style={{ left: cursor.x - 2, top: cursor.y - 2, width: 12 + settings.pointerSize * 2, height: 18 + settings.pointerSize * 2, filter: "drop-shadow(0 1px 2px rgba(0,0,0,.75))" }}
          viewBox="0 0 24 24"
          fill="none"
          aria-hidden
        >
          <path d="M3 2.5 20.2 11l-7.2 1.9-2.8 7.3L3 2.5Z" fill="#fff" stroke="#111827" strokeWidth="1.4" strokeLinejoin="round" />
        </svg>
      ) : null}
      {ripple ? (
        <div key={ripple.id} className="pointer-events-none fixed z-[9451]" style={{ left: ripple.x - 14, top: ripple.y - 14 }}>
          <div className="remote-click-ring h-7 w-7 rounded-full" style={{ border: "2px solid var(--accent)", background: "rgba(var(--accent-rgb),.22)" }} />
        </div>
      ) : null}

      {/* task view */}
      {taskViewOpen ? (
        <div className="fixed inset-x-0 top-0 z-[8700] flex flex-col overflow-hidden" style={{ bottom: "var(--taskbar-h)", background: "rgba(5,9,16,.62)", backdropFilter: "blur(22px)" }} onMouseDown={() => setTaskViewOpen(false)}>
          <div className="flex items-center justify-between px-6 pt-5 pb-3 text-white" onMouseDown={(event) => event.stopPropagation()}>
            <div>
              <div className="text-[16px] font-semibold tracking-tight">Task view</div>
              <div className="text-[10px] text-white/55">{windows.length} open window{windows.length === 1 ? "" : "s"} · select a window to bring it forward</div>
            </div>
            <button className="flex h-7 w-7 items-center justify-center rounded-md bg-white/10 transition-colors hover:bg-white/20" aria-label="Close task view" onClick={() => setTaskViewOpen(false)}><X size={15} /></button>
          </div>
          <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-6 pb-4">
            {windows.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center gap-3 text-white/60">
                <LayoutGrid size={32} />
                <div className="text-[13px] text-white/80">No application windows are open</div>
                <div className="text-[10px]">Choose an app below to start a floating desktop window.</div>
              </div>
            ) : (
              <div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-3" onMouseDown={(event) => event.stopPropagation()}>
                {windows.slice().sort((a, b) => b.z - a.z).map((window) => (
                  <div
                    key={window.id}
                    className="group overflow-hidden rounded-xl text-left text-white"
                    style={{ background: "rgba(255,255,255,.08)", border: "1px solid rgba(255,255,255,.14)", boxShadow: "0 12px 30px -20px rgba(0,0,0,.6)" }}
                  >
                    <button
                      className="block w-full p-3 text-left"
                      onClick={() => {
                        restoreWindow(window.id);
                        setTaskViewOpen(false);
                      }}
                    >
                      <div className="mb-2 flex items-center gap-2">
                        <AppIcon id={window.appId} size={24} />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-[11px] font-medium">{APP_METAS[window.appId].name}</div>
                          <div className="text-[8.5px] text-white/50">{window.minimized ? "Minimized" : window.maximized ? "Maximized" : `${window.w} × ${window.h}`}</div>
                        </div>
                        <span className="rounded px-1.5 py-0.5 text-[8px] text-white/60" style={{ background: "rgba(255,255,255,.09)" }}>{window.minimized ? "MIN" : "LIVE"}</span>
                      </div>
                      <div className="flex h-[86px] items-center justify-center rounded-lg" style={{ background: "linear-gradient(130deg, rgba(255,255,255,.1), rgba(255,255,255,.03))", border: "1px solid rgba(255,255,255,.08)" }}>
                        <div className="flex flex-col items-center gap-1.5 opacity-60">
                          <AppIcon id={window.appId} size={30} />
                          <span className="text-[8.5px]">Floating application window</span>
                        </div>
                      </div>
                    </button>
                    <div className="flex justify-end gap-1 border-t border-white/10 px-2 py-1.5">
                      <button className="rounded px-2 py-1 text-[8.5px] text-white/70 hover:bg-white/10" onClick={() => minimizeWindow(window.id)}>Minimize</button>
                      <button className="flex items-center gap-1 rounded px-2 py-1 text-[8.5px] text-white/70 hover:bg-red-500 hover:text-white" onClick={() => closeWindow(window.id)}><X size={10} /> Close</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2 border-t border-white/10 px-6 py-3" onMouseDown={(event) => event.stopPropagation()}>
            <span className="text-[9px] uppercase tracking-wider text-white/40">Applications</span>
            {DESKTOP_APPS.slice(0, 7).map((id) => (
              <button key={id} className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[9px] text-white/70 hover:bg-white/10 hover:text-white" onClick={() => { launch(id); setTaskViewOpen(false); }}>
                <AppIcon id={id} size={17} />
                {APP_METAS[id].name}
              </button>
            ))}
            <button className="ml-auto text-[9px] text-white/60 hover:text-white" onClick={() => { launch("appcenter"); setTaskViewOpen(false); }}>App Center →</button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function TerminalGlyph() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="m7 9 3 3-3 3M13 15h4" />
    </svg>
  );
}


