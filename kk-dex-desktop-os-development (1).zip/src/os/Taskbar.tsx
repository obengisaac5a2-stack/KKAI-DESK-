import { useEffect, useMemo, useState } from "react";
import {
  BatteryMedium,
  Bell,
  LayoutGrid,
  Monitor,
  Search,
  Volume2,
  Wifi,
} from "lucide-react";
import { APP_METAS } from "./appMeta";
import { AppIcon } from "./icons";
import { useOS } from "./OSContext";
import { StartMenu } from "./StartMenu";
import { SystemPanelHost } from "./SystemPanels";
import type { AppId } from "./types";
import { cn } from "@/utils/cn";

function KKLogo({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <defs>
        <linearGradient id="kk-start-grad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7cc4ff" />
          <stop offset="0.52" stopColor="#4f8cff" />
          <stop offset="1" stopColor="#8b7cff" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="url(#kk-start-grad)" />
      <path d="M9 8.5v15M9 16l6.4-7.5M9 16l6.4 7.5" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M17.5 8.5v15M17.5 16l6.2-7.5M17.5 16l6.2 7.5" stroke="#fff" strokeOpacity=".8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Taskbar() {
  const {
    windows,
    activeWindow,
    launch,
    restoreWindow,
    minimizeWindow,
    focusWindow,
    minimizAll,
    restoreAll,
    settings,
    setStartOpen,
    startOpen,
    startQuery,
    setStartQuery,
    panel,
    setPanel,
    openMenu,
    setTaskViewOpen,
    taskViewOpen,
    notifications,
    openPhoneController,
    togglePin,
    closeWindow,
    trash,
  } = useOS();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.ctrlKey && (event.key === "k" || event.key === "K")) {
        event.preventDefault();
        setStartOpen(true);
        setStartQuery("");
        setPanel(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setPanel, setStartOpen, setStartQuery]);

  const runningIds = useMemo(() => Array.from(new Set(windows.map((w) => w.appId))), [windows]);
  const taskApps = useMemo(() => {
    const base = [...settings.taskbarPins];
    runningIds.forEach((id) => {
      if (!base.includes(id)) base.push(id);
    });
    return base;
  }, [settings.taskbarPins, runningIds]);

  const appWindows = (appId: AppId) => windows.filter((w) => w.appId === appId);
  const isRunning = (appId: AppId) => appWindows(appId).length > 0;
  const isActive = (appId: AppId) => activeWindow?.appId === appId;

  const handleTaskApp = (appId: AppId) => {
    const wins = appWindows(appId);
    if (!wins.length) {
      launch(appId);
      return;
    }
    const top = wins.slice().sort((a, b) => b.z - a.z)[0];
    if (isActive(appId) && !top.minimized) minimizeWindow(top.id);
    else if (top.minimized) restoreWindow(top.id);
    else focusWindow(top.id);
  };

  const taskMenu = (event: React.MouseEvent, appId: AppId) => {
    event.preventDefault();
    event.stopPropagation();
    const meta = APP_METAS[appId];
    const wins = appWindows(appId);
    openMenu(event.clientX, event.clientY - 8, [
      { label: meta.name, icon: <AppIcon id={appId} size={16} />, disabled: true },
      { separator: true },
      { label: wins.length ? "Switch to window" : "Open", icon: <LayoutGrid size={14} />, action: () => handleTaskApp(appId) },
      { label: "Open new window", icon: <LayoutGrid size={14} />, disabled: appId === "phone", action: () => launch(appId, { newInstance: true }) },
      {
        label: settings.taskbarPins.includes(appId) ? "Unpin from taskbar" : "Pin to taskbar",
        icon: <LayoutGrid size={14} />,
        action: () => togglePin(appId),
      },
      { separator: true },
      {
        label: "Minimize window",
        disabled: !wins.length,
        icon: <Monitor size={14} />,
        action: () => wins.forEach((w) => minimizeWindow(w.id)),
      },
      {
        label: "Close all windows",
        danger: true,
        disabled: !wins.length,
        icon: <Monitor size={14} />,
        action: () => wins.forEach((w) => closeWindow(w.id)),
      },
    ], meta.name);
  };

  const togglePanel = (kind: "notifications" | "quick" | "calendar" | "volume" | "network" | "battery") => {
    setStartOpen(false);
    setPanel(panel?.kind === kind ? null : { kind });
  };

  const unread = notifications.filter((notification) => !notification.read).length;
  const visibleWindows = windows.some((window) => !window.minimized);
  const timeText = now.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  const dateText = now.toLocaleDateString(undefined, { month: "numeric", day: "numeric", year: "numeric" });

  return (
    <>
      {(startOpen || panel) ? (
        <div
          className="fixed inset-x-0 top-0 z-[8500]"
          style={{ bottom: "var(--taskbar-h)" }}
          onMouseDown={() => {
            setStartOpen(false);
            setPanel(null);
          }}
          onContextMenu={(event) => {
            event.preventDefault();
            setStartOpen(false);
            setPanel(null);
          }}
        />
      ) : null}

      <footer
        className="fixed inset-x-0 bottom-0 z-[9000] flex items-center px-2"
        style={{
          height: "var(--taskbar-h)",
          background: "var(--taskbar-bg)",
          borderTop: "1px solid var(--border)",
          backdropFilter: "blur(32px) saturate(1.5)",
          WebkitBackdropFilter: "blur(32px) saturate(1.5)",
          color: "var(--text)",
          boxShadow: "0 -8px 30px -20px rgba(0,0,0,.7)",
        }}
        onContextMenu={(event) => {
          if ((event.target as HTMLElement).closest("button")) return;
          event.preventDefault();
          openMenu(event.clientX, Math.min(event.clientY, window.innerHeight - 220), [
            { label: "Task view", icon: <LayoutGrid size={14} />, shortcut: "Alt+Tab", action: () => setTaskViewOpen(true) },
            { label: "Taskbar settings", icon: <Monitor size={14} />, action: () => launch("settings", { payload: { section: "personalization" } }) },
            { separator: true },
            { label: "Show desktop", icon: <Monitor size={14} />, shortcut: "Win+D", action: () => (visibleWindows ? minimizAll() : restoreAll()) },
            { separator: true },
            { label: "Phone controller", icon: <LayoutGrid size={14} />, action: () => launch("phone") },
            { label: "Open controller window", icon: <LayoutGrid size={14} />, action: openPhoneController },
          ], "Taskbar");
        }}
      >
        <div className="absolute left-2.5 hidden items-center gap-1.5 xl:flex">
          <button
            className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[9px] transition-colors hover:bg-[var(--hover)]"
            style={{ color: "var(--muted)" }}
            onClick={() => launch("thispc")}
            title="KK DEX Station · external display"
          >
            <Monitor size={12} />
            <span className="font-medium">KK DEX Station</span>
            <span className="h-1 w-1 rounded-full" style={{ background: "var(--success)" }} />
          </button>
        </div>

        <div className="absolute left-1/2 flex -translate-x-1/2 items-center gap-0.5">
          <button
            className={cn("taskbar-btn", startOpen && "active")}
            aria-label="Start"
            title="Start (Win)"
            onClick={() => {
              setStartOpen(!startOpen);
              setPanel(null);
              if (!startOpen) setStartQuery("");
            }}
          >
            <KKLogo size={22} />
          </button>
          <button
            className={cn("taskbar-btn", startOpen && !startQuery ? "active" : "")}
            aria-label="Search"
            title="Search"
            onClick={() => {
              setStartOpen(true);
              setStartQuery("");
              setPanel(null);
              window.setTimeout(() => {
                const input = document.querySelector<HTMLInputElement>('input[placeholder="Search apps, settings and files"]');
                input?.focus();
              }, 60);
            }}
          >
            <Search size={18} strokeWidth={1.8} />
          </button>
          <button
            className={cn("taskbar-btn", taskViewOpen && "active")}
            aria-label="Task view"
            title="Task view"
            onClick={() => {
              setTaskViewOpen(!taskViewOpen);
              setStartOpen(false);
              setPanel(null);
            }}
          >
            <LayoutGrid size={18} strokeWidth={1.7} />
          </button>
          <div className="mx-1 h-6 w-px" style={{ background: "var(--border)" }} />
          {taskApps.map((appId) => {
            const running = isRunning(appId);
            const active = isActive(appId);
            const count = appWindows(appId).length;
            return (
              <button
                key={appId}
                className={cn("taskbar-btn", running && "running", active && "active")}
                aria-label={APP_METAS[appId].name}
                title={`${APP_METAS[appId].name}${count > 1 ? ` (${count})` : ""}`}
                onClick={() => handleTaskApp(appId)}
                onContextMenu={(event) => taskMenu(event, appId)}
                onAuxClick={(event) => {
                  if (event.button === 1) launch(appId, { newInstance: true });
                }}
              >
                <AppIcon id={appId} size={26} binFull={appId === "recycle" ? trash.length > 0 : undefined} />
                {running ? <span className="taskbar-dot" style={{ width: active ? 16 : 5 }} /> : null}
                {count > 1 ? (
                  <span className="absolute right-0.5 top-0.5 flex h-3 min-w-3 items-center justify-center rounded-full px-0.5 text-[7px] font-semibold" style={{ background: "var(--accent)", color: "#fff" }}>{count}</span>
                ) : null}
              </button>
            );
          })}
        </div>

        <div className="ml-auto flex h-full items-center gap-0.5">
          <button className="hidden rounded-md px-2 py-1 sm:flex" title={`Notifications${unread ? ` · ${unread} unread` : ""}`} aria-label="Notifications" onClick={() => togglePanel("notifications")}>
            <span className="relative">
              <Bell size={14} style={{ color: panel?.kind === "notifications" ? "var(--accent)" : "var(--muted)" }} />
              {unread ? <span className="absolute -right-1 -top-1 h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} /> : null}
            </span>
          </button>
          <button
            className={cn("hidden items-center gap-1 rounded-md px-2 py-1.5 sm:flex", panel?.kind === "quick" && "bg-[var(--hover)]")}
            title={`Network · ${navigator.onLine ? "Online" : "Offline"}`}
            aria-label="Network and quick settings"
            onClick={() => togglePanel("quick")}
          >
            <Wifi size={14} style={{ color: navigator.onLine ? "var(--muted)" : "var(--danger)" }} />
            <Volume2 size={14} style={{ color: settings.muted ? "var(--faint)" : "var(--muted)" }} />
          </button>
          <button className="hidden rounded-md px-2 py-1.5 sm:flex" title="Battery and power" aria-label="Battery and power" onClick={() => togglePanel("battery")}>
            <BatteryMedium size={16} style={{ color: "var(--muted)" }} />
          </button>
          <button
            className={cn("flex flex-col items-end rounded-md px-2 py-1 leading-tight transition-colors hover:bg-[var(--hover)]", panel?.kind === "calendar" && "bg-[var(--hover)]")}
            title="Calendar and time"
            aria-label="Calendar"
            onClick={() => togglePanel("calendar")}
          >
            <span className="font-sans text-[11px] font-medium tabular-nums">{timeText}</span>
            <span className="hidden font-sans text-[9px] tabular-nums sm:block" style={{ color: "var(--muted)" }}>{dateText}</span>
          </button>
          <button
            className="ml-0.5 flex h-full w-2 items-center justify-center opacity-60 transition-opacity hover:opacity-100"
            aria-label="Show desktop"
            title={visibleWindows ? "Show desktop" : "Restore windows"}
            onClick={() => (visibleWindows ? minimizAll() : restoreAll())}
          >
            <span className="h-6 w-px" style={{ background: "var(--border-strong)" }} />
          </button>
        </div>
      </footer>

      <StartMenu />
      <SystemPanelHost />
    </>
  );
}

export { KKLogo };
