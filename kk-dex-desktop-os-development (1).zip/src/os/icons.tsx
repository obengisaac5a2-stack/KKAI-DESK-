import {
  Archive,
  Bot,
  Calculator,
  CircleUserRound,
  Code2,
  File,
  FileImage,
  FileText,
  Folder,
  FolderOpen,
  GalleryHorizontalEnd,
  Grid2X2,
  HardDrive,
  Image as ImageIcon,
  Images,
  LayoutGrid,
  Monitor,
  Music,
  Play,
  Settings,
  ShoppingBag,
  Smartphone,
  Sparkles,
  SquareTerminal,
  StickyNote,
  Store,
  Trash2,
  Video,
  type LucideIcon,
} from "lucide-react";
import type { AppId, FileKind } from "./types";

export const APP_ICON_MAP: Record<AppId, LucideIcon> = {
  thispc: Monitor,
  files: FolderOpen,
  browser: GalleryHorizontalEnd,
  ai: Sparkles,
  appcenter: Store,
  settings: Settings,
  gallery: Images,
  notes: StickyNote,
  calculator: Calculator,
  terminal: SquareTerminal,
  recycle: Trash2,
  phone: Smartphone,
};

export type IconGradient = [string, string];

export const APP_GRADIENTS: Record<AppId, IconGradient> = {
  thispc: ["#4f8cff", "#1d4ed8"],
  files: ["#f7c45c", "#d98a1e"],
  browser: ["#49d5ff", "#2d6cff"],
  ai: ["#b886ff", "#6d3ff0"],
  appcenter: ["#48dfc0", "#0e9f83"],
  settings: ["#97a6bd", "#586378"],
  gallery: ["#ff93b8", "#e0457c"],
  notes: ["#ffd76a", "#eab308"],
  calculator: ["#ffa96b", "#e2681c"],
  terminal: ["#4a5568", "#1a202c"],
  recycle: ["#7cd9b5", "#2c9874"],
  phone: ["#5eead4", "#0f766e"],
};

export function AppIcon({
  id,
  size = 26,
  variant = "tile",
  binFull,
  className = "",
}: {
  id: AppId;
  size?: number;
  variant?: "tile" | "plain";
  binFull?: boolean;
  className?: string;
}) {
  const Icon = id === "recycle" && binFull ? Trash2 : APP_ICON_MAP[id];
  const [from, to] = APP_GRADIENTS[id];
  if (variant === "plain") {
    return <Icon size={size} className={className} strokeWidth={1.7} />;
  }
  const radius = Math.round(size * 0.26);
  return (
    <div
      className={`relative flex shrink-0 items-center justify-center overflow-hidden ${className}`}
      style={{
        width: size,
        height: size,
        borderRadius: radius,
        background: `linear-gradient(145deg, ${from}, ${to})`,
        boxShadow: "inset 0 1px 0 rgba(255,255,255,.32), inset 0 -1px 0 rgba(0,0,0,.18), 0 2px 6px rgba(0,0,0,.22)",
      }}
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0"
        style={{
          height: "48%",
          background: "linear-gradient(180deg, rgba(255,255,255,.22), rgba(255,255,255,0))",
        }}
      />
      <Icon
        size={Math.round(size * 0.55)}
        color="#fff"
        strokeWidth={1.8}
        style={{ position: "relative", filter: "drop-shadow(0 1px 1px rgba(0,0,0,.18))" }}
      />
    </div>
  );
}

export const FILE_ICON_MAP: Record<FileKind, LucideIcon> = {
  folder: Folder,
  image: FileImage,
  document: FileText,
  audio: Music,
  video: Video,
  archive: Archive,
  code: Code2,
  file: File,
};

export const FILE_COLORS: Record<FileKind, string> = {
  folder: "#f0ae3c",
  image: "#f0729b",
  document: "#5b9dff",
  audio: "#a78bfa",
  video: "#fb923c",
  archive: "#facc15",
  code: "#34d399",
  file: "#94a3b8",
};

export function FileGlyph({ kind, size = 20, color }: { kind: FileKind; size?: number; color?: string }) {
  const Icon = kind === "folder" ? Folder : FILE_ICON_MAP[kind];
  return <Icon size={size} color={color ?? FILE_COLORS[kind]} strokeWidth={1.75} />;
}

// Additional named exports used by feature apps. All are vector icons, never emoji.
export const IconSprites = {
  store: Store,
  grid: LayoutGrid,
  apps: Grid2X2,
  drive: HardDrive,
  play: Play,
  music: Music,
  images: Images,
  image: ImageIcon,
  folder: Folder,
  user: CircleUserRound,
  bot: Bot,
  shopping: ShoppingBag,
  sparkles: Sparkles,
  phone: Smartphone,
};
