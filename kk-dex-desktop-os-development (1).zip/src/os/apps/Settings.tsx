import { useEffect, useState, type ReactNode } from "react";
import {
  Bell,
  Check,
  Cpu,
  Database,
  Fullscreen,
  HardDrive,
  Info,
  Keyboard,
  Lock,
  Monitor,
  Moon,
  MousePointer2,
  Palette,
  RotateCcw,
  Smartphone,
  Sparkles,
  Sun,
  Volume2,
  Wallpaper,
} from "lucide-react";
import { ACCENTS, WALLPAPERS, formatBytes, useOS, wallpaperStyle } from "../OSContext";
import type { AccentId, AppContentProps } from "../types";
import { AppIcon } from "../icons";
import { Segmented, Slider, ToggleRow } from "../ui";
import { cn } from "@/utils/cn";

type Section = "personalization" | "display" | "sound" | "mouse" | "keyboard" | "system";

const SECTIONS: { id: Section; label: string; icon: typeof Palette }[] = [
  { id: "personalization", label: "Personalization", icon: Palette },
  { id: "display", label: "Display", icon: Monitor },
  { id: "sound", label: "Sound & notifications", icon: Volume2 },
  { id: "mouse", label: "Pointer & touchpad", icon: MousePointer2 },
  { id: "keyboard", label: "Keyboard", icon: Keyboard },
  { id: "system", label: "System & about", icon: Cpu },
];

function SettingsCard({ children, title, description, icon }: { children: ReactNode; title: string; description?: string; icon?: ReactNode }) {
  return (
    <section className="mb-2.5 rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
      <div className="mb-2.5 flex items-start gap-2">
        {icon ? <span className="mt-0.5" style={{ color: "var(--accent)" }}>{icon}</span> : null}
        <div>
          <div className="text-[12px] font-semibold leading-tight">{title}</div>
          {description ? <div className="mt-0.5 text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>{description}</div> : null}
        </div>
      </div>
      {children}
    </section>
  );
}

const SHORTCUTS: [string, string][] = [
  ["Win / Ctrl + Esc", "Open Start"],
  ["Win + D", "Show desktop / restore"],
  ["Win + E", "Open Files"],
  ["Win + ← / →", "Snap window left or right"],
  ["Win + ↑ / ↓", "Maximize / restore"],
  ["Alt + Tab", "Switch between applications"],
  ["Alt + F4", "Close active window"],
  ["F2", "Rename selected item"],
  ["Delete", "Move selection to Recycle Bin"],
  ["Enter", "Open selected item"],
  ["F5", "Refresh"],
  ["Ctrl + S", "Save in Notes"],
  ["Ctrl + C / X / V", "Copy / cut / paste in Files"],
  ["Esc", "Close menus and cancel"],
];

export default function SettingsApp({ payload }: AppContentProps) {
  const {
    settings,
    updateSettings,
    resetSettings,
    launch,
    showConfirm,
    showInfo,
    notify,
    files,
    notes,
    trash,
    bootTime,
    openPhoneController,
    restartDesktop,
    factoryReset,
    lock,
    soundClick,
  } = useOS();
  const requested = payload?.section;
  const [section, setSection] = useState<Section>(
    typeof requested === "string" && SECTIONS.some((s) => s.id === requested) ? (requested as Section) : "personalization",
  );
  const [displaySize, setDisplaySize] = useState({ w: window.innerWidth, h: window.innerHeight });
  const [fullscreen, setFullscreen] = useState(Boolean(document.fullscreenElement));
  const [uptime, setUptime] = useState(Math.floor((Date.now() - bootTime) / 1000));

  useEffect(() => {
    if (typeof requested === "string" && SECTIONS.some((s) => s.id === requested)) setSection(requested as Section);
  }, [requested]);

  useEffect(() => {
    const onResize = () => setDisplaySize({ w: window.innerWidth, h: window.innerHeight });
    const onFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    window.addEventListener("resize", onResize);
    document.addEventListener("fullscreenchange", onFullscreen);
    const timer = window.setInterval(() => setUptime(Math.floor((Date.now() - bootTime) / 1000)), 1000);
    return () => {
      window.removeEventListener("resize", onResize);
      document.removeEventListener("fullscreenchange", onFullscreen);
      window.clearInterval(timer);
    };
  }, [bootTime]);

  const totalBytes = files.filter((f) => f.kind !== "folder").reduce((sum, f) => sum + f.size, 0);
  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      notify("Fullscreen unavailable", "The host WebView blocked the fullscreen request. Use the Android display controls instead.", { tone: "error" });
    }
  };

  const uptimeLabel = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m ${uptime % 60}s`;

  return (
    <div className="flex h-full min-h-0" style={{ background: "var(--surface-solid)" }}>
      <aside className="flex w-[202px] shrink-0 flex-col" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <div className="px-3 pt-3 pb-2.5">
          <div className="flex items-center gap-2">
            <AppIcon id="settings" size={28} />
            <div>
              <div className="text-[12.5px] font-semibold leading-tight">Settings</div>
              <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>KK DEX OS 1.0</div>
            </div>
          </div>
        </div>
        <div className="scroll-thin flex-1 overflow-y-auto px-1.5">
          {SECTIONS.map((item) => {
            const Icon = item.icon;
            return (
              <button key={item.id} className={cn("sidebar-item mb-0.5", section === item.id && "active")} onClick={() => setSection(item.id)}>
                <Icon size={15} strokeWidth={1.9} style={{ color: section === item.id ? "var(--accent)" : undefined }} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
        <div className="p-2">
          <button
            className="sidebar-item"
            onClick={() => showInfo("About this interface", "KK DEX Desktop is a React-based operating environment designed for an external TV or monitor. Window state is session-local; files, notes and preferences persist in this browser workspace.", <Info size={14} />)}
          >
            <Info size={14} /> About this interface
          </button>
        </div>
      </aside>

      <div className="scroll-thin min-w-0 flex-1 overflow-y-auto p-3.5">
        <div className="mb-3 flex items-center gap-2">
          <div>
            <h2 className="text-[15px] font-semibold tracking-tight">{SECTIONS.find((s) => s.id === section)?.label}</h2>
            <p className="text-[9.5px]" style={{ color: "var(--muted)" }}>
              Changes apply immediately and persist on this device.
            </p>
          </div>
          <span className="ml-auto flex items-center gap-1 rounded-full px-2 py-1 text-[8.5px]" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
            <Check size={9} /> Saved automatically
          </span>
        </div>

        {section === "personalization" ? (
          <div className="fade-in">
            <SettingsCard title="Background" description="Choose a desktop wallpaper. Images load from local KK DEX assets." icon={<Wallpaper size={15} />}>
              <div className="grid grid-cols-5 gap-2">
                {WALLPAPERS.map((wallpaper) => {
                  const active = settings.wallpaper === wallpaper.id;
                  return (
                    <button
                      key={wallpaper.id}
                      className="group relative overflow-hidden rounded-lg text-left"
                      style={{ outline: active ? `2px solid var(--accent)` : "1px solid var(--border)", outlineOffset: active ? 1 : -1 }}
                      onClick={() => {
                        updateSettings({ wallpaper: wallpaper.id });
                        notify("Wallpaper applied", `${wallpaper.name} is now your desktop background.`, { silent: true, tone: "success" });
                      }}
                    >
                      <div style={{ height: 52, ...wallpaperStyle(wallpaper.id), backgroundSize: "cover" }} />
                      <div className="px-1.5 py-1.5">
                        <div className="truncate text-[9.5px] font-medium leading-tight">{wallpaper.name}</div>
                        <div className="truncate text-[8px]" style={{ color: "var(--faint)" }}>{wallpaper.note}</div>
                      </div>
                      {active ? (
                        <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full" style={{ background: "var(--accent)", color: "#fff" }}>
                          <Check size={10} />
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </SettingsCard>

            <div className="mb-2.5 grid gap-2.5 sm:grid-cols-2">
              <SettingsCard title="Theme" description="Window, menu and panel appearance." icon={<Moon size={15} />}>
                <div className="grid grid-cols-2 gap-2">
                  {(["dark", "light"] as const).map((mode) => (
                    <button
                      key={mode}
                      className="rounded-lg p-1.5 text-left"
                      style={{ border: `1px solid ${settings.theme === mode ? "var(--accent)" : "var(--border)"}`, background: "var(--surface-solid)" }}
                      onClick={() => updateSettings({ theme: mode })}
                    >
                      <div className="mb-1.5 h-12 overflow-hidden rounded-md" style={{ background: mode === "dark" ? "#171b26" : "#f5f8fc", border: "1px solid var(--border)" }}>
                        <div className="m-1.5 rounded p-1" style={{ background: mode === "dark" ? "#242b39" : "#ffffff", height: 30, boxShadow: "0 1px 2px rgba(0,0,0,.1)" }}>
                          <div className="h-1 w-1/2 rounded-full" style={{ background: mode === "dark" ? "#5f6d84" : "#aabbd0" }} />
                          <div className="mt-1 h-1 w-2/3 rounded-full" style={{ background: mode === "dark" ? "#39465a" : "#dbe4ef" }} />
                        </div>
                      </div>
                      <div className="flex items-center justify-between px-0.5 pb-0.5">
                        <span className="text-[10px] font-medium capitalize">{mode}</span>
                        {settings.theme === mode ? <Check size={11} style={{ color: "var(--accent)" }} /> : null}
                      </div>
                    </button>
                  ))}
                </div>
              </SettingsCard>
              <SettingsCard title="Accent color" description="Used by highlights, controls and focus rings." icon={<Palette size={15} />}>
                <div className="flex flex-wrap gap-2 pt-1">
                  {(Object.keys(ACCENTS) as AccentId[]).map((accent) => (
                    <button
                      key={accent}
                      title={ACCENTS[accent].name}
                      className="flex h-7 w-7 items-center justify-center rounded-full transition-transform hover:scale-110"
                      style={{ background: ACCENTS[accent].hex, outline: settings.accent === accent ? "2px solid var(--text)" : "none", outlineOffset: 2 }}
                      onClick={() => updateSettings({ accent })}
                    >
                      {settings.accent === accent ? <Check size={13} color="#fff" /> : null}
                    </button>
                  ))}
                </div>
                <div className="mt-2 text-[9px]" style={{ color: "var(--faint)" }}>{ACCENTS[settings.accent].name}</div>
              </SettingsCard>
            </div>

            <SettingsCard title="Desktop" description="Icon density and motion preferences." icon={<Sparkles size={15} />}>
              <div className="flex items-center justify-between py-1.5">
                <div>
                  <div className="text-[11.5px] font-medium">Desktop icon size</div>
                  <div className="text-[9px]" style={{ color: "var(--muted)" }}>Affects spacing and icon dimensions on the desktop.</div>
                </div>
                <Segmented
                  size="sm"
                  value={settings.iconSize}
                  onChange={(iconSize) => updateSettings({ iconSize })}
                  options={[
                    { value: "small", label: "S" },
                    { value: "medium", label: "M" },
                    { value: "large", label: "L" },
                  ]}
                />
              </div>
              <div className="divider my-1" />
              <ToggleRow title="Reduce motion" description="Minimize window and menu animation." checked={settings.reduceMotion} onChange={(reduceMotion) => updateSettings({ reduceMotion })} />
            </SettingsCard>
          </div>
        ) : null}

        {section === "display" ? (
          <div className="fade-in">
            <SettingsCard title="Display" description="The desktop automatically fills the available host display." icon={<Monitor size={15} />}>
              <div className="mb-2 flex items-center gap-2 rounded-lg p-2.5" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}>
                <div className="flex h-12 w-[72px] items-center justify-center rounded border-2" style={{ borderColor: "var(--accent)", background: "var(--field)" }}>
                  <span className="font-mono text-[8.5px]">{displaySize.w} × {displaySize.h}</span>
                </div>
                <div>
                  <div className="text-[11.5px] font-medium">KK DEX external display</div>
                  <div className="text-[9px]" style={{ color: "var(--muted)" }}>
                    CSS viewport {displaySize.w} × {displaySize.h} · DPR {window.devicePixelRatio.toFixed(1)}
                  </div>
                  <div className="text-[9px]" style={{ color: "var(--muted)" }}>Taskbar reserves {64}px · windows are clamped to the workspace</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="btn btn-sm" onClick={toggleFullscreen}>
                  <Fullscreen size={12} /> {fullscreen ? "Exit fullscreen" : "Enter fullscreen"}
                </button>
                <span className="text-[9px]" style={{ color: "var(--faint)" }}>Fullscreen is subject to host WebView permission.</span>
              </div>
            </SettingsCard>
            <SettingsCard title="Brightness" description="Applies a display dimming layer to the desktop." icon={<Sun size={15} />}>
              <div className="flex items-center gap-3">
                <Sun size={13} style={{ color: "var(--faint)" }} />
                <Slider value={settings.brightness} min={45} max={100} onChange={(brightness) => updateSettings({ brightness })} label="Display brightness" />
                <span className="w-8 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.brightness}%</span>
              </div>
            </SettingsCard>
            <SettingsCard title="Comfort" description="Visual aids applied across the entire desktop." icon={<Moon size={15} />}>
              <ToggleRow title="Night light" description="Warm color filter to reduce blue light." checked={settings.nightLight} onChange={(nightLight) => updateSettings({ nightLight })} />
              <ToggleRow title="Reduce motion" description="Disable most menu and window transitions." checked={settings.reduceMotion} onChange={(reduceMotion) => updateSettings({ reduceMotion })} />
              <ToggleRow title="Reduce icon size" description="Use compact desktop shortcuts." checked={settings.iconSize === "small"} onChange={(on) => updateSettings({ iconSize: on ? "small" : "medium" })} />
            </SettingsCard>
          </div>
        ) : null}

        {section === "sound" ? (
          <div className="fade-in">
            <SettingsCard title="System sound" description="Short UI tones for supported desktop interactions." icon={<Volume2 size={15} />}>
              <ToggleRow title="System sounds" description="Play subtle feedback for supported desktop actions." checked={settings.sound} onChange={(sound) => updateSettings({ sound })} />
              <div className="flex items-center gap-3 py-2">
                <Volume2 size={13} style={{ color: "var(--faint)" }} />
                <Slider value={settings.volume} onChange={(volume) => updateSettings({ volume, muted: false })} label="Volume" />
                <span className="w-8 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.volume}%</span>
              </div>
              <div className="flex items-center gap-2">
                <button className="btn btn-sm" disabled={!settings.sound || settings.muted} onClick={soundClick}>Play test sound</button>
                <button className="btn btn-sm" onClick={() => { updateSettings({ muted: !settings.muted }); }}>{settings.muted ? "Unmute KK DEX" : "Mute KK DEX"}</button>
              </div>
              <div className="mt-2.5 text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>
                Browser security prevents changing host speaker volume. This controls KK DEX interface sounds only.
              </div>
            </SettingsCard>
            <SettingsCard title="Notifications" description="Control desktop alerts and toast banners." icon={<Bell size={15} />}>
              <ToggleRow title="Do not disturb" description="Silence toast banners. Notifications remain available in the notification center." checked={settings.doNotDisturb} onChange={(doNotDisturb) => updateSettings({ doNotDisturb })} />
              <div className="mt-1.5">
                <button
                  className="btn btn-sm"
                  onClick={() =>
                    notify("Notification test", "Desktop notifications are working in this workspace.", { tone: "success" })
                  }
                >
                  Send test notification
                </button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "mouse" ? (
          <div className="fade-in">
            <SettingsCard title="Phone controller pointer" description="The TV uses the host's native mouse cursor. These options tune the remote Android pointer." icon={<MousePointer2 size={15} />}>
              <div className="flex items-center gap-3 py-2">
                <span className="text-[10.5px]">Pointer speed</span>
                <Slider value={settings.pointerSpeed} min={1} max={10} onChange={(pointerSpeed) => updateSettings({ pointerSpeed })} label="Pointer speed" />
                <span className="w-7 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.pointerSpeed}</span>
              </div>
              <div className="flex items-center gap-3 py-2">
                <span className="text-[10.5px]">Pointer size</span>
                <Slider value={settings.pointerSize} min={1} max={6} onChange={(pointerSize) => updateSettings({ pointerSize })} label="Pointer size" />
                <span className="w-7 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.pointerSize}</span>
              </div>
              <ToggleRow title="Click effects" description="Show a visible click ripple on the TV from phone input." checked={settings.clickEffects} onChange={(clickEffects) => updateSettings({ clickEffects })} />
              <div className="mt-1.5 flex flex-wrap gap-2">
                <button className="btn btn-sm btn-accent" onClick={openPhoneController}><Smartphone size={12} /> Open phone controller</button>
                <button className="btn btn-sm" onClick={() => launch("phone")}><Info size={12} /> Pairing guide</button>
              </div>
            </SettingsCard>
            <SettingsCard title="How pointer input works" description="The phone never renders a duplicate desktop." icon={<MousePointer2 size={15} />}>
              <div className="space-y-1.5 text-[10px] leading-relaxed" style={{ color: "var(--muted)" }}>
                <p>The Android controller sends pointer positions through the KKDexAPI bridge. The TV translates each position into an actual pointer event using <code className="font-mono">elementFromPoint</code>.</p>
                <p>Hover, click, double-click, right-click, scroll and text insertion therefore reach real HTML controls, not a decorative overlay.</p>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "keyboard" ? (
          <div className="fade-in">
            <SettingsCard title="Keyboard shortcuts" description="Shortcuts are handled globally unless focus is inside a text field." icon={<Keyboard size={15} />}>
              <div className="overflow-hidden rounded-lg" style={{ border: "1px solid var(--border)" }}>
                {SHORTCUTS.map(([keys, label], index) => (
                  <div key={keys} className="flex items-center justify-between px-2.5 py-1.5 text-[10.5px]" style={{ background: index % 2 ? "var(--field)" : "transparent" }}>
                    <span className="flex flex-wrap gap-1">{keys.split(" + ").map((key) => <kbd key={key} className="kbd">{key}</kbd>)}</span>
                    <span style={{ color: "var(--muted)" }}>{label}</span>
                  </div>
                ))}
              </div>
            </SettingsCard>
            <SettingsCard title="Text input from your phone" description="Use the controller keyboard to type into the focused desktop field." icon={<Smartphone size={15} />}>
              <p className="text-[10px] leading-relaxed" style={{ color: "var(--muted)" }}>
                Tap a desktop text field first, then use the phone's keyboard panel. Text is inserted through the same bridge handlers used by Android's <code className="font-mono">insertText</code> and <code className="font-mono">pressKey</code> calls.
              </p>
              <div className="mt-2 flex gap-2">
                <button className="btn btn-sm btn-accent" onClick={openPhoneController}><Smartphone size={12} /> Open controller</button>
                <button
                  className="btn btn-sm"
                  onClick={() => showInfo("Keyboard bridge", "The desktop exposes KKDexAPI-compatible handlers including insertText(text), pressKey(key, modifiers), movePointer(x,y), pointerClick(), scrollDesktop(delta), and getState(). They operate on the real DOM.", <Keyboard size={24} />)}
                >
                  Bridge details
                </button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "system" ? (
          <div className="fade-in">
            <div className="mb-2.5 flex items-center gap-3 rounded-xl p-3" style={{ background: "linear-gradient(120deg, rgba(var(--accent-rgb),.17), var(--surface-2))", border: "1px solid var(--border)" }}>
              <AppIcon id="thispc" size={48} />
              <div>
                <div className="text-[14px] font-semibold">KK DEX Station</div>
                <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>Desktop build 1.0.0 · external display session</div>
                <div className="mt-1 flex flex-wrap gap-1">
                  <span className="badge badge-accent">OS 1.0</span>
                  <span className="badge">React desktop</span>
                  <span className="badge">KKDexAPI receiver</span>
                </div>
              </div>
            </div>
            <div className="mb-2.5 grid grid-cols-3 gap-2">
              <div className="rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>UPTIME</div>
                <div className="mt-0.5 truncate font-mono text-[11px]">{uptimeLabel}</div>
              </div>
              <div className="rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>WORKSPACE</div>
                <div className="mt-0.5 font-mono text-[11px]">{formatBytes(totalBytes)}</div>
              </div>
              <div className="rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>CONTENT</div>
                <div className="mt-0.5 font-mono text-[11px]">{notes.length} notes · {trash.length} trash</div>
              </div>
            </div>
            <SettingsCard title="Device & bridge" icon={<Cpu size={15} />}>
              <dl className="space-y-1.5 text-[10px]">
                {[
                  ["Display", `${displaySize.w} × ${displaySize.h} CSS px`],
                  ["Logical cores", String(navigator.hardwareConcurrency ?? "Not reported")],
                  ["Platform", navigator.platform || "External WebView"],
                  ["Network", navigator.onLine ? "Host reports online" : "Host reports offline"],
                  ["Bridge", typeof window !== "undefined" && "KKDexAPI" in window ? "KKDexAPI receiver active" : "Local browser session"],
                  ["Storage", "Browser workspace (persistent)"],
                ].map(([key, value]) => (
                  <div key={key} className="flex items-start justify-between gap-3">
                    <dt style={{ color: "var(--muted)" }}>{key}</dt>
                    <dd className="text-right">{value}</dd>
                  </div>
                ))}
              </dl>
            </SettingsCard>
            <SettingsCard title="Storage" description="Sample workspace consumption; host Android storage is not exposed through the bridge." icon={<Database size={15} />}>
              <div className="flex items-center justify-between text-[10px]">
                <span className="flex items-center gap-1.5"><HardDrive size={12} /> {files.filter((f) => f.kind !== "folder").length} files</span>
                <span style={{ color: "var(--muted)" }}>{formatBytes(totalBytes)} of 256 MB shown</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}>
                <div className="h-full rounded-full" style={{ width: `${Math.min(100, Math.max(2, (totalBytes / (256 * 1024 * 1024)) * 100))}%`, background: "var(--accent)" }} />
              </div>
              <button className="btn btn-sm mt-2.5" onClick={() => launch("files")}><HardDrive size={12} /> Open storage workspace</button>
            </SettingsCard>
            <SettingsCard title="Session actions" description="These operations affect this desktop workspace." icon={<RotateCcw size={15} />}>
              <div className="flex flex-wrap gap-2">
                <button className="btn btn-sm" onClick={lock}><Lock size={12} /> Lock screen</button>
                <button className="btn btn-sm" onClick={() => showConfirm("Restart desktop session?", "Open windows will be closed and the workspace reloaded. Your files and settings are preserved.", restartDesktop, "Restart session")}>
                  <RotateCcw size={12} /> Restart session
                </button>
                <button className="btn btn-sm" onClick={() => showConfirm("Reset preferences?", "Theme, wallpaper, accent, pointer and sound preferences will return to defaults. Files and notes are kept.", resetSettings, "Reset preferences")}>
                  <Palette size={12} /> Reset preferences
                </button>
                <button className="btn btn-sm btn-danger" onClick={() => showConfirm("Reset all KK DEX data?", "This permanently removes workspace files, notes, deleted items, settings and notifications. This cannot be undone.", factoryReset, "Erase workspace")}>
                  Reset workspace
                </button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        <div className="mt-2 flex items-center gap-1.5 text-[8.5px]" style={{ color: "var(--faint)" }}>
          <Info size={10} />
          Controls in this build perform real local actions. Host-level operations that are unavailable are identified as such.
          <button className="ml-auto flex items-center gap-1 hover:underline" onClick={openPhoneController}><Smartphone size={10} /> Phone controller</button>
        </div>
      </div>
    </div>
  );
}
