import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Globe,
  Heart,
  Home,
  Images,
  Info,
  Loader2,
  Lock,
  Maximize2,
  Mic,
  MicOff,
  MoreHorizontal,
  Plus,
  RotateCw,
  Search,
  Send,
  Settings2,
  Sparkles,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { AppIcon } from "../icons";
import { formatBytes, formatTime, GALLERY_IMAGES, useOS } from "../OSContext";
import type { AppContentProps, AppId } from "../types";
import { EmptyState, Segmented } from "../ui";
import { cn } from "@/utils/cn";
import { APP_METAS } from "../appMeta";

/* --------------------------------- Browser -------------------------------- */

const START_URL = "kkdex://start";
const QUICK_SITES = [
  { name: "Wikipedia", url: "https://www.wikipedia.org", note: "Free encyclopedia", color: "#8fa3b8" },
  { name: "MDN Web Docs", url: "https://developer.mozilla.org", note: "Web platform reference", color: "#4f8cff" },
  { name: "GitHub", url: "https://github.com", note: "Code and collaboration", color: "#a78bfa" },
  { name: "Pexels", url: "https://www.pexels.com", note: "Photography community", color: "#2cc9a0" },
  { name: "Vite", url: "https://vitejs.dev", note: "Frontend tooling", color: "#b886ff" },
  { name: "Lucide", url: "https://lucide.dev", note: "Icon toolkit", color: "#f7c45c" },
];

interface BrowserTab {
  id: string;
  title: string;
  url: string;
  history: string[];
  index: number;
  reloadKey: number;
}

function makeTab(url = START_URL): BrowserTab {
  return {
    id: `tab-${Math.random().toString(36).slice(2, 9)}`,
    title: "New tab",
    url,
    history: [url],
    index: 0,
    reloadKey: 0,
  };
}

export function BrowserApp({ payload }: AppContentProps) {
  const { showInfo, openMenu, launch, notify } = useOS();
  const initialUrl = typeof payload?.url === "string" ? payload.url : START_URL;
  const [tabs, setTabs] = useState<BrowserTab[]>([makeTab(initialUrl)]);
  const [activeId, setActiveId] = useState(() => tabs[0].id);
  const [address, setAddress] = useState(initialUrl === START_URL ? "" : initialUrl);
  const [addressFocused, setAddressFocused] = useState(false);
  const [loading, setLoading] = useState(false);
  const active = tabs.find((tab) => tab.id === activeId) ?? tabs[0];
  const addressRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setAddress(active.url === START_URL ? "" : active.url);
    setLoading(active.url !== START_URL);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active.url, activeId]);

  useEffect(() => {
    if (typeof payload?.url === "string") navigateTo(payload.url, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payload?.url]);

  const updateActive = (patch: Partial<BrowserTab>) => {
    setTabs((prev) => prev.map((tab) => (tab.id === activeId ? { ...tab, ...patch } : tab)));
  };

  const titleForUrl = (url: string) => {
    if (url === START_URL) return "New tab";
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch {
      return "Page";
    }
  };

  const navigateTo = (url: string, push = true) => {
    if (!url.trim()) return;
    const tab = tabs.find((t) => t.id === activeId);
    if (!tab) return;
    const history = push ? [...tab.history.slice(0, tab.index + 1), url] : tab.history;
    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeId
          ? { ...t, url, title: titleForUrl(url), history, index: push ? history.length - 1 : t.index, reloadKey: t.reloadKey + 1 }
          : t,
      ),
    );
    setAddress(url === START_URL ? "" : url);
    setLoading(url !== START_URL);
  };

  const normalize = (raw: string) => {
    const value = raw.trim();
    if (!value) return START_URL;
    if (value === START_URL || value.startsWith("kkdex://")) return START_URL;
    if (/^https?:\/\//i.test(value)) return value;
    if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/.test(value)) return `https://${value}`;
    return `https://www.bing.com/search?q=${encodeURIComponent(value)}`;
  };

  const submitAddress = () => {
    const target = normalize(address);
    navigateTo(target);
    setAddressFocused(false);
    addressRef.current?.blur();
  };

  const newTab = () => {
    const tab = makeTab();
    setTabs((prev) => [...prev, tab]);
    setActiveId(tab.id);
    setAddress("");
    setLoading(false);
  };

  const closeTab = (id: string) => {
    setTabs((prev) => {
      const index = prev.findIndex((t) => t.id === id);
      const next = prev.filter((t) => t.id !== id);
      if (next.length === 0) {
        const fresh = makeTab();
        setActiveId(fresh.id);
        return [fresh];
      }
      if (id === activeId) {
        const target = next[Math.max(0, index - 1)];
        setActiveId(target.id);
      }
      return next;
    });
  };

  const goBack = () => {
    if (active.index <= 0) return;
    const index = active.index - 1;
    const url = active.history[index];
    updateActive({ index, url, title: titleForUrl(url), reloadKey: active.reloadKey + 1 });
    setAddress(url === START_URL ? "" : url);
  };
  const goForward = () => {
    if (active.index >= active.history.length - 1) return;
    const index = active.index + 1;
    const url = active.history[index];
    updateActive({ index, url, title: titleForUrl(url), reloadKey: active.reloadKey + 1 });
    setAddress(url === START_URL ? "" : url);
  };

  const externalOpen = () => {
    const url = active.url === START_URL ? "https://www.bing.com" : active.url;
    const popup = window.open(url, "_blank", "noopener,noreferrer");
    if (!popup) notify("Pop-up blocked", "Allow pop-ups to open this page in a separate browser tab.", { tone: "error" });
  };

  const browserMenu = (event: React.MouseEvent) => {
    event.preventDefault();
    openMenu(event.clientX, event.clientY, [
      { label: "New tab", icon: <Plus size={14} />, action: newTab },
      { label: "Reload", icon: <RotateCw size={14} />, action: () => navigateTo(active.url, false) },
      { label: "Open page externally", icon: <ExternalLink size={14} />, action: externalOpen },
      { separator: true },
      {
        label: "Copy page address",
        icon: <Lock size={14} />,
        disabled: active.url === START_URL,
        action: async () => {
          try {
            await navigator.clipboard.writeText(active.url);
            notify("Address copied", active.url, { tone: "success", silent: true });
          } catch {
            notify("Clipboard unavailable", "Clipboard permission was denied by the host.", { tone: "error" });
          }
        },
      },
      { label: "Downloads folder", icon: <ArrowRight size={14} />, action: () => launch("files", { payload: { folderId: "downloads" } }) },
      { separator: true },
      {
        label: "Embedding limits",
        icon: <Info size={14} />,
        action: () =>
          showInfo(
            "About the KK DEX browser",
            "Pages load in a sandboxed web view. Many sites send X-Frame-Options or CSP headers that prevent embedding. When a page refuses to render, use “Open page externally” to open it in the host's browser. Browser history and tabs are session-local.",
            <Globe size={26} />,
          ),
      },
    ]);
  };

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-end gap-1 px-2 pt-1.5" style={{ background: "var(--surface-2)" }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={cn("group relative flex h-[30px] max-w-[180px] min-w-[108px] items-center gap-1.5 rounded-t-lg px-2 text-left text-[10.5px]", tab.id === activeId ? "bg-[var(--surface-solid)]" : "opacity-70 hover:opacity-100")}
            style={{ border: "1px solid var(--border)", borderBottom: tab.id === activeId ? "1px solid var(--surface-solid)" : "1px solid var(--border)" }}
            onClick={() => setActiveId(tab.id)}
            onAuxClick={(event) => {
              if (event.button === 1) closeTab(tab.id);
            }}
          >
            {tab.url === START_URL ? <Search size={11} style={{ color: "var(--muted)" }} /> : <Globe size={11} style={{ color: "var(--accent)" }} />}
            <span className="min-w-0 flex-1 truncate">{tab.title}</span>
            <span
              role="button"
              tabIndex={0}
              aria-label={`Close ${tab.title}`}
              className="flex h-4 w-4 shrink-0 items-center justify-center rounded opacity-0 hover:bg-[var(--hover)] group-hover:opacity-100"
              onClick={(event) => {
                event.stopPropagation();
                closeTab(tab.id);
              }}
            >
              <X size={10} />
            </span>
          </button>
        ))}
        <button className="icon-btn mb-1 h-6 w-6" aria-label="New tab" onClick={newTab}><Plus size={13} /></button>
      </div>

      <div className="flex items-center gap-1 px-2 py-1.5" style={{ borderBottom: "1px solid var(--border)" }}>
        <button className="icon-btn h-7 w-7" aria-label="Back" disabled={active.index <= 0} onClick={goBack}><ArrowLeft size={14} /></button>
        <button className="icon-btn h-7 w-7" aria-label="Forward" disabled={active.index >= active.history.length - 1} onClick={goForward}><ArrowRight size={14} /></button>
        <button className="icon-btn h-7 w-7" aria-label="Reload" onClick={() => { setLoading(active.url !== START_URL); updateActive({ reloadKey: active.reloadKey + 1 }); }}>
          <RotateCw size={13} />
        </button>
        <button className="icon-btn h-7 w-7" aria-label="Home" onClick={() => navigateTo(START_URL)}><Home size={13} /></button>
        <div
          className={cn("flex h-7 min-w-0 flex-1 items-center gap-1.5 rounded-full px-2.5 transition-all", addressFocused && "ring-2")}
          style={{ background: "var(--field)", border: "1px solid var(--border)", boxShadow: addressFocused ? "0 0 0 3px rgba(var(--accent-rgb),.12)" : undefined }}
        >
          {active.url === START_URL ? <Search size={12} style={{ color: "var(--faint)" }} /> : <Lock size={11} style={{ color: "var(--success)" }} />}
          <input
            ref={addressRef}
            value={address}
            placeholder="Search the web or enter an address"
            className="min-w-0 flex-1 border-0 bg-transparent text-[11.5px] outline-none placeholder:text-[var(--faint)]"
            onChange={(event) => setAddress(event.target.value)}
            onFocus={(event) => {
              setAddressFocused(true);
              event.target.select();
            }}
            onBlur={() => setAddressFocused(false)}
            onKeyDown={(event) => {
              if (event.key === "Enter") submitAddress();
              if (event.key === "Escape") {
                setAddress(active.url === START_URL ? "" : active.url);
                event.currentTarget.blur();
              }
            }}
          />
          {loading ? <Loader2 size={11} className="animate-spin" style={{ color: "var(--muted)" }} /> : null}
          <button className="icon-btn h-5 w-5" aria-label="Browser options" onClick={browserMenu}><MoreHorizontal size={12} /></button>
        </div>
        <button className="icon-btn h-7 w-7" title="Downloads" onClick={() => launch("files", { payload: { folderId: "downloads" } })}>
          <ArrowRight size={13} />
        </button>
        <button className="icon-btn h-7 w-7" title="Open page outside the desktop" onClick={externalOpen}><ExternalLink size={13} /></button>
      </div>

      <div className="flex h-7 shrink-0 items-center gap-1 px-2" style={{ background: "var(--surface-2)", borderBottom: "1px solid var(--border)" }}>
        <Star size={10} style={{ color: "var(--faint)" }} />
        {QUICK_SITES.slice(0, 5).map((site) => (
          <button
            key={site.url}
            className="truncate rounded px-1.5 py-0.5 text-[9.5px] hover:bg-[var(--hover)]"
            style={{ color: "var(--muted)" }}
            onClick={() => navigateTo(site.url)}
          >
            {site.name}
          </button>
        ))}
        <button
          className="ml-auto flex items-center gap-1 text-[9px] hover:underline"
          style={{ color: "var(--faint)" }}
          onClick={() =>
            showInfo(
              "Browser network",
              navigator.onLine
                ? "The host reports an active network connection. Websites may still refuse to be embedded for security reasons."
                : "The host reports that it is offline. Only the local KK DEX start page is available.",
              <Globe size={26} />,
            )
          }
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: navigator.onLine ? "var(--success)" : "var(--danger)" }} />
          {navigator.onLine ? "Online" : "Offline"}
        </button>
      </div>

      <div className="relative min-h-0 flex-1" style={{ background: "#fff" }}>
        {active.url === START_URL ? (
          <div className="scroll-thin h-full overflow-y-auto" style={{ background: "var(--surface-solid)" }}>
            <div className="mx-auto flex max-w-[720px] flex-col items-center px-6 pt-10 pb-6">
              <div className="mb-4 flex items-center gap-3">
                <AppIcon id="browser" size={40} />
                <div>
                  <div className="text-[19px] font-semibold tracking-tight">KK Browse</div>
                  <div className="text-[10px]" style={{ color: "var(--muted)" }}>A clean window to the web</div>
                </div>
              </div>
              <div className="mb-6 flex w-full max-w-[460px] items-center gap-2 rounded-full px-3.5 py-2.5" style={{ background: "var(--field)", border: "1px solid var(--border-strong)", boxShadow: "0 8px 24px -16px rgba(0,0,0,.4)" }}>
                <Search size={14} style={{ color: "var(--muted)" }} />
                <input
                  className="min-w-0 flex-1 border-0 bg-transparent text-[12px] outline-none placeholder:text-[var(--faint)]"
                  placeholder="Search the web with Bing"
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      const value = event.currentTarget.value;
                      if (value.trim()) navigateTo(`https://www.bing.com/search?q=${encodeURIComponent(value.trim())}`);
                    }
                  }}
                />
                <span className="rounded px-1.5 py-0.5 text-[8.5px]" style={{ background: "var(--active)", color: "var(--muted)" }}>Enter</span>
              </div>
              <div className="grid w-full grid-cols-2 gap-2 sm:grid-cols-3">
                {QUICK_SITES.map((site) => (
                  <button
                    key={site.url}
                    className="group flex items-start gap-2.5 rounded-xl p-3 text-left transition-all hover:-translate-y-0.5"
                    style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}
                    onClick={() => navigateTo(site.url)}
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style={{ background: `${site.color}20`, color: site.color }}>
                      <Globe size={15} />
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-[11px] font-medium">{site.name}</span>
                      <span className="block truncate text-[9px]" style={{ color: "var(--muted)" }}>{site.note}</span>
                    </span>
                  </button>
                ))}
              </div>
              <div className="mt-5 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-[9.5px]" style={{ background: "var(--field)", color: "var(--muted)" }}>
                <Lock size={10} />
                Pages load in a sandboxed view. Some sites block embedding and can be opened externally.
              </div>
            </div>
          </div>
        ) : (
          <div className="flex h-full flex-col">
            {!navigator.onLine ? (
              <div className="flex items-center gap-2 px-3 py-1.5 text-[10px]" style={{ background: "rgba(245,158,11,.12)", color: "var(--text)", borderBottom: "1px solid var(--border)" }}>
                <Info size={11} /> Host is offline. This page may not load.
              </div>
            ) : null}
            <div className="relative min-h-0 flex-1">
              <iframe
                key={`${active.id}-${active.reloadKey}-${active.url}`}
                src={active.url}
                title={active.title}
                className="h-full w-full border-0"
                style={{ background: "#fff" }}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
                referrerPolicy="no-referrer-when-downgrade"
                onLoad={() => setLoading(false)}
              />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center p-3">
                <div className="pointer-events-auto flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[9.5px]" style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--muted)", boxShadow: "var(--shadow-menu)", backdropFilter: "blur(16px)" }}>
                  <Info size={10} /> Page blank or refused?{" "}
                  <button className="font-medium hover:underline" style={{ color: "var(--accent)" }} onClick={externalOpen}>
                    Open externally
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <div className="flex h-6 shrink-0 items-center justify-between gap-3 px-3 text-[9px]" style={{ background: "var(--surface-2)", borderTop: "1px solid var(--border)", color: "var(--faint)" }}>
        <span className="truncate">Tabs are session-local · no browser data leaves the desktop</span>
        <span>{tabs.length} tab{tabs.length === 1 ? "" : "s"}</span>
      </div>
    </div>
  );
}

/* ---------------------------------- Gallery -------------------------------- */

const FAVORITES_KEY = "kkdex.galleryFavorites";

export function GalleryApp({ payload }: AppContentProps) {
  const { notify } = useOS();
  const payloadSrc = typeof payload?.imageSrc === "string" ? payload.imageSrc : null;
  const payloadName = typeof payload?.imageName === "string" ? payload.imageName : "Workspace image";
  const images = useMemo(() => {
    const base = GALLERY_IMAGES.map((image) => ({ ...image, source: "Sample collection" }));
    if (payloadSrc && !base.some((image) => image.src === payloadSrc)) {
      base.unshift({ id: "workspace-image", name: payloadName, src: payloadSrc, meta: "From your workspace", source: "Workspace" });
    }
    return base;
  }, [payloadSrc, payloadName]);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(FAVORITES_KEY) ?? "[]") as string[];
    } catch {
      return [];
    }
  });
  const [filter, setFilter] = useState<"all" | "favorites">("all");
  const [query, setQuery] = useState("");
  const [viewerIndex, setViewerIndex] = useState<number | null>(
    payloadSrc ? 0 : null,
  );
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  }, [favorites]);

  const filtered = images.filter(
    (image) =>
      (filter === "all" || favorites.includes(image.id)) &&
      (!query.trim() || image.name.toLowerCase().includes(query.toLowerCase())),
  );
  const viewer = viewerIndex !== null ? filtered[viewerIndex] : null;

  const toggleFavorite = (id: string) => {
    setFavorites((prev) => (prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]));
  };

  const step = (delta: number) => {
    if (viewerIndex === null) return;
    setViewerIndex((viewerIndex + delta + filtered.length) % filtered.length);
  };

  useEffect(() => {
    if (viewerIndex === null) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") setViewerIndex(null);
      if (event.key === "ArrowLeft") step(-1);
      if (event.key === "ArrowRight") step(1);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewerIndex, filtered.length]);

  return (
    <div ref={rootRef} tabIndex={0} className="flex h-full min-h-0 flex-col outline-none" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="min-w-0">
          <div className="text-[13px] font-semibold">Gallery</div>
          <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>{images.length} photos · {favorites.length} favorites</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <div className="relative flex items-center">
            <Search size={11} className="pointer-events-none absolute left-2" style={{ color: "var(--faint)" }} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search photos" className="field !h-7 !w-[150px] pl-6 !text-[10.5px]" />
          </div>
          <Segmented
            size="sm"
            value={filter}
            onChange={setFilter}
            options={[
              { value: "all", label: "All photos" },
              { value: "favorites", label: <><Heart size={11} /> Favorites</> },
            ]}
          />
        </div>
      </div>
      {filtered.length === 0 ? (
        <EmptyState icon={<Images size={22} />} title="No photos here" description="Try clearing the search or add photos to your KK DEX workspace." />
      ) : (
        <div className="scroll-thin grid min-h-0 flex-1 auto-rows-[134px] grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-2 overflow-y-auto p-3">
          {filtered.map((image, index) => (
            <button
              key={image.id}
              className="group relative overflow-hidden rounded-xl text-left image-checker"
              style={{ border: "1px solid var(--border)" }}
              onClick={() => setViewerIndex(index)}
            >
              <img src={image.src} alt={image.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]" draggable={false} />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-1 bg-gradient-to-t from-black/80 via-black/25 to-transparent px-2.5 pt-6 pb-2">
                <div className="min-w-0">
                  <div className="truncate text-[10.5px] font-medium text-white">{image.name}</div>
                  <div className="truncate text-[8.5px] text-white/65">{image.meta}</div>
                </div>
                <span
                  role="button"
                  tabIndex={0}
                  aria-label={favorites.includes(image.id) ? "Remove favorite" : "Add favorite"}
                  className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-black/30 backdrop-blur"
                  onClick={(event) => {
                    event.stopPropagation();
                    toggleFavorite(image.id);
                  }}
                >
                  <Heart size={11} color="#fff" fill={favorites.includes(image.id) ? "#ff7aa2" : "none"} />
                </span>
              </div>
              <span className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-md bg-black/35 opacity-0 backdrop-blur transition-opacity group-hover:opacity-100">
                <Maximize2 size={10} color="#fff" />
              </span>
            </button>
          ))}
        </div>
      )}
      <div className="flex h-6 shrink-0 items-center justify-between px-3 text-[8.5px]" style={{ borderTop: "1px solid var(--border)", color: "var(--faint)", background: "var(--surface-2)" }}>
        <span>Sample photography via Pexels · favorites saved locally</span>
        <span>Click a photo to open viewer</span>
      </div>

      {viewer ? (
        <div className="absolute inset-0 z-30 flex flex-col" style={{ background: "rgba(7,10,16,.96)" }} onClick={() => setViewerIndex(null)}>
          <div className="flex h-11 shrink-0 items-center gap-2 px-3" style={{ borderBottom: "1px solid rgba(255,255,255,.09)" }} onClick={(event) => event.stopPropagation()}>
            <Images size={15} color="#9fb3ca" />
            <div className="min-w-0">
              <div className="truncate text-[12px] font-medium text-white">{viewer.name}</div>
              <div className="text-[9px] text-white/50">{viewer.meta} · {viewerIndex! + 1} of {filtered.length}</div>
            </div>
            <div className="ml-auto flex items-center gap-1">
              <button className="icon-btn h-7 w-7 text-white/70" aria-label="Favorite" onClick={() => toggleFavorite(viewer.id)}>
                <Heart size={14} fill={favorites.includes(viewer.id) ? "#ff7aa2" : "none"} color={favorites.includes(viewer.id) ? "#ff7aa2" : "currentColor"} />
              </button>
              <button
                className="icon-btn h-7 w-7 text-white/70"
                aria-label="Image information"
                onClick={() => notify("Image source", `${viewer.name} — ${viewer.meta}. Sample media loaded from Pexels.`, { silent: true })}
              >
                <Info size={14} />
              </button>
              <button className="icon-btn h-7 w-7 text-white/70" aria-label="Close viewer" onClick={() => setViewerIndex(null)}><X size={15} /></button>
            </div>
          </div>
          <div className="relative flex min-h-0 flex-1 items-center justify-center p-5" onClick={(event) => event.stopPropagation()}>
            <button className="absolute left-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur hover:bg-white/20" aria-label="Previous photo" onClick={() => step(-1)}><ChevronLeft size={19} /></button>
            <img src={viewer.src} alt={viewer.name} className="max-h-full max-w-full rounded-xl object-contain shadow-2xl" draggable={false} />
            <button className="absolute right-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur hover:bg-white/20" aria-label="Next photo" onClick={() => step(1)}><ChevronRight size={19} /></button>
          </div>
          <div className="flex h-8 shrink-0 items-center justify-center gap-3 text-[9px] text-white/45" onClick={(event) => event.stopPropagation()}>
            <span>← → navigate</span>
            <span>Esc close</span>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ----------------------------------- KK AI --------------------------------- */

type AiMessage = { id: string; role: "user" | "assistant"; text: string; time: number };

const AI_SUGGESTIONS = [
  "What can you do?",
  "Open my files",
  "Show my workspace summary",
  "Switch to light theme",
  "What are the keyboard shortcuts?",
  "Open the phone controller",
];

const AI_WELCOME: AiMessage = {
  id: "ai-welcome",
  role: "assistant",
  text:
    "Hello — I'm the local KK AI workspace assistant.\n\nNo AI model is connected in this build, so I won't pretend to be one. I can genuinely run workspace commands, open apps, report your desktop state, and change supported settings. Try one of the suggestions or type a command.",
  time: Date.now(),
};

export function KKAiApp() {
  const {
    launch,
    files,
    notes,
    settings,
    updateSettings,
    openPhoneController,
    notify,
    windows,
    showInfo,
  } = useOS();
  const [messages, setMessages] = useState<AiMessage[]>(() => {
    try {
      const saved = localStorage.getItem("kkdex.aiMessages");
      if (saved) {
        const parsed = JSON.parse(saved) as AiMessage[];
        if (parsed.length) return parsed;
      }
    } catch {
      /* use welcome message */
    }
    return [AI_WELCOME];
  });
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    localStorage.setItem("kkdex.aiMessages", JSON.stringify(messages.slice(-80)));
  }, [messages]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  useEffect(() => {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    setVoiceSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
  }, []);

  interface SpeechRecognitionLike {
    lang: string;
    interimResults: boolean;
    continuous: boolean;
    start: () => void;
    stop: () => void;
    onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
    onend: (() => void) | null;
    onerror: (() => void) | null;
  }

  const respond = (question: string): string => {
    const q = question.toLowerCase().trim();
    if (/^(hi|hello|hey)\b/.test(q)) return "Hi. Your desktop is running normally. I can open apps, summarize your workspace, or change supported settings.";
    if (q.includes("what can you do") || q.includes("help") || q.includes("command")) {
      return "I'm a local command assistant. Try:\n• open files / browser / notes / calculator\n• show my workspace summary\n• switch to dark theme / light theme\n• set wallpaper to aurora / dunes / ocean\n• what are the keyboard shortcuts?\n• open phone controller\n\nFor general knowledge questions, connect an AI backend to KK DEX — this build does not include one.";
    }
    if (q.includes("summary") || q.includes("workspace") || q.includes("my files")) {
      const fileCount = files.filter((f) => f.kind !== "folder").length;
      const size = files.filter((f) => f.kind !== "folder").reduce((sum, f) => sum + f.size, 0);
      return `Workspace summary\n• ${fileCount} files across ${files.filter((f) => f.kind === "folder").length} folders\n• ${formatBytes(size)} of sample workspace storage\n• ${notes.length} notes\n• ${windows.length} open window${windows.length === 1 ? "" : "s"}\n• Desktop theme: ${settings.theme}, accent: ${settings.accent}`;
    }
    const openMatch = q.match(/open (my )?(files|browser|notes|calculator|settings|gallery|terminal|recycle bin|this pc|app center)/);
    if (openMatch) {
      const name = openMatch[2];
      const map: Record<string, AppId> = {
        files: "files",
        browser: "browser",
        notes: "notes",
        calculator: "calculator",
        settings: "settings",
        gallery: "gallery",
        terminal: "terminal",
        "recycle bin": "recycle",
        "this pc": "thispc",
        "app center": "appcenter",
      };
      const appId = map[name];
      launch(appId);
      return `Opened ${APP_METAS[appId].name} in a desktop window.`;
    }
    if (q.includes("shortcut")) {
      return "Keyboard shortcuts\nWin / Ctrl+Esc — Start\nWin + E — Files\nWin + D — Show desktop\nWin + Left/Right — Snap window\nAlt + Tab — Switch apps\nAlt + F4 — Close active window\nF5 — Refresh\nF2 — Rename\nDelete — Recycle";
    }
    if (q.includes("light theme")) {
      updateSettings({ theme: "light" });
      return "Light theme applied. You can fine-tune colors in Settings → Personalization.";
    }
    if (q.includes("dark theme")) {
      updateSettings({ theme: "dark" });
      return "Dark theme applied. Ask me to open Settings if you'd like a different accent color.";
    }
    const wp = q.match(/wallpaper.*(aurora|dunes|graphite|ocean|ember)/);
    if (wp) {
      updateSettings({ wallpaper: wp[1] as typeof settings.wallpaper });
      return `Wallpaper changed to ${wp[1]}. The update is applied immediately to the desktop.`;
    }
    if (q.includes("phone") || q.includes("controller")) {
      openPhoneController();
      return "Opening the phone controller in a separate window. It uses the KKDexAPI-compatible bridge channel to move the desktop pointer and send keys.";
    }
    if (q.includes("time") || q.includes("date")) {
      return `It is ${new Date().toLocaleTimeString()} on ${new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" })}.`;
    }
    if (q.includes("backend") || q.includes("model") || q.includes("ai connected")) {
      return "No AI model backend is connected to this build. The KKDexAPI bridge does not include an AI endpoint, so KK AI runs deterministic local workspace commands only. All state changes you see are real.";
    }
    return "I don't have an AI model connected to answer open-ended questions, but I can still run workspace commands. Try “show my workspace summary”, “open calculator”, “switch to light theme”, or “what can you do?”.";
  };

  const send = (raw?: string) => {
    const text = (raw ?? input).trim();
    if (!text || thinking) return;
    const userMessage: AiMessage = { id: `ai-${Date.now()}`, role: "user", text, time: Date.now() };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setThinking(true);
    const question = text;
    window.setTimeout(() => {
      const answer = respond(question);
      setMessages((prev) => [...prev, { id: `ai-${Date.now()}-r`, role: "assistant", text: answer, time: Date.now() }]);
      setThinking(false);
    }, 650);
  };

  const startVoice = () => {
    if (!voiceSupported) {
      showInfo(
        "Voice input unavailable",
        "Speech recognition is not exposed by this browser or WebView. The microphone control is disabled rather than pretending to record. Keyboard input still works, and the Android phone controller can send text through the existing bridge.",
        <MicOff size={26} />,
      );
      return;
    }
    try {
      const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
      const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
      if (!Ctor) return;
      const recognition = new Ctor();
      recognition.lang = "en-US";
      recognition.interimResults = true;
      recognition.continuous = false;
      setListening(true);
      recognition.onresult = (event) => {
        const transcript = Array.from({ length: event.results.length })
          .map((_, index) => event.results[index][0].transcript)
          .join(" ");
        setInput(transcript);
      };
      recognition.onend = () => setListening(false);
      recognition.onerror = () => {
        setListening(false);
        notify("Voice input stopped", "The host denied microphone access or could not recognize speech.", { tone: "error" });
      };
      recognition.start();
    } catch {
      setListening(false);
      notify("Voice input unavailable", "Speech recognition could not start in this environment.", { tone: "error" });
    }
  };

  const recentQuestions = messages.filter((m) => m.role === "user").slice(-7).reverse();

  return (
    <div className="flex h-full min-h-0" style={{ background: "var(--surface-solid)" }}>
      <aside className="hidden w-[182px] shrink-0 flex-col sm:flex" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <div className="p-2.5">
          <button
            className="btn btn-sm btn-accent w-full"
            onClick={() => {
              setMessages([{ ...AI_WELCOME, time: Date.now() }]);
              setInput("");
            }}
          >
            <Plus size={12} /> New conversation
          </button>
        </div>
        <div className="px-3 pb-1 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Recent questions</div>
        <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-1.5 py-1">
          {recentQuestions.length === 0 ? (
            <div className="px-2 py-3 text-[9.5px] leading-relaxed" style={{ color: "var(--faint)" }}>Your questions will appear here.</div>
          ) : (
            recentQuestions.map((message) => (
              <button key={message.id} className="mb-0.5 w-full truncate rounded-md px-2 py-1.5 text-left text-[10px] row-hover" style={{ color: "var(--muted)" }} title={message.text} onClick={() => setInput(message.text)}>
                {message.text}
              </button>
            ))
          )}
        </div>
        <div className="m-2 rounded-lg p-2 text-[9px] leading-relaxed" style={{ background: "var(--field)", border: "1px solid var(--border)", color: "var(--muted)" }}>
          <div className="mb-1 flex items-center gap-1 font-medium" style={{ color: "var(--text)" }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--success)" }} /> Local mode
          </div>
          No model backend connected. Replies run deterministic workspace commands.
        </div>
        <button className="mx-2 mb-2 flex items-center gap-1 text-[9px] hover:underline" style={{ color: "var(--faint)" }} onClick={() => showInfo("Connect an AI backend", "KK AI has no model endpoint in this KK DEX build. A future Android bridge can connect an authorized backend through KKDexAPI. Until then, this console only reports and changes real workspace state.", <Sparkles size={24} />)}>
          <Info size={10} /> About local mode
        </button>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
          <AppIcon id="ai" size={27} />
          <div>
            <div className="text-[12.5px] font-semibold leading-tight">KK AI</div>
            <div className="flex items-center gap-1 text-[8.5px]" style={{ color: "var(--muted)" }}>
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--success)" }} />
              Workspace assistant · local rules
            </div>
          </div>
          <div className="ml-auto flex items-center gap-1">
            <button className="btn btn-sm" onClick={() => setMessages([{ ...AI_WELCOME, time: Date.now() }])}>
              <Trash2 size={11} /> Clear
            </button>
          </div>
        </div>

        <div ref={scrollRef} className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4 py-4">
          {messages.length === 1 && messages[0].role === "assistant" ? (
            <div className="mx-auto mb-4 max-w-[520px]">
              <div className="mb-4 flex flex-col items-center text-center">
                <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl" style={{ background: "var(--accent-soft)" }}>
                  <AppIcon id="ai" size={38} />
                </div>
                <div className="text-[16px] font-semibold">Your workspace, at your command</div>
                <div className="mt-1 max-w-[360px] text-[10.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
                  This build runs local workspace actions honestly. No AI model is connected.
                </div>
              </div>
              <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                {AI_SUGGESTIONS.map((suggestion) => (
                  <button key={suggestion} className="rounded-lg px-2.5 py-2 text-left text-[10.5px] transition-colors row-hover" style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }} onClick={() => send(suggestion)}>
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
          <div className="mx-auto flex max-w-[620px] flex-col gap-3">
            {messages.map((message) => (
              <div key={message.id} className={cn("flex gap-2", message.role === "user" ? "justify-end" : "justify-start")}>
                {message.role === "assistant" ? <AppIcon id="ai" size={24} className="mt-0.5" /> : null}
                <div className={cn("max-w-[86%] rounded-xl px-3 py-2", message.role === "user" ? "rounded-tr-sm" : "rounded-tl-sm")} style={message.role === "user" ? { background: "var(--accent)", color: "#fff" } : { background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                  <div className="whitespace-pre-wrap break-words text-[11.5px] leading-[1.6]">{message.text}</div>
                  <div className="mt-1 text-right text-[8px]" style={{ color: message.role === "user" ? "rgba(255,255,255,.7)" : "var(--faint)" }}>{formatTime(message.time)}</div>
                </div>
              </div>
            ))}
            {thinking ? (
              <div className="flex items-center gap-2">
                <AppIcon id="ai" size={24} />
                <div className="flex items-center gap-1 rounded-xl rounded-tl-sm px-3 py-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                  {[0, 1, 2].map((index) => (
                    <span key={index} className="h-1.5 w-1.5 animate-pulse rounded-full" style={{ background: "var(--muted)", animationDelay: `${index * 130}ms` }} />
                  ))}
                  <span className="ml-1 text-[9.5px]" style={{ color: "var(--muted)" }}>Running workspace action…</span>
                </div>
              </div>
            ) : null}
          </div>
        </div>

        <div className="shrink-0 px-3 pb-3">
          <div className="mx-auto max-w-[620px]">
            <div className="flex items-end gap-2 rounded-xl p-2" style={{ background: "var(--field)", border: "1px solid var(--border-strong)" }}>
              <button className={cn("icon-btn h-8 w-8 shrink-0", listening && "text-[var(--accent)]")} aria-label="Voice input" title={voiceSupported ? "Voice input" : "Voice input unavailable"} onClick={startVoice}>
                {voiceSupported ? <Mic size={15} /> : <MicOff size={15} />}
              </button>
              <textarea
                ref={inputRef}
                rows={1}
                value={input}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    send();
                  }
                }}
                placeholder="Ask KK AI or type a workspace command…"
                className="scroll-thin max-h-24 min-h-[32px] min-w-0 flex-1 resize-none border-0 bg-transparent px-1 py-1.5 text-[11.5px] outline-none placeholder:text-[var(--faint)]"
                style={{ userSelect: "text" }}
              />
              <button className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white disabled:opacity-40" style={{ background: "var(--accent)" }} onClick={() => send()} disabled={!input.trim() || thinking} aria-label="Send message">
                <Send size={14} />
              </button>
            </div>
            <div className="mt-1 flex items-center justify-between px-1 text-[8.5px]" style={{ color: "var(--faint)" }}>
              <span>Local command assistant · no AI model connected</span>
              <button className="hover:underline" onClick={() => showInfo("AI backend status", "No model backend is connected in this environment. The assistant's responses are deterministic and all changes it makes to files, settings and windows are real.", <Settings2 size={24} />)}>Status</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
