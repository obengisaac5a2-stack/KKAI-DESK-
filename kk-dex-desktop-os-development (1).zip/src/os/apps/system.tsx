import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronRight,
  CircleCheck,
  Cpu,
  ExternalLink,
  FolderOpen,
  HardDrive,
  Info,
  Monitor,
  Pin,
  PinOff,
  RefreshCw,
  Smartphone,
  Sparkles,
  Store,
  Trash2,
  Undo2,
  Wifi,
} from "lucide-react";
import { ALL_APP_IDS, APP_METAS, DESKTOP_APPS } from "../appMeta";
import { AppIcon } from "../icons";
import { formatBytes, formatDate, useOS } from "../OSContext";
import type { AppCategory, AppId, MenuItemConfig } from "../types";
import { AppNotice, EmptyState, SearchBox } from "../ui";
import { cn } from "@/utils/cn";

/* --------------------------------- This PC --------------------------------- */

export function ThisPcApp() {
  const { files, windows, settings, launch, openPhoneController, notify, showInfo, trash, notes } = useOS();
  const fileCount = files.filter((f) => f.kind !== "folder").length;
  const totalBytes = files.filter((f) => f.kind !== "folder").reduce((sum, f) => sum + f.size, 0);
  const usedPercent = Math.min(100, Math.round((totalBytes / (256 * 1024 * 1024)) * 100));

  const quickFolders = [
    { id: "desktop", name: "Desktop", color: "#4f8cff" },
    { id: "documents", name: "Documents", color: "#f7c45c" },
    { id: "downloads", name: "Downloads", color: "#2cc9a0" },
    { id: "pictures", name: "Pictures", color: "#f0729b" },
    { id: "music", name: "Music", color: "#a78bfa" },
    { id: "videos", name: "Videos", color: "#fb923c" },
  ];

  return (
    <div className="scroll-thin h-full overflow-y-auto" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-3 px-4 pt-3.5 pb-3" style={{ background: "linear-gradient(120deg, rgba(var(--accent-rgb),.13), transparent)", borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <Monitor size={28} style={{ color: "var(--accent)" }} strokeWidth={1.5} />
        </div>
        <div className="min-w-0">
          <div className="text-[16px] font-semibold tracking-tight">KK DEX Station</div>
          <div className="text-[10.5px]" style={{ color: "var(--muted)" }}>External display workspace · {window.innerWidth} × {window.innerHeight}</div>
          <div className="mt-1 flex flex-wrap gap-1">
            <span className="badge badge-accent"><CircleCheck size={9} /> System ready</span>
            <span className="badge">{windows.length} window{windows.length === 1 ? "" : "s"} open</span>
            <span className="badge">{fileCount} workspace files</span>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" onClick={() => notify("Device state refreshed", "The desktop overview now reflects current workspace state.", { tone: "success", silent: true })}>
            <RefreshCw size={12} /> Refresh
          </button>
          <button className="btn btn-sm" onClick={() => launch("settings", { payload: { section: "display" } })}>
            <Monitor size={12} /> Display settings
          </button>
        </div>
      </div>

      <div className="grid gap-2.5 p-3.5 md:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="mb-2.5 flex items-center gap-2">
            <HardDrive size={14} style={{ color: "var(--accent)" }} />
            <div className="text-[12px] font-semibold">Devices and storage</div>
          </div>
          <div className="rounded-lg p-2.5" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}>
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: "var(--accent-soft)" }}>
                <HardDrive size={18} style={{ color: "var(--accent)" }} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-medium">KK DEX Workspace (C:)</div>
                <div className="text-[9px]" style={{ color: "var(--muted)" }}>Browser-persistent workspace storage</div>
              </div>
              <span className="badge">{formatBytes(totalBytes)}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}>
              <div className="h-full rounded-full transition-all" style={{ width: `${Math.max(2, usedPercent)}%`, background: "linear-gradient(90deg, var(--accent), #8b7cff)" }} />
            </div>
            <div className="mt-1 flex justify-between text-[8.5px]" style={{ color: "var(--faint)" }}>
              <span>{usedPercent}% of 256 MB display quota</span>
              <span>Local to this device</span>
            </div>
            <div className="mt-2 flex gap-1.5">
              <button className="btn btn-sm" onClick={() => launch("files")}><FolderOpen size={11} /> Open</button>
              <button className="btn btn-sm" onClick={() => launch("settings", { payload: { section: "system" } })}><HardDrive size={11} /> Storage settings</button>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2.5 rounded-lg p-2.5" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}>
            <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: "rgba(44,201,160,.13)" }}>
              <Smartphone size={18} style={{ color: "#2cc9a0" }} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[11px] font-medium">Android phone controller</div>
              <div className="text-[9px]" style={{ color: "var(--muted)" }}>Separate touchpad & keyboard interface · KKDexAPI bridge</div>
            </div>
            <button className="btn btn-sm" onClick={openPhoneController}><ExternalLink size={11} /> Pair</button>
          </div>
          <AppNotice>
            <Info size={12} className="mt-0.5 shrink-0" />
            The Android bridge does not expose raw device storage. Files shown here live in the persistent KK DEX workspace and no host files are modified.
          </AppNotice>
        </section>

        <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="mb-2.5 flex items-center gap-2">
            <Monitor size={14} style={{ color: "var(--accent)" }} />
            <div className="text-[12px] font-semibold">Device specifications</div>
          </div>
          <dl className="space-y-2">
            {[
              ["Device name", "KK DEX Station"],
              ["Operating system", "KK DEX OS 1.0 · Desktop"],
              ["Display", `${window.innerWidth} × ${window.innerHeight} CSS px`],
              ["Pixel ratio", String(window.devicePixelRatio.toFixed(2))],
              ["Logical cores", String(navigator.hardwareConcurrency ?? "Not reported")],
              ["Network", navigator.onLine ? "Host network online" : "Host network offline"],
              ["Bridge", "KKDexAPI-compatible receiver"],
              ["Theme", `${settings.theme} · ${settings.accent}`],
            ].map(([label, value]) => (
              <div key={label} className="flex items-start justify-between gap-3 text-[10px]">
                <dt style={{ color: "var(--muted)" }}>{label}</dt>
                <dd className="text-right font-medium">{value}</dd>
              </div>
            ))}
          </dl>
          <div className="mt-2.5 rounded-lg p-2 text-[9px] leading-relaxed" style={{ background: "var(--field)", color: "var(--faint)" }}>
            Hardware values are read from the browser host. System updates and firmware are managed by the Android container.
          </div>
        </section>
      </div>

      <div className="px-3.5 pb-3">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-[12px] font-semibold">Quick access</div>
          <button className="text-[9.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => showInfo("Recycle Bin", `${trash.length} deleted item${trash.length === 1 ? "" : "s"} can be restored from the Recycle Bin.`, <Trash2 size={24} />)}>
            {trash.length} in Recycle Bin
          </button>
        </div>
        <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
          {quickFolders.map((folder) => (
            <button
              key={folder.id}
              className="flex flex-col items-center gap-1.5 rounded-lg px-2 py-2.5 transition-colors row-hover"
              style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }}
              onClick={() => launch("files", { payload: { folderId: folder.id } })}
            >
              <FolderOpen size={24} color={folder.color} strokeWidth={1.5} />
              <span className="text-[9.5px]">{folder.name}</span>
            </button>
          ))}
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2 rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="text-[10px] font-medium">Recently used</div>
          {["files", "browser", "notes"].map((id) => (
            <button key={id} className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[9.5px] row-hover" style={{ border: "1px solid var(--border)" }} onClick={() => launch(id as AppId)}>
              <AppIcon id={id as AppId} size={16} /> {APP_METAS[id as AppId].name}
            </button>
          ))}
          <span className="ml-auto text-[8.5px]" style={{ color: "var(--faint)" }}>{notes.length} notes in workspace</span>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- App Center ------------------------------- */

const CATEGORIES: ("All" | AppCategory)[] = ["All", "System", "Productivity", "Media", "Utilities", "AI"];

export function AppCenterApp() {
  const { launch, settings, togglePin, notify, windows, launchHistory, openPhoneController, showInfo } = useOS();
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("All");
  const [query, setQuery] = useState("");
  const apps = useMemo(
    () =>
      ALL_APP_IDS.filter((id) => {
        const meta = APP_METAS[id];
        return (
          (category === "All" || meta.category === category) &&
          (!query.trim() ||
            meta.name.toLowerCase().includes(query.toLowerCase()) ||
            meta.description.toLowerCase().includes(query.toLowerCase()) ||
            meta.keywords?.some((keyword) => keyword.includes(query.toLowerCase())))
        );
      }),
    [category, query],
  );

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="px-3.5 pt-3 pb-2.5" style={{ background: "linear-gradient(115deg, rgba(var(--accent-rgb),.16), transparent 62%)", borderBottom: "1px solid var(--border)" }}>
        <div className="flex items-center gap-2.5">
          <AppIcon id="appcenter" size={36} />
          <div>
            <div className="flex items-center gap-1.5 text-[15px] font-semibold tracking-tight">
              App Center
              <span className="badge badge-accent">OS bundle</span>
            </div>
            <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>Every application opens in its own floating desktop window.</div>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <button className="btn btn-sm" onClick={openPhoneController}><Smartphone size={12} /> Phone controller</button>
            <button
              className="btn btn-sm"
              onClick={() =>
                showInfo(
                  "About App Center",
                  "KK DEX OS 1.0 ships its applications with the desktop build. A remote installation service is not connected, so there is no simulated download or fake install progress. Pinning changes the taskbar immediately.",
                  <Store size={24} />,
                )
              }
            >
              <Info size={12} /> About
            </button>
          </div>
        </div>
        <div className="mt-2.5 flex items-center gap-2">
          <SearchBox value={query} onChange={setQuery} placeholder="Search installed apps" className="w-[210px]" />
          <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto">
            {CATEGORIES.map((item) => (
              <button
                key={item}
                className="shrink-0 rounded-full px-2.5 py-1 text-[10px] transition-colors"
                style={{ background: category === item ? "var(--accent)" : "var(--field)", color: category === item ? "#fff" : "var(--muted)", border: "1px solid var(--border)" }}
                onClick={() => setCategory(item)}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
        <div className="mb-3 flex items-center gap-2 rounded-lg px-2.5 py-2" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <Sparkles size={13} style={{ color: "var(--accent)" }} />
          <div className="text-[10px]">
            <span className="font-medium">Recently used</span>
            <span style={{ color: "var(--muted)" }}> · {launchHistory.slice(0, 3).map((id) => APP_METAS[id]?.name).filter(Boolean).join(" · ") || "No apps launched yet"}</span>
          </div>
          <button className="ml-auto flex items-center gap-1 text-[9px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => launch("thispc")}>
            This PC <ChevronRight size={10} />
          </button>
        </div>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {apps.map((id) => {
            const meta = APP_METAS[id];
            const pinned = settings.taskbarPins.includes(id);
            const running = windows.some((w) => w.appId === id);
            return (
              <div key={id} className="group flex flex-col rounded-xl p-2.5 transition-colors" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="flex items-start gap-2">
                  <AppIcon id={id} size={36} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1">
                      <span className="truncate text-[11.5px] font-semibold">{meta.name}</span>
                      {running ? <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: "var(--success)" }} title="Running" /> : null}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1">
                      <span className="badge !text-[8px]">{meta.category}</span>
                      <span className="badge !text-[8px]"><Check size={8} /> Installed</span>
                    </div>
                  </div>
                  <button className="icon-btn h-6 w-6" title={pinned ? "Unpin from taskbar" : "Pin to taskbar"} onClick={() => { togglePin(id); notify(pinned ? "Unpinned" : "Pinned to taskbar", `${meta.name} ${pinned ? "removed from" : "added to"} the taskbar.`, { silent: true }); }}>
                    {pinned ? <PinOff size={12} /> : <Pin size={12} />}
                  </button>
                </div>
                <p className="mt-1.5 line-clamp-2 min-h-[26px] text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>{meta.description}</p>
                <div className="mt-2 flex gap-1.5">
                  <button className="btn btn-sm btn-accent flex-1 !h-6" onClick={() => launch(id)}><ArrowRight size={11} /> Open</button>
                  {DESKTOP_APPS.includes(id) ? (
                    <button className="btn btn-sm !h-6 !px-2" title="Show in Files" onClick={() => launch("files", { payload: { folderId: "desktop" } })}><FolderOpen size={11} /></button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
        {apps.length === 0 ? (
          <EmptyState icon={<Store size={22} />} title="No apps match your search" description="Try clearing the search or selecting another category." />
        ) : null}
        <div className="mt-3 flex items-start gap-2 rounded-lg p-2.5 text-[9px] leading-relaxed" style={{ background: "var(--field)", color: "var(--muted)", border: "1px solid var(--border)" }}>
          <Info size={11} className="mt-0.5 shrink-0" />
          <span>
            This build has no remote app catalog or network installation service. All installed applications are bundled with KK DEX OS 1.0. Pin/unpin actions update the real taskbar; opening apps uses the actual window manager.
          </span>
        </div>
      </div>
      <div className="flex h-6 shrink-0 items-center justify-between px-3 text-[8.5px]" style={{ background: "var(--surface-2)", borderTop: "1px solid var(--border)", color: "var(--faint)" }}>
        <span>{apps.length} applications · {settings.taskbarPins.length} pinned</span>
        <span>Windows-style floating application model</span>
      </div>
    </div>
  );
}

/* -------------------------------- Recycle Bin ------------------------------ */

export function RecycleBinApp() {
  const { trash, restoreTrash, deleteForever, emptyTrash, showConfirm, showInfo, openMenu, notify } = useOS();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const totalSize = trash.reduce((sum, item) => sum + item.size, 0);
  const selected = trash.find((item) => item.id === selectedId) ?? null;

  const menuFor = (event: React.MouseEvent, id: string) => {
    event.preventDefault();
    setSelectedId(id);
    const item = trash.find((t) => t.id === id);
    if (!item) return;
    const items: MenuItemConfig[] = [
      { label: "Restore", icon: <Undo2 size={14} />, action: () => restoreTrash(id) },
      {
        label: "Delete permanently",
        icon: <Trash2 size={14} />,
        danger: true,
        action: () => showConfirm(`Permanently delete “${item.name}”?`, "This item cannot be recovered after permanent deletion.", () => deleteForever(id), "Delete permanently"),
      },
      { separator: true },
      {
        label: "Properties",
        icon: <Info size={14} />,
        action: () => showInfo(item.name, `Type: ${item.kind}\nSize: ${formatBytes(item.size)}\nDeleted: ${formatDate(item.deletedAt)}\nItems in group: ${item.nodes.length}`, <Trash2 size={24} />),
      },
    ];
    openMenu(event.clientX, event.clientY, items, "Recycle Bin");
  };

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "var(--field)" }}>
          <Trash2 size={16} style={{ color: "var(--muted)" }} />
        </div>
        <div>
          <div className="text-[12.5px] font-semibold">Recycle Bin</div>
          <div className="text-[9px]" style={{ color: "var(--muted)" }}>{trash.length} deleted item{trash.length === 1 ? "" : "s"} · {formatBytes(totalSize)}</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" disabled={!selected} onClick={() => selected && restoreTrash(selected.id)}><Undo2 size={12} /> Restore</button>
          <button className="btn btn-sm btn-danger" disabled={!trash.length} onClick={() => showConfirm("Empty the Recycle Bin?", "Every deleted item will be permanently removed from this workspace. This cannot be undone.", emptyTrash, "Empty bin")}>
            <Trash2 size={12} /> Empty bin
          </button>
        </div>
      </div>
      <div className="px-3 pt-2">
        <AppNotice>
          <Info size={12} className="mt-0.5 shrink-0" />
          This bin only manages items deleted inside the KK DEX workspace. Android host storage deletion is not exposed by the KKDexAPI bridge.
        </AppNotice>
      </div>
      {trash.length === 0 ? (
        <div className="flex flex-1 items-center justify-center">
          <EmptyState icon={<Trash2 size={22} />} title="Recycle Bin is empty" description="Deleted files and folders from the KK DEX workspace will appear here." />
        </div>
      ) : (
        <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
          <div className="grid gap-1.5">
            {trash.map((item) => (
              <button
                key={item.id}
                className={cn("flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-left row-hover", selectedId === item.id && "row-selected")}
                style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }}
                onClick={() => setSelectedId(item.id)}
                onDoubleClick={() => restoreTrash(item.id)}
                onContextMenu={(event) => menuFor(event, item.id)}
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style={{ background: "var(--field)" }}>
                  {item.kind === "folder" ? <FolderOpen size={17} style={{ color: "#f0ae3c" }} /> : <Trash2 size={16} style={{ color: "var(--muted)" }} />}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[11.5px] font-medium">{item.name}</div>
                  <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{item.nodes.length} item{item.nodes.length === 1 ? "" : "s"} · deleted {formatDate(item.deletedAt)}</div>
                </div>
                <span className="text-[9px]" style={{ color: "var(--faint)" }}>{formatBytes(item.size)}</span>
                <span
                  role="button"
                  tabIndex={0}
                  aria-label={`Restore ${item.name}`}
                  className="icon-btn h-6 w-6"
                  onClick={(event) => {
                    event.stopPropagation();
                    restoreTrash(item.id);
                  }}
                >
                  <Undo2 size={12} />
                </span>
                <span
                  role="button"
                  tabIndex={0}
                  aria-label={`Delete ${item.name} permanently`}
                  className="icon-btn h-6 w-6"
                  onClick={(event) => {
                    event.stopPropagation();
                    showConfirm(`Delete “${item.name}” forever?`, "This item cannot be restored after permanent deletion.", () => deleteForever(item.id), "Delete permanently");
                  }}
                >
                  <Trash2 size={12} />
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="flex h-7 shrink-0 items-center justify-between px-3 text-[8.5px]" style={{ background: "var(--surface-2)", borderTop: "1px solid var(--border)", color: "var(--muted)" }}>
        <span>{selected ? `Selected: ${selected.name}` : "Double-click an item to restore it"}</span>
        <span className="flex items-center gap-2">
          <button className="hover:underline" onClick={() => { trash.slice().reverse().forEach((item) => restoreTrash(item.id)); if (trash.length) notify("Recycle Bin restored", "All recoverable items were returned to their original folders.", { tone: "success" }); }} disabled={!trash.length}>
            Restore all
          </button>
          <span>·</span>
          <span>Workspace Recycle Bin</span>
        </span>
      </div>
    </div>
  );
}

/* ------------------------------ Phone Controller --------------------------- */

const BRIDGE_FUNCTIONS = [
  "movePointer(x, y)",
  "pointerDown()",
  "pointerUp()",
  "pointerClick()",
  "pointerDoubleClick()",
  "pointerRightClick()",
  "scrollDesktop(delta)",
  "insertText(text)",
  "pressKey(key, modifiers)",
  "getState()",
  "openApp(appId)",
  "setTheme(theme)",
  "setWallpaper(id)",
];

export function PhoneApp() {
  const { settings, updateSettings, openPhoneController, notify, showInfo } = useOS();
  const [connected, setConnected] = useState(false);
  const [copied, setCopied] = useState(false);
  const controllerUrl = useMemo(() => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("controller", "1");
      url.hash = "";
      return url.toString();
    } catch {
      return "?controller=1";
    }
  }, []);

  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel("kkdex-remote");
      channel.onmessage = (event) => {
        if (event.data?.type === "hello" || event.data?.type === "state") setConnected(true);
        if (event.data?.type === "disconnect" || event.data?.type === "disconnected") setConnected(false);
      };
      channel.postMessage({ type: "query-state" });
    } catch {
      setConnected(false);
    }
    return () => channel?.close();
  }, []);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(controllerUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
      notify("Controller link copied", "Open this address on the linked Android device or in a second browser window.", { tone: "success", silent: true });
    } catch {
      notify("Clipboard unavailable", "Select the link manually and copy it from the field.", { tone: "error" });
    }
  };

  return (
    <div className="scroll-thin h-full overflow-y-auto" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-3 px-4 py-3" style={{ background: "linear-gradient(115deg, rgba(44,201,160,.14), transparent)", borderBottom: "1px solid var(--border)" }}>
        <AppIcon id="phone" size={42} />
        <div>
          <div className="text-[15px] font-semibold">Phone Controller</div>
          <div className="flex items-center gap-1.5 text-[9.5px]" style={{ color: "var(--muted)" }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: connected ? "var(--success)" : "var(--faint)" }} />
            {connected ? "Controller window connected" : "Waiting for a controller window"}
          </div>
        </div>
        <button className="btn btn-sm btn-accent ml-auto" onClick={openPhoneController}><Smartphone size={12} /> Open controller</button>
      </div>
      <div className="grid gap-2.5 p-3.5 md:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="text-[12px] font-semibold">A separate controller screen</div>
          <p className="mt-1 text-[10px] leading-relaxed" style={{ color: "var(--muted)" }}>
            The TV renders this complete desktop. Your Android phone opens only a touchpad and keyboard surface — never a mirrored or mobile-sized copy of the desktop.
          </p>
          <div className="mt-2.5 rounded-lg p-2.5" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}>
            <div className="text-[9px] font-medium" style={{ color: "var(--muted)" }}>CONTROLLER LINK</div>
            <div className="mt-1 flex items-center gap-1.5">
              <code className="min-w-0 flex-1 truncate rounded px-2 py-1.5 font-mono text-[9px]" style={{ background: "var(--field)", color: "var(--text)", userSelect: "text" }}>{controllerUrl}</code>
              <button className="btn btn-sm !px-2" onClick={copyLink}>{copied ? <Check size={11} /> : <ExternalLink size={11} />} {copied ? "Copied" : "Copy"}</button>
            </div>
            <div className="mt-1 text-[8.5px]" style={{ color: "var(--faint)" }}>
              The Android host should load this same desktop page in the external display WebView and the controller interface on the phone.
            </div>
          </div>
          <ol className="mt-3 space-y-2">
            {[
              "Keep the TV desktop window open and unlocked.",
              "Open the controller link in a second window or on the paired Android device.",
              "Use the touchpad to move the real desktop pointer. Tap for left click; two fingers for right click.",
              "Focus a desktop text field, then type using the controller keyboard. Text is inserted through insertText().",
            ].map((step, index) => (
              <li key={step} className="flex items-start gap-2 text-[10px] leading-relaxed">
                <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[8px] font-semibold" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>{index + 1}</span>
                <span style={{ color: "var(--muted)" }}>{step}</span>
              </li>
            ))}
          </ol>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="btn btn-sm btn-accent" onClick={openPhoneController}><Smartphone size={12} /> Open controller now</button>
            <button className="btn btn-sm" onClick={() => showInfo("External display architecture", "KK DEX keeps the original Android external-display model: the activity renders the desktop on the TV surface, while the phone controller sends pointer, key and text events. This build does not mirror the phone screen.", <Monitor size={24} />)}>
              <Info size={12} /> Architecture
            </button>
          </div>
        </section>

        <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="flex items-center gap-2">
            <MouseIcon />
            <div className="text-[12px] font-semibold">Controller preferences</div>
          </div>
          <div className="mt-2.5 flex items-center gap-3">
            <span className="w-[74px] text-[10px]" style={{ color: "var(--muted)" }}>Pointer speed</span>
            <input type="range" min={1} max={10} value={settings.pointerSpeed} onChange={(event) => updateSettings({ pointerSpeed: Number(event.target.value) })} className="w-full" aria-label="Pointer speed" />
            <span className="w-4 font-mono text-[10px]">{settings.pointerSpeed}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-[74px] text-[10px]" style={{ color: "var(--muted)" }}>Pointer size</span>
            <input type="range" min={1} max={6} value={settings.pointerSize} onChange={(event) => updateSettings({ pointerSize: Number(event.target.value) })} className="w-full" aria-label="Pointer size" />
            <span className="w-4 font-mono text-[10px]">{settings.pointerSize}</span>
          </div>
          <label className="mt-1 flex items-center justify-between gap-2 text-[10px]">
            <span>Show click effects on TV</span>
            <button role="switch" aria-checked={settings.clickEffects} data-on={settings.clickEffects} className="toggle" onClick={() => updateSettings({ clickEffects: !settings.clickEffects })}><span className="toggle-knob" /></button>
          </label>
          <div className="mt-2.5 border-t pt-2 text-[8.5px] leading-relaxed" style={{ borderColor: "var(--border)", color: "var(--faint)" }}>
            The TV desktop continues to use the native desktop arrow cursor. Pointer size and speed affect the controller overlay and touchpad translation.
          </div>
        </section>
      </div>

      <div className="px-3.5 pb-3">
        <div className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="flex items-center gap-2">
            <Cpu size={13} style={{ color: "var(--accent)" }} />
            <div className="text-[12px] font-semibold">KKDexAPI bridge</div>
            <span className="badge badge-accent ml-auto"><Wifi size={8} /> Compatible</span>
          </div>
          <p className="mt-1 text-[9.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
            The existing bridge functions are preserved. The desktop installs a receiver that connects each call to real pointer, key and application events. An Android host can call these functions directly through the WebView.
          </p>
          <div className="mt-2 grid grid-cols-2 gap-1 sm:grid-cols-3">
            {BRIDGE_FUNCTIONS.map((fn) => (
              <code key={fn} className="truncate rounded px-1.5 py-1 font-mono text-[8.5px]" style={{ background: "var(--field)", color: "var(--muted)", border: "1px solid var(--border)" }}>{fn}</code>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MouseIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="m3 3 7.07 16.97 2.51-7.39 7.39-2.51L3 3z" />
    </svg>
  );
}
