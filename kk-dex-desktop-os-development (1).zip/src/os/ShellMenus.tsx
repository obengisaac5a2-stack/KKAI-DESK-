import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { AlertTriangle, Check, Info, X } from "lucide-react";
import { AppIcon } from "./icons";
import { useOS } from "./OSContext";
import type { MenuItemConfig } from "./types";
import { cn } from "@/utils/cn";

export function ContextMenuHost() {
  const { menu, closeMenu } = useOS();
  const ref = useRef<HTMLDivElement>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [submenuIndex, setSubmenuIndex] = useState<number | null>(null);
  const [submenuFlip, setSubmenuFlip] = useState(false);

  useEffect(() => {
    setOffset({ x: 0, y: 0 });
    setSubmenuIndex(null);
  }, [menu]);

  useEffect(() => {
    if (!menu) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        closeMenu();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [menu, closeMenu]);

  useLayoutEffect(() => {
    if (!menu || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    let dx = 0;
    let dy = 0;
    if (rect.right > window.innerWidth - 8) dx = window.innerWidth - 8 - rect.right;
    if (rect.bottom > window.innerHeight - 8) dy = window.innerHeight - 8 - rect.bottom;
    if (rect.top + dy < 8) dy = 8 - rect.top;
    if (dx !== 0 || dy !== 0) setOffset({ x: dx, y: dy });
    setSubmenuFlip(rect.left + (menu.width ?? 238) + 216 > window.innerWidth);
  }, [menu, menu?.items]);

  if (!menu) return null;
  const itemNodes = menu.items ?? [];

  const trigger = (item: MenuItemConfig, index: number) => {
    if (item.disabled) return;
    if (item.children?.length) {
      setSubmenuIndex(submenuIndex === index ? null : index);
      return;
    }
    closeMenu();
    item.action?.();
  };

  return (
    <>
      <div
        className="fixed inset-0 z-[10000]"
        onMouseDown={closeMenu}
        onContextMenu={(event) => {
          event.preventDefault();
          closeMenu();
        }}
      />
      <div
        ref={ref}
        role="menu"
        className="menu-anim fixed z-[10001] rounded-lg p-1"
        style={{
          left: menu.x + offset.x,
          top: menu.y + offset.y,
          width: menu.width ?? 238,
          background: "var(--surface)",
          border: "1px solid var(--border-strong)",
          boxShadow: "var(--shadow-menu)",
          backdropFilter: "blur(30px) saturate(1.4)",
          color: "var(--text)",
        }}
        onContextMenu={(event) => event.preventDefault()}
        onMouseLeave={() => setSubmenuIndex(null)}
      >
        {menu.title ? (
          <>
            <div className="truncate px-2 pt-1 pb-1.5 text-[9.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>
              {menu.title}
            </div>
            <div className="mx-1 mb-1 h-px" style={{ background: "var(--border)" }} />
          </>
        ) : null}
        {itemNodes.map((item, index) => {
          if (item.separator) return <div key={`sep-${index}`} className="my-1 h-px" style={{ background: "var(--border)" }} />;
          return (
            <div key={item.id ?? `${item.label}-${index}`} className="relative" onMouseEnter={() => setSubmenuIndex(item.children?.length ? index : null)}>
              <button
                type="button"
                role="menuitem"
                aria-haspopup={item.children?.length ? "menu" : undefined}
                className={cn("menu-item", item.danger && "danger")}
                disabled={item.disabled}
                onClick={() => trigger(item, index)}
              >
                <span className="flex w-3.5 shrink-0 items-center justify-center" style={{ color: item.danger ? "var(--danger)" : "var(--muted)" }}>
                  {item.checked ? <Check size={13} style={{ color: "var(--accent)" }} /> : item.icon}
                </span>
                <span className="min-w-0 flex-1 truncate">{item.label}</span>
                {item.shortcut ? <span className="shrink-0 text-[9px]" style={{ color: "var(--faint)" }}>{item.shortcut}</span> : null}
                {item.children?.length ? <span className="shrink-0 text-[9px]" style={{ color: "var(--faint)" }}>›</span> : null}
              </button>
              {item.children?.length && submenuIndex === index ? (
                <div
                  className="menu-anim absolute rounded-lg p-1"
                  style={{
                    top: -5,
                    ...(submenuFlip ? { right: "calc(100% + 2px)" } : { left: "calc(100% + 2px)" }),
                    width: 208,
                    background: "var(--surface)",
                    border: "1px solid var(--border-strong)",
                    boxShadow: "var(--shadow-menu)",
                    backdropFilter: "blur(30px) saturate(1.4)",
                  }}
                >
                  {item.children.map((child, childIndex) =>
                    child.separator ? (
                      <div key={`child-sep-${childIndex}`} className="my-1 h-px" style={{ background: "var(--border)" }} />
                    ) : (
                      <button key={child.id ?? `${child.label}-${childIndex}`} type="button" className="menu-item" disabled={child.disabled} onClick={() => trigger(child, childIndex)}>
                        <span className="flex w-3.5 shrink-0 items-center justify-center" style={{ color: "var(--muted)" }}>
                          {child.checked ? <Check size={13} style={{ color: "var(--accent)" }} /> : child.icon}
                        </span>
                        <span className="min-w-0 flex-1 truncate">{child.label}</span>
                        {child.shortcut ? <span className="text-[9px]" style={{ color: "var(--faint)" }}>{child.shortcut}</span> : null}
                      </button>
                    ),
                  )}
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </>
  );
}

export function DialogHost() {
  const { dialog, closeDialog } = useOS();
  const [value, setValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setValue(dialog?.value ?? "");
    if (dialog?.kind === "prompt") {
      window.setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 30);
    }
  }, [dialog]);

  useEffect(() => {
    if (!dialog) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        closeDialog();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [dialog, closeDialog]);

  if (!dialog) return null;
  const confirm = () => {
    if (dialog.kind === "prompt") dialog.onConfirm?.(value);
    else dialog.onConfirm?.(value);
    closeDialog();
  };
  const danger = dialog.danger;
  const Icon = dialog.icon ?? (dialog.kind === "confirm" ? <AlertTriangle size={22} /> : <Info size={22} />);

  return (
    <div className="fixed inset-0 z-[10010] flex items-center justify-center p-6" style={{ background: "rgba(4,8,16,.5)", backdropFilter: "blur(3px)" }} onMouseDown={closeDialog} onContextMenu={(e) => e.preventDefault()}>
      <div
        className="menu-anim w-full max-w-[390px] overflow-hidden rounded-xl"
        style={{ background: "var(--surface)", border: "1px solid var(--border-strong)", boxShadow: "var(--shadow-menu)", backdropFilter: "blur(30px)" }}
        onMouseDown={(event) => event.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-start gap-3 px-4 pt-4">
          <div
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
            style={{ background: danger ? "rgba(239,68,68,.12)" : "var(--accent-soft)", color: danger ? "var(--danger)" : "var(--accent)" }}
          >
            {Icon}
          </div>
          <div className="min-w-0 flex-1 pt-0.5">
            <div className="text-[13.5px] font-semibold leading-snug">{dialog.title}</div>
            {dialog.message ? <div className="mt-1 whitespace-pre-line text-[10.5px] leading-relaxed" style={{ color: "var(--muted)" }}>{dialog.message}</div> : null}
          </div>
          <button className="icon-btn -mt-1 h-6 w-6" aria-label="Close dialog" onClick={closeDialog}><X size={13} /></button>
        </div>
        {dialog.kind === "prompt" ? (
          <div className="px-4 pt-3">
            {dialog.label ? <label className="mb-1 block text-[9.5px] font-medium" style={{ color: "var(--muted)" }}>{dialog.label}</label> : null}
            <input
              ref={inputRef}
              className="field"
              value={value}
              placeholder={dialog.placeholder}
              onChange={(event) => setValue(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  confirm();
                }
              }}
            />
          </div>
        ) : null}
        <div className="flex items-center justify-end gap-2 px-4 pt-4 pb-4">
          <button className="btn" onClick={closeDialog}>{dialog.kind === "info" ? "Close" : "Cancel"}</button>
          {dialog.kind !== "info" ? (
            <button
              className={cn("btn", danger ? "btn-danger" : "btn-accent")}
              style={danger ? { background: "var(--danger)", borderColor: "transparent", color: "#fff" } : undefined}
              onClick={confirm}
              disabled={dialog.kind === "prompt" && !value.trim()}
            >
              {dialog.confirmLabel ?? (dialog.kind === "prompt" ? "OK" : "Continue")}
            </button>
          ) : (
            <button className="btn btn-accent" onClick={closeDialog}>{dialog.confirmLabel ?? "Done"}</button>
          )}
        </div>
      </div>
    </div>
  );
}

export function ToastHost() {
  const { toasts, dismissToast } = useOS();
  if (!toasts.length) return null;
  return (
    <div className="pointer-events-none fixed right-3 z-[9600] flex w-[292px] flex-col gap-2" style={{ bottom: "calc(var(--taskbar-h) + 10px)" }}>
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="toast-anim pointer-events-auto flex items-start gap-2.5 rounded-xl p-2.5"
          style={{ background: "var(--surface)", border: "1px solid var(--border-strong)", boxShadow: "var(--shadow-menu)", backdropFilter: "blur(28px)" }}
        >
          {toast.appId ? <AppIcon id={toast.appId} size={28} /> : (
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg" style={{ background: toast.tone === "error" ? "rgba(239,68,68,.13)" : "var(--accent-soft)", color: toast.tone === "error" ? "var(--danger)" : "var(--accent)" }}>
              {toast.tone === "error" ? <AlertTriangle size={14} /> : <Check size={14} />}
            </span>
          )}
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium leading-tight">{toast.title}</div>
            {toast.message ? <div className="mt-0.5 line-clamp-3 text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>{toast.message}</div> : null}
          </div>
          <button className="icon-btn h-5 w-5" aria-label="Dismiss notification" onClick={() => dismissToast(toast.id)}><X size={11} /></button>
        </div>
      ))}
    </div>
  );
}
