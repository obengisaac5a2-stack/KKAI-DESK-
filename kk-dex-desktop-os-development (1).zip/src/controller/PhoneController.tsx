import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  AppWindow,
  ChevronDown,
  Command,
  CornerDownLeft,
  ExternalLink,
  Grip,
  Keyboard,
  Monitor,
  MousePointer2,
  MousePointerClick,
  RefreshCw,
  Smartphone,
  WifiOff,
} from "lucide-react";
import type { ControllerMessage, DesktopMessage } from "../os/bridge";
import { AppIcon } from "../os/icons";
import type { AppId } from "../os/types";
import { cn } from "@/utils/cn";

type Tab = "pad" | "keys" | "apps";

interface RemoteState {
  ready?: boolean;
  resolution?: { width: number; height: number; dpr?: number };
  windows?: { appId: AppId; name: string; minimized: boolean; maximized: boolean }[];
  apps?: { id: AppId; name: string }[];
  theme?: "dark" | "light";
  wallpaper?: string;
  activeApp?: string | null;
  controllerConnected?: boolean;
  settings?: { pointerSpeed?: number; pointerSize?: number; clickEffects?: boolean };
}

const FALLBACK_RESOLUTION = { width: 1920, height: 1016 };
const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

function KeyButton({ label, onClick, accent, muted, wide }: { label: string; onClick: () => void; accent?: boolean; muted?: boolean; wide?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("flex h-10 items-center justify-center rounded-lg border text-[10.5px] font-medium transition-all active:scale-[0.96]", wide && "col-span-2")}
      style={{
        background: accent ? "var(--accent)" : "rgba(255,255,255,.065)",
        borderColor: accent ? "transparent" : "rgba(255,255,255,.09)",
        color: accent ? "#fff" : muted ? "rgba(255,255,255,.5)" : "#e9f0fa",
      }}
    >
      {label}
    </button>
  );
}

export function PhoneController() {
  const [tab, setTab] = useState<Tab>("pad");
  const [connected, setConnected] = useState(false);
  const [remote, setRemote] = useState<RemoteState>({});
  const [composer, setComposer] = useState("");
  const [live, setLive] = useState(false);
  const [lastAction, setLastAction] = useState("Ready");
  const [dragMode, setDragMode] = useState(false);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const [speed, setSpeed] = useState(5);
  const [supportError, setSupportError] = useState("");
  const channelRef = useRef<BroadcastChannel | null>(null);
  const localPointer = useRef({ x: FALLBACK_RESOLUTION.width / 2, y: FALLBACK_RESOLUTION.height / 2 });
  const initialized = useRef(false);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({ moved: false, multi: false, lastX: 0, lastY: 0, lastMidY: 0, scroll: 0, maxDistance: 0 });
  const lastTap = useRef(0);
  const previousComposer = useRef("");
  const [cursorPos, setCursorPos] = useState({ x: 0.5, y: 0.5 });

  const resolution = remote.resolution ?? FALLBACK_RESOLUTION;

  const send = (message: ControllerMessage) => {
    try {
      channelRef.current?.postMessage(message);
      return true;
    } catch {
      setSupportError("The controller channel closed. Reload to reconnect.");
      return false;
    }
  };

  useEffect(() => {
    let channel: BroadcastChannel;
    try {
      channel = new BroadcastChannel("kkdex-remote");
      channelRef.current = channel;
    } catch {
      setSupportError("BroadcastChannel is not supported in this WebView. The Android host should route KKDexAPI calls natively.");
      return;
    }
    const request = () => {
      try {
        channel.postMessage({ type: "hello", client: "phone" } satisfies ControllerMessage);
        channel.postMessage({ type: "query-state" } satisfies ControllerMessage);
      } catch {
        /* keep controller usable while unavailable */
      }
    };
    channel.onmessage = (event: MessageEvent<DesktopMessage>) => {
      const data = event.data;
      if (data?.type === "state") {
        const state = data.state as RemoteState;
        setRemote(state);
        setConnected(true);
        setSupportError("");
        if (!initialized.current && state.resolution) {
          initialized.current = true;
          localPointer.current = { x: state.resolution.width / 2, y: state.resolution.height / 2 };
          setCursorPos({ x: 0.5, y: 0.5 });
          if (state.settings?.pointerSpeed) setSpeed(state.settings.pointerSpeed);
        }
      }
    };
    request();
    const timer = window.setInterval(request, 2800);
    const onVisible = () => {
      if (document.visibilityState === "visible") request();
    };
    document.addEventListener("visibilitychange", onVisible);
    const beforeUnload = () => {
      try {
        channel.postMessage({ type: "disconnect" } satisfies ControllerMessage);
      } catch {
        /* noop */
      }
    };
    window.addEventListener("beforeunload", beforeUnload);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("beforeunload", beforeUnload);
      try {
        channel.postMessage({ type: "disconnect" } satisfies ControllerMessage);
        channel.close();
      } catch {
        /* noop */
      }
    };
  }, []);

  const rippleAt = (x: number, y: number) => {
    const id = Date.now() + Math.random();
    setRipples((prev) => [...prev.slice(-4), { id, x, y }]);
    window.setTimeout(() => setRipples((prev) => prev.filter((ripple) => ripple.id !== id)), 520);
  };

  const padPoint = (event: ReactPointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  };

  const updatePointerAndSend = (dx: number, dy: number) => {
    const scale = 0.7 + speed * 0.28;
    const next = {
      x: clamp(localPointer.current.x + dx * scale, 0, resolution.width - 1),
      y: clamp(localPointer.current.y + dy * scale, 0, resolution.height - 1),
    };
    localPointer.current = next;
    setCursorPos({ x: next.x / resolution.width, y: next.y / resolution.height });
    send({ type: "move", x: Math.round(next.x), y: Math.round(next.y) });
    setLastAction(`Pointer ${Math.round(next.x)}, ${Math.round(next.y)}`);
  };

  const onPadDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = padPoint(event);
    pointers.current.set(event.pointerId, point);
    if (pointers.current.size === 1) {
      gesture.current = { moved: false, multi: false, lastX: point.x, lastY: point.y, lastMidY: point.y, scroll: 0, maxDistance: 0 };
      if (dragMode) send({ type: "down" });
    } else {
      gesture.current.multi = true;
      const values = [...pointers.current.values()];
      gesture.current.lastMidY = values.reduce((sum, item) => sum + item.y, 0) / values.length;
    }
  };

  const onPadMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (!pointers.current.has(event.pointerId)) return;
    const previous = pointers.current.get(event.pointerId)!;
    const point = padPoint(event);
    pointers.current.set(event.pointerId, point);
    if (pointers.current.size >= 2) {
      const values = [...pointers.current.values()];
      const midY = values.reduce((sum, item) => sum + item.y, 0) / values.length;
      const delta = midY - gesture.current.lastMidY;
      gesture.current.lastMidY = midY;
      gesture.current.scroll += Math.abs(delta);
      if (Math.abs(delta) > 1) {
        send({ type: "scroll", deltaY: Math.round(delta * 2.2) });
        gesture.current.moved = true;
        setLastAction(delta > 0 ? "Scrolling down" : "Scrolling up");
      }
      return;
    }
    const dx = point.x - previous.x;
    const dy = point.y - previous.y;
    const distance = Math.abs(dx) + Math.abs(dy);
    gesture.current.maxDistance += distance;
    if (Math.abs(dx) + Math.abs(dy) > 0.6) {
      gesture.current.moved = true;
      updatePointerAndSend(dx, dy);
    }
  };

  const finishTap = (point: { x: number; y: number }) => {
    const now = Date.now();
    const isDouble = now - lastTap.current < 300;
    lastTap.current = now;
    if (isDouble) {
      send({ type: "doubleClick" });
      setLastAction("Double-click sent");
    } else {
      send({ type: "click" });
      setLastAction("Left-click sent");
    }
    rippleAt(point.x, point.y);
  };

  const onPadUp = (event: ReactPointerEvent<HTMLDivElement>) => {
    const point = pointers.current.get(event.pointerId) ?? padPoint(event);
    pointers.current.delete(event.pointerId);
    if (pointers.current.size > 0) return;
    if (dragMode) {
      send({ type: "up" });
      setLastAction(gesture.current.moved ? "Drag released" : "Click sent");
      if (!gesture.current.moved) rippleAt(point.x, point.y);
      return;
    }
    if (gesture.current.multi && !gesture.current.moved) {
      send({ type: "rightClick" });
      rippleAt(point.x, point.y);
      setLastAction("Right-click sent");
    } else if (!gesture.current.moved) {
      finishTap(point);
    }
  };

  const sendKey = (key: string, modifiers?: string[]) => {
    send({ type: "key", key, modifiers });
    setLastAction(`${modifiers?.length ? `${modifiers.join("+")}+` : ""}${key} sent`);
  };

  const handleComposerChange = (value: string) => {
    if (live && connected) {
      if (value.length > previousComposer.current.length) {
        const added = value.slice(previousComposer.current.length);
        send({ type: "text", text: added });
        setLastAction(`Typed “${added}”`);
      } else if (value.length < previousComposer.current.length) {
        const removed = previousComposer.current.length - value.length;
        for (let i = 0; i < removed; i += 1) send({ type: "key", key: "Backspace" });
        setLastAction("Backspace sent");
      }
    }
    previousComposer.current = value;
    setComposer(value);
  };

  const sendComposer = () => {
    if (live) {
      send({ type: "key", key: "Enter" });
      setLastAction("Enter sent to the desktop");
      setComposer("");
      previousComposer.current = "";
      return;
    }
    if (!composer.trim()) return;
    send({ type: "text", text: composer });
    setLastAction("Text sent to the focused desktop field");
    setComposer("");
    previousComposer.current = "";
  };

  const openDesktop = () => {
    const url = new URL(window.location.href);
    url.searchParams.delete("controller");
    url.searchParams.set("desktop", "1");
    window.open(url.toString(), "_blank", "noopener");
  };

  const activeWindows = remote.windows ?? [];

  return (
    <div
      className="flex h-[100dvh] min-h-[520px] w-full flex-col overflow-hidden"
      style={{
        background: "radial-gradient(ellipse at 20% -10%, #17284a 0%, transparent 55%), radial-gradient(ellipse at 90% 10%, #1a2a46 0%, transparent 42%), #070c15",
        color: "#eaf1fa",
        fontFamily: "'Inter', system-ui, sans-serif",
      }}
    >
      <header className="flex shrink-0 items-center gap-2.5 px-4 pt-[max(14px,env(safe-area-inset-top))] pb-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ background: "linear-gradient(145deg,#4f8cff,#8b7cff)", boxShadow: "0 5px 18px -6px rgba(79,140,255,.6)" }}>
          <svg width="20" height="20" viewBox="0 0 32 32" fill="none" aria-hidden>
            <path d="M9 8.5v15M9 16l6.4-7.5M9 16l6.4 7.5" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M17.5 8.5v15M17.5 16l6.2-7.5M17.5 16l6.2 7.5" stroke="#fff" strokeOpacity=".82" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-semibold tracking-tight">KK DEX Controller</div>
          <div className="flex items-center gap-1.5 text-[8.5px]" style={{ color: connected ? "#7ee7c7" : "#8d9db3" }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: connected ? "#34d399" : "#64748b" }} />
            {connected ? `Linked to TV · ${resolution.width} × ${resolution.height}` : "Waiting for desktop…"}
          </div>
        </div>
        <button className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.08)" }} onClick={() => { send({ type: "query-state" }); setLastAction("Reconnected"); }} aria-label="Reconnect">
          <RefreshCw size={14} color="#a9b9cd" />
        </button>
      </header>

      {supportError ? (
        <div className="mx-4 mb-2 flex items-start gap-2 rounded-lg px-2.5 py-2 text-[9.5px] leading-relaxed" style={{ background: "rgba(245,158,11,.1)", border: "1px solid rgba(245,158,11,.22)", color: "#f3d18b" }}>
          <WifiOff size={12} className="mt-0.5 shrink-0" /> {supportError}
        </div>
      ) : null}

      <main className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4 pb-3">
        {tab === "pad" ? (
          <div className="fade-in">
            {!connected ? (
              <div className="mb-2 flex items-center gap-2 rounded-lg px-2.5 py-2 text-[9.5px]" style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.08)", color: "#9daec2" }}>
                <Monitor size={12} className="shrink-0" />
                <span>Open the TV desktop so the controller can link.</span>
                <button className="ml-auto shrink-0 font-medium text-[#8db9ff] underline-offset-2 hover:underline" onClick={openDesktop}>Open</button>
              </div>
            ) : null}
            <div
              className="relative flex aspect-[4/5] max-h-[48vh] min-h-[230px] w-full touch-none select-none flex-col overflow-hidden rounded-2xl"
              style={{
                background: "linear-gradient(145deg, rgba(255,255,255,.075), rgba(255,255,255,.025))",
                border: `1px solid ${dragMode ? "rgba(79,140,255,.55)" : "rgba(255,255,255,.1)"}`,
                boxShadow: "inset 0 1px 0 rgba(255,255,255,.08), 0 20px 44px -24px rgba(0,0,0,.7)",
                backdropFilter: "blur(20px)",
              }}
              onPointerDown={onPadDown}
              onPointerMove={onPadMove}
              onPointerUp={onPadUp}
              onPointerCancel={onPadUp}
              role="application"
              aria-label="Touchpad — drag to move the desktop pointer"
            >
              <div className="pointer-events-none absolute inset-0 opacity-[.35]" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,.28) 1px, transparent 1px)", backgroundSize: "18px 18px" }} />
              <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 55%, rgba(79,140,255,.11), transparent 62%)" }} />
              <div className="pointer-events-none relative flex items-start justify-between p-3">
                <span className="rounded-full px-2 py-1 text-[8px] font-medium uppercase tracking-wider" style={{ background: "rgba(255,255,255,.07)", color: "#ecf4ff", border: "1px solid rgba(255,255,255,.08)" }}>
                  {dragMode ? "Drag mode · press & move" : "Touchpad"}
                </span>
                <span className="text-[8px] tabular-nums" style={{ color: "rgba(255,255,255,.35)" }}>
                  {Math.round(cursorPos.x * resolution.width)} · {Math.round(cursorPos.y * resolution.height)}
                </span>
              </div>
              <div className="pointer-events-none relative flex flex-1 flex-col items-center justify-center gap-2">
                <div className="flex h-12 w-12 items-center justify-center rounded-full" style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.09)" }}>
                  <MousePointer2 size={21} color={dragMode ? "#7fb2ff" : "#9fb2c9"} />
                </div>
                <div className="text-[10px] font-medium text-white/65">{connected ? "Drag to move the pointer" : "Controller channel idle"}</div>
                <div className="text-[8.5px] text-white/35">Tap left-click · double-tap open · two-finger tap right-click</div>
                <div className="mt-1 flex items-center gap-1.5 text-[8px] text-white/30">
                  <Grip size={9} /> two-finger drag scrolls
                </div>
              </div>
              <div className="pointer-events-none absolute h-2.5 w-2.5 rounded-full transition-transform duration-75" style={{ left: `calc(${cursorPos.x * 100}% - 5px)`, top: `calc(${cursorPos.y * 100}% - 5px)`, background: "#8db9ff", boxShadow: "0 0 0 4px rgba(79,140,255,.18), 0 1px 3px rgba(0,0,0,.5)" }} />
              {ripples.map((ripple) => (
                <span key={ripple.id} className="pointer-events-none absolute h-9 w-9 rounded-full" style={{ left: ripple.x - 18, top: ripple.y - 18, border: "2px solid rgba(141,185,255,.9)", animation: "controllerRipple .5s ease-out forwards" }} />
              ))}
              <div className="pointer-events-none absolute inset-x-3 bottom-2 flex items-center justify-between">
                <span className="text-[8px]" style={{ color: "rgba(255,255,255,.3)" }}>Local gesture feedback only</span>
                <span className="flex items-center gap-1 text-[8px]" style={{ color: dragMode ? "#8db9ff" : "rgba(255,255,255,.3)" }}>
                  {dragMode ? <Grip size={9} /> : <MousePointer2 size={9} />} {dragMode ? "Holding mouse button" : "Hover mode"}
                </span>
              </div>
            </div>

            <div className="mt-2 grid grid-cols-4 gap-1.5">
              <button className="flex h-12 flex-col items-center justify-center gap-1 rounded-xl text-[8.5px]" style={{ background: "rgba(255,255,255,.07)", border: "1px solid rgba(255,255,255,.09)" }} onClick={() => { send({ type: "click" }); setLastAction("Left-click sent"); }}>
                <MousePointerClick size={17} color="#8db9ff" /> Left
              </button>
              <button className="flex h-12 flex-col items-center justify-center gap-1 rounded-xl text-[8.5px]" style={{ background: "rgba(255,255,255,.07)", border: "1px solid rgba(255,255,255,.09)" }} onClick={() => { send({ type: "rightClick" }); setLastAction("Right-click sent"); }}>
                <MousePointerClick size={17} color="#f7c45c" style={{ transform: "scaleX(-1)" }} /> Right
              </button>
              <button className="flex h-12 flex-col items-center justify-center gap-1 rounded-xl text-[8.5px]" style={{ background: "rgba(255,255,255,.07)", border: "1px solid rgba(255,255,255,.09)" }} onClick={() => { send({ type: "doubleClick" }); setLastAction("Double-click sent"); }}>
                <CopyGlyph /> Double
              </button>
              <button
                className="flex h-12 flex-col items-center justify-center gap-1 rounded-xl text-[8.5px]"
                style={{ background: dragMode ? "rgba(79,140,255,.28)" : "rgba(255,255,255,.07)", border: `1px solid ${dragMode ? "rgba(79,140,255,.55)" : "rgba(255,255,255,.09)"}`, color: dragMode ? "#dceaff" : undefined }}
                onClick={() => { setDragMode(!dragMode); setLastAction(dragMode ? "Hover mode enabled" : "Drag mode enabled"); }}
              >
                <Grip size={17} /> {dragMode ? "Dragging" : "Drag"}
              </button>
            </div>

            <div className="mt-2 flex gap-1.5">
              <button className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[9px]" style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.08)" }} onClick={() => { send({ type: "scroll", deltaY: -180 }); setLastAction("Scrolled up"); }}>
                <ChevronUpGlyph /> Scroll up
              </button>
              <button className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[9px]" style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.08)" }} onClick={() => { send({ type: "scroll", deltaY: 180 }); setLastAction("Scrolled down"); }}>
                <ChevronDown size={12} /> Scroll down
              </button>
            </div>
            <div className="mt-2 flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[8.5px]" style={{ background: "rgba(255,255,255,.035)", border: "1px solid rgba(255,255,255,.06)", color: "rgba(255,255,255,.45)" }}>
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: connected ? "#34d399" : "#64748b" }} />
              <span className="truncate">{lastAction}</span>
              <span className="ml-auto shrink-0">Speed {speed}</span>
            </div>
          </div>
        ) : null}

        {tab === "keys" ? (
          <div className="fade-in">
            <div className="mb-2 flex items-center justify-between">
              <div>
                <div className="text-[12.5px] font-semibold">Keyboard</div>
                <div className="text-[8.5px]" style={{ color: "rgba(255,255,255,.42)" }}>Tap the destination field on the TV first.</div>
              </div>
              <button
                className="flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[8.5px]"
                style={{ background: live ? "rgba(79,140,255,.28)" : "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.09)", color: live ? "#b9d5ff" : "rgba(255,255,255,.55)" }}
                onClick={() => setLive(!live)}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: live ? "#7fb2ff" : "#64748b" }} />
                {live ? "Live typing" : "Manual send"}
              </button>
            </div>
            <div className="rounded-xl p-2.5" style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.09)" }}>
              <textarea
                value={composer}
                onChange={(event) => handleComposerChange(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    if (live) send({ type: "key", key: "Enter" });
                    else sendComposer();
                  }
                  if (event.key === "Escape") sendKey("Escape");
                }}
                rows={3}
                placeholder="Type here to enter text on the TV…"
                className="scroll-thin w-full resize-none border-0 bg-transparent text-[12px] leading-relaxed outline-none placeholder:text-white/25"
                style={{ color: "#eef4fb", userSelect: "text" }}
              />
              <div className="mt-1 flex items-center gap-2">
                <span className="text-[8px]" style={{ color: "rgba(255,255,255,.3)" }}>{live ? "Keystrokes are forwarded immediately" : "Nothing is sent until you press Send"}</span>
                <button
                  className="ml-auto flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[9.5px] font-medium text-white active:scale-[0.97]"
                  style={{ background: "linear-gradient(145deg,#4f8cff,#3b70e0)", boxShadow: "0 4px 14px -6px rgba(79,140,255,.8)" }}
                  onClick={sendComposer}
                  disabled={!connected || (!live && !composer.trim())}
                >
                  <CornerDownLeft size={11} /> {live ? "Send Enter" : "Send to TV"}
                </button>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-5 gap-1.5">
              {[
                { label: "Esc", action: () => sendKey("Escape") },
                { label: "Tab", action: () => sendKey("Tab") },
                { label: "Enter", action: () => sendKey("Enter"), accent: true },
                { label: "Bksp", action: () => sendKey("Backspace") },
                { label: "Del", action: () => sendKey("Delete") },
                { label: "↑", action: () => sendKey("ArrowUp") },
                { label: "←", action: () => sendKey("ArrowLeft") },
                { label: "↓", action: () => sendKey("ArrowDown") },
                { label: "→", action: () => sendKey("ArrowRight") },
                { label: "F5", action: () => sendKey("F5") },
                { label: "F2", action: () => sendKey("F2") },
                { label: "Win", action: () => sendKey("Meta") },
              { label: "Ctrl C", action: () => sendKey("c", ["ctrl"]) },
              { label: "Ctrl V", action: () => sendKey("v", ["ctrl"]) },
              { label: "Ctrl X", action: () => sendKey("x", ["ctrl"]) },
              { label: "Ctrl Z", action: () => sendKey("z", ["ctrl"]) },
              { label: "Ctrl A", action: () => sendKey("a", ["ctrl"]) },
              { label: "Ctrl S", action: () => sendKey("s", ["ctrl"]) },
                { label: "Alt Tab", action: () => sendKey("Tab", ["alt"]) },
                { label: "Alt F4", action: () => sendKey("F4", ["alt"]) },
              ].map((key) => (
                <KeyButton key={key.label} label={key.label} onClick={key.action} accent={key.accent} />
              ))}
            </div>
            <div className="mt-2.5 flex items-center gap-2 rounded-lg px-2.5 py-2 text-[8.5px]" style={{ background: "rgba(255,255,255,.035)", border: "1px solid rgba(255,255,255,.06)", color: "rgba(255,255,255,.45)" }}>
              <Command size={10} /> Shortcuts work in the active desktop app. Text fields receive standard editing behavior.
              <span className="ml-auto flex shrink-0 items-center gap-1" style={{ color: connected ? "#7ee7c7" : "rgba(255,255,255,.35)" }}>
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: connected ? "#34d399" : "#64748b" }} /> {connected ? "Sent live" : "Not linked"}
              </span>
            </div>
          </div>
        ) : null}

        {tab === "apps" ? (
          <div className="fade-in">
            <div className="rounded-xl p-3" style={{ background: "linear-gradient(140deg, rgba(79,140,255,.17), rgba(255,255,255,.035))", border: "1px solid rgba(255,255,255,.1)" }}>
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(255,255,255,.1)" }}><Monitor size={16} /></span>
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-medium">{connected ? "KK DEX Station" : "No desktop linked"}</div>
                  <div className="text-[8.5px]" style={{ color: "rgba(255,255,255,.45)" }}>
                    {connected ? `${resolution.width} × ${resolution.height} · external display` : "Start the TV desktop or use the Android bridge"}
                  </div>
                </div>
                <span className="rounded-full px-2 py-0.5 text-[7.5px] font-semibold" style={{ background: connected ? "rgba(52,211,153,.16)" : "rgba(255,255,255,.08)", color: connected ? "#7ee7c7" : "rgba(255,255,255,.45)" }}>
                  {connected ? "LINKED" : "OFFLINE"}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-3 text-[8.5px]" style={{ color: "rgba(255,255,255,.45)" }}>
                <span>{activeWindows.length} window{activeWindows.length === 1 ? "" : "s"}</span>
                <span>{remote.activeApp ?? "Desktop"}</span>
                <span className="ml-auto">{remote.theme ?? "dark"} theme</span>
              </div>
            </div>

            <div className="mt-3 text-[9px] font-semibold uppercase tracking-wider" style={{ color: "rgba(255,255,255,.38)" }}>Launch on TV</div>
            <div className="mt-1.5 grid grid-cols-4 gap-1.5">
              {(["files", "browser", "ai", "calculator", "notes", "gallery", "settings", "terminal"] as AppId[]).map((appId) => (
                <button
                  key={appId}
                  className="flex flex-col items-center gap-1 rounded-xl py-2.5 text-[8px] transition-all active:scale-[0.96] disabled:opacity-35"
                  style={{ background: "rgba(255,255,255,.055)", border: "1px solid rgba(255,255,255,.07)", color: "rgba(255,255,255,.7)" }}
                  disabled={!connected}
                  onClick={() => {
                    send({ type: "openApp", appId });
                    setLastAction(`Open ${appId} requested`);
                  }}
                >
                  <AppIcon id={appId} size={28} />
                  {appId === "ai" ? "KK AI" : appId === "thispc" ? "This PC" : appId.charAt(0).toUpperCase() + appId.slice(1)}
                </button>
              ))}
            </div>

            <div className="mt-3 rounded-xl p-2.5" style={{ background: "rgba(255,255,255,.045)", border: "1px solid rgba(255,255,255,.08)" }}>
              <div className="flex items-center justify-between text-[9.5px]">
                <span className="flex items-center gap-1.5"><MousePointer2 size={12} /> Pointer speed</span>
                <span className="font-mono text-[9px]" style={{ color: "rgba(255,255,255,.45)" }}>{speed}/10</span>
              </div>
              <input
                type="range"
                min={1}
                max={10}
                value={speed}
                onChange={(event) => setSpeed(Number(event.target.value))}
                className="mt-1.5 w-full"
                aria-label="Controller pointer speed"
                style={{ accentColor: "#4f8cff" }}
              />
              <div className="mt-1 flex items-center justify-between text-[8px]" style={{ color: "rgba(255,255,255,.3)" }}>
                <span>Movement scale is applied on the phone.</span>
                <span>Desktop overlay: {remote.settings?.pointerSize ?? 3}</span>
              </div>
            </div>

            <div className="mt-2.5 rounded-xl p-2.5" style={{ background: "rgba(255,255,255,.035)", border: "1px solid rgba(255,255,255,.07)" }}>
              <div className="flex items-center gap-1.5 text-[9px] font-medium"><Smartphone size={11} /> Phone controller architecture</div>
              <p className="mt-1 text-[8.5px] leading-relaxed" style={{ color: "rgba(255,255,255,.4)" }}>
                The TV keeps the full desktop. This screen only carries touchpad, keyboard and app commands. The Android host retains its external-display WebView and KKDexAPI bridge; this interface uses the same message contract.
              </p>
              <button className="mt-2 flex items-center gap-1 text-[8.5px] text-[#8db9ff] hover:underline" onClick={openDesktop}>
                Open TV desktop in another window <ExternalLink size={9} />
              </button>
            </div>

            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {[
                { label: "Dark", action: () => send({ type: "setTheme", theme: "dark" }) },
                { label: "Light", action: () => send({ type: "setTheme", theme: "light" }) },
                { label: "Refresh link", action: () => send({ type: "query-state" }) },
              ].map((action) => (
                <button key={action.label} className="rounded-md px-2.5 py-1.5 text-[8.5px]" style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.09)", color: "rgba(255,255,255,.6)" }} onClick={action.action}>
                  {action.label}
                </button>
              ))}
            </div>
          </div>
        ) : null}
      </main>

      <nav className="flex shrink-0 items-center justify-around border-t px-3 pt-1.5 pb-[max(8px,env(safe-area-inset-bottom))]" style={{ borderColor: "rgba(255,255,255,.08)", background: "rgba(8,13,23,.9)", backdropFilter: "blur(20px)" }}>
        {[
          { id: "pad" as Tab, label: "Touchpad", Icon: MousePointer2 },
          { id: "keys" as Tab, label: "Keyboard", Icon: Keyboard },
          { id: "apps" as Tab, label: "Apps", Icon: AppWindow },
        ].map((item) => (
          <button key={item.id} className="flex flex-1 flex-col items-center gap-1 py-1 text-[8.5px]" style={{ color: tab === item.id ? "#8db9ff" : "rgba(255,255,255,.35)" }} onClick={() => setTab(item.id)}>
            <item.Icon size={17} />
            {item.label}
            <span className="h-0.5 w-4 rounded-full" style={{ background: tab === item.id ? "#4f8cff" : "transparent" }} />
          </button>
        ))}
      </nav>
    </div>
  );
}

function CopyGlyph() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c4b5fd" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <rect x="8" y="8" width="12" height="12" rx="2" />
      <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
    </svg>
  );
}

function ChevronUpGlyph() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="m18 15-6-6-6 6" />
    </svg>
  );
}


