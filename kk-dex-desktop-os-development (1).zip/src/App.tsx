import { OSProvider } from "./os/OSContext";
import { Desktop } from "./os/Desktop";
import { PhoneController } from "./controller/PhoneController";

function shouldUseController(): boolean {
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get("desktop") === "1") return false;
    if (params.get("controller") === "1") return true;
    const coarsePointer = window.matchMedia("(pointer: coarse)").matches;
    const narrow = window.innerWidth <= 620;
    return coarsePointer && narrow;
  } catch {
    return false;
  }
}

export default function App() {
  if (shouldUseController()) {
    return <PhoneController />;
  }
  return (
    <OSProvider>
      <Desktop />
    </OSProvider>
  );
}
