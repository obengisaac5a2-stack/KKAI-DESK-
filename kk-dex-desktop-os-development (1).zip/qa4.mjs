import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errs=[]; page.on('pageerror', e=>errs.push(e.message));
await page.goto('http://127.0.0.1:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(500);

// drag icon to a new slot
const icon = page.locator('[aria-label="Notes"]').first();
let b = await icon.boundingBox();
await page.mouse.move(b.x + 30, b.y + 20);
await page.mouse.down();
await page.mouse.move(b.x + 300, b.y + 20, { steps: 10 });
await page.mouse.up();
await page.waitForTimeout(400);
const b2 = await page.locator('[aria-label="Notes"]').first().boundingBox();
console.log('icon moved:', Math.round(b.x), '->', Math.round(b2.x), 'slot persisted:', await page.evaluate(()=>localStorage.getItem('kkdex.desktopSlots')));

// new folder via desktop context menu
await page.mouse.click(900, 640, { button: 'right' });
await page.waitForTimeout(300);
await page.getByRole('menuitem', { name: /New folder/ }).click();
await page.waitForTimeout(300);
const dialog = page.getByRole('dialog');
await dialog.locator('input').fill('QA Folder');
await dialog.getByRole('button', { name: 'Create folder' }).click();
await page.waitForTimeout(500);
console.log('new folder icon:', await page.locator('[aria-label="QA Folder"]').count());

// gallery
await page.evaluate(() => window.KKDexAPI.openApp('gallery'));
await page.waitForTimeout(900);
const gallery = page.locator('[aria-label="Gallery window"]');
console.log('gallery images:', await gallery.locator('img').count());
await gallery.locator('img').first().waitFor({ state: 'visible' });
await page.waitForTimeout(1000);
await page.screenshot({ path: '/tmp/gallery.png' });
// click first photo
await gallery.locator('button').filter({ has: page.locator('img') }).first().click();
await page.waitForTimeout(500);
console.log('viewer open:', await gallery.getByText('Esc close').count());
await gallery.getByRole('button', { name: 'Close viewer' }).click();
await page.waitForTimeout(300);

// app center
await page.evaluate(() => window.KKDexAPI.openApp('appcenter'));
await page.waitForTimeout(600);
const ac = page.locator('[aria-label="App Center window"]');
console.log('app cards:', await ac.getByText('Installed').count());
await page.screenshot({ path: '/tmp/appcenter.png' });
console.log('errors:', errs);
await browser.close();
