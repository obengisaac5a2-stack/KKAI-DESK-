import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
await page.goto('http://127.0.0.1:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(800);

// Launch Files by double click
await page.locator('[aria-label="Files"]').first().dblclick();
await page.waitForTimeout(500);
const winCount = await page.locator('.os-window').count();
const filesVisible = await page.getByText('Quick access').isVisible();
console.log('windows after Files:', winCount, 'quickaccess:', filesVisible);

// launch calculator from desktop
await page.locator('[aria-label="Calculator"]').first().dblclick();
await page.waitForTimeout(400);
console.log('windows after calc:', await page.locator('.os-window').count());

// maximize active calculator
const activeWin = page.locator('.os-window').last();
await activeWin.locator('[aria-label="Maximize window"]').click();
await page.waitForTimeout(300);
const box = await activeWin.boundingBox();
console.log('calc maximized box:', JSON.stringify(box));
await activeWin.locator('[aria-label="Restore window"]').click();
await page.waitForTimeout(300);
console.log('calc restored box:', JSON.stringify(await activeWin.boundingBox()));

// drag files window
const filesWin = page.locator('.os-window').first();
let fb = await filesWin.boundingBox();
await page.mouse.move(fb.x + 200, fb.y + 15);
await page.mouse.down();
await page.mouse.move(fb.x + 320, fb.y + 95, { steps: 10 });
await page.mouse.up();
await page.waitForTimeout(250);
console.log('files moved from', Math.round(fb.x), Math.round(fb.y), 'to', Math.round((await filesWin.boundingBox()).x), Math.round((await filesWin.boundingBox()).y));

// resize files from SE corner
fb = await filesWin.boundingBox();
await page.mouse.move(fb.x + fb.width - 2, fb.y + fb.height - 2);
await page.mouse.down();
await page.mouse.move(fb.x + fb.width + 80, fb.y + fb.height + 50, { steps: 10 });
await page.mouse.up();
await page.waitForTimeout(250);
console.log('files resized:', JSON.stringify(await filesWin.boundingBox()));

// minimize / restore via taskbar
await page.locator('.os-window').first().locator('[aria-label="Minimize window"]').click();
await page.waitForTimeout(300);
console.log('visible windows after minimize:', await page.locator('.os-window:not(.window-minimized)').count());
await page.locator('footer [aria-label="Files"]').click();
await page.waitForTimeout(300);
console.log('visible windows after taskbar restore:', await page.locator('.os-window:not(.window-minimized)').count());

// start menu
await page.locator('footer [aria-label="Start"]').click();
await page.waitForTimeout(300);
console.log('start visible:', await page.locator('[aria-label="Start menu"]').isVisible());
await page.locator('input[placeholder="Search apps, settings and files"]').fill('set');
await page.waitForTimeout(300);
console.log('start results:', await page.locator('[aria-label="Start menu"] button').filter({ hasText: 'Settings' }).count());
await page.keyboard.press('Escape');
await page.waitForTimeout(200);

// settings via desktop icon
await page.locator('[aria-label="Settings"]').first().dblclick();
await page.waitForTimeout(500);
const settingsWin = page.locator('.os-window').filter({ hasText: 'Personalization' }).last();
console.log('settings personalization visible:', await settingsWin.isVisible());
// change wallpaper
await settingsWin.getByText('Golden Dunes').click();
await page.waitForTimeout(400);
const bg = await page.locator('.fixed.inset-0').first().evaluate(el => getComputedStyle(el).backgroundImage);
console.log('background contains dunes:', bg.includes('dunes'));

// notes
await page.locator('[aria-label="Notes"]').first().dblclick();
await page.waitForTimeout(400);
const notesWin = page.locator('.os-window').filter({ hasText: 'in workspace' }).last();
await notesWin.locator('button').filter({ hasText: 'New' }).first().click();
await page.waitForTimeout(300);
await notesWin.locator('input[placeholder="Note title"]').fill('QA note');
await notesWin.locator('textarea').fill('Auto-save works');
await page.waitForTimeout(1000);
const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('kkdex.notes') || '[]').some(n => n.title === 'QA note'));
console.log('note persisted:', saved);

// calculator
await page.locator('footer [aria-label="Calculator"]').click();
await page.waitForTimeout(400);
const calcWin = page.locator('.os-window').filter({ hasText: 'Standard' }).first();
await calcWin.getByRole('button', { name: '7', exact: true }).click();
await calcWin.getByRole('button', { name: '+', exact: true }).click();
await calcWin.getByRole('button', { name: '3', exact: true }).click();
await calcWin.getByRole('button', { name: '=', exact: true }).click();
await page.waitForTimeout(200);
const calcText = await calcWin.locator('.font-mono').first().textContent();
console.log('calc result text:', calcText);

// context menu on desktop empty area
await page.mouse.click(720, 760, { button: 'right' });
await page.waitForTimeout(300);
console.log('desktop context menu:', await page.getByRole('menu').isVisible());
await page.keyboard.press('Escape');
await page.waitForTimeout(200);

// console errors
console.log('CONSOLE ERRORS:', JSON.stringify(errors.slice(0, 10)));
await page.screenshot({ path: '/tmp/qa-apps.png' });

// controller
await page.goto('http://127.0.0.1:4173/?controller=1', { waitUntil: 'networkidle' });
await page.waitForTimeout(800);
console.log('controller touchpad:', await page.locator('[aria-label^="Touchpad"]').isVisible());
await page.locator('nav button').filter({ hasText: 'Keyboard' }).click();
await page.waitForTimeout(300);
console.log('keyboard panel keys:', await page.getByRole('button', { name: 'Esc', exact: true }).count());
await page.screenshot({ path: '/tmp/qa-controller.png' });
console.log('controller errors:', JSON.stringify(errors.slice(0, 10)));
await browser.close();
