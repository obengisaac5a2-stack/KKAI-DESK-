# KK DEX

A complete interactive React desktop workspace for an external monitor, with a separate phone-controller surface.

## Run

1. `npm install`
2. `npm run dev`
3. Open the desktop at `/` and the separate controller at `/?controller`.

## Build

`npm run build` produces an inlined HTML application and its local assets in `dist/`. Copy the entire directory to the trusted WebView asset directory. See [INTEGRATION.md](./INTEGRATION.md) before integrating with Android.

## Systems

- `src/system.tsx`: application lifecycle, window state, managed storage, persistence, undo/redo, settings, notifications, and dialogs.
- `src/WindowManager.tsx`: registered application content, independent floating windows, dragging, eight-way resizing, focus, minimize, maximize, restore, and edge snapping.
- `src/Desktop.tsx`: desktop shortcuts, non-overlapping persistent placement, selection, desktop context menu, and keyboard shortcuts.
- `src/Panels.tsx`: taskbar, Start, app search, task view, notifications, calendar, quick settings, context menus, and system dialogs.
- `src/bridge.tsx`: the preserved KKDexAPI contract, actual DOM input, pointer synchronization, selection, text editing, and keyboard forwarding.
- `src/Controller.tsx`: the independent touchpad and keyboard interface. Native transport is required; the phone does not mirror the desktop.
- `src/icons.tsx` and `src/registry.ts`: reusable professional SVG iconography and application registration.
- `src/apps/`: functional Files / This PC, Browser, KK AI, App Center, Settings, Gallery, Notes, Calculator, Terminal, and Recycle Bin.

## Genuine Capabilities

Files and notes are real locally persisted workspace data. Import and export use the actual browser file APIs. The calculator evaluates mathematical expressions without `eval`. The terminal executes explicitly documented workspace operations, not a simulated Android shell. The browser maintains genuine tabs and per-tab navigation, with a sandboxed web-content frame and a system-browser action.

AI, arbitrary Android filesystem access, package installation, Bluetooth, hardware network/power controls, and Android shell execution are not fabricated. Their UI states explain when a native service is unavailable. Optional native adapters are documented separately.

## Verify

- `npx tsc --noEmit`
- `npx playwright install chromium`
- `npx playwright install-deps chromium` if Linux browser libraries are missing.
- Run the dev server, then `npx playwright test`.
- `npm run build`

Tests cover both desktop interactions and bridge-generated input. They do not replace tests on the physical Android controller, external display, or native backend.
