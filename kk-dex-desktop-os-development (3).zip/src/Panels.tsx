import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  ArrowLeft,
  ArrowUpRight,
  Battery,
  BatteryCharging,
  Bell,
  Bluetooth,
  Check,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock3,
  Info,
  LayoutGrid,
  Monitor,
  Moon,
  PanelsTopLeft,
  Power,
  RotateCw,
  Search,
  Settings2,
  ShieldCheck,
  Sun,
  Trash2,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { AppIcon, BrandMark } from "./icons";
import { apps, appRegistry, pinnedApps } from "./registry";
import { useSystem } from "./system";
import { IconButton } from "./ui";
import type { MenuItem } from "./types";

function useClock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);
  return time;
}

export function Taskbar() {
  const {
    windows,
    activeId,
    panel,
    openApp,
    minimizeWindow,
    focusWindow,
    closeWindow,
    setContextMenu,
    togglePanel,
    preferences,
    online,
    notifications,
    showDesktop,
  } = useSystem();
  const time = useClock();
  const [battery, setBattery] = useState<{
    level: number;
    charging: boolean;
  } | null>(null);
  useEffect(() => {
    const navigatorWithBattery = navigator as Navigator & {
      getBattery?: () => Promise<{
        level: number;
        charging: boolean;
        addEventListener: (event: string, callback: () => void) => void;
        removeEventListener: (event: string, callback: () => void) => void;
      }>;
    };
    let cleanup = () => {};
    void navigatorWithBattery
      .getBattery?.()
      .then((info) => {
        const update = () =>
          setBattery({
            level: Math.round(info.level * 100),
            charging: info.charging,
          });
        update();
        info.addEventListener("levelchange", update);
        info.addEventListener("chargingchange", update);
        cleanup = () => {
          info.removeEventListener("levelchange", update);
          info.removeEventListener("chargingchange", update);
        };
      })
      .catch(() => {});
    return () => cleanup();
  }, []);
  const taskApps = [
    ...pinnedApps,
    ...windows.filter((w) => !pinnedApps.includes(w.appId)).map((w) => w.appId),
  ];
  const unread = notifications.some((n) => !n.read);
  return (
    <footer
      className="taskbar"
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setContextMenu({
          x: e.clientX,
          y: e.clientY,
          items: [
            {
              label: "Task view",
              icon: <PanelsTopLeft size={15} />,
              action: () => togglePanel("tasks"),
            },
            {
              label: "Show desktop",
              icon: <Monitor size={15} />,
              shortcut: "Super+D",
              action: showDesktop,
            },
            {
              label: "Taskbar personalization",
              icon: <Settings2 size={15} />,
              divider: true,
              action: () => openApp("settings", "appearance"),
            },
          ],
        });
      }}
    >
      <button
        className="taskbar-brand"
        onClick={() => openApp("settings", "about")}
        title="About KK DEX"
      >
        <BrandMark size={23} />
        <strong>KK DEX</strong>
        <span className="taskbar-brand-divider" />
        <span>Desktop</span>
      </button>
      <div className="taskbar-center">
        <button
          className={`taskbar-button start-button ${panel === "start" ? "panel-active" : ""}`}
          aria-label="Start menu"
          title="Start"
          onClick={() => togglePanel("start")}
        >
          <BrandMark size={26} />
        </button>
        <button
          className={`taskbar-button ${panel === "search" ? "panel-active" : ""}`}
          aria-label="Search desktop"
          title="Search"
          onClick={() => togglePanel("search")}
        >
          <Search size={23} strokeWidth={1.7} />
        </button>
        <button
          className={`taskbar-button task-view-button ${panel === "tasks" ? "panel-active" : ""}`}
          aria-label="Task view"
          title="Task view"
          onClick={() => togglePanel("tasks")}
        >
          <PanelsTopLeft size={22} strokeWidth={1.6} />
        </button>
        <span className="taskbar-divider" />
        {taskApps.map((id) => {
          const win = windows.find((w) => w.appId === id),
            active = win?.id === activeId && !win.minimized;
          return (
            <button
              key={id}
              data-taskbar-app={id}
              className={`taskbar-button taskbar-app ${win ? "running" : ""} ${active ? "active-app" : ""}`}
              aria-label={`${appRegistry[id].name}${win ? " - running" : ""}`}
              title={appRegistry[id].name}
              onClick={() => {
                if (!win) openApp(id);
                else if (active) minimizeWindow(win.id);
                else focusWindow(win.id);
              }}
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setContextMenu({
                  x: e.clientX,
                  y: e.clientY,
                  items: [
                    {
                      label: appRegistry[id].name,
                      icon: <AppIcon app={id} size={20} />,
                      action: () => openApp(id),
                    },
                    ...(win
                      ? [
                          {
                            label: win.minimized
                              ? "Restore window"
                              : "Minimize window",
                            action: () =>
                              win.minimized
                                ? focusWindow(win.id)
                                : minimizeWindow(win.id),
                            divider: true,
                          },
                          {
                            label: "Close window",
                            icon: <X size={15} />,
                            action: () => closeWindow(win.id),
                          },
                        ]
                      : []),
                  ],
                });
              }}
            >
              <AppIcon app={id} size={29} />
              <span className="running-indicator" />
            </button>
          );
        })}
      </div>
      <div className="system-tray">
        <IconButton
          className="tray-chevron"
          label="Quick settings"
          onClick={() => togglePanel("quick")}
        >
          <ChevronUp size={14} />
        </IconButton>
        <button
          className={`tray-status ${panel === "quick" ? "panel-active" : ""}`}
          onClick={() => togglePanel("quick")}
          aria-label="Network, volume and display settings"
          title={`Network ${online ? "online" : "offline"} / Volume ${preferences.muted ? "muted" : `${preferences.volume}%`}`}
        >
          {online ? <Wifi size={16} /> : <WifiOff size={16} />}{" "}
          {preferences.muted || preferences.volume === 0 ? (
            <VolumeX size={16} />
          ) : (
            <Volume2 size={16} />
          )}{" "}
          {battery ? (
            battery.charging ? (
              <BatteryCharging size={20} />
            ) : (
              <Battery size={20} />
            )
          ) : (
            <Monitor size={16} />
          )}
        </button>
        <button
          className={`taskbar-clock ${panel === "calendar" ? "panel-active" : ""}`}
          onClick={() => togglePanel("calendar")}
          aria-label="Open calendar"
          title={time.toLocaleDateString(undefined, { dateStyle: "full" })}
        >
          <span>
            {time.toLocaleTimeString(undefined, {
              hour: "numeric",
              minute: "2-digit",
            })}
          </span>
          <span>
            {time.toLocaleDateString(undefined, {
              month: "2-digit",
              day: "2-digit",
              year: "numeric",
            })}
          </span>
        </button>
        <button
          className={`notification-button ${panel === "notifications" ? "panel-active" : ""}`}
          aria-label="Notification center"
          title="Notifications"
          onClick={() => togglePanel("notifications")}
        >
          <Bell size={17} />
          {unread && <i />}
        </button>
        <button
          className="show-desktop-button"
          aria-label="Show desktop"
          title="Show desktop"
          onClick={showDesktop}
        />
      </div>
    </footer>
  );
}

function PanelFrame({
  children,
  className,
  name,
}: {
  children: ReactNode;
  className: string;
  name: string;
}) {
  const { preferences } = useSystem();
  return (
    <motion.div
      className={`system-panel ${className}`}
      role="dialog"
      aria-label={name}
      initial={{ opacity: 0, y: 16, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 8, scale: 0.985 }}
      transition={{
        duration: preferences.reducedMotion ? 0 : 0.19,
        ease: [0.2, 0.8, 0.2, 1],
      }}
      onPointerDown={(e) => e.stopPropagation()}
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
    >
      {children}
    </motion.div>
  );
}

function StartMenu({ searchOnly = false }: { searchOnly?: boolean }) {
  const { openApp, recentApps, explain } = useSystem();
  const [search, setSearch] = useState("");
  const [allApps, setAllApps] = useState(searchOnly);
  const [power, setPower] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (searchOnly) setTimeout(() => input.current?.focus(), 100);
  }, [searchOnly]);
  useEffect(() => {
    const find = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "f") {
        event.preventDefault();
        event.stopImmediatePropagation();
        input.current?.focus();
      }
    };
    window.addEventListener("keydown", find, true);
    return () => window.removeEventListener("keydown", find, true);
  }, []);
  const visible = apps.filter((a) =>
    `${a.name} ${a.description}`.toLowerCase().includes(search.toLowerCase()),
  );
  const powerAction = (action: "sleep" | "restart" | "shutdown") => {
    if (window.KKDexServices?.power) window.KKDexServices.power(action);
    else
      explain(
        "Device power is not connected",
        "The desktop cannot control Android device power in this environment. Connect the native power adapter to enable sleep, restart, or shutdown. Your workspace has not been interrupted.",
      );
    setPower(false);
  };
  return (
    <PanelFrame
      className="start-panel"
      name={searchOnly ? "Desktop search" : "Start menu"}
    >
      <div className="start-search">
        <Search size={17} />
        <input
          ref={input}
          aria-label="Search apps in Start"
          placeholder="Search for apps, find your flow"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <kbd>Ctrl + F</kbd>
      </div>
      <div className="start-body">
        <div className="start-section-title">
          <h3>
            {search
              ? "Search results"
              : allApps
                ? "All applications"
                : "Pinned"}
          </h3>
          {!search && (
            <button onClick={() => setAllApps((a) => !a)}>
              {allApps ? "Pinned apps" : "All apps"}
              <ChevronRight size={12} />
            </button>
          )}
        </div>
        <div
          className={allApps || search ? "start-all-apps" : "start-app-grid"}
        >
          {visible.map((a) => (
            <button key={a.id} onClick={() => openApp(a.id)}>
              <AppIcon app={a.id} size={allApps || search ? 33 : 39} />
              <span>{a.name}</span>
              {(allApps || search) && <small>{a.description}</small>}
            </button>
          ))}
        </div>
        {!visible.length && (
          <p className="start-no-results">No apps match "{search}".</p>
        )}
        {!allApps && !search && (
          <>
            <div className="start-section-title recommended-heading">
              <h3>Pick up where you left off</h3>
              <Clock3 size={14} />
            </div>
            <div className="start-recommended">
              {recentApps.slice(0, 4).map((id) => (
                <button key={id} onClick={() => openApp(id)}>
                  <AppIcon app={id} size={33} />
                  <span>
                    <strong>{appRegistry[id].name}</strong>
                    <small>Used in this workspace</small>
                  </span>
                </button>
              ))}
            </div>
          </>
        )}
      </div>
      <div className="start-footer">
        <button
          className="start-profile"
          onClick={() => openApp("settings", "about")}
        >
          <span className="profile-avatar">KK</span>
          <span>
            <strong>KK DEX</strong>
            <small>Your personal workspace</small>
          </span>
        </button>
        <div className="power-control">
          <IconButton
            label="Power menu"
            className={power ? "chosen" : ""}
            onClick={() => setPower((p) => !p)}
          >
            <Power size={20} />
          </IconButton>
          {power && (
            <div className="power-menu">
              <button onClick={() => powerAction("sleep")}>
                <Moon size={15} />
                Sleep
              </button>
              <button onClick={() => powerAction("restart")}>
                <RotateCw size={15} />
                Restart
              </button>
              <button onClick={() => powerAction("shutdown")}>
                <Power size={15} />
                Shut down
              </button>
            </div>
          )}
        </div>
      </div>
    </PanelFrame>
  );
}

function QuickSettings() {
  const {
    preferences: p,
    setPreference,
    online,
    explain,
    openApp,
  } = useSystem();
  return (
    <PanelFrame className="quick-panel" name="Quick settings">
      <div className="panel-heading">
        <h3>A little fine-tuning.</h3>
        <IconButton
          label="Open system settings"
          onClick={() => openApp("settings")}
        >
          <Settings2 size={17} />
        </IconButton>
      </div>
      <div className="quick-toggles">
        <button
          className={online ? "on" : ""}
          onClick={() => {
            if (window.KKDexServices?.setWifi)
              window.KKDexServices.setWifi(!online);
            else
              explain(
                "Network status",
                `This workspace is currently ${online ? "online" : "offline"} according to the browser. Changing Wi-Fi networks requires the Android native network adapter. No connection setting has been changed.`,
              );
          }}
        >
          {online ? <Wifi size={23} /> : <WifiOff size={23} />}
          <strong>Network</strong>
          <small>{online ? "Online" : "Offline"}</small>
        </button>
        <button
          onClick={() =>
            explain(
              "Bluetooth",
              "Bluetooth controls are not connected. Pair and manage Bluetooth devices in Android system settings.",
            )
          }
        >
          <Bluetooth size={23} />
          <strong>Bluetooth</strong>
          <small>Not connected</small>
        </button>
        <button
          className={p.theme === "dark" ? "on" : ""}
          onClick={() =>
            setPreference("theme", p.theme === "dark" ? "light" : "dark")
          }
        >
          <Moon size={23} />
          <strong>Dark mode</strong>
          <small>{p.theme === "dark" ? "On" : "Off"}</small>
        </button>
      </div>
      <div className="quick-sliders">
        <div>
          <Sun size={18} />
          <input
            type="range"
            min="35"
            max="100"
            value={p.brightness}
            aria-label="Quick workspace brightness"
            onChange={(e) => {
              const value = Number(e.target.value);
              setPreference("brightness", value);
              window.KKDexServices?.setBrightness?.(value);
            }}
          />
          <span>{p.brightness}%</span>
        </div>
        <div>
          <IconButton
            label={p.muted ? "Unmute" : "Mute"}
            onClick={() => setPreference("muted", !p.muted)}
          >
            {p.muted ? <VolumeX size={19} /> : <Volume2 size={19} />}
          </IconButton>
          <input
            type="range"
            min="0"
            max="100"
            value={p.muted ? 0 : p.volume}
            aria-label="Quick workspace volume"
            onChange={(e) => {
              const value = Number(e.target.value);
              setPreference("volume", value);
              setPreference("muted", false);
              window.KKDexServices?.setVolume?.(value);
            }}
          />
          <span>{p.muted ? 0 : p.volume}%</span>
        </div>
      </div>
      <div className="quick-footer">
        <span>
          <Monitor size={14} />
          Workspace display
        </span>
        <button onClick={() => openApp("settings", "sound")}>
          Audio settings
          <ChevronRight size={12} />
        </button>
      </div>
    </PanelFrame>
  );
}

function CalendarPanel() {
  const time = useClock();
  const [month, setMonth] = useState(
    new Date(time.getFullYear(), time.getMonth(), 1),
  );
  const [selected, setSelected] = useState(new Date());
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const first = (month.getDay() + 6) % 7;
  const dayValues = Array.from(
    { length: Math.ceil((first + days) / 7) * 7 },
    (_, i) => i - first + 1,
  );
  const changeMonth = (direction: number) =>
    setMonth((m) => new Date(m.getFullYear(), m.getMonth() + direction, 1));
  return (
    <PanelFrame className="calendar-panel" name="Calendar">
      <div className="calendar-current">
        <span>
          {time.toLocaleDateString(undefined, {
            weekday: "long",
            month: "long",
            day: "numeric",
          })}
        </span>
        <strong>
          {time.toLocaleTimeString(undefined, {
            hour: "numeric",
            minute: "2-digit",
          })}
          <small>
            {time.toLocaleTimeString(undefined, { second: "2-digit" })}
          </small>
        </strong>
      </div>
      <div className="calendar-month">
        <strong>
          {month.toLocaleDateString(undefined, {
            month: "long",
            year: "numeric",
          })}
        </strong>
        <div>
          <IconButton label="Previous month" onClick={() => changeMonth(-1)}>
            <ChevronLeft size={16} />
          </IconButton>
          <IconButton label="Next month" onClick={() => changeMonth(1)}>
            <ChevronRight size={16} />
          </IconButton>
        </div>
      </div>
      <div className="calendar-grid">
        {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
          <span key={`day-${i}`} className="calendar-weekday">
            {d}
          </span>
        ))}
        {dayValues.map((d) => {
          const date = new Date(month.getFullYear(), month.getMonth(), d),
            outside = d < 1 || d > days,
            today = date.toDateString() === time.toDateString(),
            chosen = date.toDateString() === selected.toDateString();
          return (
            <button
              key={d}
              className={`${outside ? "outside-month" : ""} ${today ? "today" : ""} ${chosen ? "selected-day" : ""}`}
              onClick={() => setSelected(date)}
            >
              {date.getDate()}
            </button>
          );
        })}
      </div>
      <div className="calendar-footer">
        <span>
          {selected.toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
          })}{" "}
          <small>No calendar service connected</small>
        </span>
        <button
          onClick={() => {
            setMonth(new Date(time.getFullYear(), time.getMonth(), 1));
            setSelected(new Date());
          }}
        >
          Today
        </button>
      </div>
    </PanelFrame>
  );
}

function NotificationPanel() {
  const { notifications, setNotifications, openApp } = useSystem();
  return (
    <PanelFrame className="notification-panel" name="Notifications">
      <div className="panel-heading">
        <h3>Notifications</h3>
        <button
          disabled={!notifications.length}
          className="text-tool"
          onClick={() => setNotifications([])}
        >
          Clear all
        </button>
      </div>
      {notifications.length ? (
        <div className="notification-list">
          {notifications.map((n) => (
            <div className="notification-item" key={n.id}>
              <div className="notification-item-header">
                {n.appId ? (
                  <AppIcon app={n.appId} size={22} />
                ) : (
                  <Bell size={17} />
                )}
                <span>{n.appId ? appRegistry[n.appId].name : "KK DEX"}</span>
                <small>
                  {new Date(n.time).toLocaleTimeString(undefined, {
                    hour: "numeric",
                    minute: "2-digit",
                  })}
                </small>
                <IconButton
                  label={`Dismiss ${n.title}`}
                  onClick={() =>
                    setNotifications((ns) => ns.filter((x) => x.id !== n.id))
                  }
                >
                  <X size={13} />
                </IconButton>
              </div>
              <button onClick={() => n.appId && openApp(n.appId)}>
                <strong>{n.title}</strong>
                <p>{n.message}</p>
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="notifications-empty">
          <Bell size={33} strokeWidth={1.2} />
          <h3>All caught up.</h3>
          <p>A little peace and quiet.</p>
        </div>
      )}
      <div className="notification-panel-footer">
        <ShieldCheck size={13} />A space for the things that matter.
      </div>
    </PanelFrame>
  );
}

function TaskView() {
  const { windows, focusWindow, closeWindow, setPanel, activeId, showDesktop } =
    useSystem();
  return (
    <PanelFrame className="task-view-panel" name="Task view">
      <div className="panel-heading">
        <h3>Your open spaces</h3>
        <span>{windows.length} applications</span>
      </div>
      <div className="task-view-grid">
        {[...windows]
          .sort((a, b) => a.z - b.z)
          .map((w) => (
            <div
              className={`task-preview ${w.id === activeId ? "active" : ""}`}
              key={w.id}
            >
              <div>
                <span>
                  <AppIcon app={w.appId} size={19} />
                  {w.title}
                </span>
                <IconButton
                  label={`Close ${w.title} from task view`}
                  onClick={() => closeWindow(w.id)}
                >
                  <X size={14} />
                </IconButton>
              </div>
              <button
                onClick={() => {
                  focusWindow(w.id);
                  setPanel(null);
                }}
              >
                <AppIcon app={w.appId} size={52} />
                <strong>{w.title}</strong>
                <small>
                  {w.minimized ? "Minimized" : "Open in your workspace"}
                </small>
              </button>
            </div>
          ))}
      </div>
      <div className="task-view-footer">
        <span>
          <Monitor size={14} />
          Desktop 1
        </span>
        <button onClick={showDesktop}>
          Show desktop
          <ArrowUpRight size={13} />
        </button>
      </div>
    </PanelFrame>
  );
}

function ContextMenu() {
  const { contextMenu, setContextMenu, size } = useSystem();
  const [submenu, setSubmenu] = useState<MenuItem[] | null>(null);
  const [parentLabel, setParentLabel] = useState("");
  useEffect(() => {
    setSubmenu(null);
  }, [contextMenu]);
  if (!contextMenu) return null;
  const items = submenu || contextMenu.items;
  const height =
    items.length * 35 +
    items.filter((x) => x.divider).length * 9 +
    (submenu ? 39 : 12);
  return (
    <motion.div
      role="menu"
      className="context-menu"
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.1 }}
      style={{
        left: Math.max(6, Math.min(size.width - 258, contextMenu.x)),
        top: Math.max(6, Math.min(size.height - height - 8, contextMenu.y)),
      }}
      onPointerDown={(e) => e.stopPropagation()}
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
    >
      {submenu && (
        <button className="context-back" onClick={() => setSubmenu(null)}>
          <ArrowLeft size={14} />
          {parentLabel}
        </button>
      )}
      {items.map((item, i) => (
        <div key={`${item.label}-${i}`}>
          {item.divider && <div className="context-divider" />}
          <button
            role="menuitem"
            aria-label={item.label}
            aria-keyshortcuts={item.shortcut}
            disabled={item.disabled}
            className={item.danger ? "danger-text" : ""}
            onClick={() => {
              if (item.children) {
                setSubmenu(item.children);
                setParentLabel(item.label);
              } else {
                setContextMenu(null);
                item.action?.();
              }
            }}
          >
            <span className="context-icon">{item.icon}</span>
            <span>{item.label}</span>
            {item.shortcut && <kbd>{item.shortcut}</kbd>}
            {item.children && <ChevronRight size={13} />}
          </button>
        </div>
      ))}
    </motion.div>
  );
}

function SystemDialog() {
  const { dialog, setDialog } = useSystem();
  const [value, setValue] = useState(dialog?.initialValue || "");
  const input = useRef<HTMLInputElement>(null);
  const confirm = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    setValue(dialog?.initialValue || "");
    const timer = setTimeout(() => {
      if (dialog?.input) {
        input.current?.focus();
        input.current?.select();
      } else confirm.current?.focus();
    }, 50);
    return () => clearTimeout(timer);
  }, [dialog]);
  if (!dialog) return null;
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (dialog.input && !value.trim()) return;
    const action = dialog.onConfirm;
    setDialog(null);
    action?.(value);
  };
  return (
    <div
      className="dialog-backdrop"
      onPointerDown={(e) => {
        e.stopPropagation();
        if (e.target === e.currentTarget) setDialog(null);
      }}
    >
      <motion.form
        className="system-dialog"
        role="dialog"
        aria-modal="true"
        aria-label={dialog.title}
        initial={{ opacity: 0, scale: 0.96, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        onSubmit={submit}
        onContextMenu={(e) => e.stopPropagation()}
      >
        <div className="dialog-heading">
          <div className={`dialog-icon ${dialog.danger ? "danger-icon" : ""}`}>
            {dialog.danger ? (
              <Trash2 size={23} />
            ) : dialog.input ? (
              <FolderPlusIcon />
            ) : (
              <Info size={23} />
            )}
          </div>
          <IconButton label="Close dialog" onClick={() => setDialog(null)}>
            <X size={17} />
          </IconButton>
        </div>
        <h2>{dialog.title}</h2>
        {dialog.message && <p>{dialog.message}</p>}
        {dialog.input && (
          <input
            className="dialog-input"
            ref={input}
            aria-label={dialog.title === "Rename" ? "New name" : "Folder name"}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            required
            autoComplete="off"
          />
        )}
        <div className="dialog-actions">
          {dialog.onConfirm && (
            <button
              className="secondary-button"
              type="button"
              onClick={() => setDialog(null)}
            >
              Cancel
            </button>
          )}
          <button
            ref={confirm}
            type="submit"
            disabled={dialog.input && !value.trim()}
            className={dialog.danger ? "danger-button" : "primary-button"}
          >
            {dialog.confirmLabel || "Okay"}
          </button>
        </div>
      </motion.form>
    </div>
  );
}
function FolderPlusIcon() {
  return <LayoutGrid size={23} />;
}

export function SystemOverlays() {
  const { panel, setPanel, contextMenu, setContextMenu, dialog, toast } =
    useSystem();
  return (
    <>
      {(panel || contextMenu) && (
        <div
          className={`system-dismiss ${contextMenu ? "context-dismiss" : ""}`}
          onPointerDown={(e) => {
            e.stopPropagation();
            setPanel(null);
            setContextMenu(null);
          }}
          onContextMenu={(e) => {
            e.preventDefault();
            setPanel(null);
            setContextMenu(null);
          }}
        />
      )}
      <AnimatePresence>
        {panel === "start" && <StartMenu key="start" />}
        {panel === "search" && <StartMenu searchOnly key="search" />}
        {panel === "quick" && <QuickSettings key="quick" />}
        {panel === "calendar" && <CalendarPanel key="calendar" />}
        {panel === "notifications" && <NotificationPanel key="notifications" />}
        {panel === "tasks" && <TaskView key="tasks" />}
      </AnimatePresence>
      <AnimatePresence>{contextMenu && <ContextMenu />}</AnimatePresence>
      {dialog && <SystemDialog />}
      <AnimatePresence mode="wait">
        {toast && (
          <motion.div
            className="system-toast"
            role="status"
            key={toast}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 6 }}
          >
            <Check size={16} />
            <span>{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
