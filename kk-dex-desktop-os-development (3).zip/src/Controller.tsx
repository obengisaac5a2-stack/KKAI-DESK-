import { useRef, useState, type PointerEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  ChevronDown,
  Keyboard,
  Monitor,
  Mouse,
  MousePointer2,
  Move,
  Send,
  Smartphone,
  X,
} from "lucide-react";
import { BrandMark } from "./icons";
import type { InputMessage } from "./types";

export default function Controller() {
  const [text, setText] = useState("");
  const [keyboard, setKeyboard] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [modifiers, setModifiers] = useState({
    ctrl: false,
    alt: false,
    shift: false,
    meta: false,
  });
  const [notice, setNotice] = useState("");
  const [touching, setTouching] = useState(false);
  const points = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({ x: 0, y: 0, time: 0, moved: false, fingers: 1 });
  const lastTap = useRef(0);
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const connected = !!window.KKDexControllerBridge?.sendInput;
  const send = (message: InputMessage) => {
    if (window.KKDexControllerBridge?.sendInput)
      window.KKDexControllerBridge.sendInput(JSON.stringify(message));
    else
      setNotice(
        "No external display transport is connected. The Android host must relay controller input to the desktop WebView.",
      );
  };
  const pressKey = (key: string) => send({ type: "pressKey", key, modifiers });
  const down = (e: PointerEvent) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (points.current.size === 1)
      gesture.current = {
        x: e.clientX,
        y: e.clientY,
        time: Date.now(),
        moved: false,
        fingers: 1,
      };
    else
      gesture.current.fingers = Math.max(
        gesture.current.fingers,
        points.current.size,
      );
    setTouching(true);
  };
  const move = (e: PointerEvent) => {
    const previous = points.current.get(e.pointerId);
    if (!previous) return;
    const dx = e.clientX - previous.x,
      dy = e.clientY - previous.y;
    if (
      Math.hypot(e.clientX - gesture.current.x, e.clientY - gesture.current.y) >
      5
    )
      gesture.current.moved = true;
    points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (points.current.size > 1)
      send({ type: "scrollDesktop", dx: -dx * 1.5, dy: -dy * 1.5 });
    else
      send({ type: "movePointer", dx: dx * 1.6, dy: dy * 1.6, relative: true });
  };
  const up = (e: PointerEvent) => {
    points.current.delete(e.pointerId);
    if (!points.current.size) setTouching(false);
    if (gesture.current.moved || points.current.size) return;
    if (gesture.current.fingers > 1 || Date.now() - gesture.current.time > 550)
      send({ type: "pointerRightClick" });
    else if (Date.now() - lastTap.current < 300) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      send({ type: "pointerDoubleClick" });
      lastTap.current = 0;
    } else {
      lastTap.current = Date.now();
      tapTimer.current = setTimeout(() => send({ type: "pointerClick" }), 300);
    }
  };
  return (
    <div className="controller-page">
      <header className="controller-header">
        <div>
          <BrandMark size={25} />
          <strong>KK DEX</strong>
          <span>CONTROLLER</span>
        </div>
        <span
          className={`controller-connection ${connected ? "connected" : ""}`}
        >
          <span />
          {connected ? "Native transport available" : "Not connected"}
        </span>
      </header>
      <main className="controller-main">
        <div className="controller-title">
          <span className="eyebrow">SMALL SCREEN. BIG POSSIBILITIES.</span>
          <h1>
            Your desktop,
            <br />
            at your fingertips.
          </h1>
          <p>Your phone is the controller. Your display is the workspace.</p>
        </div>
        <div className="controller-tools">
          <span>
            <MousePointer2 size={15} />
            Touchpad
          </span>
          <button
            className={dragging ? "active" : ""}
            onClick={() => {
              send({ type: dragging ? "pointerUp" : "pointerDown" });
              setDragging(!dragging);
            }}
          >
            <Move size={15} />
            {dragging ? "Release drag" : "Drag mode"}
          </button>
        </div>
        <div
          className={`touchpad ${touching ? "touching" : ""}`}
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerCancel={(e) => {
            points.current.delete(e.pointerId);
            setTouching(false);
          }}
        >
          <div>
            <MousePointer2 size={30} strokeWidth={1.2} />
            <strong>A natural connection.</strong>
            <span>Slide to move. Tap to click.</span>
            <small>Two fingers to scroll. Hold for right-click.</small>
          </div>
          <span className="touchpad-corner top-left" />
          <span className="touchpad-corner top-right" />
          <span className="touchpad-corner bottom-left" />
          <span className="touchpad-corner bottom-right" />
        </div>
        <div className="controller-mouse-buttons">
          <button
            onPointerDown={() => send({ type: "pointerDown" })}
            onPointerUp={() => send({ type: "pointerUp" })}
            onPointerCancel={() => send({ type: "pointerUp" })}
          >
            <Mouse size={18} />
            Left click
          </button>
          <button onClick={() => send({ type: "pointerRightClick" })}>
            <Mouse size={18} />
            Right click
          </button>
        </div>
        <button
          className={`controller-keyboard-toggle ${keyboard ? "active" : ""}`}
          onClick={() => setKeyboard((k) => !k)}
        >
          <Keyboard size={20} />
          <span>Keyboard & shortcuts</span>
          <ChevronDown size={17} />
        </button>
        {keyboard && (
          <div className="controller-keyboard">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (text) {
                  send({ type: "insertText", text });
                  setText("");
                }
              }}
            >
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type for your desktop"
                aria-label="Text to send to desktop"
              />
              <button type="submit" aria-label="Send text">
                <Send size={18} />
              </button>
            </form>
            <div className="controller-modifiers">
              {(["ctrl", "alt", "shift", "meta"] as const).map((key) => (
                <button
                  key={key}
                  className={modifiers[key] ? "active" : ""}
                  onClick={() =>
                    setModifiers((m) => ({ ...m, [key]: !m[key] }))
                  }
                >
                  {key === "meta"
                    ? "Super"
                    : key[0].toUpperCase() + key.slice(1)}
                </button>
              ))}
            </div>
            <div className="controller-key-row">
              {[
                "Escape",
                "Tab",
                "Backspace",
                "Enter",
                "Delete",
                "F2",
                "F5",
              ].map((key) => (
                <button key={key} onClick={() => pressKey(key)}>
                  {key === "Escape" ? "Esc" : key}
                </button>
              ))}
            </div>
            <div className="controller-key-row">
              {[
                ["ArrowLeft", ArrowLeft],
                ["ArrowUp", ArrowUp],
                ["ArrowDown", ArrowDown],
                ["ArrowRight", ArrowRight],
              ].map(([key, Icon]) => {
                const KeyIcon = Icon as typeof ArrowLeft;
                return (
                  <button
                    key={key as string}
                    aria-label={key as string}
                    onClick={() => pressKey(key as string)}
                  >
                    <KeyIcon size={16} />
                  </button>
                );
              })}
              <button
                onClick={() =>
                  send({
                    type: "pressKey",
                    key: "e",
                    modifiers: { meta: true },
                  })
                }
              >
                Files
              </button>
              <button
                onClick={() =>
                  send({
                    type: "pressKey",
                    key: "d",
                    modifiers: { meta: true },
                  })
                }
              >
                Desktop
              </button>
            </div>
          </div>
        )}
        {notice && (
          <div className="controller-notice">
            <Monitor size={19} />
            <p>{notice}</p>
            <button
              aria-label="Dismiss controller notice"
              onClick={() => setNotice("")}
            >
              <X size={16} />
            </button>
          </div>
        )}
        <footer className="controller-footer">
          <Smartphone size={15} />
          <span>One phone. A whole new perspective.</span>
        </footer>
      </main>
    </div>
  );
}
