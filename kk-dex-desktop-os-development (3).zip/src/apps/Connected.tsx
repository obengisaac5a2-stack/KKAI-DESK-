import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowUpRight,
  Check,
  ExternalLink,
  Globe,
  Home,
  Info,
  LoaderCircle,
  LockKeyhole,
  MessageSquare,
  Mic,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { AppIcon } from "../icons";
import { apps } from "../registry";
import { useSystem } from "../system";
import { persist, readPersisted, uid } from "../storage";
import { EmptyState, IconButton } from "../ui";
import type { ChatMessage, DesktopWindow } from "../types";

type BrowserTab = { id: string; history: string[]; index: number };
export function BrowserApp({ win }: { win: DesktopWindow }) {
  const { activeId, explain } = useSystem();
  const [tabs, setTabs] = useState<BrowserTab[]>([
    { id: "first-tab", history: ["about:home"], index: 0 },
  ]);
  const [active, setActive] = useState("first-tab");
  const [address, setAddress] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [loading, setLoading] = useState(false);
  const addressRef = useRef<HTMLInputElement>(null);
  const tab = tabs.find((t) => t.id === active) || tabs[0];
  const url = tab.history[tab.index];
  const isHome = url === "about:home";
  useEffect(() => {
    setAddress(isHome ? "" : url);
  }, [url, active]);
  const navigate = (raw: string) => {
    if (!raw.trim()) return;
    let target = raw.trim();
    if (target !== "about:home" && !/^https?:\/\//i.test(target))
      target =
        /^[\w-]+(\.[\w-]+)+(?::\d+)?(?:\/.*)?$/.test(target) ||
        target.startsWith("localhost")
          ? `https://${target}`
          : `https://duckduckgo.com/?q=${encodeURIComponent(target)}`;
    if (target !== "about:home") {
      try {
        const parsed = new URL(target);
        if (!["https:", "http:"].includes(parsed.protocol)) throw new Error();
      } catch {
        explain("Invalid address", "Enter a valid HTTP or HTTPS address.");
        return;
      }
    }
    setTabs((ts) =>
      ts.map((t) =>
        t.id === active
          ? {
              ...t,
              history: [...t.history.slice(0, t.index + 1), target],
              index: t.index + 1,
            }
          : t,
      ),
    );
    setLoading(target !== "about:home");
  };
  const newTab = () => {
    const id = uid();
    setTabs((ts) => [...ts, { id, history: ["about:home"], index: 0 }]);
    setActive(id);
    setTimeout(() => addressRef.current?.focus(), 50);
  };
  const closeTab = (id: string) => {
    if (tabs.length === 1) {
      setTabs([{ id, history: ["about:home"], index: 0 }]);
      return;
    }
    const remaining = tabs.filter((t) => t.id !== id);
    setTabs(remaining);
    if (active === id) setActive(remaining[remaining.length - 1].id);
  };
  const external = () => {
    if (isHome) return;
    if (window.KKDexServices?.openBrowser)
      window.KKDexServices.openBrowser(url);
    else {
      const opened = window.open("about:blank", "_blank");
      if (opened) {
        opened.opener = null;
        opened.location.href = url;
      } else
        explain(
          "Open in your browser",
          `Your browser may block new windows. Open this address in your system browser:\n\n${url}`,
        );
    }
  };
  useEffect(() => {
    if (!loading) return;
    const timer = setTimeout(() => setLoading(false), 7000);
    return () => clearTimeout(timer);
  }, [loading, url]);
  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      if (activeId !== win.id) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "l") {
        e.preventDefault();
        addressRef.current?.focus();
        addressRef.current?.select();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "t") {
        e.preventDefault();
        newTab();
      }
      if (e.key === "F5") {
        e.preventDefault();
        setReloadKey((k) => k + 1);
        setLoading(!isHome);
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  });
  const tabName = (t: BrowserTab) => {
    const address = t.history[t.index];
    if (address === "about:home") return "New tab";
    try {
      return new URL(address).hostname.replace("www.", "");
    } catch {
      return "Browser";
    }
  };
  return (
    <div className="browser-app">
      <div className="browser-tabs">
        {tabs.map((t) => (
          <div
            key={t.id}
            className={`browser-tab ${active === t.id ? "active" : ""}`}
          >
            <button onClick={() => setActive(t.id)}>
              <Globe size={12} />
              <span>{tabName(t)}</span>
            </button>
            <IconButton label="Close tab" onClick={() => closeTab(t.id)}>
              <X size={12} />
            </IconButton>
          </div>
        ))}
        <IconButton label="New browser tab" onClick={newTab}>
          <Plus size={16} />
        </IconButton>
      </div>
      <div className="browser-toolbar">
        <IconButton
          label="Go back"
          disabled={tab.index === 0}
          onClick={() =>
            setTabs((ts) =>
              ts.map((t) =>
                t.id === active ? { ...t, index: t.index - 1 } : t,
              ),
            )
          }
        >
          <ArrowLeft size={16} />
        </IconButton>
        <IconButton
          label="Go forward"
          disabled={tab.index >= tab.history.length - 1}
          onClick={() =>
            setTabs((ts) =>
              ts.map((t) =>
                t.id === active ? { ...t, index: t.index + 1 } : t,
              ),
            )
          }
        >
          <ArrowRight size={16} />
        </IconButton>
        <IconButton
          label="Reload page"
          onClick={() => {
            setReloadKey((k) => k + 1);
            setLoading(!isHome);
          }}
        >
          <RefreshCw size={15} className={loading ? "spin" : ""} />
        </IconButton>
        <IconButton label="Browser home" onClick={() => navigate("about:home")}>
          <Home size={15} />
        </IconButton>
        <form
          className="browser-address"
          onSubmit={(e) => {
            e.preventDefault();
            navigate(address);
          }}
        >
          <ShieldCheck size={14} />
          <input
            ref={addressRef}
            aria-label="Browser address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onFocus={(e) => e.target.select()}
            placeholder="Search the web or enter an address"
          />
          <button aria-label="Go to address" type="submit">
            <ArrowRight size={14} />
          </button>
        </form>
        <IconButton
          label="Open in system browser"
          disabled={isHome}
          onClick={external}
        >
          <ExternalLink size={15} />
        </IconButton>
      </div>
      {isHome ? (
        <div className="browser-home">
          <AppIcon app="browser" size={64} />
          <span className="eyebrow">A WORLD OF POSSIBILITY</span>
          <h1>Where to next?</h1>
          <p>Follow your curiosity.</p>
          <form
            className="browser-home-search"
            onSubmit={(e) => {
              e.preventDefault();
              navigate(address);
            }}
          >
            <Search size={18} />
            <input
              aria-label="Search the web"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Search the web or enter an address"
            />
            <button type="submit" aria-label="Search">
              <ArrowRight size={18} />
            </button>
          </form>
          <div className="browser-shortcuts">
            {[
              {
                label: "Wikipedia",
                url: "https://www.wikipedia.org",
                letter: "W",
                color: "wiki",
              },
              {
                label: "DuckDuckGo",
                url: "https://duckduckgo.com",
                letter: "D",
                color: "duck",
              },
              {
                label: "MDN Web Docs",
                url: "https://developer.mozilla.org",
                letter: "M",
                color: "mdn",
              },
              {
                label: "GitHub",
                url: "https://github.com",
                letter: "G",
                color: "github",
              },
            ].map((site) => (
              <button key={site.label} onClick={() => navigate(site.url)}>
                <span className={`website-mark ${site.color}`}>
                  <Globe size={22} />
                </span>
                <span>{site.label}</span>
              </button>
            ))}
          </div>
          <div className="browser-privacy">
            <LockKeyhole size={13} />
            Your browsing. Your space.
          </div>
        </div>
      ) : (
        <div className="browser-web-content">
          <div className="browser-embed-notice">
            <Info size={13} />
            <span>
              Some sites block embedding. Full phone input needs a native
              browser.
            </span>
            <button onClick={external}>
              Open in system browser <ArrowUpRight size={12} />
            </button>
          </div>
          <iframe
            key={`${active}-${reloadKey}-${url}`}
            title={`Web page: ${url}`}
            src={url}
            sandbox="allow-scripts allow-forms allow-popups"
            referrerPolicy="no-referrer"
            onLoad={() => setLoading(false)}
            onError={() => {
              setLoading(false);
              explain(
                "Page unavailable",
                "This site could not be displayed. It may block embedded viewing. Use Open in system browser to continue.",
              );
            }}
          />
        </div>
      )}
    </div>
  );
}

type Conversation = {
  id: string;
  title: string;
  messages: ChatMessage[];
  updated: number;
};
export function AIApp() {
  const { explain } = useSystem();
  const [conversations, setConversations] = useState<Conversation[]>(() =>
    readPersisted("ai-conversations", []),
  );
  const [active, setActive] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState("");
  const bottom = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const conversation = conversations.find((c) => c.id === active);
  const connected = !!window.KKDexServices?.chat;
  useEffect(() => {
    persist("ai-conversations", conversations);
  }, [conversations]);
  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [conversation?.messages, thinking]);
  const newChat = () => {
    if (thinking) return;
    setActive(null);
    setMessage("");
    setError("");
    input.current?.focus();
  };
  const send = async () => {
    if (!message.trim() || thinking) return;
    const text = message.trim();
    if (!connected) {
      setError(
        "KK AI is not connected. Add a genuine AI service through the KKDexServices.chat adapter to send messages. Your text has not been sent.",
      );
      return;
    }
    const id = active || uid(),
      messages: ChatMessage[] = [
        ...(conversation?.messages || []),
        { role: "user", content: text },
      ];
    if (!active) {
      setConversations((cs) => [
        { id, title: text.slice(0, 36), messages, updated: Date.now() },
        ...cs,
      ]);
      setActive(id);
    } else
      setConversations((cs) =>
        cs.map((c) =>
          c.id === id ? { ...c, messages, updated: Date.now() } : c,
        ),
      );
    setMessage("");
    setThinking(true);
    setError("");
    try {
      const response = await window.KKDexServices!.chat!(messages);
      if (typeof response !== "string" || !response.trim())
        throw new Error("The connected service returned an empty response.");
      setConversations((cs) =>
        cs.map((c) =>
          c.id === id
            ? {
                ...c,
                messages: [
                  ...messages,
                  { role: "assistant", content: response },
                ],
                updated: Date.now(),
              }
            : c,
        ),
      );
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "The connected service could not complete this request.",
      );
    } finally {
      setThinking(false);
    }
  };
  return (
    <div className="ai-app">
      <aside className="ai-sidebar">
        <div className="ai-sidebar-brand">
          <AppIcon app="ai" size={27} />
          <strong>KK AI</strong>
        </div>
        <button
          className="new-chat-button"
          onClick={newChat}
          disabled={thinking}
        >
          <Plus size={15} />
          New conversation
        </button>
        <span className="sidebar-caption">Your conversations</span>
        <div className="chat-history">
          {conversations.length ? (
            conversations.map((c) => (
              <button
                key={c.id}
                disabled={thinking}
                className={active === c.id ? "selected" : ""}
                onClick={() => setActive(c.id)}
              >
                <MessageSquare size={14} />
                <span>{c.title}</span>
              </button>
            ))
          ) : (
            <p>
              Your next great idea
              <br />
              starts with a conversation.
            </p>
          )}
        </div>
        <div className="ai-local-note">
          <ShieldCheck size={15} />
          <span>History stays on this device</span>
        </div>
      </aside>
      <main className="ai-main">
        <div className="ai-topbar">
          <span>
            <span className={`status-dot ${connected ? "" : "offline"}`} />
            {connected ? "AI service connected" : "AI service not connected"}
          </span>
          <IconButton
            label="Clear conversation"
            disabled={thinking || !conversation}
            onClick={() => {
              setConversations((cs) => cs.filter((c) => c.id !== active));
              setActive(null);
            }}
          >
            <Trash2 size={15} />
          </IconButton>
        </div>
        <div className="ai-conversation">
          {conversation?.messages.length ? (
            conversation.messages.map((m, i) => (
              <div key={i} className={`ai-message ${m.role}`}>
                <div className="ai-message-avatar">
                  {m.role === "assistant" ? (
                    <AppIcon app="ai" size={25} />
                  ) : (
                    <span>KK</span>
                  )}
                </div>
                <div>
                  <strong>{m.role === "assistant" ? "KK AI" : "You"}</strong>
                  <p>{m.content}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="ai-welcome">
              <AppIcon app="ai" size={70} />
              <span className="eyebrow">
                A LITTLE HELP. A LOT OF POSSIBILITY.
              </span>
              <h1>
                Good things start
                <br />
                with a little curiosity.
              </h1>
              <p>A thinking partner for whatever comes next.</p>
              <div className="ai-suggestions">
                {[
                  "Help me explore a new idea",
                  "Make a plan for my day",
                  "Find a fresh perspective",
                ].map((text) => (
                  <button
                    key={text}
                    onClick={() => {
                      setMessage(text);
                      input.current?.focus();
                    }}
                  >
                    <Sparkles size={15} />
                    <span>{text}</span>
                    <ArrowUpRight size={14} />
                  </button>
                ))}
              </div>
            </div>
          )}
          {thinking && (
            <div className="ai-thinking">
              <LoaderCircle size={16} className="spin" />
              Thinking...
            </div>
          )}
          <div ref={bottom} />
        </div>
        <div className="ai-compose-area">
          {error && (
            <div className="inline-notice">
              <Info size={15} />
              <span>{error}</span>
            </div>
          )}
          <div className="ai-compose">
            <textarea
              ref={input}
              aria-label="Message KK AI"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Ask a question. Explore an idea."
              rows={2}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
            />
            <div>
              <IconButton
                label="Voice input availability"
                onClick={() =>
                  explain(
                    "Voice input",
                    "Voice transcription is not connected in this environment. You can use voice typing on your Android keyboard to enter text through the controller.",
                  )
                }
              >
                <Mic size={17} />
              </IconButton>
              <button
                className="ai-send"
                disabled={!message.trim() || thinking}
                aria-label="Send message"
                onClick={() => void send()}
              >
                {thinking ? (
                  <LoaderCircle size={17} className="spin" />
                ) : (
                  <ArrowUp size={18} />
                )}
              </button>
            </div>
          </div>
          <small>
            {connected
              ? "AI can make mistakes. Check important information."
              : "Connect your AI backend to start a real conversation."}
          </small>
        </div>
      </main>
    </div>
  );
}

export function AppCenter() {
  const { openApp, windows, explain } = useSystem();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All apps");
  const filtered = apps.filter(
    (a) =>
      a.id !== "store" &&
      a.id !== "bin" &&
      `${a.name} ${a.description}`
        .toLowerCase()
        .includes(query.toLowerCase()) &&
      (category === "All apps" || a.category === category),
  );
  return (
    <div className="app-center">
      <div className="app-center-header">
        <div>
          <span className="eyebrow">MADE FOR YOUR BIGGER SCREEN</span>
          <h1>A little more possibility.</h1>
          <p>Your everyday essentials, all in one place.</p>
        </div>
        <AppIcon app="store" size={76} />
      </div>
      <div className="app-center-controls">
        <div className="app-center-tabs">
          {["All apps", "Productivity", "Creativity", "Utilities"].map((c) => (
            <button
              key={c}
              className={category === c ? "active" : ""}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="app-search">
          <Search size={14} />
          <input
            aria-label="Search applications"
            placeholder="Find an app"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>
      <div className="app-catalog">
        {filtered.map((app) => (
          <div className="catalog-app" key={app.id}>
            <AppIcon app={app.id} size={45} />
            <div>
              <strong>{app.name}</strong>
              <p>{app.description}</p>
              <small>
                <Check size={10} />
                Included with KK DEX
              </small>
            </div>
            <button onClick={() => openApp(app.id)}>
              {windows.some((w) => w.appId === app.id) ? "Switch to" : "Open"}
              <ArrowUpRight size={12} />
            </button>
          </div>
        ))}
        {!filtered.length && (
          <EmptyState
            icon={<Search size={28} />}
            title="No apps found"
            description="Try a different name or category."
          />
        )}
      </div>
      <div className="app-center-footer">
        <ShieldCheck size={15} />
        <span>Thoughtfully built for your workspace.</span>
        <button
          onClick={() =>
            explain(
              "Installing Android applications",
              "The applications shown here are built into this desktop and are ready to open. Installing additional Android applications requires a native package-manager integration, which is not connected in this environment. No installation will be simulated.",
            )
          }
        >
          About installing apps
          <ArrowUpRight size={12} />
        </button>
      </div>
    </div>
  );
}
