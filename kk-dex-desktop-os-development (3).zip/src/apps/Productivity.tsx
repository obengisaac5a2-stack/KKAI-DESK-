import { useEffect, useRef, useState } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  Delete,
  FilePenLine,
  MoreHorizontal,
  Plus,
  Save,
  Search,
  SquarePen,
  TerminalSquare,
  Trash2,
} from "lucide-react";
import { appRegistry } from "../registry";
import { useSystem, resolveAppId } from "../system";
import { persist, uid } from "../storage";
import { EmptyState, IconButton } from "../ui";
import type { DesktopWindow } from "../types";

export function NotesApp({ win }: { win: DesktopWindow }) {
  const {
    notes,
    setNotes,
    files,
    setFiles,
    activeId,
    notify,
    setDialog,
    setContextMenu,
    storageHealthy,
  } = useSystem();
  const [selected, setSelected] = useState<string>(
    win.payload || notes[0]?.id || "",
  );
  const [query, setQuery] = useState("");
  const textarea = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    if (win.payload) setSelected(win.payload);
  }, [win.payload]);
  const file = files.find((f) => f.id === selected && f.kind === "text");
  const note = notes.find((n) => n.id === selected);
  const title = file?.name || note?.title || "";
  const content = file?.content || note?.content || "";
  const change = (value: string, field: "title" | "content") => {
    const updated = new Date().toISOString();
    if (file)
      setFiles((fs) =>
        fs.map((f) =>
          f.id === selected
            ? {
                ...f,
                ...(field === "title"
                  ? { name: value }
                  : { content: value, size: new Blob([value]).size }),
                modified: updated,
              }
            : f,
        ),
      );
    else
      setNotes((ns) =>
        ns.map((n) =>
          n.id === selected ? { ...n, [field]: value, updated } : n,
        ),
      );
  };
  const newNote = () => {
    const id = uid();
    setNotes((ns) => [
      {
        id,
        title: "Untitled note",
        content: "",
        updated: new Date().toISOString(),
      },
      ...ns,
    ]);
    setSelected(id);
    setTimeout(() => textarea.current?.focus(), 50);
  };
  const save = () => {
    const success = persist(file ? "files" : "notes", file ? files : notes);
    notify(
      success ? "Note saved" : "Could not save",
      success
        ? "Your note is saved on this device."
        : "Local storage is full. Export this note before closing.",
      "notes",
    );
  };
  const exportNote = () => {
    const url = URL.createObjectURL(
      new Blob([`${title}\n\n${content}`], { type: "text/plain" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title || "Untitled"}.txt`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      if (activeId !== win.id) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        save();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        document.getElementById(`notes-search-${win.id}`)?.focus();
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  });
  const deleteNote = (id: string) =>
    setDialog({
      title: "Delete this note?",
      message:
        "This note will be removed from this device. Export it first if you want to keep a copy.",
      confirmLabel: "Delete note",
      danger: true,
      onConfirm: () => {
        setNotes((ns) => ns.filter((n) => n.id !== id));
        if (id === selected)
          setSelected(notes.find((n) => n.id !== id)?.id || "");
      },
    });
  return (
    <div className="notes-app">
      <aside className="notes-sidebar">
        <div className="notes-sidebar-heading">
          <h2>My notes</h2>
          <IconButton label="Create note" onClick={newNote}>
            <SquarePen size={17} />
          </IconButton>
        </div>
        <div className="notes-search">
          <Search size={13} />
          <input
            id={`notes-search-${win.id}`}
            placeholder="Find a thought"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="note-list">
          {file && (
            <button
              className="note-list-item selected"
              onClick={() => setSelected(file.id)}
            >
              <small>WORKSPACE FILE</small>
              <strong>{file.name}</strong>
              <p>{file.content?.slice(0, 70)}</p>
            </button>
          )}
          {notes
            .filter((n) =>
              `${n.title} ${n.content}`
                .toLowerCase()
                .includes(query.toLowerCase()),
            )
            .map((n) => (
              <button
                key={n.id}
                className={`note-list-item ${selected === n.id ? "selected" : ""}`}
                onClick={() => setSelected(n.id)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setContextMenu({
                    x: e.clientX,
                    y: e.clientY,
                    items: [
                      {
                        label: "Delete note",
                        icon: <Trash2 size={15} />,
                        action: () => deleteNote(n.id),
                        danger: true,
                      },
                    ],
                  });
                }}
              >
                <strong>{n.title || "Untitled note"}</strong>
                <p>
                  {n.content.slice(0, 70) || "A blank page, a fresh start."}
                </p>
                <small>
                  {new Date(n.updated).toLocaleDateString(undefined, {
                    month: "short",
                    day: "numeric",
                  })}
                </small>
              </button>
            ))}
        </div>
        <button className="new-note-button" onClick={newNote}>
          <Plus size={15} />
          New note
        </button>
      </aside>
      <main className="note-editor">
        {note || file ? (
          <>
            <div className="note-editor-toolbar">
              <span>
                <span
                  className={`status-dot ${storageHealthy ? "" : "offline"}`}
                />
                {storageHealthy
                  ? "Saved on this device"
                  : "Storage full: changes not saved"}
              </span>
              <div>
                <button className="text-tool" onClick={save}>
                  <Save size={14} />
                  Save
                </button>
                <IconButton label="Export note" onClick={exportNote}>
                  <ArrowDownToLine size={15} />
                </IconButton>
                {!file && (
                  <IconButton
                    label="Delete note"
                    onClick={() => deleteNote(selected)}
                  >
                    <Trash2 size={15} />
                  </IconButton>
                )}
              </div>
            </div>
            <div className="note-writing-area">
              <input
                className="note-title"
                aria-label="Note title"
                value={title}
                placeholder="Untitled note"
                onChange={(e) => change(e.target.value, "title")}
              />
              <span className="note-date">
                {new Date(
                  file?.modified || note?.updated || Date.now(),
                ).toLocaleDateString(undefined, {
                  weekday: "long",
                  month: "long",
                  day: "numeric",
                })}
              </span>
              <textarea
                ref={textarea}
                className="note-text"
                aria-label="Note content"
                placeholder="Let your thoughts wander..."
                value={content}
                onChange={(e) => change(e.target.value, "content")}
              />
            </div>
            <div className="note-footer">
              <span>
                {content.trim() ? content.trim().split(/\s+/).length : 0} words
              </span>
              <span>Plain text</span>
            </div>
          </>
        ) : (
          <EmptyState
            icon={<FilePenLine size={34} />}
            title="A good idea starts here"
            description="Create a note and give your thoughts a little room."
          >
            <button className="primary-button" onClick={newNote}>
              <Plus size={15} />
              New note
            </button>
          </EmptyState>
        )}
      </main>
    </div>
  );
}

export function calculate(source: string): number {
  const tokens =
    source.replace(/\s/g, "").match(/\d*\.?\d+(?:e[+-]?\d+)?|[()+\-*/%]/gi) ||
    [];
  if (tokens.join("") !== source.replace(/\s/g, ""))
    throw new Error("Invalid expression");
  let position = 0;
  const factor = (): number => {
    const token = tokens[position++];
    if (token === "+") return factor();
    if (token === "-") return -factor();
    let value: number;
    if (token === "(") {
      value = expression();
      if (tokens[position++] !== ")") throw new Error("Missing parenthesis");
    } else {
      value = Number(token);
      if (!token || !Number.isFinite(value)) throw new Error("Invalid number");
    }
    while (tokens[position] === "%") {
      position++;
      value /= 100;
    }
    return value;
  };
  const term = (): number => {
    let value = factor();
    while (tokens[position] === "*" || tokens[position] === "/") {
      const op = tokens[position++];
      const next = factor();
      if (op === "/" && next === 0) throw new Error("Cannot divide by zero");
      value = op === "*" ? value * next : value / next;
    }
    return value;
  };
  const expression = (): number => {
    let value = term();
    while (tokens[position] === "+" || tokens[position] === "-") {
      const op = tokens[position++];
      value = op === "+" ? value + term() : value - term();
    }
    return value;
  };
  const value = expression();
  if (position !== tokens.length || !Number.isFinite(value))
    throw new Error("Invalid expression");
  return Number(value.toPrecision(12));
}

export function CalculatorApp({ win }: { win: DesktopWindow }) {
  const { activeId, setContextMenu, explain } = useSystem();
  const [expression, setExpression] = useState("");
  const [answer, setAnswer] = useState("0");
  const [done, setDone] = useState(false);
  const [history, setHistory] = useState<
    { expression: string; answer: string }[]
  >([]);
  const [showHistory, setShowHistory] = useState(false);
  const input = (key: string) => {
    if (key === "C") {
      setExpression("");
      setAnswer("0");
      setDone(false);
      return;
    }
    if (key === "CE") {
      setExpression(done ? "" : expression.replace(/\d*\.?\d+%?$/, ""));
      setAnswer("0");
      setDone(false);
      return;
    }
    if (key === "back") {
      const next = expression.slice(0, -1);
      setExpression(next);
      setAnswer(next.match(/[\d.]+$/)?.[0] || "0");
      setDone(false);
      return;
    }
    if (key === "=") {
      try {
        const result = String(calculate(expression || answer));
        setAnswer(result);
        setHistory((h) =>
          [{ expression: expression || answer, answer: result }, ...h].slice(
            0,
            20,
          ),
        );
        setDone(true);
      } catch (e) {
        setAnswer(e instanceof Error ? e.message : "Error");
        setDone(true);
      }
      return;
    }
    if (["1/x", "x2", "sqrt", "+/-"].includes(key)) {
      try {
        const value = calculate(done ? answer : expression || "0");
        const next =
          key === "1/x"
            ? 1 / value
            : key === "x2"
              ? value * value
              : key === "sqrt"
                ? Math.sqrt(value)
                : -value;
        if (!Number.isFinite(next)) throw new Error();
        setExpression(String(next));
        setAnswer(String(Number(next.toPrecision(12))));
        setDone(false);
      } catch {
        setAnswer("Invalid operation");
        setDone(true);
      }
      return;
    }
    const operator = ["+", "-", "*", "/"].includes(key);
    let next = done
      ? operator || key === "%"
        ? `${answer}${key}`
        : key
      : `${expression}${key}`;
    if (operator && /[+*/-]$/.test(expression) && !done)
      next = expression.slice(0, -1) + key;
    if (
      key === "." &&
      (expression.match(/[\d.]+$/)?.[0] || "").includes(".") &&
      !done
    )
      return;
    setExpression(next);
    setDone(false);
    if (!operator && key !== "%") setAnswer(next.match(/[\d.]+$/)?.[0] || "0");
  };
  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      if (
        activeId !== win.id ||
        e.ctrlKey ||
        e.altKey ||
        e.metaKey ||
        (e.target instanceof Element && e.target.closest("input,textarea"))
      )
        return;
      if (/^[0-9.+*/%()-]$/.test(e.key)) {
        e.preventDefault();
        input(e.key);
      } else if (e.key === "Enter" || e.key === "=") {
        e.preventDefault();
        input("=");
      } else if (e.key === "Backspace") {
        e.preventDefault();
        input("back");
      } else if (e.key === "Escape") input("C");
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  });
  const keys = [
    "%",
    "CE",
    "C",
    "back",
    "1/x",
    "x2",
    "sqrt",
    "/",
    "7",
    "8",
    "9",
    "*",
    "4",
    "5",
    "6",
    "-",
    "1",
    "2",
    "3",
    "+",
    "+/-",
    "0",
    ".",
    "=",
  ];
  const labels: Record<string, string> = {
    "/": "\u00f7",
    "*": "\u00d7",
    "-": "\u2212",
    x2: "x\u00b2",
    sqrt: "\u221ax",
    "+/-": "\u00b1",
  };
  return (
    <div className="calculator-app">
      <div className="calculator-mode">
        <strong>{showHistory ? "History" : "Standard"}</strong>
        <IconButton
          label={showHistory ? "Back to calculator" : "Calculation history"}
          onClick={() => setShowHistory((s) => !s)}
        >
          {showHistory ? <ArrowLeft size={17} /> : <MoreHorizontal size={18} />}
        </IconButton>
      </div>
      {showHistory ? (
        <div className="calculator-history">
          {history.length ? (
            history.map((h, i) => (
              <button
                key={i}
                onClick={() => {
                  setExpression(h.answer);
                  setAnswer(h.answer);
                  setDone(true);
                  setShowHistory(false);
                }}
              >
                <small>{h.expression.replace(/\*/g, "\u00d7")} =</small>
                <strong>{h.answer}</strong>
              </button>
            ))
          ) : (
            <p>Your calculations will appear here.</p>
          )}
          <button className="text-tool" onClick={() => setHistory([])}>
            <Trash2 size={14} />
            Clear history
          </button>
        </div>
      ) : (
        <>
          <div
            className="calculator-display"
            onContextMenu={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setContextMenu({
                x: e.clientX,
                y: e.clientY,
                items: [
                  {
                    label: "Copy result",
                    action: () => {
                      if (navigator.clipboard)
                        void navigator.clipboard
                          .writeText(answer)
                          .catch(() =>
                            explain(
                              "Clipboard unavailable",
                              "Clipboard permission was denied. You can select and copy the result with your local keyboard.",
                            ),
                          );
                      else
                        explain(
                          "Clipboard unavailable",
                          "System clipboard access is not available in this WebView.",
                        );
                    },
                  },
                ],
              });
            }}
          >
            <div className="calculator-expression">
              {expression.replace(/\*/g, "\u00d7").replace(/\//g, "\u00f7")}
              {done && " ="}
            </div>
            <div
              className={`calculator-answer ${answer.length > 12 ? "small-answer" : ""}`}
            >
              {answer}
            </div>
          </div>
          <div className="calculator-keys">
            {keys.map((k) => (
              <button
                key={k}
                className={`${/^[0-9.]$/.test(k) ? "number-key" : ""} ${k === "=" ? "equals-key" : ""}`}
                aria-label={
                  k === "back" ? "Backspace" : k === "=" ? "Equals" : k
                }
                onClick={() => input(k)}
              >
                {k === "back" ? <Delete size={18} /> : labels[k] || k}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

type TerminalLine = {
  id: string;
  text: string;
  kind: "normal" | "command" | "error" | "accent";
};
export function TerminalApp({ win }: { win: DesktopWindow }) {
  const {
    files,
    createFolder,
    deleteFiles,
    openApp,
    setPreference,
    preferences,
  } = useSystem();
  const [lines, setLines] = useState<TerminalLine[]>([
    {
      id: "intro",
      text: 'KK DEX Workspace Shell 1.0\nYour local workspace, one command at a time.\nType "help" to get started. This is not an Android system shell.',
      kind: "accent",
    },
  ]);
  const [command, setCommand] = useState("");
  const [cwd, setCwd] = useState("documents");
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const path: string[] = [];
  let folder = files.find((f) => f.id === cwd);
  while (folder && path.length < 20) {
    path.unshift(folder.name);
    folder = files.find((f) => f.id === folder!.parent);
  }
  const prompt = `kk@workspace:~${path.length ? `/${path.join("/")}` : ""}`;
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [lines]);
  const print = (text: string, kind: TerminalLine["kind"] = "normal") =>
    setLines((ls) => [...ls, { id: uid(), text, kind }]);
  const execute = async () => {
    if (!command.trim() || busy) return;
    const raw = command.trim(),
      [cmd, ...args] = raw.split(/\s+/),
      argument = args.join(" ");
    setHistory((h) => [raw, ...h]);
    setHistoryIndex(-1);
    setCommand("");
    print(`${prompt} $ ${raw}`, "command");
    const children = files.filter((f) => f.parent === cwd && !f.deleted);
    const find = (value: string) =>
      children.find(
        (f) =>
          f.name.toLowerCase() ===
          value.replace(/^['"]|['"]$/g, "").toLowerCase(),
      );
    switch (cmd.toLowerCase()) {
      case "help":
        print(
          "WORKSPACE COMMANDS\n  ls                 List files in the current folder\n  cd <folder|..|~>    Change workspace folder\n  pwd                Show your workspace path\n  cat <file>         Read a text file\n  mkdir <name>       Create a workspace folder\n  rm <name>          Move a workspace item to Recycle Bin\n  open <app>         Launch a desktop application\n  echo <text>        Print text\n  date               Show the current date and time\n  theme <light|dark> Change the desktop theme\n  clear              Clear terminal output\n  native <command>   Use an explicitly connected native backend\n\nFile operations apply only to the KK DEX managed workspace.",
        );
        break;
      case "clear":
        setLines([]);
        break;
      case "pwd":
        print(`workspace:/${path.join("/")}`);
        break;
      case "ls":
        print(
          children.length
            ? children
                .map(
                  (f) => `${f.kind === "folder" ? "DIR " : "FILE"}  ${f.name}`,
                )
                .join("\n")
            : "(empty folder)",
        );
        break;
      case "cd":
        if (argument === "~" || !argument) setCwd("root");
        else if (argument === "..")
          setCwd(files.find((f) => f.id === cwd)?.parent || "root");
        else {
          const target = find(argument);
          if (target?.kind === "folder") setCwd(target.id);
          else print(`Folder not found: ${argument}`, "error");
        }
        break;
      case "cat": {
        const target = find(argument);
        if (target?.kind === "text") print(target.content || "(empty file)");
        else print("Text file not found in the current folder.", "error");
        break;
      }
      case "mkdir":
        if (argument) createFolder(cwd, argument);
        else print("Usage: mkdir <folder name>", "error");
        break;
      case "rm": {
        const target = find(argument);
        if (target?.parent === "root") {
          print("Built-in workspace locations cannot be deleted.", "error");
        } else if (target) {
          deleteFiles([target.id]);
          print(`Moved to Recycle Bin: ${target.name}`);
        } else print("Item not found.", "error");
        break;
      }
      case "open": {
        const id = resolveAppId(argument);
        if (id) {
          openApp(id);
          print(`Opened ${appRegistry[id].name}`);
        } else print("Application not found. Try: open files", "error");
        break;
      }
      case "echo":
        print(argument);
        break;
      case "date":
        print(new Date().toString());
        break;
      case "whoami":
        print("KK DEX local workspace user (not an Android system identity)");
        break;
      case "theme":
        if (argument === "dark" || argument === "light") {
          setPreference("theme", argument);
          print(`Desktop theme: ${argument}`);
        } else
          print(`Current theme: ${preferences.theme}. Usage: theme light|dark`);
        break;
      case "native":
        if (!window.KKDexServices?.execute)
          print(
            "No native shell backend is connected. No system command was executed.",
            "error",
          );
        else {
          setBusy(true);
          try {
            print(await window.KKDexServices.execute(argument));
          } catch (error) {
            print(
              error instanceof Error ? error.message : "Native command failed.",
              "error",
            );
          } finally {
            setBusy(false);
          }
        }
        break;
      default:
        print(
          `Unsupported command: ${cmd}. Type "help" for available workspace commands.`,
          "error",
        );
    }
  };
  return (
    <div
      className="terminal-app"
      onClick={() => {
        if (!window.getSelection()?.toString()) inputRef.current?.focus();
      }}
    >
      <div className="terminal-tab">
        <TerminalSquare size={13} />
        <span>Workspace shell</span>
        <span className="terminal-local">LOCAL</span>
      </div>
      <div className="terminal-output" ref={scrollRef}>
        {lines.map((line) => (
          <pre key={line.id} className={`terminal-line ${line.kind}`}>
            {line.text}
          </pre>
        ))}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void execute();
          }}
          className="terminal-prompt"
        >
          <label htmlFor={`terminal-${win.id}`}>
            {prompt}
            <span> $ </span>
          </label>
          <input
            id={`terminal-${win.id}`}
            ref={inputRef}
            autoComplete="off"
            spellCheck={false}
            aria-label="Terminal command"
            value={command}
            disabled={busy}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "ArrowUp") {
                e.preventDefault();
                const index = Math.min(history.length - 1, historyIndex + 1);
                setHistoryIndex(index);
                setCommand(history[index] || "");
              }
              if (e.key === "ArrowDown") {
                e.preventDefault();
                const index = Math.max(-1, historyIndex - 1);
                setHistoryIndex(index);
                setCommand(history[index] || "");
              }
            }}
          />
        </form>
        {busy && (
          <p className="terminal-line accent">Waiting for native backend...</p>
        )}
      </div>
      <div className="terminal-status">
        <span>
          <span className="status-dot" />
          Workspace runtime
        </span>
        <span>
          {window.KKDexServices?.execute
            ? "Native backend available"
            : "No Android shell connected"}
        </span>
      </div>
    </div>
  );
}
