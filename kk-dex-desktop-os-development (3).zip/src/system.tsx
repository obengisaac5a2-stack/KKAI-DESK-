import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
} from "react";
import { appRegistry, apps } from "./registry";
import {
  defaultPreferences,
  initialFiles,
  initialNotes,
  persist,
  readPersisted,
  uid,
} from "./storage";
import type {
  AppId,
  ContextMenuState,
  DesktopWindow,
  FileEntry,
  Note,
  Panel,
  Preferences,
  Rect,
  SystemNotification,
} from "./types";

export const TASKBAR_HEIGHT = 64;
export type Dialog = {
  title: string;
  message?: string;
  input?: boolean;
  initialValue?: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm?: (value: string) => void;
} | null;
type Clipboard = { ids: string[]; cut: boolean } | null;
type SystemContextType = {
  windows: DesktopWindow[];
  activeId: string | null;
  size: { width: number; height: number };
  openApp: (id: AppId, payload?: string) => void;
  closeWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  updateWindow: (id: string, update: Partial<DesktopWindow>) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  snapWindow: (id: string, side: "left" | "right") => void;
  showDesktop: () => void;
  preferences: Preferences;
  setPreference: <K extends keyof Preferences>(
    key: K,
    value: Preferences[K],
  ) => void;
  files: FileEntry[];
  setFiles: Dispatch<SetStateAction<FileEntry[]>>;
  createFolder: (parent: string, name?: string) => void;
  undoFiles: () => void;
  redoFiles: () => void;
  renameFile: (id: string) => void;
  deleteFiles: (ids: string[]) => void;
  restoreFiles: (ids: string[]) => void;
  purgeFiles: (ids: string[]) => void;
  openFile: (id: string) => void;
  clipboard: Clipboard;
  copyFiles: (ids: string[], cut?: boolean) => void;
  pasteFiles: (parent: string) => void;
  notes: Note[];
  setNotes: Dispatch<SetStateAction<Note[]>>;
  notifications: SystemNotification[];
  setNotifications: Dispatch<SetStateAction<SystemNotification[]>>;
  notify: (title: string, message: string, appId?: AppId) => void;
  toast: string | null;
  panel: Panel;
  setPanel: Dispatch<SetStateAction<Panel>>;
  togglePanel: (panel: Panel) => void;
  contextMenu: ContextMenuState;
  setContextMenu: Dispatch<SetStateAction<ContextMenuState>>;
  dialog: Dialog;
  setDialog: Dispatch<SetStateAction<Dialog>>;
  explain: (title: string, message: string) => void;
  online: boolean;
  recentApps: AppId[];
  storageHealthy: boolean;
};
const SystemContext = createContext<SystemContextType | null>(null);
export const useSystem = () => {
  const context = useContext(SystemContext);
  if (!context) throw new Error("SystemProvider is required");
  return context;
};

function fitRect(width: number, height: number, index = 0): Rect {
  const maxHeight = Math.max(260, window.innerHeight - TASKBAR_HEIGHT - 24);
  const w = Math.min(width, window.innerWidth - 28);
  const h = Math.min(height, maxHeight);
  return {
    width: w,
    height: h,
    x: Math.max(
      14,
      Math.min(
        window.innerWidth - w - 14,
        (window.innerWidth - w) / 2 + 48 + index * 22,
      ),
    ),
    y: Math.max(
      12,
      Math.min(maxHeight - h + 12, (maxHeight - h) / 2 - 10 + index * 24),
    ),
  };
}
function constrainRect(
  rect: Rect,
  viewportWidth: number,
  viewportHeight: number,
): Rect {
  const width = Math.max(100, Math.min(rect.width, viewportWidth - 16));
  const height = Math.max(
    100,
    Math.min(rect.height, viewportHeight - TASKBAR_HEIGHT - 12),
  );
  return {
    width,
    height,
    x: Math.max(0, Math.min(rect.x, viewportWidth - width)),
    y: Math.max(0, Math.min(rect.y, viewportHeight - TASKBAR_HEIGHT - height)),
  };
}
function descendants(files: FileEntry[], ids: string[]) {
  const result = new Set(ids);
  let previous = 0;
  while (previous !== result.size) {
    previous = result.size;
    files.forEach((f) => {
      if (result.has(f.parent)) result.add(f.id);
    });
  }
  return result;
}

export function SystemProvider({ children }: { children: ReactNode }) {
  const [size, setSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });
  const [windows, setWindows] = useState<DesktopWindow[]>([
    {
      id: "files-initial",
      appId: "files",
      title: "Files",
      ...fitRect(900, 584),
      z: 10,
      minimized: false,
      maximized: false,
    },
  ]);
  const [activeId, setActiveId] = useState<string | null>("files-initial");
  const zIndex = useRef(10);
  const [preferences, setPreferences] = useState<Preferences>(() => ({
    ...defaultPreferences,
    ...readPersisted("preferences", defaultPreferences),
  }));
  const [files, rawSetFiles] = useState<FileEntry[]>(() =>
    readPersisted("files", initialFiles),
  );
  const filesRef = useRef(files);
  const fileHistory = useRef<{ past: FileEntry[][]; future: FileEntry[][] }>({
    past: [],
    future: [],
  });
  const desktopHidden = useRef<Set<string> | null>(null);
  const [notes, setNotes] = useState<Note[]>(() =>
    readPersisted("notes", initialNotes),
  );
  const [filesSaved, setFilesSaved] = useState(true),
    [notesSaved, setNotesSaved] = useState(true);
  const [clipboard, setClipboard] = useState<Clipboard>(null);
  const [notifications, setNotifications] = useState<SystemNotification[]>([
    {
      id: "welcome",
      title: "Welcome to your new workspace",
      message:
        "A little more room for everything you do. Make it yours in Settings.",
      time: Date.now(),
      read: false,
      appId: "settings",
    },
  ]);
  const [toast, setToast] = useState<string | null>(null);
  const [panel, setPanel] = useState<Panel>(null);
  const [contextMenu, setContextMenu] = useState<ContextMenuState>(null);
  const [dialog, setDialog] = useState<Dialog>(null);
  const [online, setOnline] = useState(navigator.onLine);
  const [recentApps, setRecentApps] = useState<AppId[]>(() =>
    readPersisted("recent-apps", ["files", "notes", "browser"]),
  );

  useEffect(() => {
    const resize = () => {
      const width = window.innerWidth,
        height = window.innerHeight;
      setSize({ width, height });
      setWindows((current) =>
        current.map((w) => ({
          ...w,
          ...(w.maximized
            ? { x: 0, y: 0, width, height: height - TASKBAR_HEIGHT }
            : constrainRect(w, width, height)),
          restoreRect: w.restoreRect
            ? constrainRect(w.restoreRect, width, height)
            : undefined,
        })),
      );
    };
    const network = () => setOnline(navigator.onLine);
    window.addEventListener("resize", resize);
    window.addEventListener("online", network);
    window.addEventListener("offline", network);
    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("online", network);
      window.removeEventListener("offline", network);
    };
  }, []);
  useEffect(() => {
    persist("preferences", preferences);
    document.documentElement.dataset.theme = preferences.theme;
  }, [preferences]);
  useEffect(() => {
    const saved = persist("files", files);
    setFilesSaved(saved);
    if (!saved)
      setToast(
        "Local storage is full. Recent file changes could not be saved. Export files before closing.",
      );
  }, [files]);
  useEffect(() => {
    const saved = persist("notes", notes);
    setNotesSaved(saved);
    if (!saved)
      setToast(
        "Local storage is full. Notes could not be saved to this device.",
      );
  }, [notes]);
  useEffect(() => {
    persist("recent-apps", recentApps);
  }, [recentApps]);
  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(timeout);
  }, [toast]);

  const notify = (title: string, message: string, appId?: AppId) => {
    setNotifications((n) => [
      { id: uid(), title, message, time: Date.now(), read: false, appId },
      ...n,
    ]);
    setToast(message);
  };
  const explain = (title: string, message: string) =>
    setDialog({ title, message, confirmLabel: "Got it" });
  const setFiles: Dispatch<SetStateAction<FileEntry[]>> = (update) => {
    const current = filesRef.current,
      next = typeof update === "function" ? update(current) : update;
    if (next === current) return;
    fileHistory.current.past = [
      ...fileHistory.current.past.slice(-29),
      current,
    ];
    fileHistory.current.future = [];
    filesRef.current = next;
    rawSetFiles(next);
  };
  const undoFiles = () => {
    const previous = fileHistory.current.past.pop();
    if (!previous) return;
    fileHistory.current.future.push(filesRef.current);
    filesRef.current = previous;
    rawSetFiles(previous);
    setToast("Workspace change undone");
  };
  const redoFiles = () => {
    const next = fileHistory.current.future.pop();
    if (!next) return;
    fileHistory.current.past.push(filesRef.current);
    filesRef.current = next;
    rawSetFiles(next);
    setToast("Workspace change restored");
  };
  const setPreference = <K extends keyof Preferences>(
    key: K,
    value: Preferences[K],
  ) => setPreferences((p) => ({ ...p, [key]: value }));
  const focusWindow = (id: string) => {
    if (!id) {
      setActiveId(null);
      return;
    }
    setActiveId(id);
    setWindows((ws) =>
      ws.map((w) =>
        w.id === id ? { ...w, minimized: false, z: ++zIndex.current } : w,
      ),
    );
  };
  const updateWindow = (id: string, update: Partial<DesktopWindow>) =>
    setWindows((ws) => ws.map((w) => (w.id === id ? { ...w, ...update } : w)));
  const openApp = (id: AppId, payload?: string) => {
    if (!appRegistry[id]) return;
    setPanel(null);
    setContextMenu(null);
    setRecentApps((r) => [id, ...r.filter((x) => x !== id)].slice(0, 6));
    const existing = windows.find((w) => w.appId === id);
    if (existing) {
      if (payload !== undefined) updateWindow(existing.id, { payload });
      focusWindow(existing.id);
      return;
    }
    const definition = appRegistry[id],
      windowId = `${id}-${uid()}`;
    setWindows((ws) => [
      ...ws,
      {
        id: windowId,
        appId: id,
        title: definition.name,
        ...fitRect(
          definition.defaultSize.width,
          definition.defaultSize.height,
          Math.min(ws.filter((w) => !w.minimized).length, 3),
        ),
        z: ++zIndex.current,
        minimized: false,
        maximized: false,
        payload,
      },
    ]);
    setActiveId(windowId);
  };
  const focusTop = (remaining: DesktopWindow[]) =>
    setActiveId(
      [...remaining].filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]
        ?.id ?? null,
    );
  const closeWindow = (id: string) => {
    setWindows((ws) => ws.filter((w) => w.id !== id));
    if (activeId === id) focusTop(windows.filter((w) => w.id !== id));
  };
  const minimizeWindow = (id: string) => {
    updateWindow(id, { minimized: true });
    if (activeId === id) focusTop(windows.filter((w) => w.id !== id));
  };
  const maximizeWindow = (id: string) => {
    const w = windows.find((win) => win.id === id);
    if (!w) return;
    updateWindow(
      id,
      w.maximized
        ? {
            ...constrainRect(w.restoreRect || w, size.width, size.height),
            maximized: false,
            restoreRect: undefined,
          }
        : {
            restoreRect: { x: w.x, y: w.y, width: w.width, height: w.height },
            x: 0,
            y: 0,
            width: size.width,
            height: size.height - TASKBAR_HEIGHT,
            maximized: true,
          },
    );
    focusWindow(id);
  };
  const snapWindow = (id: string, side: "left" | "right") => {
    const w = windows.find((win) => win.id === id);
    if (!w) return;
    if (size.width / 2 < appRegistry[w.appId].minSize.width) {
      explain(
        "A little more room is needed",
        "This application needs more than half of this display to stay usable. Resize it freely, or use snapping on a larger display.",
      );
      return;
    }
    updateWindow(id, {
      restoreRect: w.restoreRect || {
        x: w.x,
        y: w.y,
        width: w.width,
        height: w.height,
      },
      x: side === "left" ? 0 : size.width / 2,
      y: 0,
      width: size.width / 2,
      height: size.height - TASKBAR_HEIGHT,
      maximized: false,
    });
    focusWindow(id);
  };
  const showDesktop = () => {
    const visible = windows.filter((w) => !w.minimized);
    if (visible.length) {
      desktopHidden.current = new Set(visible.map((w) => w.id));
      setWindows((ws) => ws.map((w) => ({ ...w, minimized: true })));
      setActiveId(null);
    } else {
      const hidden = desktopHidden.current;
      const restored = windows.map((w) => ({
        ...w,
        minimized: hidden ? !hidden.has(w.id) : false,
      }));
      setWindows(restored);
      focusTop(restored);
      desktopHidden.current = null;
    }
    setPanel(null);
  };
  const createFolder = (parent: string, suggestedName?: string) => {
    const create = (value: string) => {
      const name = value.trim();
      if (!name || /[/\\]/.test(name)) {
        explain(
          "Choose another name",
          "Folder names cannot be empty or contain slashes.",
        );
        return;
      }
      if (
        files.some((f) => f.parent === parent && f.name === name && !f.deleted)
      ) {
        explain(
          "Folder already exists",
          "Choose a unique name for this folder.",
        );
        return;
      }
      setFiles((fs) => [
        ...fs,
        {
          id: uid(),
          name,
          parent,
          kind: "folder",
          size: 0,
          modified: new Date().toISOString(),
        },
      ]);
    };
    if (suggestedName) create(suggestedName);
    else
      setDialog({
        title: "New folder",
        input: true,
        initialValue: "Untitled folder",
        confirmLabel: "Create folder",
        onConfirm: create,
      });
  };
  const renameFile = (id: string) => {
    const file = files.find((f) => f.id === id);
    if (!file) return;
    if (file.parent === "root") {
      explain(
        "Workspace location",
        "Built-in workspace locations keep their names so navigation stays consistent. You can rename any folder or file inside them.",
      );
      return;
    }
    setDialog({
      title: "Rename",
      input: true,
      initialValue: file.name,
      confirmLabel: "Rename",
      onConfirm: (name) => {
        if (!name.trim() || /[/\\]/.test(name)) {
          explain("Invalid name", "Enter a name without slashes.");
          return;
        }
        if (
          files.some(
            (f) =>
              f.id !== id &&
              !f.deleted &&
              f.parent === file.parent &&
              f.name === name.trim(),
          )
        ) {
          explain("Name already in use", "Another item already has this name.");
          return;
        }
        setFiles((fs) =>
          fs.map((f) =>
            f.id === id
              ? { ...f, name: name.trim(), modified: new Date().toISOString() }
              : f,
          ),
        );
      },
    });
  };
  const deleteFiles = (ids: string[]) => {
    if (files.some((f) => ids.includes(f.id) && f.parent === "root")) {
      explain(
        "Keep your workspace organized",
        "Built-in workspace locations cannot be deleted. Open the location to delete the files and folders inside it.",
      );
      return;
    }
    const all = descendants(files, ids);
    setFiles((fs) =>
      fs.map((f) =>
        all.has(f.id) ? { ...f, deleted: true, originalParent: f.parent } : f,
      ),
    );
    setToast(
      `${ids.length === 1 ? "Item" : `${ids.length} items`} moved to Recycle Bin`,
    );
  };
  const restoreFiles = (ids: string[]) => {
    const all = descendants(files, ids);
    setFiles((fs) =>
      fs.map((f) =>
        all.has(f.id)
          ? {
              ...f,
              deleted: false,
              parent:
                fs.find((p) => p.id === f.originalParent)?.deleted &&
                !all.has(f.originalParent || "")
                  ? "documents"
                  : f.originalParent || f.parent,
              originalParent: undefined,
            }
          : f,
      ),
    );
    setToast("Items restored");
  };
  const purgeFiles = (ids: string[]) =>
    setDialog({
      title: "Delete permanently?",
      message:
        "These items will be permanently removed from the KK DEX workspace. This cannot be undone.",
      confirmLabel: "Delete permanently",
      danger: true,
      onConfirm: () => {
        const all = descendants(files, ids);
        setFiles((fs) => fs.filter((f) => !all.has(f.id)));
        fileHistory.current = { past: [], future: [] };
      },
    });
  const openFile = (id: string) => {
    const f = files.find((f) => f.id === id && !f.deleted);
    if (!f) return;
    if (f.kind === "folder") openApp("files", id);
    else if (f.kind === "image") openApp("gallery", id);
    else if (f.kind === "text") openApp("notes", id);
    else
      explain(
        f.name,
        "This file type has no registered viewer. Use Files > Export to save the original file to your device.",
      );
  };
  const copyFiles = (ids: string[], cut = false) => {
    if (!ids.length) return;
    if (cut && files.some((f) => ids.includes(f.id) && f.parent === "root")) {
      explain(
        "Workspace location",
        "Built-in workspace locations cannot be moved. You can move the files and folders inside them.",
      );
      return;
    }
    setClipboard({ ids, cut });
    setToast(
      `${ids.length} item${ids.length === 1 ? "" : "s"} ${cut ? "ready to move" : "copied"}`,
    );
  };
  const pasteFiles = (parent: string) => {
    if (!clipboard) return;
    if (clipboard.ids.some((id) => descendants(files, [id]).has(parent))) {
      explain(
        "Cannot paste here",
        "A folder cannot be moved or copied inside itself.",
      );
      return;
    }
    if (clipboard.cut) {
      if (
        files.some(
          (f) =>
            clipboard.ids.includes(f.id) &&
            files.some(
              (o) =>
                o.parent === parent &&
                o.name === f.name &&
                o.id !== f.id &&
                !o.deleted,
            ),
        )
      ) {
        explain(
          "Name conflict",
          "An item with the same name already exists in this folder. Rename it first.",
        );
        return;
      }
      setFiles((fs) =>
        fs.map((f) => (clipboard.ids.includes(f.id) ? { ...f, parent } : f)),
      );
      setClipboard(null);
    } else {
      const all = descendants(files, clipboard.ids),
        mapping = new Map([...all].map((id) => [id, uid()]));
      const copies = files
        .filter((f) => all.has(f.id) && !f.deleted)
        .map((f) => {
          let name = f.name;
          if (
            clipboard.ids.includes(f.id) &&
            files.some(
              (o) => o.parent === parent && o.name === name && !o.deleted,
            )
          ) {
            const extension =
                f.kind === "folder" ? "" : f.name.match(/\.[^.]+$/)?.[0] || "",
              base = extension ? f.name.slice(0, -extension.length) : f.name;
            name = `${base} - Copy${extension}`;
            let count = 2;
            while (
              files.some(
                (o) => o.parent === parent && o.name === name && !o.deleted,
              )
            )
              name = `${base} - Copy (${count++})${extension}`;
          }
          return {
            ...f,
            id: mapping.get(f.id)!,
            parent: clipboard.ids.includes(f.id)
              ? parent
              : mapping.get(f.parent) || parent,
            name,
            modified: new Date().toISOString(),
          };
        });
      setFiles((fs) => [...fs, ...copies]);
    }
    setToast("Items pasted");
  };
  const togglePanel = (next: Panel) => {
    setPanel((p) => (p === next ? null : next));
    setContextMenu(null);
    if (next === "notifications")
      setNotifications((n) => n.map((x) => ({ ...x, read: true })));
  };

  return (
    <SystemContext.Provider
      value={{
        windows,
        activeId,
        size,
        openApp,
        closeWindow,
        focusWindow,
        updateWindow,
        minimizeWindow,
        maximizeWindow,
        snapWindow,
        showDesktop,
        preferences,
        setPreference,
        files,
        setFiles,
        undoFiles,
        redoFiles,
        createFolder,
        renameFile,
        deleteFiles,
        restoreFiles,
        purgeFiles,
        openFile,
        clipboard,
        copyFiles,
        pasteFiles,
        notes,
        setNotes,
        notifications,
        setNotifications,
        notify,
        toast,
        panel,
        setPanel,
        togglePanel,
        contextMenu,
        setContextMenu,
        dialog,
        setDialog,
        explain,
        online,
        recentApps,
        storageHealthy: filesSaved && notesSaved,
      }}
    >
      {children}
    </SystemContext.Provider>
  );
}

export function resolveAppId(value: string): AppId | undefined {
  const normalized = value.toLowerCase().replace(/[\s_-]/g, "");
  return apps.find(
    (a) =>
      a.id === value || a.name.toLowerCase().replace(/\s/g, "") === normalized,
  )?.id;
}
