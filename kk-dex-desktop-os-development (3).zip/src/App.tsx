import Desktop from "./Desktop";
import Controller from "./Controller";
import { SystemProvider } from "./system";

export default function App() {
  const controller =
    new URLSearchParams(window.location.search).has("controller") ||
    window.location.hash === "#controller";
  return controller ? (
    <Controller />
  ) : (
    <SystemProvider>
      <Desktop />
    </SystemProvider>
  );
}
