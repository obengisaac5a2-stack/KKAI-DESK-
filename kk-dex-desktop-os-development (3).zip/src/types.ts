import type { ReactNode } from "react";

export type AppId =
  | "pc"
  | "files"
  | "browser"
  | "ai"
  | "store"
  | "settings"
  | "gallery"
  | "notes"
  | "calculator"
  | "terminal"
  | "bin";
export type Rect = { x: number; y: number; width: number; height: number };
export type DesktopWindow = Rect & {
  id: string;
  appId: AppId;
  title: string;
  z: number;
  minimized: boolean;
  maximized: boolean;
  restoreRect?: Rect;
  payload?: string;
};
export type AppDefinition = {
  id: AppId;
  name: string;
  description: string;
  category: string;
  defaultSize: { width: number; height: number };
  minSize: { width: number; height: number };
  launchBehavior: "singleton";
  closeBehavior: "preserve-data";
};
export type FileEntry = {
  id: string;
  name: string;
  parent: string;
  kind: "folder" | "text" | "image" | "file";
  content?: string;
  size: number;
  modified: string;
  deleted?: boolean;
  originalParent?: string;
};
export type Note = {
  id: string;
  title: string;
  content: string;
  updated: string;
};
export type Preferences = {
  theme: "light" | "dark";
  wallpaper: "alpine" | "coast" | "dunes";
  volume: number;
  muted: boolean;
  brightness: number;
  pointerSpeed: number;
  textScale: number;
  reducedMotion: boolean;
  showIcons: boolean;
  iconSize: "small" | "medium";
};
export type SystemNotification = {
  id: string;
  title: string;
  message: string;
  time: number;
  read: boolean;
  appId?: AppId;
};
export type MenuItem = {
  label: string;
  icon?: ReactNode;
  shortcut?: string;
  action?: () => void;
  danger?: boolean;
  disabled?: boolean;
  divider?: boolean;
  children?: MenuItem[];
};
export type ContextMenuState = {
  x: number;
  y: number;
  items: MenuItem[];
} | null;
export type Panel =
  "start" | "search" | "quick" | "calendar" | "notifications" | "tasks" | null;

export type InputMessage = { type: string; [key: string]: unknown };
export type ChatMessage = { role: "user" | "assistant"; content: string };
export type DesktopAPI = {
  movePointer: (
    x:
      | number
      | {
          x?: number;
          y?: number;
          dx?: number;
          dy?: number;
          relative?: boolean;
        },
    y?: number,
    relative?: boolean,
  ) => void;
  pointerDown: (button?: number) => void;
  pointerUp: (button?: number) => void;
  pointerClick: () => void;
  pointerDoubleClick: () => void;
  pointerRightClick: () => void;
  scrollDesktop: (dx: number, dy?: number) => void;
  insertText: (text: string) => void;
  pressKey: (
    key: string,
    modifiers?: {
      ctrl?: boolean;
      alt?: boolean;
      shift?: boolean;
      meta?: boolean;
    },
  ) => void;
  getState: () => unknown;
  openApp: (appId: string, payload?: string) => void;
  setTheme: (theme: "light" | "dark") => void;
  setWallpaper: (wallpaper: string) => void;
};

declare global {
  interface Window {
    KKDexAPI?: Partial<DesktopAPI> & Record<string, unknown>;
    KKDexDesktop?: DesktopAPI;
    KKDexServices?: {
      chat?: (messages: ChatMessage[]) => Promise<string>;
      execute?: (command: string) => Promise<string>;
      openBrowser?: (url: string) => void;
      setVolume?: (value: number) => void;
      setBrightness?: (value: number) => void;
      setWifi?: (enabled: boolean) => void;
      power?: (action: "sleep" | "restart" | "shutdown") => void;
      requestStorageAccess?: () => Promise<boolean>;
    };
    KKDexControllerBridge?: { sendInput: (message: string) => void };
  }
}
