import type { FileEntry, Note, Preferences } from "./types";

export function readPersisted<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(`kkdex:${key}`);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function persist(key: string, value: unknown): boolean {
  try {
    localStorage.setItem(`kkdex:${key}`, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export const defaultPreferences: Preferences = {
  theme: "light",
  wallpaper: "alpine",
  volume: 65,
  muted: false,
  brightness: 100,
  pointerSpeed: 1,
  textScale: 1,
  reducedMotion: false,
  showIcons: true,
  iconSize: "medium",
};
const now = new Date().toISOString();
const folder = (id: string, name: string, parent = "root"): FileEntry => ({
  id,
  name,
  parent,
  kind: "folder",
  size: 0,
  modified: now,
});
const text = (
  id: string,
  name: string,
  parent: string,
  content: string,
): FileEntry => ({
  id,
  name,
  parent,
  content,
  kind: "text",
  size: new Blob([content]).size,
  modified: now,
});
export const initialFiles: FileEntry[] = [
  folder("desktop", "Desktop"),
  folder("documents", "Documents"),
  folder("downloads", "Downloads"),
  folder("pictures", "Pictures"),
  folder("music", "Music"),
  folder("videos", "Videos"),
  folder("projects", "Projects", "documents"),
  text(
    "welcome",
    "Getting started.md",
    "documents",
    "# Welcome to KK DEX\n\nA little more space for everything you do.\n\nYour desktop\n- Double-click an app to open it.\n- Drag a title bar to move a window.\n- Resize from any edge or corner.\n- Press Super + E to open Files.\n- Press Super + D to show the desktop.\n\nYour files and notes are stored locally in this WebView. Android device storage requires explicit native authorization.\n\nMake this space your own in Settings.",
  ),
  text(
    "brief",
    "Project brief.md",
    "projects",
    "# A fresh perspective\n\nDesign a workspace that feels calm, considered, and completely yours.\n\nFocus\n1. Keep the important things close.\n2. Give good ideas room to grow.\n3. Make every interaction feel effortless.\n\nNext steps\nExplore the desktop, organize your files, and start something new.",
  ),
  {
    id: "alpine-photo",
    name: "Alpine morning.jpg",
    parent: "pictures",
    kind: "image",
    content: "./wallpaper-alpine.jpg",
    size: 0,
    modified: now,
  },
  {
    id: "coast-photo",
    name: "Ocean air.jpg",
    parent: "pictures",
    kind: "image",
    content: "./wallpaper-coast.jpg",
    size: 0,
    modified: now,
  },
  {
    id: "dunes-photo",
    name: "Quiet dunes.jpg",
    parent: "pictures",
    kind: "image",
    content: "./wallpaper-dunes.jpg",
    size: 0,
    modified: now,
  },
  text(
    "ideas",
    "Weekend ideas.txt",
    "documents",
    "Take the scenic route.\nFind a new favorite coffee shop.\nMake something just for the joy of it.\nLeave a little room for the unexpected.",
  ),
  text(
    "workspace",
    "Workspace notes.md",
    "downloads",
    "# My workspace\n\nOne screen. Endless possibilities.\n\nSave your thoughts here. Changes stay on this device.",
  ),
];
export const initialNotes: Note[] = [
  {
    id: "first-note",
    title: "A fresh perspective",
    content:
      "A little more space for your ideas.\n\nThis is your place to think out loud, collect the small things, and start something good.\n\nWhat will you make today?",
    updated: now,
  },
];
export const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
export function formatBytes(value: number) {
  return value === 0
    ? "--"
    : value < 1024
      ? `${value} B`
      : value < 1048576
        ? `${(value / 1024).toFixed(1)} KB`
        : `${(value / 1048576).toFixed(1)} MB`;
}
