import type { AppDefinition, AppId } from "./types";

const app = (
  id: AppId,
  name: string,
  description: string,
  category: string,
  width = 860,
  height = 560,
  minWidth = 600,
  minHeight = 320,
): AppDefinition => ({
  id,
  name,
  description,
  category,
  defaultSize: { width, height },
  minSize: { width: minWidth, height: minHeight },
  launchBehavior: "singleton",
  closeBehavior: "preserve-data",
});

export const apps: AppDefinition[] = [
  app("pc", "This PC", "Your device and connected storage", "System", 820, 540),
  app(
    "files",
    "Files",
    "A home for everything you create",
    "Productivity",
    900,
    584,
    620,
    380,
  ),
  app("browser", "Browser", "A window to the world", "Internet", 940, 610),
  app(
    "ai",
    "KK AI",
    "A little help for your big ideas",
    "Productivity",
    800,
    580,
  ),
  app(
    "store",
    "App Center",
    "Discover your next favorite app",
    "System",
    850,
    570,
  ),
  app(
    "settings",
    "Settings",
    "Make this space your own",
    "System",
    860,
    580,
    640,
    380,
  ),
  app(
    "gallery",
    "Gallery",
    "Your moments, beautifully organized",
    "Creativity",
    880,
    590,
  ),
  app("notes", "Notes", "Room for a fresh thought", "Productivity", 800, 540),
  app(
    "calculator",
    "Calculator",
    "Make it all add up",
    "Utilities",
    344,
    510,
    292,
    440,
  ),
  app(
    "terminal",
    "Terminal",
    "Your workspace, one command away",
    "Developer",
    750,
    475,
  ),
  app(
    "bin",
    "Recycle Bin",
    "A second chance for your files",
    "System",
    760,
    510,
  ),
];

export const appRegistry = Object.fromEntries(
  apps.map((a) => [a.id, a]),
) as Record<AppId, AppDefinition>;
export const pinnedApps: AppId[] = [
  "files",
  "browser",
  "ai",
  "store",
  "notes",
  "settings",
];
export const wallpaperPaths = {
  alpine: "./wallpaper-alpine.jpg",
  coast: "./wallpaper-coast.jpg",
  dunes: "./wallpaper-dunes.jpg",
};
