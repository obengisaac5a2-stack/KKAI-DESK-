import { useEffect, useRef, useState } from "react";
import { wallpaperPaths } from "./registry";
import { resolveAppId, useSystem } from "./system";
import type { DesktopAPI, InputMessage } from "./types";

type TextInput = HTMLInputElement | HTMLTextAreaElement;
type EditSnapshot = { value: string; start: number; end: number };
const editHistory = new WeakMap<
  TextInput,
  { undo: EditSnapshot[]; redo: EditSnapshot[] }
>();
function editable(element: Element | null): element is TextInput {
  return (
    element instanceof HTMLTextAreaElement ||
    (element instanceof HTMLInputElement &&
      ["text", "search", "url", "tel", "password"].includes(element.type))
  );
}
function writeValue(
  element: TextInput,
  text: string,
  start = element.selectionStart ?? element.value.length,
  end = element.selectionEnd ?? start,
) {
  const history = editHistory.get(element) || { undo: [], redo: [] };
  history.undo.push({ value: element.value, start, end });
  history.undo = history.undo.slice(-100);
  history.redo = [];
  editHistory.set(element, history);
  const value = element.value.slice(0, start) + text + element.value.slice(end);
  const prototype =
    element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(prototype, "value")?.set?.call(
    element,
    value,
  );
  element.setSelectionRange(start + text.length, start + text.length);
  element.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      inputType: "insertText",
      data: text,
    }),
  );
}
function undoEdit(element: TextInput, redo = false) {
  const history = editHistory.get(element),
    source = redo ? history?.redo : history?.undo;
  const snapshot = source?.pop();
  if (!history || !snapshot) {
    document.execCommand(redo ? "redo" : "undo");
    return;
  }
  (redo ? history.undo : history.redo).push({
    value: element.value,
    start: element.selectionStart ?? 0,
    end: element.selectionEnd ?? 0,
  });
  const prototype =
    element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(prototype, "value")?.set?.call(
    element,
    snapshot.value,
  );
  element.setSelectionRange(snapshot.start, snapshot.end);
  element.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      inputType: redo ? "historyRedo" : "historyUndo",
    }),
  );
}
function moveCaret(element: TextInput, index: number, extend: boolean) {
  const anchor =
    element.selectionDirection === "backward"
      ? (element.selectionEnd ?? 0)
      : (element.selectionStart ?? 0);
  element.setSelectionRange(
    extend ? Math.min(anchor, index) : index,
    extend ? Math.max(anchor, index) : index,
    extend && index < anchor ? "backward" : "forward",
  );
}
function caretIndex(element: TextInput, x: number, y: number) {
  const rect = element.getBoundingClientRect(),
    style = getComputedStyle(element);
  const canvas = document.createElement("canvas"),
    context = canvas.getContext("2d");
  if (!context) return element.value.length;
  context.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
  const left =
    x - rect.left - parseFloat(style.paddingLeft) + element.scrollLeft;
  const lineHeight =
    parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.4;
  const row =
    element instanceof HTMLTextAreaElement
      ? Math.max(
          0,
          Math.floor(
            (y - rect.top - parseFloat(style.paddingTop) + element.scrollTop) /
              lineHeight,
          ),
        )
      : 0;
  const width =
    element.clientWidth -
    parseFloat(style.paddingLeft) -
    parseFloat(style.paddingRight);
  const lines: { start: number; text: string }[] = [];
  let start = 0,
    text = "";
  for (let i = 0; i < element.value.length; i++) {
    const char = element.value[i];
    if (
      char === "\n" ||
      (element instanceof HTMLTextAreaElement &&
        context.measureText(text + char).width > width)
    ) {
      lines.push({ start, text });
      start = char === "\n" ? i + 1 : i;
      text = char === "\n" ? "" : char;
    } else text += char;
  }
  lines.push({ start, text });
  const line = lines[Math.min(row, lines.length - 1)];
  let index = 0;
  for (; index < line.text.length; index++)
    if (context.measureText(line.text.slice(0, index + 1)).width > left) break;
  return line.start + index;
}

export function useDesktopBridge() {
  const system = useSystem(),
    systemRef = useRef(system);
  systemRef.current = system;
  const [pointer, setPointer] = useState({
    x: window.innerWidth / 2,
    y: window.innerHeight / 2,
    visible: false,
    cursor: "",
  });
  const pointerRef = useRef(pointer);
  useEffect(() => {
    let hover: Element | null = null;
    let hoverControl: Element | null = null;
    let down: { target: Element; x: number; y: number; button: number } | null =
      null;
    let selection: { element: TextInput; anchor: number } | null = null;
    let textAnchor: { node: Node; offset: number } | null = null;
    const caretRange = () =>
      (
        document as Document & {
          caretRangeFromPoint?: (x: number, y: number) => Range | null;
        }
      ).caretRangeFromPoint?.(pointerRef.current.x, pointerRef.current.y);
    const position = () => ({
      clientX: pointerRef.current.x,
      clientY: pointerRef.current.y,
      screenX: pointerRef.current.x,
      screenY: pointerRef.current.y,
    });
    const target = () =>
      document.elementFromPoint(pointerRef.current.x, pointerRef.current.y);
    const emit = (element: Element, type: string, button = 0, detail = 1) => {
      const init = {
        ...position(),
        bubbles: true,
        cancelable: true,
        button,
        buttons: down ? (button === 2 ? 2 : 1) : 0,
        detail,
        view: window,
      };
      if (type.startsWith("pointer"))
        element.dispatchEvent(
          new PointerEvent(type, {
            ...init,
            pointerId: 99,
            pointerType: "mouse",
            isPrimary: true,
          }),
        );
      else element.dispatchEvent(new MouseEvent(type, init));
    };
    const api: DesktopAPI = {
      movePointer: (x, y, relative = false) => {
        const current = pointerRef.current,
          speed = systemRef.current.preferences.pointerSpeed;
        let px: number, py: number;
        if (typeof x === "object") {
          const delta = x.relative || x.dx !== undefined || x.dy !== undefined;
          px = delta
            ? current.x + (x.dx ?? x.x ?? 0) * speed
            : (x.x ?? current.x);
          py = delta
            ? current.y + (x.dy ?? x.y ?? 0) * speed
            : (x.y ?? current.y);
        } else {
          px = relative ? current.x + x * speed : x;
          py = relative ? current.y + (y ?? 0) * speed : (y ?? current.y);
        }
        if (!Number.isFinite(px) || !Number.isFinite(py)) return;
        pointerRef.current = {
          x: Math.max(0, Math.min(window.innerWidth - 1, px)),
          y: Math.max(0, Math.min(window.innerHeight - 1, py)),
          visible: true,
          cursor: "",
        };
        const element = target();
        pointerRef.current.cursor =
          down?.target.closest<HTMLElement>("[data-resize]")?.dataset.resize ||
          element?.closest<HTMLElement>("[data-resize]")?.dataset.resize ||
          (editable(element) ? "text" : "");
        setPointer(pointerRef.current);
        if (element !== hover) {
          if (hover) {
            emit(hover, "pointerout");
            emit(hover, "mouseout");
          }
          hoverControl?.classList.remove("remote-hover");
          if (element) {
            emit(element, "pointerover");
            emit(element, "mouseover");
            hoverControl =
              element.closest("button, a, [data-resize]") || element;
            hoverControl.classList.add("remote-hover");
          }
          hover = element;
        }
        if (element) {
          emit(element, "pointermove", down?.button);
          emit(element, "mousemove", down?.button);
        }
        if (selection && down) {
          const index = caretIndex(
            selection.element,
            pointerRef.current.x,
            pointerRef.current.y,
          );
          selection.element.setSelectionRange(
            Math.min(index, selection.anchor),
            Math.max(index, selection.anchor),
            index < selection.anchor ? "backward" : "forward",
          );
        } else if (textAnchor?.node.isConnected && down) {
          const range = caretRange();
          if (range && range.startContainer.nodeType === Node.TEXT_NODE)
            window
              .getSelection()
              ?.setBaseAndExtent(
                textAnchor.node,
                textAnchor.offset,
                range.startContainer,
                range.startOffset,
              );
        }
      },
      pointerDown: (button = 0) => {
        const element = target();
        if (!element) return;
        down = {
          target: element,
          x: pointerRef.current.x,
          y: pointerRef.current.y,
          button,
        };
        const focus = element.closest<HTMLElement>(
          'button, input, textarea, a, [tabindex], [contenteditable="true"]',
        );
        focus?.focus({ preventScroll: true });
        if (
          editable(element) &&
          ["text", "search", "email", "url", "tel", "password", ""].includes(
            element instanceof HTMLInputElement ? element.type : "text",
          )
        ) {
          const anchor = caretIndex(element, down.x, down.y);
          element.setSelectionRange(anchor, anchor);
          selection = { element, anchor };
        } else if (
          !element.closest(
            "button, a, .window-titlebar, [data-resize], .desktop-icon",
          )
        ) {
          const range = caretRange();
          if (range && range.startContainer.nodeType === Node.TEXT_NODE) {
            textAnchor = {
              node: range.startContainer,
              offset: range.startOffset,
            };
            window.getSelection()?.removeAllRanges();
            window.getSelection()?.addRange(range);
          }
        }
        emit(element, "pointerdown", button);
        emit(element, "mousedown", button);
      },
      pointerUp: (button = 0) => {
        const element = target() || down?.target;
        if (!element) return;
        const previous = down;
        emit(element, "pointerup", button);
        emit(element, "mouseup", button);
        down = null;
        selection = null;
        textAnchor = null;
        if (
          previous &&
          button === 0 &&
          Math.hypot(
            pointerRef.current.x - previous.x,
            pointerRef.current.y - previous.y,
          ) < 6
        )
          emit(element, "click");
      },
      pointerClick: () => {
        api.pointerDown();
        api.pointerUp();
      },
      pointerDoubleClick: () => {
        api.pointerClick();
        api.pointerClick();
        const element = target();
        if (element) emit(element, "dblclick", 0, 2);
      },
      pointerRightClick: () => {
        api.pointerDown(2);
        api.pointerUp(2);
        const element = target();
        if (element) emit(element, "contextmenu", 2);
      },
      scrollDesktop: (dx, dy) => {
        const deltaX = dy === undefined ? 0 : dx,
          deltaY = dy === undefined ? dx : dy;
        let element = target();
        element?.dispatchEvent(
          new WheelEvent("wheel", {
            ...position(),
            bubbles: true,
            cancelable: true,
            deltaX,
            deltaY,
          }),
        );
        while (element) {
          const style = getComputedStyle(element);
          if (
            /(auto|scroll)/.test(style.overflowY + style.overflowX) &&
            (element.scrollHeight > element.clientHeight ||
              element.scrollWidth > element.clientWidth)
          ) {
            element.scrollBy({
              left: deltaX,
              top: deltaY,
              behavior: "instant",
            });
            break;
          }
          element = element.parentElement;
        }
      },
      insertText: (text) => {
        const element = document.activeElement;
        if (editable(element)) writeValue(element, text);
        else if (element instanceof HTMLElement && element.isContentEditable)
          document.execCommand("insertText", false, text);
      },
      pressKey: (raw, modifiers = {}) => {
        const aliases: Record<string, string> = {
          Super: "Meta",
          Win: "Meta",
          Esc: "Escape",
          Del: "Delete",
          Return: "Enter",
          Left: "ArrowLeft",
          Right: "ArrowRight",
          Up: "ArrowUp",
          Down: "ArrowDown",
        };
        const key = aliases[raw] || raw,
          element = document.activeElement || document.body;
        const options = {
          key,
          code:
            key === " "
              ? "Space"
              : key.length === 1
                ? `Key${key.toUpperCase()}`
                : key,
          ctrlKey: !!modifiers.ctrl,
          altKey: !!modifiers.alt,
          metaKey: !!modifiers.meta,
          shiftKey: !!modifiers.shift,
          bubbles: true,
          cancelable: true,
        };
        const event = new KeyboardEvent("keydown", options);
        element.dispatchEvent(event);
        if (!event.defaultPrevented && editable(element)) {
          const start = element.selectionStart ?? 0,
            end = element.selectionEnd ?? start;
          if (modifiers.ctrl || modifiers.meta) {
            if (key.toLowerCase() === "a") element.select();
            else if (key.toLowerCase() === "c" || key.toLowerCase() === "x") {
              if (navigator.clipboard)
                void navigator.clipboard
                  .writeText(element.value.slice(start, end))
                  .then(() => {
                    if (key.toLowerCase() === "x")
                      writeValue(element, "", start, end);
                  })
                  .catch(() =>
                    systemRef.current.explain(
                      "Clipboard unavailable",
                      "Clipboard permission was denied. The selected text has not been removed.",
                    ),
                  );
              else
                systemRef.current.explain(
                  "Clipboard unavailable",
                  "System clipboard access is unavailable in this WebView. Send text using the phone keyboard instead.",
                );
            } else if (key.toLowerCase() === "v") {
              if (navigator.clipboard)
                void navigator.clipboard
                  .readText()
                  .then((text) => writeValue(element, text))
                  .catch(() =>
                    systemRef.current.explain(
                      "Clipboard unavailable",
                      "Clipboard permission was denied. Send the text through the phone keyboard instead.",
                    ),
                  );
              else
                systemRef.current.explain(
                  "Clipboard unavailable",
                  "System clipboard access is unavailable in this WebView. Send text using the phone keyboard instead.",
                );
            } else if (key.toLowerCase() === "z" || key.toLowerCase() === "y")
              undoEdit(element, key.toLowerCase() === "y" || !!modifiers.shift);
          } else if (key === "Backspace")
            writeValue(
              element,
              "",
              start === end ? Math.max(0, start - 1) : start,
              end,
            );
          else if (key === "Delete")
            writeValue(
              element,
              "",
              start,
              start === end ? Math.min(element.value.length, end + 1) : end,
            );
          else if (key === "Enter") {
            if (element instanceof HTMLTextAreaElement)
              writeValue(element, "\n");
            else element.form?.requestSubmit();
          } else if (key === "ArrowLeft" || key === "ArrowRight") {
            const caret =
              element.selectionDirection === "backward" ? start : end;
            const index =
              !modifiers.shift && start !== end
                ? key === "ArrowLeft"
                  ? start
                  : end
                : Math.max(
                    0,
                    Math.min(
                      element.value.length,
                      caret + (key === "ArrowLeft" ? -1 : 1),
                    ),
                  );
            moveCaret(element, index, !!modifiers.shift);
          } else if (key === "ArrowUp" || key === "ArrowDown") {
            const caret =
              element.selectionDirection === "backward" ? start : end;
            const lineStart = element.value.lastIndexOf("\n", caret - 1) + 1,
              column = caret - lineStart;
            let index = caret;
            if (key === "ArrowUp") {
              const previousEnd = Math.max(0, lineStart - 1),
                previousStart =
                  element.value.lastIndexOf(
                    "\n",
                    Math.max(0, previousEnd - 1),
                  ) + 1;
              index = Math.min(previousEnd, previousStart + column);
            } else {
              const currentEnd = element.value.indexOf("\n", caret);
              if (currentEnd < 0) index = element.value.length;
              else {
                const nextEnd = element.value.indexOf("\n", currentEnd + 1);
                index = Math.min(
                  nextEnd < 0 ? element.value.length : nextEnd,
                  currentEnd + 1 + column,
                );
              }
            }
            moveCaret(element, index, !!modifiers.shift);
          } else if (key === "Home") moveCaret(element, 0, !!modifiers.shift);
          else if (key === "End")
            moveCaret(element, element.value.length, !!modifiers.shift);
          else if (key.length === 1 && !modifiers.alt) api.insertText(key);
        } else if (
          !event.defaultPrevented &&
          key === "Enter" &&
          element instanceof HTMLButtonElement
        )
          element.click();
        if (
          !event.defaultPrevented &&
          key === "Tab" &&
          !modifiers.alt &&
          !modifiers.ctrl &&
          !modifiers.meta
        ) {
          const scope =
            element.closest("[data-window], .system-panel, .system-dialog") ||
            document;
          const focusables = Array.from(
            scope.querySelectorAll<HTMLElement>(
              'button:not(:disabled), input:not(:disabled), textarea:not(:disabled), select, a[href], [tabindex="0"]',
            ),
          ).filter(
            (el) => el.getClientRects().length && !el.closest("[inert]"),
          );
          const index = focusables.indexOf(element as HTMLElement);
          focusables[
            (index + (modifiers.shift ? -1 : 1) + focusables.length) %
              focusables.length
          ]?.focus();
        }
        element.dispatchEvent(new KeyboardEvent("keyup", options));
      },
      getState: () => {
        const s = systemRef.current;
        return {
          version: "1.0",
          display: s.size,
          windows: s.windows,
          activeWindow: s.activeId,
          pointer: pointerRef.current,
          theme: s.preferences.theme,
          wallpaper: s.preferences.wallpaper,
          capabilities: {
            managedFiles: true,
            nativeStorage: !!window.KKDexServices?.requestStorageAccess,
            ai: !!window.KKDexServices?.chat,
            nativeTerminal: !!window.KKDexServices?.execute,
            nativeBrowser: !!window.KKDexServices?.openBrowser,
          },
        };
      },
      openApp: (id, payload) => {
        const app = resolveAppId(id);
        if (app) systemRef.current.openApp(app, payload);
        else
          systemRef.current.explain(
            "Application not found",
            `No application is registered as "${id}".`,
          );
      },
      setTheme: (theme) => {
        if (theme === "light" || theme === "dark")
          systemRef.current.setPreference("theme", theme);
      },
      setWallpaper: (wallpaper) => {
        const key = Object.keys(wallpaperPaths).find(
          (k) =>
            k === wallpaper ||
            wallpaperPaths[k as keyof typeof wallpaperPaths] === wallpaper,
        ) as keyof typeof wallpaperPaths | undefined;
        if (key) systemRef.current.setPreference("wallpaper", key);
        else
          systemRef.current.explain(
            "Wallpaper unavailable",
            "Choose a registered wallpaper: alpine, coast, or dunes.",
          );
      },
    };
    // Keep pre-existing host methods authoritative; add only missing compatibility aliases.
    const original = window.KKDexAPI,
      bridge = original || {},
      installed: string[] = [];
    Object.entries(api).forEach(([key, value]) => {
      try {
        if (
          typeof bridge[key] !== "function" &&
          Reflect.set(bridge, key, value)
        )
          installed.push(key);
      } catch {
        /* Native host objects can be read-only; KKDexDesktop remains available. */
      }
    });
    if (!original) window.KKDexAPI = bridge;
    window.KKDexDesktop = api;
    const input = (event: Event) => {
      const data = (event as CustomEvent<InputMessage>).detail;
      if (!data || typeof data.type !== "string") return;
      switch (data.type) {
        case "movePointer":
          api.movePointer({
            x: data.x as number,
            y: data.y as number,
            dx: data.dx as number,
            dy: data.dy as number,
            relative: data.relative as boolean,
          });
          break;
        case "pointerDown":
          api.pointerDown(data.button as number);
          break;
        case "pointerUp":
          api.pointerUp(data.button as number);
          break;
        case "pointerClick":
          api.pointerClick();
          break;
        case "pointerDoubleClick":
          api.pointerDoubleClick();
          break;
        case "pointerRightClick":
          api.pointerRightClick();
          break;
        case "scrollDesktop":
          api.scrollDesktop((data.dx as number) || 0, (data.dy as number) || 0);
          break;
        case "insertText":
          api.insertText(String(data.text ?? ""));
          break;
        case "pressKey":
          api.pressKey(
            String(data.key ?? ""),
            data.modifiers as Parameters<DesktopAPI["pressKey"]>[1],
          );
          break;
      }
    };
    const localMove = (event: globalThis.PointerEvent) => {
      if (event.isTrusted && event.pointerType === "mouse") {
        pointerRef.current = { ...pointerRef.current, visible: false };
        setPointer(pointerRef.current);
        hoverControl?.classList.remove("remote-hover");
      }
    };
    const resizePointer = () => {
      pointerRef.current = {
        ...pointerRef.current,
        x: Math.min(pointerRef.current.x, window.innerWidth - 1),
        y: Math.min(pointerRef.current.y, window.innerHeight - 1),
      };
      setPointer(pointerRef.current);
    };
    window.addEventListener("kkdex:input", input);
    window.addEventListener("pointermove", localMove);
    window.addEventListener("resize", resizePointer);
    return () => {
      window.removeEventListener("kkdex:input", input);
      window.removeEventListener("pointermove", localMove);
      window.removeEventListener("resize", resizePointer);
      installed.forEach((key) => {
        if (bridge[key] === api[key as keyof DesktopAPI])
          Reflect.deleteProperty(bridge, key);
      });
      if (!original) delete window.KKDexAPI;
      delete window.KKDexDesktop;
      hoverControl?.classList.remove("remote-hover");
    };
  }, []);
  return pointer;
}
