# KK DEX Desktop Integration

## Deliverables

- `src/App.tsx` selects the desktop or the separate phone controller.
- `npm run build` creates `dist/index.html` with the JavaScript and CSS inlined.
- Copy **all** files in `dist/`, including the local wallpapers, font, and SVG favicon, to the WebView asset root. The desktop has no runtime CDN dependencies.
- Keep the assets beside the generated index. Wallpapers and the favicon use document-relative URLs, and the font is bundled. The inlined build can load from your existing Android asset directory. An HTTPS `WebViewAssetLoader` origin is recommended for modern web APIs; preserve your existing loader and map the complete asset directory rather than changing the external-display architecture.
- Enable JavaScript and DOM storage in the trusted desktop and controller WebViews.

No Android project or existing bridge implementation was present in the supplied repository. No Java/Kotlin source has been replaced or modified. Physical external-display routing and the native services must be verified in the host project.

## Two independent surfaces

Load `/index.html` in the external-display WebView owned by the existing `Presentation` or external-display activity. Load `/index.html?controller` in the phone's controller WebView. The controller never renders or mirrors the desktop.

Keep the existing Android external-display lifecycle, display routing, orientation handling, and controller transport. The supplied controller is an optional web surface, not a replacement for an existing native controller.

## Desktop input contract

`window.KKDexAPI` exposes all requested method names. Pre-existing functions and unknown members on this object are preserved. Missing functions are installed as compatibility aliases. `window.KKDexDesktop` always exposes the new desktop implementation and can be used to forward calls from a pre-existing bridge. Neither object is an Android native service object.

| Method                                         | Contract                                                                                                                                           |
| ---------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| `movePointer(x, y)`                            | Absolute desktop CSS pixel coordinates, clamped to the viewport.                                                                                   |
| `movePointer(dx, dy, true)`                    | Relative CSS pixel movement, multiplied by the mouse-speed setting.                                                                                |
| `movePointer({dx, dy})`                        | Preferred explicit relative movement form.                                                                                                         |
| `movePointer({x, y})`                          | Explicit absolute movement form.                                                                                                                   |
| `pointerDown(button = 0)`                      | Press left button (0) or right button (2) on a real element.                                                                                       |
| `pointerUp(button = 0)`                        | Release; a stationary left down/up pair also produces a click.                                                                                     |
| `pointerClick()`                               | Left down/up and click. Do not send in addition to a stationary down/up pair.                                                                      |
| `pointerDoubleClick()`                         | Two clicks followed by a double-click event.                                                                                                       |
| `pointerRightClick()`                          | Right down/up followed by a context-menu event.                                                                                                    |
| `scrollDesktop(dx, dy)`                        | Scroll the actual scrollable ancestor under the pointer. A single argument means vertical scrolling.                                               |
| `insertText(text)`                             | Insert text into the focused input, textarea, or content-editable element.                                                                         |
| `pressKey(key, modifiers)`                     | Dispatch keyboard input. Modifiers: `{ctrl, alt, shift, meta}`. Key names follow `KeyboardEvent.key`; Win and Super are accepted aliases for Meta. |
| `getState()`                                   | Return a serializable object with windows, focus, viewport, pointer, appearance, and actual connected capabilities.                                |
| `openApp(appId, payload?)`                     | Launch or focus a registered app. A file ID or Settings section can be passed as payload.                                                          |
| `setTheme('light' or 'dark')`                  | Apply and persist the desktop theme.                                                                                                               |
| `setWallpaper('alpine' or 'coast' or 'dunes')` | Apply and persist a bundled wallpaper.                                                                                                             |

App IDs: `pc`, `files`, `browser`, `ai`, `store`, `settings`, `gallery`, `notes`, `calculator`, `terminal`, `bin`.

Coordinate conventions in the original host are unknown. If it sends numeric deltas to `movePointer`, change its forwarding adapter to use `movePointer(dx, dy, true)` rather than changing the host's internal protocol. For absolute physical-display coordinates, divide coordinates by the WebView device-pixel ratio and account for the WebView origin/insets. `getState().display` returns CSS viewport dimensions.

The bridge uses hit testing, PointerEvents, MouseEvents, focus, real click handlers, input events, scrollable elements, and text selection. It does not merely draw a pointer. The small visual cursor appears only after remote movement and disappears when a real local mouse moves.

Synthetic input cannot bypass browser or Android security policies. System file choosers, downloads, clipboard permissions, pop-ups, full-screen requests, and third-party embedded-page input may require native handling or a trusted user gesture. Clipboard failures are reported. Cross-origin iframe contents cannot be hit-tested or typed into by the parent desktop; use the native browser integration for full remote browsing.

## Controller transport

If using the included phone controller, provide the small transport adapter:

`window.KKDexControllerBridge.sendInput(jsonString)`

This is a new optional adapter, not a claim about the supplied Android API. If an existing native controller already forwards input, keep it instead.

The controller sends JSON objects such as:

- `{ "type": "movePointer", "dx": 8, "dy": -3, "relative": true }`
- `{ "type": "pointerDown", "button": 0 }`
- `{ "type": "pointerUp", "button": 0 }`
- `{ "type": "pointerClick" }`
- `{ "type": "pointerDoubleClick" }`
- `{ "type": "pointerRightClick" }`
- `{ "type": "scrollDesktop", "dx": 0, "dy": 40 }`
- `{ "type": "insertText", "text": "Hello" }`
- `{ "type": "pressKey", "key": "e", "modifiers": { "meta": true } }`

Relay input on the external WebView's UI thread using safely JSON-encoded arguments. The desktop also accepts `window.dispatchEvent(new CustomEvent('kkdex:input', { detail: parsedMessage }))`. Do not interpolate unescaped user input into JavaScript source. Do not broadcast desktop input into untrusted frames.

## Optional native services

Provide `window.KKDexServices` **only in the trusted top-level desktop document** as a JavaScript adapter around the host's actual existing backend methods. The following hooks are optional; disconnected capabilities are explicitly identified in the UI.

| Adapter                                    | Purpose                                                                                                                           |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------- |
| `chat(messages): Promise<string>`          | Real AI backend; messages contain `role` and `content`. Credentials must remain in the native backend or server.                  |
| `execute(command): Promise<string>`        | Real authorized terminal backend. Used only for the explicit `native` shell command.                                              |
| `openBrowser(url): void`                   | Open a URL in the host's genuine browser/WebView integration.                                                                     |
| `setVolume(percent): void`                 | Actual Android audio control. Without it, volume applies only to workspace test audio.                                            |
| `setBrightness(percent): void`             | Optional native brightness. The workspace dimmer also updates immediately.                                                        |
| `setWifi(enabled): void`                   | Actual Android network control, subject to platform restrictions.                                                                 |
| `power(action): void`                      | Actual supported `sleep`, `restart`, or `shutdown` behavior, subject to platform permissions.                                     |
| `requestStorageAccess(): Promise<boolean>` | Launch an authorized Storage Access Framework permission/picker flow. This does not imply a file-listing provider is implemented. |

These are integration hooks, not guessed native methods. Missing adapters never produce fabricated successful operations. Installing Android packages, listing arbitrary device files, Bluetooth management, and calendar accounts are not supplied by this web-only project.

## Storage and applications

Files, folders, deleted items, notes, appearance, shortcut positions, recent apps, and connected-service chat history persist in localStorage. Files clearly label this as the KK DEX workspace, not Android internal storage. Imported files are genuine File API data, with a 2 MB per-file limit because this implementation uses localStorage. Clearing WebView data removes the workspace. Export important files before clearing data. Quota errors are surfaced.

The shell executes real operations against that workspace (`ls`, `cd`, `pwd`, `cat`, `mkdir`, `rm`, `open`, `theme`, `echo`, `date`, `clear`). It never claims Android root or filesystem access.

The web browser provides real tabs, per-tab address history, back/forward, reload, search, and a sandboxed iframe. Sites may refuse framing. An explicit system-browser action is always available; a full native browser should use a separate WebView with its own navigation and input routing.

## Android security requirements

Do not expose privileged `addJavascriptInterface` objects to arbitrary sites, redirects, or third-party iframes. Android's legacy JavaScript interfaces are available to frames and have no origin-based access control. Prefer origin-allowlisted AndroidX WebKit messaging where possible. Use a separate unprivileged WebView for internet browsing, remove native bridges from it, and preserve the trusted desktop WebView independently. Do not enable universal file URL access as a workaround.

Native host work, if not already implemented, is limited to routing controller events to the existing external-display WebView, optionally adapting supported native services, handling file chooser/download callbacks, and applying the host's bridge security policy. None of this can be hardware-validated without the Android host project.

## Assets

The Alpine wallpaper was generated for this project. Ocean photograph: Justyna Serafin, Pexels #16837600. Dunes photograph: MART PRODUCTION, Pexels #8869381. Icons use Lucide and custom SVG artwork. Inter is distributed under the SIL Open Font License.
