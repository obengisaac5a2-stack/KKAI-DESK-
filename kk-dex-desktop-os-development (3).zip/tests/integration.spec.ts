import { test, expect, type Page } from "@playwright/test";

const launch = async (page: Page, id: string) => {
  await page.evaluate((id) => window.KKDexDesktop!.openApp(id), id);
  await expect(page.locator(`[data-app="${id}"]`)).toBeVisible();
  await page.waitForTimeout(200);
};
const pointTo = async (page: Page, selector: string) => {
  const box = await page.locator(selector).boundingBox();
  if (!box) throw new Error("Missing target");
  await page.evaluate(({ x, y }) => window.KKDexDesktop!.movePointer(x, y), {
    x: box.x + box.width / 2,
    y: box.y + box.height / 2,
  });
};

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await page.waitForTimeout(250);
});

test("every desktop icon double-click launches its registered application", async ({
  page,
}) => {
  for (const id of [
    "pc",
    "files",
    "browser",
    "ai",
    "store",
    "settings",
    "gallery",
    "notes",
    "calculator",
    "terminal",
    "bin",
  ]) {
    await page.locator(`[data-desktop-icon="${id}"]`).dblclick();
    await expect(page.locator(`[data-app="${id}"]`)).toBeVisible();
  }
  await expect(page.locator("[data-window]")).toHaveCount(11);
});

test("titlebar and taskbar right-click menus perform actual window actions", async ({
  page,
}) => {
  await page
    .locator('[data-app="files"] .window-titlebar')
    .click({ button: "right", position: { x: 120, y: 20 } });
  await page.getByRole("menuitem", { name: "Minimize", exact: true }).click();
  await expect(page.locator('[data-app="files"]')).toHaveAttribute(
    "aria-hidden",
    "true",
  );
  await page.locator('[data-taskbar-app="files"]').click({ button: "right" });
  await page
    .getByRole("menuitem", { name: "Restore window", exact: true })
    .click();
  await expect(page.locator('[data-app="files"]')).toHaveAttribute(
    "aria-hidden",
    "false",
  );
  await page.locator('[data-taskbar-app="files"]').click({ button: "right" });
  await page
    .getByRole("menuitem", { name: "Close window", exact: true })
    .click();
  await expect(page.locator('[data-app="files"]')).toHaveCount(0);
  await page.locator(".taskbar-brand").click({ button: "right" });
  await expect(
    page.getByRole("menuitem", { name: "Show desktop", exact: true }),
  ).toBeVisible();
});

test("remote input supports relative movement, scrolling, text selection, undo and redo", async ({
  page,
}) => {
  await page.evaluate(() => {
    const api = window.KKDexDesktop!;
    api.movePointer(1000, 700);
    api.movePointer({ dx: 20, dy: -10 });
  });
  expect(
    await page.evaluate(
      () =>
        (
          window.KKDexDesktop!.getState() as {
            pointer: { x: number; y: number };
          }
        ).pointer,
    ),
  ).toMatchObject({ x: 1020, y: 690 });
  await launch(page, "settings");
  await pointTo(page, ".settings-content");
  await page.evaluate(() => window.KKDexDesktop!.scrollDesktop(0, 180));
  expect(
    await page.locator(".settings-content").evaluate((el) => el.scrollTop),
  ).toBeGreaterThan(0);
  await launch(page, "notes");
  await pointTo(page, ".note-text");
  await page.evaluate(() => window.KKDexDesktop!.pointerClick());
  const original = await page.locator(".note-text").inputValue();
  await page.evaluate(() => {
    const api = window.KKDexDesktop!;
    api.pressKey("a", { ctrl: true });
    api.insertText("Actual bridge text");
  });
  await expect(page.locator(".note-text")).toHaveValue("Actual bridge text");
  await page.evaluate(() => window.KKDexDesktop!.pressKey("z", { ctrl: true }));
  await expect(page.locator(".note-text")).toHaveValue(original);
  await page.evaluate(() => window.KKDexDesktop!.pressKey("y", { ctrl: true }));
  await expect(page.locator(".note-text")).toHaveValue("Actual bridge text");
  await page.evaluate(() => window.KKDexDesktop!.pressKey("a", { ctrl: true }));
  expect(
    await page
      .locator(".note-text")
      .evaluate(
        (el: HTMLTextAreaElement) => el.selectionEnd! - el.selectionStart!,
      ),
  ).toBe("Actual bridge text".length);
});

test("remote pointer resizes from all eight handles and uses matching cursors", async ({
  page,
}) => {
  for (const [edge, dx, dy] of [
    ["e", 10, 0],
    ["w", -10, 0],
    ["n", 0, -10],
    ["s", 0, 10],
    ["ne", 8, -8],
    ["nw", -8, -8],
    ["se", 8, 8],
    ["sw", -8, 8],
  ] as const) {
    const box = await page.locator(`[data-resize="${edge}"]`).boundingBox();
    const before = await page.locator('[data-app="files"]').boundingBox();
    await page.evaluate(
      ({ x, y, dx, dy }) => {
        const api = window.KKDexDesktop!;
        api.movePointer(x, y);
        api.pointerDown();
        api.movePointer(x + dx, y + dy);
        api.pointerUp();
      },
      { x: box!.x + box!.width / 2, y: box!.y + box!.height / 2, dx, dy },
    );
    const after = await page.locator('[data-app="files"]').boundingBox();
    if (dx) expect(after!.width).toBeGreaterThan(before!.width);
    if (dy) expect(after!.height).toBeGreaterThan(before!.height);
    expect(
      await page.evaluate(
        () =>
          (window.KKDexDesktop!.getState() as { pointer: { cursor: string } })
            .pointer.cursor,
      ),
    ).toBe(edge);
  }
});

test("file undo, redo and repeated paste operate on real managed data", async ({
  page,
}) => {
  const files = page.locator('[data-app="files"]');
  await files.locator(".sidebar-item").filter({ hasText: "Documents" }).click();
  await files.getByRole("button", { name: "New", exact: true }).click();
  await page.getByRole("textbox", { name: "Folder name" }).fill("Undo folder");
  await page
    .getByRole("button", { name: "Create folder", exact: true })
    .click();
  await expect(
    files.locator(".file-row").filter({ hasText: "Undo folder" }),
  ).toHaveCount(1);
  await page.keyboard.press("Control+z");
  await expect(
    files.locator(".file-row").filter({ hasText: "Undo folder" }),
  ).toHaveCount(0);
  await page.keyboard.press("Control+y");
  await expect(
    files.locator(".file-row").filter({ hasText: "Undo folder" }),
  ).toHaveCount(1);
  await files.locator(".file-row").filter({ hasText: "Undo folder" }).click();
  await page.keyboard.press("Control+c");
  await page.keyboard.press("Control+v");
  await page.keyboard.press("Control+v");
  await expect(
    files.locator(".file-row").filter({ hasText: "Undo folder - Copy (2)" }),
  ).toHaveCount(1);
});

test("Show Desktop preserves pre-existing minimized window states", async ({
  page,
}) => {
  await launch(page, "notes");
  await page
    .getByRole("button", { name: "Minimize Notes", exact: true })
    .click();
  await launch(page, "calculator");
  await page.keyboard.press("Meta+d");
  await page.keyboard.press("Meta+d");
  await expect(page.locator('[data-app="notes"]')).toHaveAttribute(
    "aria-hidden",
    "true",
  );
  await expect(page.locator('[data-app="files"]')).toHaveAttribute(
    "aria-hidden",
    "false",
  );
  await expect(page.locator('[data-app="calculator"]')).toHaveAttribute(
    "aria-hidden",
    "false",
  );
});

test("existing KKDexAPI members are preserved and the event adapter remains available", async ({
  page,
}) => {
  await page.addInitScript(() => {
    window.KKDexAPI = {
      movePointer: () => {
        (window as unknown as { originalCalled: boolean }).originalCalled =
          true;
      },
      nativeExtension: "preserved",
    };
  });
  await page.reload();
  await page.evaluate(() => window.KKDexAPI!.movePointer!(20, 20));
  expect(
    await page.evaluate(
      () => (window as unknown as { originalCalled: boolean }).originalCalled,
    ),
  ).toBeTruthy();
  expect(await page.evaluate(() => window.KKDexAPI!.nativeExtension)).toBe(
    "preserved",
  );
  await page.evaluate(() =>
    window.dispatchEvent(
      new CustomEvent("kkdex:input", {
        detail: { type: "movePointer", x: 400, y: 250 },
      }),
    ),
  );
  expect(
    await page.evaluate(
      () =>
        (
          window.KKDexDesktop!.getState() as {
            pointer: { x: number; y: number };
          }
        ).pointer,
    ),
  ).toMatchObject({ x: 400, y: 250 });
});

test("storage quota failures are visible and never presented as successful saves", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = function (key, value) {
      if (key === "kkdex:files" || key === "kkdex:notes")
        throw new DOMException("Storage full", "QuotaExceededError");
      original.call(this, key, value);
    };
  });
  await page.reload();
  await launch(page, "notes");
  await expect(page.locator(".note-editor-toolbar")).toContainText(
    "Storage full: changes not saved",
  );
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.getByRole("status")).toContainText("Local storage is full");
});

test("controller sends one double-click and real relative pointer messages", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(() => {
    (window as unknown as { messages: unknown[] }).messages = [];
    window.KKDexControllerBridge = {
      sendInput: (data) =>
        (window as unknown as { messages: unknown[] }).messages.push(
          JSON.parse(data),
        ),
    };
  });
  await page.goto("/?controller");
  await page.locator(".touchpad").dblclick({ position: { x: 80, y: 80 } });
  await page.waitForTimeout(360);
  expect(
    await page.evaluate(
      () => (window as unknown as { messages: unknown[] }).messages,
    ),
  ).toEqual([{ type: "pointerDoubleClick" }]);
  const box = await page.locator(".touchpad").boundingBox();
  await page.mouse.move(box!.x + 90, box!.y + 90);
  await page.mouse.down();
  await page.mouse.move(box!.x + 120, box!.y + 110, { steps: 3 });
  await page.mouse.up();
  expect(
    await page.evaluate(() =>
      (window as unknown as { messages: { type: string }[] }).messages.some(
        (m) => m.type === "movePointer",
      ),
    ),
  ).toBeTruthy();
});

test("icons remain within the workspace and do not collide after resolution changes", async ({
  page,
}) => {
  await page.evaluate(() =>
    localStorage.setItem(
      "kkdex:icon-positions",
      JSON.stringify({
        files: { col: 0, row: 5 },
        calculator: { col: 1, row: 5 },
      }),
    ),
  );
  await page.reload();
  await page.setViewportSize({ width: 1024, height: 600 });
  const boxes = await page.locator(".desktop-icon").evaluateAll((elements) =>
    elements.map((el) => {
      const r = el.getBoundingClientRect();
      return { x: r.x, y: r.y, right: r.right, bottom: r.bottom };
    }),
  );
  for (const box of boxes) {
    expect(box.bottom).toBeLessThanOrEqual(536);
    expect(box.right).toBeLessThanOrEqual(1024);
  }
  expect(new Set(boxes.map((b) => `${b.x}:${b.y}`)).size).toBe(boxes.length);
});

test("restoring after a display resolution change stays inside the workspace", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Maximize Files", exact: true })
    .click();
  await page.setViewportSize({ width: 800, height: 600 });
  await page
    .getByRole("button", { name: "Restore Files", exact: true })
    .click();
  const box = await page.locator('[data-app="files"]').boundingBox();
  expect(box!.x).toBeGreaterThanOrEqual(0);
  expect(box!.y).toBeGreaterThanOrEqual(0);
  expect(box!.x + box!.width).toBeLessThanOrEqual(800);
  expect(box!.y + box!.height).toBeLessThanOrEqual(536);
});

test("text-size settings scale real desktop and application text", async ({
  page,
}) => {
  const previous = await page
    .locator(".file-page-heading h1")
    .evaluate((el) => parseFloat(getComputedStyle(el).fontSize));
  await launch(page, "settings");
  await page
    .locator(".settings-sidebar .sidebar-item")
    .filter({ hasText: "Display" })
    .click();
  await page
    .getByRole("combobox", { name: "Desktop text size" })
    .selectOption("1.15");
  const changed = await page
    .locator(".file-page-heading h1")
    .evaluate((el) => parseFloat(getComputedStyle(el).fontSize));
  expect(changed).toBeGreaterThan(previous);
});

test("permanent deletion requires confirmation and cannot be undone", async ({
  page,
}) => {
  const files = page.locator('[data-app="files"]');
  await files.locator(".sidebar-item").filter({ hasText: "Downloads" }).click();
  await files.locator(".file-row").first().click();
  await page.keyboard.press("Delete");
  await launch(page, "bin");
  await page
    .getByRole("button", { name: "Empty Recycle Bin", exact: true })
    .click();
  await expect(
    page.getByRole("dialog", { name: "Delete permanently?", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Delete permanently", exact: true })
    .click();
  await expect(page.locator(".recycle-file")).toHaveCount(0);
  await page
    .getByRole("button", { name: "Close Recycle Bin", exact: true })
    .click();
  await page.keyboard.press("Control+z");
  await expect(files.locator(".file-row")).toHaveCount(0);
});

test("a read-only existing native bridge never prevents desktop initialization", async ({
  page,
}) => {
  await page.addInitScript(() => {
    window.KKDexAPI = Object.freeze({ movePointer: () => undefined });
  });
  await page.reload();
  await expect(page.locator('[data-app="files"]')).toBeVisible();
  expect(await page.evaluate(() => typeof window.KKDexDesktop!.getState)).toBe(
    "function",
  );
  await launch(page, "calculator");
  await expect(page.locator(".calculator-keys")).toBeVisible();
});

test("phone arrow keys move and extend real text selections and Start owns its search shortcut", async ({
  page,
}) => {
  await launch(page, "notes");
  await pointTo(page, ".note-text");
  await page.evaluate(() => {
    const api = window.KKDexDesktop!;
    api.pointerClick();
    api.pressKey("a", { ctrl: true });
    api.insertText("first\nsecond\nthird");
    api.pressKey("Home");
    api.pressKey("ArrowDown");
  });
  expect(
    await page
      .locator(".note-text")
      .evaluate((el: HTMLTextAreaElement) => el.selectionStart),
  ).toBe(6);
  await page.evaluate(() => {
    const api = window.KKDexDesktop!;
    api.pressKey("ArrowUp");
    api.pressKey("ArrowRight", { shift: true });
  });
  expect(
    await page
      .locator(".note-text")
      .evaluate(
        (el: HTMLTextAreaElement) => el.selectionEnd - el.selectionStart,
      ),
  ).toBe(1);
  await page.getByRole("button", { name: "Start menu", exact: true }).click();
  await page.keyboard.press("Control+f");
  await expect(
    page.getByRole("textbox", { name: "Search apps in Start" }),
  ).toBeFocused();
});
