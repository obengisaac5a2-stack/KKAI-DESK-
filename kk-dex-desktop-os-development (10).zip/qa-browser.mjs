import { chromium } from 'playwright';
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await context.newPage();
const errors=[]; page.on('pageerror',e=>errors.push(e.message)); page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.addInitScript(() => {
  window.__calls=[];
  window.KKDexNative={
    getCapabilities:()=>JSON.stringify({bridge:'KKDexNative',platform:'Pixel Test',sdkInt:34,storageAccessFramework:true,mediaStore:true,installedApps:true,appLaunch:true,externalDisplay:true,downloads:true,writeAccess:true,browser:true,storageStats:true,downloadManager:true,apkInstall:true,systemControls:true,gameDiscovery:true,performanceModes:true}),
    browserOpen:(url,dm,pm,id)=>{window.__calls.push(['open',url,dm,pm]);setTimeout(()=>window.KKDexBrowserEvent(JSON.stringify({type:'state',state:{url,title:'Example Domain',loading:false,progress:100,canGoBack:false,canGoForward:false,desktopMode:dm}})),20);return JSON.stringify({url,title:'Example Domain',loading:true,progress:10,canGoBack:false,canGoForward:false,desktopMode:dm});},
    browserNavigate:(url,id)=>{window.__calls.push(['nav',url]);setTimeout(()=>window.KKDexBrowserEvent(JSON.stringify({type:'state',state:{url,title:'YouTube',loading:false,progress:100,canGoBack:true,canGoForward:false,desktopMode:true}})),20);return JSON.stringify({url,title:'YouTube',loading:true,progress:5,canGoBack:true,canGoForward:false,desktopMode:true});},
    browserSetBounds:(l,t,w,h,v,dpr,id)=>{window.__bounds={l,t,w,h,v};return true;},
    browserBack:()=>JSON.stringify({url:'https://back.example',title:'Back',canGoBack:false,canGoForward:true}),
    browserForward:()=>JSON.stringify({url:'https://forward.example',title:'Forward',canGoBack:true,canGoForward:false}),
    browserReload:()=>JSON.stringify({url:'https://www.youtube.com',title:'YouTube',loading:true,progress:20,canGoBack:true,canGoForward:false}),
    browserFocus:()=>JSON.stringify({ok:true}),
    browserClose:()=>true,
    browserSetDesktopMode:()=>JSON.stringify({url:'https://www.youtube.com',desktopMode:true}),
    browserInput:(a,x,y,v,id)=>{window.__input=[a,x,y,v];return JSON.stringify({ok:true});},
    relayToDesktop:()=>true,
    relayToController:()=>true,
    getInstalledApps:()=>JSON.stringify({ok:true,apps:[{packageName:'com.test.game',label:'Native Test Game',isGame:true,icon:''}]}),
    launchAndroidApp:()=>JSON.stringify({ok:true,launched:true,display:'phone',message:'Test launch on phone'}),
    getStorageInfo:()=>JSON.stringify({ok:true,totalBytes:137438953472,availableBytes:68719476736,usedBytes:68719476736,categories:{apps:1,images:2,videos:3,audio:4,documents:5,downloads:6,apk:7,games:8,other:9}}),
  };
});
await page.goto('http://127.0.0.1:4173/', {waitUntil:'networkidle'}); await page.waitForTimeout(500);
await page.evaluate(()=>window.KKDexAPI.openApp('browser'));
await page.waitForTimeout(500);
const bw=page.locator('[aria-label="Browser window"]');
console.log('browser native label:', await bw.getByText('Native browser surface').count());
console.log('native state title in tabs:', await bw.getByText('Example Domain').count());
await bw.locator('input[placeholder="Search Google or type a URL"]').fill('youtube');
await bw.locator('input[placeholder="Search Google or type a URL"]').press('Enter');
await page.waitForTimeout(500);
console.log('address after search:', await bw.locator('input').first().inputValue());
console.log('nav calls:', await page.evaluate(()=>window.__calls));
await bw.getByRole('button',{name:'New tab'}).click();
await page.waitForTimeout(300);
console.log('tab count:', await bw.locator('button').filter({hasText:'New tab'}).count());
await bw.getByRole('button',{name:'Downloads'}).first().click();
await page.waitForTimeout(300);
console.log('download side panel:', await bw.getByText('Website downloads are handled').count());
await bw.getByRole('button',{name:'Close browser panel'}).click();
console.log('bounds:', await page.evaluate(()=>window.__bounds));
// app center android apps
await page.evaluate(()=>window.KKDexAPI.openApp('appcenter'));
await page.waitForTimeout(800);
const ac=page.locator('[aria-label="App Center window"]');
console.log('app center android game:', await ac.getByText('Native Test Game').count());
await ac.getByTitle('Launch on Android').first().click();
await page.waitForTimeout(400);
console.log('launch status:', await ac.getByText(/Test launch on phone/).count());
await page.screenshot({path:'/tmp/browser-native.png'});
console.log('errors:', errors.length?errors.slice(0,5):'none');
await browser.close();
