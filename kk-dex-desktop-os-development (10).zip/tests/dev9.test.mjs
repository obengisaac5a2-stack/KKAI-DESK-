/**
 * KK DEX Development 9 automated tests.
 *
 * Run: node tests/dev9.test.mjs   (requires a preview server on :4173)
 * Start the server first: npm run build && npx vite preview --host 127.0.0.1 --port 4173
 */
import { chromium } from "playwright";

const BASE = process.env.KKDEX_URL ?? "http://127.0.0.1:4173/";
let passed = 0;
let failed = 0;

function check(name, condition, detail = "") {
  if (condition) {
    passed += 1;
    console.log(`PASS  ${name}`);
  } else {
    failed += 1;
    console.log(`FAIL  ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

const browser = await chromium.launch();

// ---------- 1. Settings: full-screen, scaling, wallpapers, security ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.addInitScript(() => {
    window.__fullscreen = [];
    window.KKDexNative = {
      getCapabilities: () =>
        JSON.stringify({
          bridge: "KKDexNative", platform: "Test", sdkInt: 34, browser: true, shellExecution: true,
          storageStats: true, systemControls: true, performanceModes: true, downloadManager: true,
          installedApps: true, appLaunch: true, storageAccessFramework: true,
        }),
      setFullscreen: (enabled, id) => {
        window.__fullscreen.push(enabled);
        setTimeout(() => window.KKDexNativeResult(id, JSON.stringify({ ok: true, enabled })), 5);
        return true;
      },
      runtimeInfo: () =>
        JSON.stringify({
          shell: "sh", shellPath: "/system/bin/sh",
          runtimes: [
            { name: "python", available: true, version: "Python 3.11.6" },
            { name: "node", available: false, note: "not installed" },
          ],
          packageManager: { name: "pkg", available: true, note: "pkg is installed." },
          userland: { available: true, note: "prefix installed" },
          cpuAbi: "arm64-v8a", apiLevel: 34,
        }),
      terminalStart: () => JSON.stringify({ ok: true, id: "main", cwd: "/data/user/0/app/files/workspace", alive: true }),
      terminalExec: (session, command, id) => {
        const result =
          command === "false"
            ? { stdout: "", stderr: "", exitCode: 1 }
            : { stdout: `ok:${command}`, stderr: "", exitCode: 0 };
        setTimeout(() => window.KKDexNativeResult(id, JSON.stringify({ ...result, cwd: "/data/user/0/app/files/workspace", durationMs: 12 })), 10);
        return "";
      },
      terminalInterrupt: () => JSON.stringify({ ok: true }),
      terminalList: () => JSON.stringify({ ok: true, sessions: [{ id: "main", cwd: "/data/user/0/app/files/workspace", alive: true }] }),
      relayToDesktop: () => true, relayToController: () => true,
    };
  });
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForTimeout(700);

  // Full-screen is enabled by default and reflected in the setting.
  await page.evaluate(() => window.KKDexAPI.openApp("settings"));
  await page.waitForTimeout(500);
  const settings = page.locator('[aria-label="Settings window"]');
  await settings.getByText("Display", { exact: true }).first().click();
  await page.waitForTimeout(300);
  check("full-screen enabled by default", await settings.getByText("ENABLED").count() > 0);
  check("native full-screen requested on start", await page.evaluate(() => window.__fullscreen[0] === true));

  // Toggle works and calls the native controller.
  await settings.getByRole("button", { name: /Exit full screen/ }).click();
  await page.waitForTimeout(300);
  const calls = await page.evaluate(() => window.__fullscreen);
  check("full-screen toggle calls native API", calls.includes(false) && (await settings.getByText("DISABLED").count()) > 0);
  await settings.getByRole("button", { name: /Enter full screen/ }).click();
  await page.waitForTimeout(250);

  // Scaling modes apply without crashing and persist.
  for (const [mode, label] of [["large", "Large"], ["small", "Small"], ["minimal", "Minimal"], ["manual", "Manual"]]) {
    await settings.getByRole("button", { name: new RegExp(`^${label}`) }).first().click();
    await page.waitForTimeout(150);
    const applied = await page.evaluate(() => document.documentElement.dataset.uiScale);
    check(`scaling mode ${mode} applied`, applied === mode);
  }
  check("manual scale slider appears", await settings.getByText("Scale", { exact: true }).count() > 0);
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForTimeout(500);
  check("scaling persists after reload", (await page.evaluate(() => document.documentElement.dataset.uiScale)) === "manual");

  // Wallpaper set: at least ten, required categories, selection persists.
  await page.evaluate(() => window.KKDexAPI.openApp("settings"));
  await page.waitForTimeout(400);
  const settings2 = page.locator('[aria-label="Settings window"]');
  await settings2.getByText("Personalization", { exact: true }).first().click();
  await page.waitForTimeout(300);
  const wallpaperNames = await settings2.locator("button").allInnerTexts();
  const wanted = ["Modern sports cars", "Luxury vehicles", "Motorcycles", "Green forests", "Trees & nature", "Mountains & landscape", "Sunset scenery", "Animated abstract", "Animated futuristic", "Animated character art"];
  for (const note of wanted) {
    check(`wallpaper category present: ${note}`, wallpaperNames.some((text) => text.includes(note)));
  }
  await settings2.getByText("Ember Coast").click();
  await page.waitForTimeout(300);
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForTimeout(500);
  const savedWallpaper = await page.evaluate(() => JSON.parse(localStorage.getItem("kkdex.settings") || "{}").wallpaper);
  check("wallpaper selection persists", savedWallpaper === "sunset");

  // Security: create PIN, verify hashed storage.
  await page.evaluate(() => window.KKDexAPI.openApp("settings"));
  await page.waitForTimeout(400);
  const settings3 = page.locator('[aria-label="Settings window"]');
  await settings3.getByText("Security & login", { exact: true }).first().click();
  await page.waitForTimeout(300);
  const passwordInputs = settings3.locator('input[type="password"]');
  await passwordInputs.nth(0).fill("2468");
  await passwordInputs.nth(1).fill("2468");
  await settings3.getByRole("button", { name: /Create PIN/ }).click();
  await page.waitForTimeout(1200);
  const credential = await page.evaluate(() => localStorage.getItem("kkdex.credential"));
  check("PIN stored as hash, never plaintext", Boolean(credential) && !credential.includes("2468") && credential.includes("PBKDF2"));

  // Lock and unlock with wrong then correct PIN.
  await settings3.getByRole("button", { name: "Lock now" }).click();
  await page.waitForTimeout(500);
  check("lock screen shows PIN entry", await page.getByPlaceholder("PIN or password").count() > 0);
  await page.getByPlaceholder("PIN or password").fill("0000");
  await page.getByRole("button", { name: "Unlock", exact: true }).click();
  await page.waitForTimeout(800);
  check("wrong PIN rejected", await page.getByText("Incorrect PIN or password").count() > 0);
  await page.getByPlaceholder("PIN or password").fill("2468");
  await page.getByRole("button", { name: "Unlock", exact: true }).click();
  await page.waitForTimeout(800);
  check("correct PIN unlocks desktop", await page.locator(".desk-icon").count() > 0);

  // Sleep and wake with authentication.
  await page.evaluate(() => window.KKDexAPI.openApp("settings"));
  await page.waitForTimeout(400);
  const settings4 = page.locator('[aria-label="Settings window"]');
  await settings4.getByText("Power & sleep", { exact: true }).first().click();
  await page.waitForTimeout(300);
  await settings4.getByRole("button", { name: /^Sleep/ }).first().click();
  await page.waitForTimeout(400);
  check("sleep screen shown", await page.getByText("Desktop session preserved").count() > 0);
  await page.getByRole("button", { name: "Wake desktop" }).click();
  await page.waitForTimeout(500);
  check("waking requires authentication when PIN set", await page.getByPlaceholder("PIN or password").count() > 0);
  await page.getByPlaceholder("PIN or password").fill("2468");
  await page.getByRole("button", { name: "Unlock", exact: true }).click();
  await page.waitForTimeout(500);

  check("no page errors in settings flow", errors.length === 0, errors.slice(0, 2).join(" | "));
  await page.close();
}

// ---------- 2. Terminal ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.addInitScript(() => {
    window.__terminal = [];
    window.KKDexNative = {
      getCapabilities: () => JSON.stringify({ bridge: "KKDexNative", platform: "Test", sdkInt: 34, shellExecution: true, terminal: true }),
      runtimeInfo: () =>
        JSON.stringify({
          shell: "sh", shellPath: "/system/bin/sh",
          runtimes: [
            { name: "python", available: true, version: "Python 3.11.6" },
            { name: "node", available: true, version: "v20.11.0" },
            { name: "git", available: false },
          ],
          packageManager: { name: "pkg", available: true, note: "pkg is installed." },
          userland: { available: false, note: "No Linux userland bootstrap is bundled." },
          cpuAbi: "arm64-v8a", apiLevel: 34,
        }),
      terminalStart: () => JSON.stringify({ ok: true, id: "main", cwd: "/data/user/0/com.kkdex.desktop/files/workspace", alive: true }),
      terminalExec: (session, command, id) => {
        window.__terminal.push(command);
        const fail = command.includes("definitely-missing");
        setTimeout(() => {
          if (fail) window.KKDexNativeResult(id, JSON.stringify({ stdout: "", stderr: `sh: ${command.split(" ")[0]}: not found`, exitCode: 127, cwd: "/data/user/0/com.kkdex.desktop/files/workspace", durationMs: 8 }));
          else window.KKDexNativeResult(id, JSON.stringify({ stdout: `hello from real process\n${command}\n`, stderr: "", exitCode: 0, cwd: "/data/user/0/com.kkdex.desktop/files/workspace", durationMs: 14 }));
        }, 15);
        return "";
      },
      terminalInterrupt: () => JSON.stringify({ ok: true, interrupted: true }),
      terminalList: () => JSON.stringify({ ok: true, sessions: [{ id: "main", cwd: "/data/user/0/com.kkdex.desktop/files/workspace", alive: true }] }),
      relayToDesktop: () => true, relayToController: () => true,
    };
  });
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForTimeout(600);
  await page.evaluate(() => window.KKDexAPI.openApp("terminal"));
  await page.waitForTimeout(700);
  const term = page.locator('[aria-label="Terminal window"]');

  check("terminal shows live process host", await term.getByText("LIVE PROCESS HOST").count() > 0);
  await term.locator("input").fill("ls -la");
  await term.locator("input").press("Enter");
  await page.waitForTimeout(500);
  check("command executes through process host", (await page.evaluate(() => window.__terminal)).includes("ls -la"));
  check("command output rendered", await term.getByText("hello from real process").count() > 0);
  check("exit code reported", await term.getByText(/exit 0/).count() > 0);

  await term.locator("input").fill("definitely-missing");
  await term.locator("input").press("Enter");
  await page.waitForTimeout(500);
  check("missing tool reports real OS error", await term.getByText("not found").count() > 0);
  check("non-zero exit code reported", await term.getByText(/exit 127/).count() > 0);

  await term.getByTitle("Runtime information").click();
  await page.waitForTimeout(400);
  check("runtime detection listed", await term.getByText("Python 3.11.6").count() > 0);
  check("missing runtime honestly shown", await term.getByText("not installed").count() > 0);
  check("package manager reported", await term.getByText("pkg").count() > 0);

  await term.getByRole("button", { name: "New terminal session" }).click();
  await page.waitForTimeout(300);
  check("multiple terminal sessions supported", await term.getByText("s").count() > 0);
  await term.getByRole("button", { name: /Close s/ }).first().click();
  await page.waitForTimeout(200);

  check("no page errors in terminal flow", errors.length === 0, errors.slice(0, 2).join(" | "));
  await page.close();
}

// ---------- 3. Desktop regression: windows + controller separation ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForTimeout(500);
  for (const id of ["files", "browser", "games"]) {
    await page.evaluate((appId) => window.KKDexAPI.openApp(appId), id);
    await page.waitForTimeout(250);
  }
  check("multiple application windows open", (await page.evaluate(() => window.KKDexAPI.getState().windows.length)) === 3);
  const win = page.locator('[aria-label="Files window"]');
  await page.locator('footer [aria-label="Files"]').click();
  await page.waitForTimeout(250);
  await win.locator('[aria-label="Minimize window"]').click();
  await page.waitForTimeout(250);
  await page.locator('footer [aria-label="Files"]').click();
  await page.waitForTimeout(250);
  check("minimize/restore keeps same window", await win.isVisible());
  check("desktop has no controller UI", await page.getByText("Touchpad", { exact: true }).count() === 0);
  await page.close();
}

await browser.close();
console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
