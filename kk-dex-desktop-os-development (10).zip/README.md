# KK DEX — Gaming Desktop OS

KK DEX turns an Android phone into the system host and controller for a PC-style desktop on an external TV or monitor. The desktop and phone controller are separate interfaces; the TV never shows the controller UI.

## Run the web client

```bash
npm install
npm run dev
```

- Desktop: `/`
- Phone controller: `/?controller=1`
- Force desktop mode on a phone: `/?desktop=1`

`npm run build` emits a single-file desktop bundle to `dist/`. Serve the whole `dist/` directory so `/wallpapers` and `/gallery` resolve. Do not open `dist/index.html` with `file://`; WebView assets need an HTTP(S) origin.

## Development 9 highlights

- **Full-screen TV desktop by default**, controlled by native immersive APIs (Settings → Display → Full screen).
- **Interface scaling**: Large, Small, Minimal and Manual (80–135 %) with instant, persistent application.
- **12 built-in wallpapers** — automotive, motorcycle, forest, nature, mountain and sunset art plus animated abstract/futuristic/character backgrounds.
- **Security**: local account with PBKDF2-SHA256 hashed PIN/password, lock screen, auto-lock, documented recovery.
- **Power**: sleep/wake with session preservation and authentication on wake.
- **Persistent TV session**: `DisplaySessionService` foreground service keeps the desktop alive while the phone is used.
- **KK DEX Terminal**: real Android process host (`ShellSessionManager`) with sessions, streamed output, exit codes, interruption, runtime detection and a source editor. See `TESTING.md` for the honest capability matrix.
- **Android debug APK builds successfully** (`gradle assembleDebug`) and `gradle lint` passes.

## Android host

The native project lives in `android/`. It wraps the built `dist/` bundle in dedicated WebViews:

| Surface | Implementation |
| --- | --- |
| TV / monitor desktop | `DesktopPresentation` (Android `Presentation`) |
| Phone controller | `MainActivity` WebView (`?controller=1`) |
| Native browser | `BrowserHost` WebView overlay above the desktop |
| Storage | `FileAccessManager` (SAF), `StorageStatsProvider` (StatFs/MediaStore) |
| Downloads | `DownloadBridge` (Android DownloadManager) |
| System controls | `SystemBridge` (connectivity, Wi-Fi/Bluetooth settings, AudioManager) |
| JavaScript bridge | `KKdexBridge` exposed as `window.KKDexNative` only on trusted bundle pages |

### Build the APK

1. Build the web bundle: `npm ci && npm run build`.
2. Install JDK 17 and Android SDK platform 35 + build-tools.
3. From `android/`: `gradle assembleDebug` using Gradle 8.10.2.
4. Install: `adb install -r android/app/build/outputs/apk/debug/app-debug.apk`.

The included `.github/workflows/android-apk.yml` performs steps 1–3 on GitHub Actions and uploads `kkdex-debug-apk`. Gradle syncs `dist/index.html`, `wallpapers`, and `gallery` into `android/app/src/main/assets/`.

> **Build status:** the frontend production build has been run successfully here. The Android Gradle build has **not** been executed in this environment because it has no JDK or Android SDK. No APK is included, and no Android-device feature is claimed as device-tested.

## Native bridge contract

`src/os/native.ts` supports synchronous JSON results and asynchronous `window.KKDexNativeResult(requestId, payload)` callbacks. The high-level functions include:

- Capabilities/display/storage/system/network/audio/performance.
- SAF folder and file selection, directory listing, reads, writes, rename, delete, copy, move.
- Android DownloadManager start/list/control/open and APK installation handoff.
- Installed app discovery/launch and Android settings.
- Browser open/navigate/back/forward/reload/focus/close/bounds/desktop-UA/input.
- Phone-to-TV and TV-to-phone relays.

See `android/README.md` for the Kotlin implementation and security model.

## Browser architecture (important)

A web iframe **cannot** act as a real PC browser: YouTube and Google block embedding with CSP/X-Frame-Options, and iframes cannot own cookies/popups/downloads the way the desktop needs. KK DEX therefore has:

- **Native Android mode:** a real `WebView` (`BrowserHost`) rendered as an overlay exactly aligned to the browser window's content rectangle. It owns navigation, cookies, DOM storage, JavaScript, HTML5 media, file chooser, popups/new windows, fullscreen and downloads. Physical and phone-relayed mouse/keyboard input are routed to the page.
- **Browser-only fallback:** a clearly labelled preview iframe with an external-open escape hatch. It does not claim to make blocked sites work.

YouTube playback and Google sign-in can still fail in WebView when the device lacks required codecs/DRM or when the service rejects embedded WebViews. KK DEX surfaces those limitations rather than pretending they work.

## Included desktop applications

Files, Android Device Storage (SAF), Storage Manager, Browser, Downloads/DownloadManager, Gaming Centre, Media Player, PDF Viewer, Archive Manager, Notes, Calculator, Terminal, Developer, Gallery, Settings, This PC, App Center, Recycle Bin, KK AI (local command assistant), Phone Controller.

## Validation

See `TESTING.md` for the executed test checklist, mock-native contract tests, and unverified device areas.

## Build the Development 9 ZIP

```bash
npm ci && npm run build
(cd android && gradle assembleDebug)   # optional, produces app-debug.apk
zip -r kk-dex-desktop-os-development-9.zip . -x "node_modules/*" "android/.gradle/*" "android/build/*" "android/app/build/*" "android/.kotlin/*"
```

## Known limitations

- The Android module is unbuilt here; OEM external-display behavior, WebView codec support and installer flows require real-device testing.
- Android DownloadManager exposes no public pause/resume API. KK DEX cancels/retries and says so; it does not show fake pause controls.
- DownloadManager saves to the public `Download/KK DEX` collection. Absolute arbitrary folders require SAF and are not pretended.
- Private browsing is not supported with a single shared WebView profile.
- Camera/mic/location website permission requests are denied by the native host; Android runtime permissions and UI flows still require device-specific handling.
- Ordinary Windows `.exe` games cannot run natively. Cloud gaming or a separately installed compatibility runtime is required.
- Third-party Android activities usually launch on the phone, not the TV; the UI reports actual behavior.
- Native Python/Node/Git/pkg tools are executed only when actually installed; KK DEX ships no Linux distribution and never fakes package output.
- Multiple browser tabs share one native WebView; per-tab back stacks are approximated by stored URLs.
- Controller-to-TV input uses a BroadcastChannel in one process or the native relay in the Android host. Physical USB/Bluetooth keyboard/mouse inside the native page is handled by Android's WebView.
