# KK DEX — Development 9 Test Report

## Commands executed (this environment)

| Command | Result |
| --- | --- |
| `npm ci` | PASS (exit 0) |
| `npm run build` | PASS — `dist/index.html` 854.82 kB (gzip 238.17 kB) |
| `npx tsc --noEmit` | PASS (no type errors) |
| `node tests/dev9.test.mjs` | **41 passed, 0 failed** |
| `node qa-regression.mjs` | PASS (windows, Win+D, Start, context menus, settings) |
| `node qa-browser.mjs` | PASS (native browser bridge calls, bounds sync, app discovery) |
| `node qa-native.mjs` | PASS (storage, gaming, downloads, network settings with mock bridge) |
| `node qa-controller-native.mjs` | PASS (pointer relay, text relay, phone file transfer) |
| `gradle lint` | **BUILD SUCCESSFUL** (`LINT_EXIT=0`) |
| `gradle assembleDebug` | **BUILD SUCCESSFUL** → `app-debug.apk` (7.6 MB) |

The Android debug APK now compiles. The Kotlin errors reported from Development 8 were reproduced
and fixed in this tree (see "Kotlin fixes" below).

## Kotlin compilation fixes

The failing areas named in Development 8 (`BrowserActivity` callback/context argument types,
`DownloadController` `File`/`usableSpace` misuse) map onto this project's native classes.
Real compiler errors were obtained from Gradle and fixed one by one:

| File | Error | Fix |
| --- | --- | --- |
| `BrowserHost.kt` | `supportMultipleWindows` property invocation | `setSupportMultipleWindows(true)` |
| `BrowserHost.kt` | `doUpdateVisitedHistory` overrides nothing | Corrected `isReload: Boolean` signature |
| `BrowserHost.kt` | `KeyEvent` overload resolved to `(Long, String, Int, Int)` | Explicit 6-argument `KeyEvent(downTime, eventTime, action, code, repeat, meta)` |
| `DownloadBridge.kt` | `downloadFolder()` inside string template | `${downloadFolder()}/…` template form |
| `FullscreenController.kt` | `isSystemBarsVisible` property misuse | Simplified to `FLAG_FULLSCREEN` window state |
| `KKdexBridge.kt` | `DisplayMetrics` unresolved | Correct import `android.util.DisplayMetrics` |
| `MainActivity.kt` | `BuildConfig` unresolved (AGP 8 disables generation) | Debuggable check via `ApplicationInfo.FLAG_DEBUGGABLE` |
| `MainActivity.kt` | `Intent` unresolved | Added `android.content.Intent` import |
| `ShellSessionManager.kt` | `$PREFIX` string-template escape | Plain wording (no template reference) |
| `StorageStatsProvider.kt` | `MediaStore.Videos` unresolved | `MediaStore.Video.Media` |
| `AndroidManifest.xml` | `connectedDisplay` is not a foreground-service type | `specialUse` (real Android flag) + `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` |

## Development 9 feature tests

### Full screen — PASS
- Enabled by default: `kkdex.settings.fullscreen === true` on a fresh profile.
- Native `setFullscreen(true)` invoked on desktop start.
- Toggle in Settings → Display calls `setFullscreen(false)` and the UI reflects **DISABLED**;
  toggling back reports **ENABLED**. No "This WebView does not allow this" message remains.
- `FullscreenController` uses window/insets APIs (no WebView JavaScript), reapplies after
  `onResume()` and after external-display changes.

### Interface scaling — PASS (regression found and fixed)
- Large / Small / Minimal / Manual all apply `data-ui-scale` immediately and persist across reload.
- Manual mode exposes a 80–135 % slider.
- **Bug found by tests:** the scale effect did not re-run on scale-only changes (stale dependency
  list). Fixed; all four modes now verified live.
- Wallpaper aspect is preserved at every scale — no stretching or cropping.

### Wallpapers — PASS (12 built-in, real assets)
| Requirement | Asset |
| --- | --- |
| Modern sports cars | `wallpapers/cars-sport.jpg` |
| Luxury vehicles | `wallpapers/cars-luxury.jpg` |
| Motorcycles | `wallpapers/motorcycle.jpg` |
| Green forests | `wallpapers/forest.jpg` |
| Trees & nature | `wallpapers/trees-nature.jpg` |
| Mountains & landscape | `wallpapers/mountains.svg` (rendered vector art) |
| Sunset scenery | `wallpapers/sunset.svg` (rendered vector art) |
| Animated abstract | `anim-abstract` — animated CSS gradient field |
| Animated futuristic | `anim-future` — animated perspective grid + neon glow |
| Animated character | `anim-avatar` + `wallpapers/avatar.svg` — character art with pulsing glow |
| Extras | `aurora.jpg`, `dunes.jpg` |
Selection is previewed in Settings → Personalization, applies instantly and persists across restart
(tested: `wallpaper === "sunset"` after reload).

### Security / login — PASS
- PIN/password creation (4+ chars, confirmation required).
- Stored **only** as PBKDF2-SHA256 (210,000 iterations, 16-byte random salt); test verifies the
  stored record does not contain the plaintext secret.
- Lock screen shows clock/date, rejects a wrong PIN, unlocks with the correct one.
- Wake-from-sleep requires authentication when an account exists.
- Auto-lock preference (never/5/15/30/60 min) with idle tracking.
- Recovery is documented: `Reset desktop security` removes the local account only.

### Sleep and wake — PASS
- Sleep screen, session preserved (`windows.length` retained), animations paused.
- Wake restores the desktop and requests the PIN when security is enabled.
- Android device shutdown is never invoked.

### Terminal — PARTIAL PASS (real execution path, mocked in tests)
- Web suite verifies: session tabs, commands reaching the real process host, streamed output,
  exit codes (0 and 127), runtime detection, missing-tool errors, multi-session support.
- Native `ShellSessionManager` executes real `/system/bin/sh` processes with stdout/stderr
  streaming, exit codes, timeouts and interruption. **Not yet run on physical hardware** —
  the emulator/device step below remains.

## Not tested on physical hardware (requires phone + TV)

- Real shell process execution on an Android device (file ops, script runs, process interrupt).
- Actual `pkg`/`apt` operations, Python/Node/Git/Clang execution on a device with those runtimes.
- SAF document picker round-trips and DownloadManager network transfers.
- APK installation through Android's package installer.
- YouTube playback/login in the native WebView, Bluetooth mouse/keyboard input, external-display
  Presentation on OEM hardware, foreground-service survival during phone calls.

## Terminal capability summary (honest)

| Capability | Status |
| --- | --- |
| Real shell (`sh`) with cwd, env, stdin/stdout/stderr, exit codes | **Real** (Android process API) |
| Sessions/tabs, history, interrupt, persistence | **Real** |
| Core utilities (`ls cat mkdir cp mv rm grep find df ps env …`) | **Real** — Android toybox/applet tools; absent tools return the OS "not found" |
| `pkg` / `apt` | **Only if installed** — KK DEX never fabricates package output |
| Python / Node.js / Git / Clang / PHP / Ruby / Java | **Only if installed** — detected live and reported with version |
| Linux userland (Termux-style prefix) | **Not bundled** — a bootstrap may be installed into the app prefix, after which tools resolve from it |
| Root / arbitrary filesystem access | **Never** — sessions are confined to the app workspace and authorized SAF folders |
| Remote command execution / RPC server | **Not exposed** — no unauthenticated RCE surface exists |

## Re-verification (this session)

Environment was re-provisioned (JDK 17, Android SDK 35, Gradle 8.10.2, Chromium). Results:

| Check | Result |
| --- | --- |
| `npx tsc --noEmit` | PASS |
| `npm run build` | PASS |
| `npm test` (tests/dev9.test.mjs) | 41 passed, 0 failed |
| `qa-regression`, `qa-browser`, `qa-native`, `qa-controller-native` | all PASS, no page errors |
| `gradle assembleDebug lint` | BUILD SUCCESSFUL → `app-debug.apk` (7.6 MB) |

Build note: the first Gradle attempts were killed by memory pressure (two orphaned Kotlin compile
daemons held ~1 GB on a 2 GB host). `android/gradle.properties` now runs the Kotlin compiler
in-process and caps the Gradle heap at 1.5 GB. This is a build-host setting, not a code change.
