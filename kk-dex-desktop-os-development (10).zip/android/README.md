# KK DEX Android host

This module wraps the built KK DEX desktop bundle in an Android app:

- **Phone:** `MainActivity` hosts only the controller (`?controller=1`).
- **TV / monitor:** `DesktopPresentation` hosts the desktop (`?desktop=1`) on a secondary display.
- **Native browser:** `BrowserHost` places a real WebView above the desktop and aligns it to the React browser window content rectangle. It handles cookies, DOM storage, media, file chooser, popups, fullscreen and downloads.
- **Storage:** `FileAccessManager` (SAF) and `StorageStatsProvider` (StatFs/MediaStore/package sizes).
- **Downloads:** `DownloadBridge` uses DownloadManager and stages APKs with FileProvider for Android's installer.
- **System:** `SystemBridge` reports connectivity, opens Wi-Fi/Bluetooth/display/install settings, and controls AudioManager media volume.
- **Terminal:** `ShellSessionManager` runs real `/system/bin/sh` processes with streaming, exit codes, interruption and live runtime detection inside the app sandbox.
- **Full screen:** `FullscreenController` applies native immersive window flags and restores them on resume/display changes.
- **Persistent session:** `DisplaySessionService` is a `specialUse` foreground service that keeps the external-display desktop running while the phone is used.
- **Bridge:** `KKdexBridge` is added as `window.KKDexNative` only to trusted bundled pages loaded through `WebViewAssetLoader`.

## Terminal security model

Shell sessions are confined to the application workspace (`filesDir`, cache and app external files).
There is no root, no arbitrary filesystem access and no remote command service. `pkg`/`apt` and
language runtimes are executed only when genuinely present on the device; if absent, the operating
system error is shown. A Termux-compatible bootstrap can be installed into the app `usr` prefix to
unlock package management — nothing is simulated until it is really installed.

> **Build status (Development 9):** `gradle assembleDebug` and `gradle lint` both complete successfully in this environment (JDK 17, Android SDK 35, Gradle 8.10.2), producing `android/app/build/outputs/apk/debug/app-debug.apk`. The APK has **not** been installed or exercised on a physical phone/TV, so device-only behaviour (external display, SAF pickers, WebView media, Bluetooth input, foreground-service lifetime) still requires hardware testing.

## Build the web bundle first

From the repository root:

```bash
npm ci
npm run build
```

The Gradle task `syncDesktopAssets` copies `dist/index.html`, `dist/wallpapers`, and `dist/gallery` into `android/app/src/main/assets/` before the Android build.

## Build the APK

From `android/` using Gradle 8.10.2 and JDK 17:

```bash
gradle assembleDebug
```

Or push to GitHub / run **Build KK DEX debug APK** manually. The workflow uploads `android/app/build/outputs/apk/debug/app-debug.apk` as `kkdex-debug-apk`.

To install on a device:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

## Native bridge contract

The Kotlin bridge exposes the methods consumed by `src/os/native.ts`:

| Area | Methods |
| --- | --- |
| Capabilities | `getCapabilities`, `getDisplayInfo`, `requestStoragePermission` |
| SAF | `pickFiles`, `pickFolder`, `listDirectory` |
| File I/O | `readFile`, `writeFile` |
| File operations | `createFolder`, `renameFile`, `deleteFile`, `copyFile`, `moveFile` |
| Downloads | `getDownloads` |
| Android apps | `getInstalledApps`, `launchAndroidApp`, `openWith` |
| Browser | `browserOpen`, `browserNavigate`, `browserBack/Forward/Reload/Focus/Close`, `browserSetBounds`, `browserSetDesktopMode`, `browserInput`, `browserState` |
| Downloads | `startDownload`, `getNativeDownloads`, `controlDownload`, `openDownload`, `installApk`, `setDownloadFolder` |
| System | `getStorageInfo`, `getSystemStats`, `getNetworkInfo`, `getAudioInfo`, `setVolume`, `openSystemSettings`, `setPerformanceMode` |
| Relays | `relayToDesktop`, `relayToController` |
| Runtime | `exec` (reports unavailable until a verified runtime is integrated) |

Methods may return a JSON string or asynchronously call:

```js
window.KKDexNativeResult(requestId, JSON.stringify(payload))
```

The adapter supports both shapes. `pickFiles` and `pickFolder` are asynchronous because they launch Android's SAF picker.

### SAF permission flow

1. The desktop or controller calls `KKDexNative.pickFolder(requestId)`.
2. Android opens the system document-tree picker.
3. `FileAccessManager` retains the persistable read grant.
4. The selected `content://` tree URI is returned to JavaScript.
5. `listDirectory(uri)` uses `DocumentFile` and `ContentResolver` to enumerate only that authorized tree.
6. Reads use `ContentResolver.openInputStream`; writes require a write grant from the provider.

The bridge never opens arbitrary filesystem paths and does not expose `MANAGE_EXTERNAL_STORAGE`.

## Android app discovery and launch

`getInstalledApps()` queries launcher activities through PackageManager. Manifest `<queries>` is declared for Android 11+ visibility.

`launchAndroidApp(packageName)` uses the package's launch intent and reports:

- the app was launched on the **phone**, with an explanation;
- or a clear error if Android has no launch activity.

Most consumer Android devices do not run arbitrary third-party activities on secondary displays. KK DEX therefore does not claim that an Android app is running on the TV when Android launched it on the phone. Vendor desktop modes may offer additional support but require device-specific integration.

## Runtime execution

No Python, Node.js, Git, or shell runtime is bundled. `exec()` returns a clear unsupported error and `getCapabilities()` reports those runtimes as false. The desktop Developer app always provides real JavaScript execution in an isolated Web Worker.

Do not enable `exec()` by forwarding arbitrary commands from an unprivileged origin. If a runtime is added later, run it in an app-private directory, validate command ownership, enforce timeouts and quotas, and never expose a generic shell to remote content.

## Known integration gaps

- External-display behavior varies by OEM. Test `Presentation` on the target phone + TV with Android's `dumpsys display`.
- MediaStore download queries can be restricted by Android/OEM policy; SAF remains the reliable user-authorized path.
- The phone controller and TV desktop are separate WebViews. Pointer/keyboard input currently uses the existing `KKDexAPI` / BroadcastChannel path; on separate processes, the Android host must forward those events or enable a same-process WebView configuration.
- There is no background service, boot persistence, APK auto-update, or signing configuration in this starter.
- The controller's Android file picker UI is not yet wired to transfer selected files into the desktop WebView. The desktop Files app has the working SAF import flow.
- Web browser embedding depends on site CSP/X-Frame-Options; the desktop offers external opening when embedding is blocked.
- No real hardware or emulator build has been executed here.
