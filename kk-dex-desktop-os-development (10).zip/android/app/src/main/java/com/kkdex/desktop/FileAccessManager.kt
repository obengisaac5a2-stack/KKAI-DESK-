package com.kkdex.desktop

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

/**
 * SAF-backed file operations. Every operation works only on a content URI that the
 * user selected. Persistable read/write grants are retained for future sessions.
 */
class FileAccessManager(private val activity: ComponentActivity) {
    private var pendingCompletion: ((JSONObject) -> Unit)? = null
    private var folderMode = false
    private var multipleMode = false
    private var webFileCallback: android.webkit.ValueCallback<Array<Uri>>? = null

    private val launcher: ActivityResultLauncher<Intent> =
        activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val webCallback = webFileCallback
            if (webCallback != null) {
                webFileCallback = null
                if (result.resultCode != Activity.RESULT_OK || result.data == null) {
                    webCallback.onReceiveValue(null)
                    return@registerForActivityResult
                }
                val data = result.data!!
                val uris = mutableListOf<Uri>()
                data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
                data.data?.let { uris.add(it) }
                webCallback.onReceiveValue(uris.takeIf { it.isNotEmpty() }?.toTypedArray())
                return@registerForActivityResult
            }
            val completion = pendingCompletion
            pendingCompletion = null
            if (result.resultCode != Activity.RESULT_OK) {
                completion?.invoke(JSONObject().put("ok", true).put("cancelled", true).put("files", JSONArray()))
                return@registerForActivityResult
            }
            val intent = result.data
            if (intent == null) {
                completion?.invoke(JSONObject().put("ok", false).put("error", "Android returned no document selection."))
                return@registerForActivityResult
            }
            runCatching {
                val flags = intent.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                val uri = intent.data
                if (folderMode) {
                    uri ?: throw IllegalStateException("Android returned an empty tree URI.")
                    try {
                        activity.contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: SecurityException) {
                        // Read access can still be granted for this session without persistence.
                    }
                    completion?.invoke(
                        JSONObject().put("ok", true)
                            .put("uri", uri.toString())
                            .put("name", displayName(uri)),
                    )
                } else {
                    val clip = intent.clipData
                    val uris = mutableListOf<Uri>()
                    if (clip != null) {
                        for (index in 0 until clip.itemCount) uris.add(clip.getItemAt(index).uri)
                    } else if (uri != null) {
                        uris.add(uri)
                    }
                    val files = JSONArray()
                    uris.take(if (multipleMode) 50 else 1).forEach { selected ->
                        try {
                            activity.contentResolver.takePersistableUriPermission(selected, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        } catch (_: SecurityException) {
                            // Provider may not offer persistable grants.
                        }
                        files.put(fileJson(selected))
                    }
                    completion?.invoke(JSONObject().put("ok", true).put("files", files))
                }
            }.onFailure {
                completion?.invoke(JSONObject().put("ok", false).put("error", it.message ?: "The SAF result could not be processed."))
            }
        }

    fun pickFiles(mime: String, multiple: Boolean, requestId: String, completion: (JSONObject) -> Unit) {
        if (pendingCompletion != null) {
            completion(JSONObject().put("ok", false).put("error", "Another Android picker is already open."))
            return
        }
        pendingCompletion = completion
        folderMode = false
        multipleMode = multiple
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        activity.runOnUiThread { launcher.launch(intent) }
    }

    fun pickFolder(requestId: String, completion: (JSONObject) -> Unit) {
        if (pendingCompletion != null) {
            completion(JSONObject().put("ok", false).put("error", "Another Android picker is already open."))
            return
        }
        pendingCompletion = completion
        folderMode = true
        multipleMode = false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }
        activity.runOnUiThread { launcher.launch(intent) }
    }

    fun pickForWeb(acceptTypes: String, callback: android.webkit.ValueCallback<Array<Uri>>?) {
        if (callback == null) return
        if (webFileCallback != null) {
            callback.onReceiveValue(null)
            return
        }
        webFileCallback = callback
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = when {
                acceptTypes.contains("image") -> "image/*"
                acceptTypes.contains("video") -> "video/*"
                acceptTypes.contains("audio") -> "audio/*"
                acceptTypes.contains("pdf") -> "application/pdf"
                else -> "*/*"
            }
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        activity.runOnUiThread { launcher.launch(intent) }
    }

    fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index)?.let { return it }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Android item"
    }

    fun listDirectory(uri: Uri): JSONArray {
        val tree = DocumentFile.fromTreeUri(activity, uri)
            ?: throw IllegalStateException("This URI is not a document tree. Select the folder again with Android's folder picker.")
        if (!tree.canRead()) throw SecurityException("The folder grant is no longer valid. Authorize it again.")
        val children = JSONArray()
        tree.listFiles().sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name?.lowercase() }).forEach { child ->
            children.put(fileJson(child.uri, child.name ?: "Unnamed", child.type, child.length(), child.lastModified(), child.isDirectory))
        }
        return children
    }

    fun readBytes(uri: Uri): ByteArray =
        activity.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Android could not open this content URI for reading.")

    fun createFolder(parent: Uri, name: String): JSONObject {
        val tree = DocumentFile.fromTreeUri(activity, parent)
            ?: throw IllegalStateException("The destination is not an authorized document tree.")
        if (!tree.canWrite()) throw SecurityException("Write access was not granted for this folder.")
        val folder = tree.createDirectory(name)
            ?: throw IllegalStateException("Android refused to create “$name”. The provider may be read-only.")
        return fileJson(folder.uri, folder.name ?: name, folder.type, 0, folder.lastModified(), true)
    }

    fun rename(uri: Uri, name: String): Boolean {
        val document = DocumentFile.fromSingleUri(activity, uri)
            ?: throw IllegalStateException("This URI cannot be modified.")
        if (!document.renameTo(name)) throw IllegalStateException("This document provider refused the rename.")
        return true
    }

    fun delete(uri: Uri): Boolean {
        val document = DocumentFile.fromSingleUri(activity, uri)
            ?: return false
        return document.delete()
    }

    fun copy(source: Uri, targetParent: Uri): JSONObject {
        val parent = DocumentFile.fromTreeUri(activity, targetParent)
            ?: throw IllegalStateException("The destination folder is not authorized.")
        if (!parent.canWrite()) throw SecurityException("Write access was not granted for the destination folder.")
        val mime = activity.contentResolver.getType(source) ?: "application/octet-stream"
        val name = displayName(source)
        val created = parent.createFile(mime, name)
            ?: throw IllegalStateException("Android could not create the destination file.")
        activity.contentResolver.openOutputStream(created.uri)?.use { output ->
            activity.contentResolver.openInputStream(source)?.use { input -> input.copyTo(output) }
        } ?: throw IllegalStateException("Android could not open the destination for writing.")
        return fileJson(created.uri, created.name ?: name, created.type, created.length(), created.lastModified(), created.isDirectory)
    }

    fun move(source: Uri, targetParent: Uri): JSONObject {
        val copy = copy(source, targetParent)
        val sourceFile = DocumentFile.fromSingleUri(activity, source)
        if (sourceFile?.delete() != true) {
            throw IllegalStateException("The file was copied, but the provider refused to remove the original. Both copies may now exist.")
        }
        return copy
    }

    private fun fileJson(uri: Uri): JSONObject = fileJson(
        uri,
        displayName(uri),
        activity.contentResolver.getType(uri) ?: "application/octet-stream",
        querySize(uri),
        queryModified(uri),
        false,
    )

    private fun querySize(uri: Uri): Long = runCatching {
        activity.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index)
            }
        }
        0L
    }.getOrDefault(0L)

    private fun queryModified(uri: Uri): Long = runCatching {
        activity.contentResolver.query(uri, arrayOf(android.provider.MediaStore.MediaColumns.DATE_MODIFIED), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DATE_MODIFIED)
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index) * 1000L
            }
        }
        System.currentTimeMillis()
    }.getOrDefault(System.currentTimeMillis())

    private fun fileJson(uri: Uri, name: String, mime: String?, size: Long, modified: Long, directory: Boolean): JSONObject =
        JSONObject()
            .put("uri", uri.toString())
            .put("name", name)
            .put("mime", mime ?: if (directory) "vnd.android.document/directory" else "application/octet-stream")
            .put("size", size)
            .put("modified", modified)
            .put("isDirectory", directory)
            .put("source", "Android SAF")

}
