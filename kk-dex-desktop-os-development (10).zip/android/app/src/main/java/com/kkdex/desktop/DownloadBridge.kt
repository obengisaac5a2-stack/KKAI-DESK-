package com.kkdex.desktop

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.webkit.CookieManager
import org.json.JSONArray
import org.json.JSONObject
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/**
 * Real Android DownloadManager integration. Files are written to the public
 * Download collection; no download is kept only in memory.
 */
class DownloadBridge(private val activity: Activity) {
    private val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val prefs = activity.getSharedPreferences("kkdex_downloads", Context.MODE_PRIVATE)
    private val lastSamples = mutableMapOf<Long, Pair<Long, Long>>()

    fun downloadFolder(): String = prefs.getString("folder", "KK DEX") ?: "KK DEX"

    fun setFolder(folder: String): JSONObject {
        val clean = folder.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().trim('/').ifBlank { "KK DEX" }.take(60)
        prefs.edit().putString("folder", clean).apply()
        return JSONObject().put("ok", true).put("folder", clean)
    }

    fun start(url: String, requestedName: String, mime: String, referer: String): JSONObject {
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http")) {
            throw IllegalArgumentException("Only HTTP and HTTPS download URLs are accepted.")
        }
        val fileName = safeName(requestedName.ifBlank { uri.lastPathSegment ?: "kkdex-download" }, mime)
        val folder = downloadFolder()
        val relative = "$folder/$fileName"
        val request = DownloadManager.Request(uri).apply {
            setTitle(fileName)
            setDescription("KK DEX download")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, relative)
            setAllowedOverMetered(true)
            setAllowedOverRoaming(true)
            if (mime.isNotBlank() && mime != "application/octet-stream") setMimeType(mime)
            try {
                val cookie = CookieManager.getInstance().getCookie(url)
                if (!cookie.isNullOrBlank()) addRequestHeader("Cookie", cookie)
                if (referer.isNotBlank()) addRequestHeader("Referer", referer)
            } catch (_: Exception) {
                // Cookies/referer are optional.
            }
        }
        return try {
            val id = manager.enqueue(request)
            val records = JSONObject(prefs.getString("records", "{}") ?: "{}")
            records.put(id.toString(), JSONObject().put("url", url).put("name", fileName).put("mime", mime))
            prefs.edit().putString("records", records.toString()).apply()
            val result = queryOne(id)
            result.put("ok", true)
        } catch (error: Exception) {
            throw IllegalStateException("Android DownloadManager rejected the download: ${error.message}")
        }
    }

    fun list(): JSONArray {
        val result = JSONArray()
        val cursor = manager.query(DownloadManager.Query().setFilterByStatus(
            DownloadManager.STATUS_PENDING or DownloadManager.STATUS_RUNNING or DownloadManager.STATUS_PAUSED or DownloadManager.STATUS_SUCCESSFUL or DownloadManager.STATUS_FAILED
        ))
        cursor?.use {
            while (it.moveToNext()) {
                result.put(readRow(it))
            }
        }
        return result
    }

    fun queryOne(id: Long): JSONObject {
        manager.query(DownloadManager.Query().setFilterById(id))?.use { cursor ->
            if (cursor.moveToFirst()) return readRow(cursor)
        }
        throw IllegalArgumentException("Android has no download with id $id.")
    }

    fun cancel(id: Long): JSONObject {
        manager.remove(id)
        return JSONObject().put("ok", true).put("id", id)
    }

    fun retry(id: Long): JSONObject {
        val records = JSONObject(prefs.getString("records", "{}") ?: "{}")
        val record = records.optJSONObject(id.toString()) ?: throw IllegalStateException("The original URL for this download is not available, so it cannot be retried.")
        manager.remove(id)
        return start(record.optString("url"), record.optString("name"), record.optString("mime"), "")
    }

    fun openDownloadedFile(id: Long): JSONObject {
        val uri = manager.getUriForDownloadedFile(id) ?: throw IllegalStateException("The file is not complete, or Android no longer has this download.")
        val record = JSONObject(prefs.getString("records", "{}") ?: "{}").optJSONObject(id.toString())
        val mime = record?.optString("mime")?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
        if (mime == APK_MIME) return install(uri.toString())
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            activity.runOnUiThread { activity.startActivity(intent) }
        } catch (error: Exception) {
            throw IllegalStateException("No Android app can open this file type ($mime). ${error.message}")
        }
        return JSONObject().put("ok", true).put("opened", true)
    }

    fun install(uriString: String): JSONObject {
        if (android.os.Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).setData(Uri.parse("package:${activity.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { activity.runOnUiThread { activity.startActivity(settingsIntent) } } catch (_: Exception) { }
            return JSONObject().put("ok", false).put("opened", false)
                .put("message", "Android requires you to allow installs from KK DEX. The Unknown app sources screen was opened; enable it, then retry.")
        }
        val sourceUri = Uri.parse(uriString)
        val intent = try {
            val cacheDir = File(activity.cacheDir, "apk").apply { mkdirs() }
            val localFile = File(cacheDir, "kkdex-install-${System.currentTimeMillis()}.apk")
            activity.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(localFile).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Android could not read the selected APK.")
            val contentUri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", localFile)
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, APK_MIME)
                clipData = android.content.ClipData.newRawUri("KK DEX APK", contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } catch (error: Exception) {
            return JSONObject().put("ok", false).put("opened", false)
                .put("message", "KK DEX could not stage the APK for Android's installer: ${error.message}")
        }
        return try {
            activity.runOnUiThread { activity.startActivity(intent) }
            JSONObject().put("ok", true).put("opened", true)
        } catch (error: Exception) {
            JSONObject().put("ok", false).put("opened", false)
                .put("message", "Android could not open the package installer: ${error.message}")
        }
    }

    private fun readRow(cursor: android.database.Cursor): JSONObject {
        fun column(name: String): Int = cursor.getColumnIndex(name)
        val id = cursor.getLong(column(DownloadManager.COLUMN_ID))
        val statusCode = cursor.getInt(column(DownloadManager.COLUMN_STATUS))
        val total = cursor.getLong(column(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)).coerceAtLeast(0)
        val downloaded = cursor.getLong(column(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)).coerceAtLeast(0)
        val status = when (statusCode) {
            DownloadManager.STATUS_PENDING -> "pending"
            DownloadManager.STATUS_RUNNING -> "running"
            DownloadManager.STATUS_PAUSED -> "paused"
            DownloadManager.STATUS_SUCCESSFUL -> "successful"
            else -> "failed"
        }
        val now = System.currentTimeMillis()
        val last = lastSamples[id]
        var speed = 0L
        if (last != null && now > last.first) {
            speed = ((downloaded - last.second).coerceAtLeast(0) * 1000L) / (now - last.first)
        }
        lastSamples[id] = now to downloaded
        val reasonText = when (statusCode) {
            DownloadManager.STATUS_FAILED -> "Android download failed (reason code ${cursor.getInt(column(DownloadManager.COLUMN_REASON))})"
            DownloadManager.STATUS_PAUSED -> "Download paused by Android (reason code ${cursor.getInt(column(DownloadManager.COLUMN_REASON))})"
            else -> null
        }
        val local = if (status == "successful") manager.getUriForDownloadedFile(id)?.toString() else null
        val destination = "${downloadFolder()}/${cursor.getString(column(DownloadManager.COLUMN_TITLE)) ?: "Download"}"
        return JSONObject().apply {
            put("id", id)
            put("uri", local ?: "")
            put("localUri", local ?: "")
            put("name", cursor.getString(column(DownloadManager.COLUMN_TITLE)) ?: "Download")
            put("mime", cursor.getString(column(DownloadManager.COLUMN_MEDIA_TYPE)) ?: "application/octet-stream")
            put("status", status)
            put("bytesDownloaded", downloaded)
            put("totalBytes", total)
            put("progress", if (total > 0) ((downloaded * 100) / total).coerceIn(0, 100).toInt() else 0)
            put("speedBytesPerSecond", speed)
            if (reasonText != null) put("reason", reasonText)
            put("destination", destination)
        }
    }

    private fun safeName(input: String, mime: String): String {
        var name = input.substringAfterLast('/').replace(Regex("[^A-Za-z0-9 ._-]"), "_").trim().ifBlank { "kkdex-download" }
        if (name.length > 90) {
            val ext = name.substringAfterLast('.', "")
            val base = name.substringBeforeLast('.', name).take(80)
            name = if (ext.isNotEmpty()) "$base.$ext" else base
        }
        if (!name.contains('.')) {
            val extension = when {
                mime.contains("apk") -> "apk"
                mime.contains("zip") -> "zip"
                mime.startsWith("image/") -> mime.substringAfter('/').substringBefore('+')
                mime.startsWith("audio/") -> "mp3"
                mime.startsWith("video/") -> "mp4"
                mime.contains("pdf") -> "pdf"
                else -> ""
            }
            if (extension.isNotEmpty()) name += ".$extension"
        }
        val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), downloadFolder())
        var candidate = name
        var index = 2
        val base = name.substringBeforeLast('.', name)
        val extension = name.substringAfterLast('.', "")
        while (File(folder, candidate).exists()) {
            candidate = if (extension.isNotEmpty()) "$base ($index).$extension" else "$base ($index)"
            index += 1
        }
        return candidate
    }

    companion object {
        const val APK_MIME = "application/vnd.android.package-archive"
    }
}
