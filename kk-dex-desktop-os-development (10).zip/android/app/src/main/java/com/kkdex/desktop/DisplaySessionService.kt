package com.kkdex.desktop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * Keeps the external-display session alive while the phone controller activity is
 * backgrounded (phone calls, other apps, locked screen).
 *
 * The service owns no UI: [MainActivity] attaches the Presentation and detaches
 * it on destruction. Android may still stop the process under memory pressure;
 * KK DEX never claims behaviour Android does not guarantee.
 */
class DisplaySessionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "KK DEX external display",
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = "Keeps the KK DEX desktop running on the TV" }
            manager.createNotificationChannel(channel)
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
            .setContentTitle("KK DEX desktop is running")
            .setContentText("The TV desktop stays active while you use your phone.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    companion object {
        const val CHANNEL_ID = "kkdex_display_session"
        const val NOTIFICATION_ID = 42
    }
}
