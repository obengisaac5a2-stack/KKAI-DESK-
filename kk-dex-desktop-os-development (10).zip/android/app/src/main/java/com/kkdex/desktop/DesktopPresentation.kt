package com.kkdex.desktop

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import org.json.JSONObject

/**
 * The actual TV/monitor desktop. The desktop WebView and the native browser overlay
 * share one trusted bridge. The phone controller remains in MainActivity.
 */
class DesktopPresentation(
    outerContext: Context,
    display: Display,
    private val hostActivity: android.app.Activity,
    private val fileAccess: FileAccessManager,
    private val downloads: DownloadBridge,
    private val systemBridge: SystemBridge,
    private val storageStats: StorageStatsProvider,
    private val shell: ShellSessionManager,
) : Presentation(outerContext, display) {

    private var webView: WebView? = null
    private var browserHost: BrowserHost? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(context)
        val view = WebView(context)
        webView = view
        view.setBackgroundColor(Color.parseColor("#070C15"))
        view.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(view)
        val browser = BrowserHost(hostActivity, root, { webView }, downloads, fileAccess)
        browserHost = browser
        setupWebView(view, browser)
        setContentView(root)
        DesktopRelay.attach { json ->
            Handler(Looper.getMainLooper()).post {
                val script = "window.KKDexHostMessage && window.KKDexHostMessage(${JSONObject.quote(json)});"
                webView?.evaluateJavascript(script, null)
            }
            true
        }
        TerminalRelay.attach { json ->
            Handler(Looper.getMainLooper()).post {
                val script = "window.KKDexTerminalEvent && window.KKDexTerminalEvent(${JSONObject.quote(json)});"
                webView?.evaluateJavascript(script, null)
            }
            true
        }
        FullscreenController.apply(hostActivity, this, true)
        view.loadUrl("$ASSET_ORIGIN/assets/index.html?desktop=1")
    }

    private fun setupWebView(view: WebView, browser: BrowserHost) {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            databaseEnabled = false
        }
        view.addJavascriptInterface(
            KKdexBridge(
                hostActivity,
                { webView },
                fileAccess,
                "desktop",
                browserHost = browser,
                downloads = downloads,
                systemBridge = systemBridge,
                storageStats = storageStats,
                shell = shell,
                presentationProvider = { this@DesktopPresentation },
                externalDisplayProvider = { display },
            ),
            "KKDexNative",
        )
        view.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return !(url.host == "appassets.androidplatform.net" || url.scheme == "https" || url.scheme == "http")
            }
        }
    }

    override fun dismiss() {
        Handler(Looper.getMainLooper()).post {
            DesktopRelay.detach()
            browserHost?.destroy()
            browserHost = null
            webView?.loadUrl("about:blank")
            webView?.removeAllViews()
            webView?.destroy()
            webView = null
        }
        FullscreenController.restore(hostActivity, null, true)
        super.dismiss()
    }

    companion object {
        const val ASSET_ORIGIN = "https://appassets.androidplatform.net"
    }
}
