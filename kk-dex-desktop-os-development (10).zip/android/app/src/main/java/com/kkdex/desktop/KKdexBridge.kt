package com.kkdex.desktop

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.util.DisplayMetrics
import android.view.Display
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Trusted native bridge for the bundled KK DEX pages only.
 *
 * Security notes:
 *  - This object is added only to WebViews that load the bundled asset origin.
 *  - Content is read only through URIs the user explicitly granted with SAF.
 *  - Arbitrary filesystem paths and unrestricted shell execution are not exposed.
 *  - Runtime execution is reported as unavailable unless the host integrates a real runtime.
 */
class KKdexBridge(
    private val activity: Activity,
    private val webViewProvider: () -> WebView?,
    private val fileAccess: FileAccessManager,
    private val role: String,
    private val browserHost: BrowserHost? = null,
    private val downloads: DownloadBridge? = null,
    private val systemBridge: SystemBridge? = null,
    private val storageStats: StorageStatsProvider? = null,
    private val shell: ShellSessionManager? = null,
    private val presentationProvider: (() -> android.app.Presentation?)? = null,
    private val externalDisplayProvider: (() -> Display?)? = null,
) {
    private val main = Handler(Looper.getMainLooper())

    private fun emit(requestId: String?, payload: JSONObject) {
        if (requestId.isNullOrBlank()) return
        val json = JSONObject(payload.toString()).toString()
        val script = "window.KKDexNativeResult && window.KKDexNativeResult(${JSONObject.quote(requestId)}, $json);"
        main.post {
            webViewProvider()?.evaluateJavascript(script, null)
        }
    }

    private fun error(requestId: String?, message: String) {
        emit(requestId, JSONObject().put("ok", false).put("error", message))
    }

    private fun fileJson(uri: Uri, name: String, mime: String, size: Long, modified: Long, directory: Boolean): JSONObject =
        JSONObject()
            .put("uri", uri.toString())
            .put("name", name)
            .put("mime", mime)
            .put("size", size)
            .put("modified", modified)
            .put("isDirectory", directory)
            .put("source", "Android SAF")

    @JavascriptInterface
    fun getCapabilities(requestId: String?): String = JSONObject().apply {
        put("bridge", "KKDexNative")
        put("platform", "${Build.MANUFACTURER} ${Build.MODEL}")
        put("sdkInt", Build.VERSION.SDK_INT)
        put("storageAccessFramework", true)
        put("mediaStore", true)
        put("installedApps", true)
        put("appLaunch", true)
        put("externalDisplay", externalDisplayProvider?.invoke() != null)
        put("downloads", downloads != null)
        put("writeAccess", true)
        put("browser", browserHost != null)
        put("storageStats", storageStats != null)
        put("downloadManager", downloads != null)
        put("apkInstall", downloads != null)
        put("systemControls", systemBridge != null)
        put("gameDiscovery", true)
        put("performanceModes", systemBridge != null)
        put("shellExecution", shell != null)
        put("terminal", shell != null)
        put("downloadLocation", downloads?.downloadFolder() ?: "Download/KK DEX")
        // Language runtimes are detected live by ShellSessionManager.runtimeInfo().
        put("python", false)
        put("node", false)
        put("git", false)
    }.toString()

    @JavascriptInterface
    fun getDisplayInfo(requestId: String?): String = JSONObject().apply {
        val display = externalDisplayProvider?.invoke()
        val metrics = activity.resources.displayMetrics
        if (display != null) {
            val displayMetrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            display.getRealMetrics(displayMetrics)
            put("width", displayMetrics.widthPixels)
            put("height", displayMetrics.heightPixels)
            put("density", displayMetrics.density)
        } else {
            put("width", metrics.widthPixels)
            put("height", metrics.heightPixels)
            put("density", metrics.density)
        }
        put("refreshRate", display?.refreshRate ?: 60.0)
        put("role", role)
        put("externalDisplay", display?.displayId ?: 0)
    }.toString()

    @JavascriptInterface
    fun requestStoragePermission(typesJson: String?, requestId: String?): Boolean = runCatching {
        val host = activity as? MainActivity
            ?: throw IllegalStateException("Runtime permission requests must originate from MainActivity.")
        host.requestMediaPermissions()
        emit(
            requestId,
            JSONObject().put("ok", true).put("requested", typesJson ?: "images,video,audio,documents")
                .put("note", "Android's permission dialog is host-controlled. File access still requires a SAF selection."),
        )
        true
    }.getOrElse {
        error(requestId, it.message ?: "Unable to request Android permissions.")
        false
    }

    @JavascriptInterface
    fun pickFiles(mime: String?, multiple: Boolean, requestId: String?) {
        fileAccess.pickFiles(mime ?: "*/*", multiple, requestId ?: "") { payload -> emit(requestId, payload) }
    }

    @JavascriptInterface
    fun pickFolder(requestId: String?) {
        fileAccess.pickFolder(requestId ?: "") { payload -> emit(requestId, payload) }
    }

    @JavascriptInterface
    fun listDirectory(uriString: String?, requestId: String): String = runCatching {
        val uri = Uri.parse(uriString ?: throw IllegalArgumentException("A content URI is required."))
        val files = fileAccess.listDirectory(uri)
        JSONObject().put("ok", true).put("uri", uri.toString()).put("name", fileAccess.displayName(uri)).put("files", files).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Unable to list the authorized folder.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun readFile(uriString: String?, requestId: String): String = runCatching {
        val uri = Uri.parse(uriString ?: throw IllegalArgumentException("A content URI is required."))
        val bytes = fileAccess.readBytes(uri)
        if (bytes.size > MAX_READ_BYTES) throw IllegalStateException("The file exceeds the ${MAX_READ_BYTES / 1024 / 1024} MB bridge read limit.")
        val mime = activity.contentResolver.getType(uri) ?: "application/octet-stream"
        val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
        JSONObject().put("ok", true).put("content", encoded).put("encoding", "base64").put("mime", mime).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Unable to read this Android file.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun writeFile(uriString: String?, content: String?, encoding: String?, requestId: String?): Boolean = runCatching {
        val uri = Uri.parse(uriString ?: throw IllegalArgumentException("A content URI is required."))
        val bytes = if (encoding == "base64") {
            Base64.decode(content ?: "", Base64.DEFAULT)
        } else {
            (content ?: "").toByteArray(Charsets.UTF_8)
        }
        activity.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
            ?: throw IllegalStateException("Android refused to open this document for writing.")
        emit(requestId, JSONObject().put("ok", true))
        true
    }.getOrElse {
        error(requestId, it.message ?: "Unable to write this Android file.")
        false
    }

    @JavascriptInterface
    fun createFolder(parentUri: String?, name: String?, requestId: String): String = runCatching {
        val parent = Uri.parse(parentUri ?: throw IllegalArgumentException("A parent content URI is required."))
        val clean = (name ?: "").trim().ifBlank { throw IllegalArgumentException("A folder name is required.") }
        val created = fileAccess.createFolder(parent, clean)
        val payload = JSONObject().put("ok", true).put("file", created)
        emit(requestId, payload)
        payload.toString()
    }.getOrElse {
        error(requestId, it.message ?: "Unable to create the folder.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun renameFile(uriString: String?, name: String?, requestId: String?): Boolean = runCatching {
        val uri = Uri.parse(uriString ?: throw IllegalArgumentException("A content URI is required."))
        val clean = (name ?: "").trim().ifBlank { throw IllegalArgumentException("A new name is required.") }
        fileAccess.rename(uri, clean)
        emit(requestId, JSONObject().put("ok", true))
        true
    }.getOrElse {
        error(requestId, it.message ?: "This document provider does not permit renaming.")
        false
    }

    @JavascriptInterface
    fun deleteFile(uriString: String?, requestId: String?): Boolean = runCatching {
        val uri = Uri.parse(uriString ?: throw IllegalArgumentException("A content URI is required."))
        val deleted = fileAccess.delete(uri)
        if (!deleted) throw IllegalStateException("This document provider refused deletion.")
        emit(requestId, JSONObject().put("ok", true))
        true
    }.getOrElse {
        error(requestId, it.message ?: "Unable to delete this Android file.")
        false
    }

    @JavascriptInterface
    fun copyFile(uriString: String?, targetParentUri: String?, requestId: String?): String = runCatching {
        val source = Uri.parse(uriString ?: throw IllegalArgumentException("A source content URI is required."))
        val parent = Uri.parse(targetParentUri ?: throw IllegalArgumentException("A destination content URI is required."))
        val copied = fileAccess.copy(source, parent)
        emit(requestId, JSONObject().put("ok", true).put("file", copied))
        JSONObject().put("ok", true).put("file", copied).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Unable to copy this Android file.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun moveFile(uriString: String?, targetParentUri: String?, requestId: String?): String = runCatching {
        val source = Uri.parse(uriString ?: throw IllegalArgumentException("A source content URI is required."))
        val parent = Uri.parse(targetParentUri ?: throw IllegalArgumentException("A destination content URI is required."))
        val moved = fileAccess.move(source, parent)
        emit(requestId, JSONObject().put("ok", true).put("file", moved))
        JSONObject().put("ok", true).put("file", moved).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Unable to move this Android file.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun importMedia(requestId: String?) {
        runCatching {
            val intent = Intent(MediaStore.ACTION_PICK_IMAGES).apply {
                putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 50)
            }
            activity.runOnUiThread { activity.startActivity(intent) }
            emit(requestId, JSONObject().put("ok", true).put("note", "Android's visual media picker opened on the phone."))
        }.onFailure {
            error(requestId, "Android's media picker could not be opened: ${it.message}")
        }
    }



    @JavascriptInterface
    fun getDownloads(requestId: String?): String = runCatching {
        val files = JSONArray()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            activity.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.MIME_TYPE, MediaStore.Downloads.SIZE, MediaStore.Downloads.DATE_MODIFIED),
                null,
                null,
                "${MediaStore.Downloads.DATE_MODIFIED} DESC",
            )?.use { cursor ->
                while (cursor.moveToNext() && files.length() < 300) {
                    val id = cursor.getLong(0)
                    val uri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id.toString())
                    files.put(
                        fileJson(
                            uri,
                            cursor.getString(1) ?: "Download",
                            cursor.getString(2) ?: "application/octet-stream",
                            cursor.getLong(3),
                            cursor.getLong(4) * 1000L,
                            false,
                        ),
                    )
                }
            }
        }
        JSONObject().put("ok", true).put("files", files).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Download access was denied. Grant the required Android permission or use SAF.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun getInstalledApps(requestId: String?): String = runCatching {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launcherApps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            activity.packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            activity.packageManager.queryIntentActivities(intent, 0)
        }
        val seen = HashSet<String>()
        val apps = JSONArray()
        launcherApps.forEach { info ->
            val pkg = info.activityInfo.packageName
            if (seen.add(pkg) && pkg != activity.packageName) {
                apps.put(
                    JSONObject()
                        .put("packageName", pkg)
                        .put("label", info.loadLabel(activity.packageManager).toString())
                        .put("icon", drawableToBase64(info.loadIcon(activity.packageManager)))
                        .put("isGame", (info.activityInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_IS_GAME) != 0)
                        .put("versionName", runCatching { activity.packageManager.getPackageInfo(pkg, 0).versionName }.getOrNull())
                        .put("size", runCatching { java.io.File(info.activityInfo.applicationInfo.sourceDir).length() }.getOrDefault(0L))
                        .put("installedAt", runCatching { activity.packageManager.getPackageInfo(pkg, 0).firstInstallTime }.getOrDefault(0L)),
                )
            }
        }
        JSONObject().put("ok", true).put("apps", apps).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Android package discovery failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun launchAndroidApp(packageName: String?, requestId: String?): String = runCatching {
        val target = (packageName ?: "").trim().ifBlank { throw IllegalArgumentException("A package name is required.") }
        val launch = activity.packageManager.getLaunchIntentForPackage(target)
            ?: throw IllegalStateException("Android reports no launch activity for $target.")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.runOnUiThread { activity.startActivity(launch) }
        emit(requestId, JSONObject().put("ok", true))
        JSONObject()
            .put("ok", true)
            .put("launched", true)
            .put("display", "phone")
            .put("message", "Android launched this application on the phone. The external display cannot host arbitrary third-party activities on devices without a vendor desktop mode.")
            .toString()
    }.getOrElse {
        error(requestId, it.message ?: "Android could not launch this application.")
        JSONObject().put("ok", false).put("launched", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun openWith(uriString: String?, mime: String?, requestId: String?): String = runCatching {
        val uri = Uri.parse(uriString ?: throw IllegalArgumentException("A content URI is required."))
        val resolvedMime = mime?.takeIf { it.isNotBlank() } ?: activity.contentResolver.getType(uri) ?: "*/*"
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, resolvedMime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        activity.runOnUiThread { activity.startActivity(view) }
        emit(requestId, JSONObject().put("ok", true).put("opened", true))
        JSONObject().put("ok", true).put("opened", true).toString()
    }.getOrElse {
        error(requestId, it.message ?: "No Android application accepted this file.")
        JSONObject().put("ok", false).put("opened", false).put("error", it.message).toString()
    }

    /** Native execution is intentionally unavailable until a real sandbox runtime is integrated. */
    @JavascriptInterface
    fun exec(command: String?, runtime: String?, requestId: String?): String {
        error(requestId, "KK DEX has no verified $runtime runtime installed. The host refuses to simulate command execution. JavaScript execution remains available in the Developer app.")
        return JSONObject().put("ok", false).put("exitCode", 127).put("error", "No verified native runtime is installed.").toString()
    }

    @JavascriptInterface
    fun getStorageInfo(requestId: String?): String = runCatching {
        val provider = storageStats ?: throw IllegalStateException("Storage statistics are not available in this controller WebView.")
        provider.storageInfo().toString()
    }.getOrElse {
        error(requestId, it.message ?: "Android storage statistics failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun getSystemStats(requestId: String?): String = runCatching {
        val provider = storageStats ?: throw IllegalStateException("System statistics are unavailable.")
        val display = externalDisplayProvider?.invoke()
        val metrics = DisplayMetrics()
        val width: Int
        val height: Int
        val density: Float
        val refresh: Float
        val rates: List<Float>
        if (display != null) {
            @Suppress("DEPRECATION")
            display.getRealMetrics(metrics)
            width = metrics.widthPixels
            height = metrics.heightPixels
            density = metrics.density
            refresh = display.refreshRate
            rates = display.supportedModes.map { it.refreshRate }
        } else {
            val displayMetrics = activity.resources.displayMetrics
            width = displayMetrics.widthPixels
            height = displayMetrics.heightPixels
            density = displayMetrics.density
            @Suppress("DEPRECATION")
            refresh = activity.windowManager.defaultDisplay.refreshRate
            rates = listOf(refresh)
        }
        val result = provider.systemStats(Triple(width, height, density), refresh, rates)
        result.put("externalDisplay", display != null)
        result.toString()
    }.getOrElse {
        error(requestId, it.message ?: "Android system statistics failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun getNetworkInfo(requestId: String?): String = runCatching {
        (systemBridge ?: throw IllegalStateException("Native network controls are unavailable.")).networkInfo().toString()
    }.getOrElse {
        error(requestId, it.message ?: "Network information failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun getAudioInfo(requestId: String?): String = runCatching {
        (systemBridge ?: throw IllegalStateException("Native audio controls are unavailable.")).audioInfo().toString()
    }.getOrElse {
        error(requestId, it.message ?: "Audio information failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun setVolume(stream: String?, volume: Int, requestId: String?): String = runCatching {
        (systemBridge ?: throw IllegalStateException("Native audio controls are unavailable.")).setVolume(stream ?: "music", volume).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Volume change failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun openSystemSettings(section: String?, requestId: String?): Boolean = runCatching {
        (systemBridge ?: throw IllegalStateException("Native system settings are unavailable.")).openSettings(section ?: "root")
        emit(requestId, JSONObject().put("ok", true))
        true
    }.getOrElse {
        error(requestId, it.message ?: "Android settings could not be opened.")
        false
    }

    @JavascriptInterface
    fun setPerformanceMode(mode: String?, requestId: String?): String = runCatching {
        (systemBridge ?: throw IllegalStateException("Native performance modes are unavailable.")).setPerformanceMode(mode ?: "balanced").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Performance mode failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun setDownloadFolder(folder: String?, requestId: String?): String = runCatching {
        (downloads ?: throw IllegalStateException("Android downloads are unavailable.")).setFolder(folder ?: "KK DEX").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Download folder could not be changed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun startDownload(url: String?, filename: String?, mime: String?, referer: String?, requestId: String?): String = runCatching {
        val bridge = downloads ?: throw IllegalStateException("Android downloads are unavailable.")
        bridge.start(url ?: throw IllegalArgumentException("A URL is required."), filename ?: "", mime ?: "application/octet-stream", referer ?: "").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Download could not be started.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun getNativeDownloads(requestId: String?): String = runCatching {
        val bridge = downloads ?: throw IllegalStateException("Android downloads are unavailable.")
        JSONObject().put("ok", true).put("downloads", bridge.list()).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Could not query Android downloads.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun controlDownload(id: Long, action: String?, requestId: String?): String = runCatching {
        val bridge = downloads ?: throw IllegalStateException("Android downloads are unavailable.")
        when (action) {
            "retry" -> bridge.retry(id)
            "cancel" -> bridge.cancel(id)
            "remove" -> { bridge.cancel(id); JSONObject().put("ok", true) }
            else -> JSONObject().put("ok", true)
        }.toString()
    }.getOrElse {
        error(requestId, it.message ?: "Download action failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun openDownload(id: Long, requestId: String?): String = runCatching {
        (downloads ?: throw IllegalStateException("Android downloads are unavailable.")).openDownloadedFile(id).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Could not open the download.")
        JSONObject().put("ok", false).put("message", it.message).toString()
    }

    @JavascriptInterface
    fun installApk(uriString: String?, requestId: String?): String = runCatching {
        val bridge = downloads ?: throw IllegalStateException("APK installation is unavailable.")
        val uri = uriString ?: throw IllegalArgumentException("An APK content URI is required.")
        val result = bridge.install(uri)
        if (result.optBoolean("opened", false)) emit(requestId, JSONObject().put("ok", true).put("opened", true))
        else emit(requestId, result.put("ok", false))
        result.toString()
    }.getOrElse {
        error(requestId, it.message ?: "Android could not open the package installer.")
        JSONObject().put("ok", false).put("message", it.message).toString()
    }

    @JavascriptInterface
    fun browserOpen(url: String?, desktopMode: Boolean, privateMode: Boolean, requestId: String?): String = runCatching {
        val browser = browserHost ?: throw IllegalStateException("The native browser is not available in this window.")
        if (privateMode) throw IllegalStateException("A truly isolated private browsing profile is not supported by this single-WebView host.")
        browser.open(url ?: "https://www.google.com", desktopMode).toString()
    }.getOrElse {
        error(requestId, it.message ?: "The native browser could not start.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun browserNavigate(url: String?, requestId: String?): String = runCatching {
        (browserHost ?: throw IllegalStateException("Native browser unavailable.")).navigate(url ?: "about:blank").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Native navigation failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun browserBack(requestId: String?): String = runCatching { (browserHost ?: throw IllegalStateException("Native browser unavailable.")).back().toString() }.getOrElse { JSONObject().put("ok", false).put("error", it.message).toString() }
    @JavascriptInterface
    fun browserForward(requestId: String?): String = runCatching { (browserHost ?: throw IllegalStateException("Native browser unavailable.")).forward().toString() }.getOrElse { JSONObject().put("ok", false).put("error", it.message).toString() }
    @JavascriptInterface
    fun browserReload(requestId: String?): String = runCatching { (browserHost ?: throw IllegalStateException("Native browser unavailable.")).reload().toString() }.getOrElse { JSONObject().put("ok", false).put("error", it.message).toString() }
    @JavascriptInterface
    fun browserFocus(requestId: String?): String = runCatching { (browserHost ?: throw IllegalStateException("Native browser unavailable.")).focus().toString() }.getOrElse { JSONObject().put("ok", false).put("error", it.message).toString() }
    @JavascriptInterface
    fun browserState(requestId: String?): String = runCatching { (browserHost ?: throw IllegalStateException("Native browser unavailable.")).state().toString() }.getOrElse { JSONObject().put("ok", false).put("error", it.message).toString() }

    @JavascriptInterface
    fun browserClose(requestId: String?): Boolean = runCatching {
        browserHost?.close()
        emit(requestId, JSONObject().put("ok", true))
        true
    }.getOrElse {
        error(requestId, it.message ?: "Native browser close failed.")
        false
    }

    @JavascriptInterface
    fun browserSetDesktopMode(enabled: Boolean, requestId: String?): String = runCatching {
        (browserHost ?: throw IllegalStateException("Native browser unavailable.")).setDesktopMode(enabled).toString()
    }.getOrElse {
        error(requestId, it.message ?: "User agent change failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun browserSetBounds(left: Int, top: Int, width: Int, height: Int, visible: Boolean, dpr: Float, requestId: String?): Boolean = runCatching {
        browserHost?.setBounds(left, top, width, height, visible, dpr)
        emit(requestId, JSONObject().put("ok", true))
        true
    }.getOrElse {
        error(requestId, it.message ?: "Browser bounds failed.")
        false
    }

    @JavascriptInterface
    fun browserInput(action: String?, x: Int, y: Int, value: String?, requestId: String?): String = runCatching {
        (browserHost ?: throw IllegalStateException("Native browser unavailable.")).input(action ?: "", x, y, value ?: "").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Browser input failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun setFullscreen(enabled: Boolean, requestId: String?): Boolean = runCatching {
        FullscreenController.apply(activity, presentationProvider?.invoke(), enabled)
        emit(requestId, JSONObject().put("ok", true).put("enabled", enabled))
        true
    }.getOrElse {
        error(requestId, it.message ?: "Full-screen control failed.")
        false
    }

    @JavascriptInterface
    fun terminalStart(cwd: String?, requestId: String?): String = runCatching {
        val manager = shell ?: throw IllegalStateException("The KK DEX Terminal process host is not available in this window.")
        manager.start("main", cwd ?: "").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Terminal session could not start.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun terminalExec(sessionId: String?, command: String?, requestId: String?): String {
        val manager = shell
        if (manager == null) {
            error(requestId, "The KK DEX Terminal process host is not available in this window.")
            return JSONObject().put("ok", false).put("error", "no process host").toString()
        }
        val session = sessionId ?: "main"
        val commandText = command ?: ""
        // Real process execution runs off the JavaScript bridge thread so that
        // streamed output and interrupt requests stay responsive.
        Thread {
            runCatching {
                val result = manager.exec(session, commandText)
                emit(requestId, result)
            }.onFailure {
                emit(requestId, JSONObject().put("ok", false).put("error", it.message ?: "Command failed."))
            }
        }.start()
        return ""
    }

    @JavascriptInterface
    fun terminalInterrupt(sessionId: String?, requestId: String?): String = runCatching {
        (shell ?: throw IllegalStateException("Terminal host unavailable.")).interrupt(sessionId ?: "main").toString()
    }.getOrElse {
        error(requestId, it.message ?: "Interrupt failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun terminalList(requestId: String?): String = runCatching {
        val manager = shell ?: throw IllegalStateException("Terminal host unavailable.")
        JSONObject().put("ok", true).put("sessions", manager.list()).toString()
    }.getOrElse {
        error(requestId, it.message ?: "Session listing failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun runtimeInfo(requestId: String?): String = runCatching {
        (shell ?: throw IllegalStateException("Terminal host unavailable.")).runtimeInfo().toString()
    }.getOrElse {
        error(requestId, it.message ?: "Runtime detection failed.")
        JSONObject().put("ok", false).put("error", it.message).toString()
    }

    @JavascriptInterface
    fun relayToController(messageJson: String?, requestId: String?): Boolean = runCatching {
        val delivered = PhoneRelay.send(messageJson ?: "")
        emit(requestId, JSONObject().put("ok", delivered))
        delivered
    }.getOrElse {
        error(requestId, it.message ?: "The phone relay is unavailable.")
        false
    }

    @JavascriptInterface
    fun relayToDesktop(messageJson: String?, requestId: String?): Boolean = runCatching {
        val delivered = DesktopRelay.send(messageJson ?: "")
        emit(requestId, JSONObject().put("ok", delivered))
        delivered
    }.getOrElse {
        error(requestId, it.message ?: "The desktop relay is unavailable.")
        false
    }

    private fun drawableToBase64(drawable: android.graphics.drawable.Drawable): String? = runCatching {
        val width = 96
        val height = 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, width, height)
        drawable.draw(canvas)
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream)
        "data:image/png;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }.getOrNull()

    companion object {
        private const val MAX_READ_BYTES = 64L * 1024L * 1024L
    }

}
