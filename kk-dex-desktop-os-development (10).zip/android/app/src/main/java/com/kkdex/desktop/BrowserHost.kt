package com.kkdex.desktop

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject

/** Relays messages from the phone controller WebView to the desktop WebView. */
object DesktopRelay {
    private var listener: ((String) -> Boolean)? = null
    fun attach(block: (String) -> Boolean) { listener = block }
    fun detach() { listener = null }
    fun send(json: String): Boolean = listener?.invoke(json) ?: false
}

/** Relays desktop state back to the phone controller WebView. */
object PhoneRelay {
    private var listener: ((String) -> Boolean)? = null
    fun attach(block: (String) -> Boolean) { listener = block }
    fun detach() { listener = null }
    fun send(json: String): Boolean = listener?.invoke(json) ?: false
}

/**
 * A real native browser surface hosted above the desktop WebView. The React browser
 * chrome positions it; WebView owns page rendering, cookies, input and downloads.
 */
@SuppressLint("SetJavaScriptEnabled")
class BrowserHost(
    private val activity: Activity,
    private val root: FrameLayout,
    private val desktopWebViewProvider: () -> WebView?,
    private val downloads: DownloadBridge,
    private val fileAccess: FileAccessManager,
) {
    private val container = FrameLayout(activity)
    private val fullscreenContainer = FrameLayout(activity)
    private var webView: WebView? = null
    private var cursorView: CursorView? = null
    private var transport: WebView? = null
    private var customView: View? = null
    private var bounds = android.graphics.Rect(0, 0, 0, 0)
    private var density = 1f
    private var visible = false
    private var desktopMode = true
    private var lastError: String? = null
    private var progress = 0
    private var pageTitle = ""
    private var pageUrl = ""
    private var pageLoading = false
    private var canBack = false
    private var canForward = false

    init {
        container.visibility = View.GONE
        container.setBackgroundColor(Color.WHITE)
        root.addView(container, FrameLayout.LayoutParams(0, 0))
        cursorView = CursorView(activity).also { cursor ->
            cursor.visibility = View.GONE
            cursor.isClickable = false
            cursor.isFocusable = false
            container.addView(cursor, FrameLayout.LayoutParams(44, 44))
        }
        fullscreenContainer.setBackgroundColor(Color.BLACK)
        fullscreenContainer.visibility = View.GONE
        root.addView(fullscreenContainer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun ensureWebView(): WebView {
        webView?.let { return it }
        val view = WebView(activity)
        webView = view
        view.setBackgroundColor(Color.WHITE)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = desktopUserAgent()
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        view.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                pageUrl = url ?: pageUrl
                lastError = null
                emitState()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageUrl = url ?: pageUrl
                emitState()
                view?.requestFocus()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    lastError = error?.description?.toString() ?: "The page could not be loaded."
                    emitState()
                }
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: android.webkit.WebResourceResponse?) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 200) >= 400) {
                    lastError = "HTTP ${errorResponse?.statusCode}: ${errorResponse?.reasonPhrase ?: "page error"}"
                    emitState()
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return true
                if (scheme == "http" || scheme == "https") return false
                return try {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                pageUrl = url ?: pageUrl
                emitState()
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress = newProgress
                emitState()
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title ?: ""
                emitState()
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?,
            ): Boolean {
                val opened = createTransport()
                (resultMsg?.obj as? WebView.WebViewTransport)?.webView = opened
                resultMsg?.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                window.destroy()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?,
            ): Boolean {
                fileAccess.pickForWeb(fileChooserParams?.acceptTypes?.joinToString(",").orEmpty(), filePathCallback)
                return true
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val resources = request.resources
                emitBrowserEvent(JSONObject().put("type", "permission").put("origin", request.origin.toString()).put("resources", resources.joinToString(",")))
                request.deny()
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) return
                customView = view
                fullscreenContainer.removeAllViews()
                fullscreenContainer.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                val exit = TextView(activity).apply {
                    text = "Exit fullscreen"
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    setBackgroundColor(Color.argb(150, 0, 0, 0))
                    setPadding(22, 12, 22, 12)
                    setOnClickListener {
                        onHideCustomView()
                    }
                }
                fullscreenContainer.addView(exit, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                    setMargins(0, 24, 24, 0)
                })
                fullscreenContainer.visibility = View.VISIBLE
                container.visibility = View.GONE
                fullscreenContainer.bringToFront()
            }

            override fun onHideCustomView() {
                fullscreenContainer.removeAllViews()
                fullscreenContainer.visibility = View.GONE
                customView = null
                if (visible) container.visibility = View.VISIBLE
                webView?.requestFocus()
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                AlertDialog.Builder(activity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }
        view.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val guessed = contentDisposition?.substringAfter("filename=", "")?.trim('"', ' ')
                val info = downloads.start(url, guessed.orEmpty(), mimeType ?: "application/octet-stream", pageUrl)
                emitBrowserEvent(JSONObject().put("type", "download").put("download", info))
            } catch (error: Exception) {
                lastError = error.message
                emitState()
            }
        }
        container.addView(view, 0, FrameLayout.LayoutParams(0, 0))
        return view
    }

    private fun createTransport(): WebView {
        val view = WebView(activity)
        transport = view
        view.settings.javaScriptEnabled = true
        view.settings.userAgentString = desktopUserAgent()
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return true
                emitBrowserEvent(JSONObject().put("type", "new-tab").put("url", url))
                container.removeView(view)
                transport = null
                view?.destroy()
                return true
            }
        }
        container.addView(view, FrameLayout.LayoutParams(1, 1))
        return view
    }

    private fun desktopUserAgent(): String =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 KK DEX/1.0"

    private fun mobileUserAgent(): String? = null

    fun open(url: String, desktopMode: Boolean): JSONObject {
        this.desktopMode = desktopMode
        pageUrl = url
        pageLoading = true
        activity.runOnUiThread {
            val view = ensureWebView()
            view.settings.userAgentString = if (desktopMode) desktopUserAgent() else mobileUserAgent()
            view.loadUrl(url)
            view.requestFocus()
        }
        return state().put("ok", true)
    }

    fun navigate(url: String): JSONObject {
        pageUrl = url
        pageLoading = true
        activity.runOnUiThread {
            val view = ensureWebView()
            view.loadUrl(url)
            view.requestFocus()
        }
        return state().put("ok", true)
    }

    fun back(): JSONObject {
        activity.runOnUiThread { webView?.let { if (it.canGoBack()) it.goBack() } }
        return state()
    }

    fun forward(): JSONObject {
        activity.runOnUiThread { webView?.let { if (it.canGoForward()) it.goForward() } }
        return state()
    }

    fun reload(): JSONObject {
        pageLoading = true
        activity.runOnUiThread { webView?.reload() }
        return state()
    }

    fun focus(): JSONObject {
        activity.runOnUiThread {
            val view = ensureWebView()
            view.requestFocus()
            view.requestFocusFromTouch()
        }
        return state()
    }

    fun close() {
        activity.runOnUiThread {
            container.visibility = View.GONE
            fullscreenContainer.visibility = View.GONE
            webView?.stopLoading()
            cursorView?.visibility = View.GONE
            webView?.clearFocus()
        }
    }

    fun destroy() {
        activity.runOnUiThread {
            container.visibility = View.GONE
            fullscreenContainer.removeAllViews()
            fullscreenContainer.visibility = View.GONE
            webView?.loadUrl("about:blank")
            webView?.removeAllViews()
            webView?.destroy()
            webView = null
            cursorView = null
        }
    }

    fun setDesktopMode(enabled: Boolean): JSONObject {
        desktopMode = enabled
        activity.runOnUiThread {
            ensureWebView().settings.userAgentString = if (enabled) desktopUserAgent() else mobileUserAgent()
            webView?.reload()
        }
        return state()
    }

    fun setBounds(left: Int, top: Int, width: Int, height: Int, show: Boolean, dpr: Float): JSONObject {
        density = if (dpr > 0f) dpr else activity.resources.displayMetrics.density
        bounds = android.graphics.Rect(left, top, left + width, top + height)
        visible = show && width > 0 && height > 0
        activity.runOnUiThread {
            val params = container.layoutParams as FrameLayout.LayoutParams
            params.leftMargin = (left * density).toInt()
            params.topMargin = (top * density).toInt()
            params.width = (width * density).toInt()
            params.height = (height * density).toInt()
            container.layoutParams = params
            container.visibility = if (visible && fullscreenContainer.visibility != View.VISIBLE) View.VISIBLE else View.GONE
            if (visible) {
                ensureWebView()
                container.bringToFront()
            }
        }
        return JSONObject().put("ok", true)
    }

    /** Safe to call from the JavaScript bridge thread: uses cached state only. */
    fun state(): JSONObject = JSONObject().apply {
        put("url", pageUrl)
        put("title", pageTitle.ifBlank { "Page" })
        put("loading", pageLoading)
        put("progress", progress)
        put("canGoBack", canBack)
        put("canGoForward", canForward)
        put("desktopMode", desktopMode)
        if (lastError != null) put("error", lastError)
    }

    fun emitState() {
        activity.runOnUiThread {
            canBack = webView?.canGoBack() == true
            canForward = webView?.canGoForward() == true
            pageUrl = webView?.url ?: pageUrl
            pageTitle = when {
                pageTitle.isNotBlank() -> pageTitle
                else -> webView?.title ?: ""
            }
            progress = webView?.progress ?: progress
            pageLoading = progress < 100
            emitBrowserEvent(JSONObject().put("type", "state").put("state", state()))
        }
    }

    private fun emitBrowserEvent(event: JSONObject) {
        val json = event.toString()
        activity.runOnUiThread {
            desktopWebViewProvider()?.evaluateJavascript(
                "window.KKDexBrowserEvent && window.KKDexBrowserEvent(${JSONObject.quote(json)});",
                null,
            )
        }
    }

    fun input(action: String, x: Int, y: Int, value: String): JSONObject {
        val localX = ((x - bounds.left) * density).toFloat()
        val localY = ((y - bounds.top) * density).toFloat()
        activity.runOnUiThread {
            val view = ensureWebView()
            view.requestFocus()
            when (action) {
                "move" -> moveCursor(localX, localY)
                "click", "doubleClick" -> {
                    tap(view, localX, localY)
                    if (action == "doubleClick") view.postDelayed({ tap(view, localX, localY) }, 90)
                }
                "rightClick" -> {
                    moveCursor(localX, localY)
                    view.performLongClick()
                }
                "scroll" -> {
                    val delta = value.toFloatOrNull()?.toInt() ?: 160
                    view.scrollBy(0, delta)
                }
                "text" -> insertText(value)
                "key" -> dispatchKey(value)
            }
        }
        return JSONObject().put("ok", true)
    }

    private fun moveCursor(x: Float, y: Float) {
        val cursor = cursorView ?: return
        cursor.translationX = x
        cursor.translationY = y
        cursor.visibility = View.VISIBLE
        cursor.invalidate()
    }

    private fun tap(view: WebView, x: Float, y: Float) {
        moveCursor(x, y)
        val now = android.os.SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0)
        val up = MotionEvent.obtain(now, now + 40, MotionEvent.ACTION_UP, x, y, 0)
        down.source = InputDevice.SOURCE_MOUSE
        up.source = InputDevice.SOURCE_MOUSE
        view.dispatchTouchEvent(down)
        view.dispatchTouchEvent(up)
        down.recycle()
        up.recycle()
    }

    private fun insertText(text: String) {
        val js = """
            (function(t){
              var el = document.activeElement;
              if (!el) return false;
              if (el.isContentEditable) { document.execCommand('insertText', false, t); return true; }
              var tag = (el.tagName || '').toLowerCase();
              if (tag === 'input' || tag === 'textarea') {
                var start = el.selectionStart == null ? el.value.length : el.selectionStart;
                var end = el.selectionEnd == null ? start : el.selectionEnd;
                el.value = el.value.substring(0, start) + t + el.value.substring(end);
                var caret = start + t.length;
                try { el.setSelectionRange(caret, caret); } catch (e) {}
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                return true;
              }
              return false;
            })(${JSONObject.quote(text)});
        """.trimIndent()
        webView?.evaluateJavascript(js, null)
    }

    private fun dispatchKey(value: String) {
        val parts = value.split("+").filter { it.isNotBlank() }
        if (parts.isEmpty()) return
        val key = parts.last()
        var meta = 0
        if (parts.contains("ctrl")) meta = meta or android.view.KeyEvent.META_CTRL_ON
        if (parts.contains("shift")) meta = meta or android.view.KeyEvent.META_SHIFT_ON
        if (parts.contains("alt")) meta = meta or android.view.KeyEvent.META_ALT_ON
        val keyCode = when (key.lowercase()) {
            "enter" -> android.view.KeyEvent.KEYCODE_ENTER
            "tab" -> android.view.KeyEvent.KEYCODE_TAB
            "escape" -> android.view.KeyEvent.KEYCODE_ESCAPE
            "backspace" -> android.view.KeyEvent.KEYCODE_DEL
            "delete" -> android.view.KeyEvent.KEYCODE_FORWARD_DEL
            "arrowup" -> android.view.KeyEvent.KEYCODE_DPAD_UP
            "arrowdown" -> android.view.KeyEvent.KEYCODE_DPAD_DOWN
            "arrowleft" -> android.view.KeyEvent.KEYCODE_DPAD_LEFT
            "arrowright" -> android.view.KeyEvent.KEYCODE_DPAD_RIGHT
            "home" -> android.view.KeyEvent.KEYCODE_MOVE_HOME
            "end" -> android.view.KeyEvent.KEYCODE_MOVE_END
            "f5" -> android.view.KeyEvent.KEYCODE_F5
            "f11" -> android.view.KeyEvent.KEYCODE_F11
            "f2" -> android.view.KeyEvent.KEYCODE_F2
            "space" -> android.view.KeyEvent.KEYCODE_SPACE
            else -> when {
                key.length == 1 && key[0].isLetter() -> android.view.KeyEvent.KEYCODE_A + (key.uppercase()[0] - 'A')
                key.length == 1 && key[0].isDigit() -> android.view.KeyEvent.KEYCODE_0 + (key[0] - '0')
                else -> 0
            }
        }
        val view = webView ?: return
        if (keyCode == 0) return
        val now = android.os.SystemClock.uptimeMillis()
        view.dispatchKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        view.dispatchKeyEvent(android.view.KeyEvent(now + 40, now + 40, android.view.KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    private class CursorView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 30, 40)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        private val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(0f, 18f)
            lineTo(5f, 13f)
            lineTo(8.5f, 21f)
            lineTo(11.5f, 19.5f)
            lineTo(8f, 12f)
            lineTo(15f, 12f)
            close()
        }

        override fun onDraw(canvas: Canvas) {
            canvas.save()
            canvas.scale(1.25f, 1.25f)
            canvas.drawPath(path, paint)
            canvas.drawPath(path, outline)
            canvas.restore()
        }
    }
}
