package com.kkdex.desktop

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File

/** Reports real device storage and best-effort MediaStore category usage. */
class StorageStatsProvider(private val context: Context) {

    fun storageInfo(): JSONObject {
        val notes = mutableListOf<String>()
        val data = Environment.getDataDirectory()
        val total: Long
        val available: Long
        try {
            val stat = StatFs(data.path)
            total = stat.totalBytes
            available = stat.availableBytes
        } catch (error: Exception) {
            throw IllegalStateException("Android could not read internal storage statistics: ${error.message}")
        }
        val used = (total - available).coerceAtLeast(0)
        val images = querySize(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, null, notes, "images")
        val videos = querySize(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, null, null, notes, "videos")
        val audio = querySize(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, notes, "audio")
        val downloads = querySize(
            MediaStore.Files.getContentUri("external"),
            "${MediaStore.Files.FileColumns.RELATIVE_PATH} LIKE ?",
            arrayOf("%Download%"),
            notes,
            "downloads",
        )
        val documents = querySize(
            MediaStore.Files.getContentUri("external"),
            "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ?",
            arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_DOCUMENT.toString()),
            notes,
            "documents",
        )
        val apk = querySize(
            MediaStore.Files.getContentUri("external"),
            "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?",
            arrayOf("%.apk"),
            notes,
            "apk",
        )
        var apps = 0L
        var games = 0L
        try {
            val packages = context.packageManager.getInstalledApplications(0)
            packages.forEach { info ->
                val size = installedSize(info)
                if (info.flags and ApplicationInfo.FLAG_IS_GAME != 0) games += size else apps += size
            }
            notes.add("Application category uses installed APK byte sizes; app-private data is not counted by Android.")
        } catch (error: Exception) {
            notes.add("Android did not permit complete application size calculation: ${error.message}")
        }
        val measured = images + videos + audio + documents + downloads + apk + apps + games
        val other = (used - measured).coerceAtLeast(0)
        notes.add("Category values come from MediaStore and installed package sizes. They may not add up to used storage because Android hides private app data.")
        var externalTotal = 0L
        var externalAvailable = 0L
        try {
            val dirs = context.getExternalFilesDirs(null)
            if (dirs.size > 1 && dirs[1] != null) {
                val stat = StatFs(dirs[1]!!.absolutePath)
                externalTotal = stat.totalBytes
                externalAvailable = stat.availableBytes
            }
        } catch (_: Exception) {
            // Optional removable volume.
        }
        return JSONObject().apply {
            put("ok", true)
            put("totalBytes", total)
            put("availableBytes", available)
            put("usedBytes", used)
            put("internalTotalBytes", total)
            put("internalAvailableBytes", available)
            put("externalTotalBytes", externalTotal)
            put("externalAvailableBytes", externalAvailable)
            put("categories", JSONObject().apply {
                put("apps", apps)
                put("images", images)
                put("videos", videos)
                put("audio", audio)
                put("documents", documents)
                put("downloads", downloads)
                put("apk", apk)
                put("games", games)
                put("other", other)
            })
            put("categoryNote", notes.distinct().joinToString(" "))
            put("downloadDir", "${Environment.getExternalStorageDirectory().absolutePath}/Download/KK DEX")
        }
    }

    fun systemStats(displayMetrics: Triple<Int, Int, Float>, refreshRate: Float, supportedRates: List<Float>): JSONObject {
        val memInfo = android.app.ActivityManager.MemoryInfo()
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(memInfo)
        val runtime = Runtime.getRuntime()
        val procTotal = readMemTotal()
        val glEs = activityManager.deviceConfigurationInfo.glEsVersion
        return JSONObject().apply {
            put("ok", true)
            put("model", android.os.Build.MODEL)
            put("manufacturer", android.os.Build.MANUFACTURER)
            put("platform", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            put("androidVersion", android.os.Build.VERSION.RELEASE)
            put("sdkInt", android.os.Build.VERSION.SDK_INT)
            put("cpuCores", Runtime.getRuntime().availableProcessors())
            put("cpuAbi", android.os.Build.SUPPORTED_ABIS.joinToString(","))
            put("totalRamBytes", if (procTotal > 0) procTotal else memInfo.totalMem)
            put("availableRamBytes", memInfo.availMem)
            put("appUsedRamBytes", runtime.totalMemory() - runtime.freeMemory())
            put("displayWidth", displayMetrics.first)
            put("displayHeight", displayMetrics.second)
            put("density", displayMetrics.third)
            put("refreshRate", refreshRate)
            put("supportedRefreshRates", org.json.JSONArray(supportedRates.distinct().sorted()))
            put("gpuRenderer", "GLES $glEs · hardware ${android.os.Build.HARDWARE}")
            put("gpuVendor", android.os.Build.HARDWARE)
            put("externalDisplay", supportedRates.isNotEmpty())
            put("uptimeMs", android.os.SystemClock.elapsedRealtime())
        }
    }

    private fun readMemTotal(): Long = try {
        File("/proc/meminfo").readLines().firstOrNull { it.startsWith("MemTotal:") }
            ?.split(Regex("\\s+"))?.getOrNull(1)?.toLongOrNull()?.times(1024) ?: 0L
    } catch (_: Exception) {
        0L
    }

    private fun installedSize(info: ApplicationInfo): Long {
        var size = 0L
        try {
            info.sourceDir?.let { size += File(it).length() }
            info.splitSourceDirs?.forEach { size += File(it).length() }
        } catch (_: Exception) {
            // Some packages can revoke path access.
        }
        return size
    }

    private fun querySize(uri: Uri, selection: String?, args: Array<String>?, notes: MutableList<String>, label: String): Long = try {
        var sum = 0L
        context.contentResolver.query(
            uri,
            arrayOf(MediaStore.Files.FileColumns.SIZE),
            selection,
            args,
            null,
        )?.use { cursor ->
            val index = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
            while (cursor.moveToNext()) {
                if (index >= 0 && !cursor.isNull(index)) sum += cursor.getLong(index)
            }
        }
        sum
    } catch (error: Exception) {
        notes.add("Unable to measure $label: ${error.message}")
        0L
    }
}
