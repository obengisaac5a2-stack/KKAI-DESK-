package com.kkdex.desktop

import android.Manifest
import android.app.Presentation
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

class MainActivity : AppCompatActivity() {
    private lateinit var controllerWebView: WebView
    private lateinit var fileAccess: FileAccessManager
    private lateinit var downloads: DownloadBridge
    private lateinit var systemBridge: SystemBridge
    private lateinit var storageStats: StorageStatsProvider
    private lateinit var shell: ShellSessionManager
    private var presentation: Presentation? = null
    private lateinit var displayManager: DisplayManager
    private var desktopInstalled = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val denied = result.filterValues { !it }.keys
        controllerWebView.evaluateJavascript(
            "window.KKDexPermissionResult && window.KKDexPermissionResult(${org.json.JSONObject.quote(denied.joinToString(","))});",
            null,
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fileAccess = FileAccessManager(this)
        downloads = DownloadBridge(this)
        systemBridge = SystemBridge(this)
        storageStats = StorageStatsProvider(this)
        shell = ShellSessionManager(this) { event -> TerminalRelay.send(event) }
        TerminalRelay.attach { json ->
            runOnUiThread {
                val script = "window.KKDexTerminalEvent && window.KKDexTerminalEvent(${org.json.JSONObject.quote(json)});"
                if (!isFinishing && !isDestroyed) controllerWebView.evaluateJavascript(script, null)
            }
            true
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(Intent(this, DisplaySessionService::class.java))
        } else {
            startService(Intent(this, DisplaySessionService::class.java))
        }
        FullscreenController.apply(this, null, true)
        // The phone activity is always the controller interface. The actual desktop is
        // hosted independently in DesktopPresentation on the TV/monitor display.
        controllerWebView = buildWebView("controller")
        setContentView(controllerWebView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        PhoneRelay.attach { json ->
            runOnUiThread {
                val script = "window.KKDexHostState && window.KKDexHostState(${org.json.JSONObject.quote(json)});"
                if (!isFinishing && !isDestroyed) controllerWebView.evaluateJavascript(script, null)
            }
            true
        }
        controllerWebView.loadUrl("$ASSET_ORIGIN/assets/index.html?controller=1")

        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, null)
        syncDisplays()
        installDesktopOnMainDisplayIfNeeded()
        requestMediaPermissions()
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = syncDisplays()
        override fun onDisplayRemoved(displayId: Int) {
            if (presentation?.display?.displayId == displayId) {
                presentation?.dismiss()
                presentation = null
                desktopInstalled = false
            }
        }
        override fun onDisplayChanged(displayId: Int) = Unit
    }

    private fun syncDisplays() {
        val external = displayManager.displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }
        if (external != null) {
            if (presentation?.display?.displayId != external.displayId) {
                presentation?.dismiss()
                presentation = try {
                    DesktopPresentation(this, external, this, fileAccess, downloads, systemBridge, storageStats, shell).apply {
                        show()
                    }.also { desktopInstalled = true }
                } catch (error: Exception) {
                    desktopInstalled = false
                    showToast("Android could not create the external display surface: ${error.message}")
                    null
                }
            }
        } else if (desktopInstalled) {
            presentation?.dismiss()
            presentation = null
            desktopInstalled = false
        }
    }

    /**
     * If no external display is available, this keeps the phone usable as a controller
     * preview surface rather than pretending a TV is connected.
     */
    private fun installDesktopOnMainDisplayIfNeeded() {
        if (displayManager.displays.none { it.displayId != Display.DEFAULT_DISPLAY }) {
            showToast("No external display detected. Connect a TV or monitor, or use the controller with an external display session.")
        }
    }

    private fun showToast(message: String) {
        runOnUiThread {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun buildWebView(role: String): WebView {
        val view = WebView(this)
        view.setBackgroundColor(Color.parseColor("#070C15"))
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            // The single-file desktop bundle references /wallpapers and /gallery by root path.
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            databaseEnabled = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled((applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0)
        }
        view.addJavascriptInterface(KKdexBridge(this, { view }, fileAccess, role, downloads = downloads, systemBridge = systemBridge, storageStats = storageStats, shell = shell), "KKDexNative")
        view.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return !(url.host == "appassets.androidplatform.net" || url.scheme == "https" || url.scheme == "http")
            }
        }
        return view
    }

    fun requestMediaPermissions() {
        val required = when {
            Build.VERSION.SDK_INT >= 33 -> listOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
            )
            Build.VERSION.SDK_INT >= 29 -> listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            else -> listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = required.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        // Reapply immersive full-screen after returning from other activities.
        FullscreenController.restore(this, presentation, true)
    }

    override fun onDestroy() {
        PhoneRelay.detach()
        TerminalRelay.detach()
        stopService(Intent(this, DisplaySessionService::class.java))
        displayManager.unregisterDisplayListener(displayListener)
        presentation?.dismiss()
        presentation = null
        controllerWebView.loadUrl("about:blank")
        controllerWebView.removeAllViews()
        controllerWebView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val ASSET_ORIGIN = "https://appassets.androidplatform.net"
    }

    @Suppress("unused")
    @JavascriptInterface
    fun role(): String = "controller"
}
