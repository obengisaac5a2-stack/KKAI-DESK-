package com.kkdex.desktop

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import org.json.JSONObject

/** Native Android controls that are safe to expose to the trusted KK DEX page. */
class SystemBridge(private val activity: Activity) {
    private val context: Context = activity.applicationContext

    fun networkInfo(): JSONObject {
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivity.activeNetwork
        val caps = connectivity.getNetworkCapabilities(network)
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val type = when {
            caps == null -> "offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
            else -> "unknown"
        }
        @Suppress("DEPRECATION")
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        var wifiEnabled = false
        try { wifiEnabled = wifi.isWifiEnabled } catch (_: SecurityException) { }
        var ssid: String? = null
        var wifiConnected = false
        try {
            @Suppress("DEPRECATION")
            val info = wifi.connectionInfo
            if (info != null) {
                ssid = info.ssid?.trim('"')?.takeIf { it.isNotEmpty() && it != "<unknown ssid>" }
                wifiConnected = info.networkId != -1
            }
        } catch (_: SecurityException) {
            // Android redacts SSID without fine location permission.
        }
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter: BluetoothAdapter? = bluetoothManager?.adapter
        var bluetoothEnabled = false
        var bluetoothSupported = adapter != null
        if (adapter != null) {
            try { bluetoothEnabled = adapter.isEnabled } catch (_: SecurityException) {
                bluetoothSupported = true
                bluetoothEnabled = false
            }
        }
        return JSONObject().apply {
            put("ok", true)
            put("online", online)
            put("type", type)
            put("wifiEnabled", wifiEnabled)
            put("wifiConnected", wifiConnected)
            if (ssid != null) put("wifiSsid", ssid)
            put("bluetoothSupported", bluetoothSupported)
            put("bluetoothEnabled", bluetoothEnabled)
            put("vpnActive", caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true)
        }
    }

    fun audioInfo(): JSONObject {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return JSONObject().apply {
            put("ok", true)
            put("musicVolume", audio.getStreamVolume(AudioManager.STREAM_MUSIC))
            put("maxMusicVolume", audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
            put("ringerVolume", audio.getStreamVolume(AudioManager.STREAM_RING))
            put("maxRingerVolume", audio.getStreamMaxVolume(AudioManager.STREAM_RING))
            put("isMuted", audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0)
        }
    }

    fun setVolume(stream: String, volume: Int): JSONObject {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val target = if (stream == "ring") AudioManager.STREAM_RING else AudioManager.STREAM_MUSIC
        val max = audio.getStreamMaxVolume(target)
        val safe = volume.coerceIn(0, max)
        try {
            audio.setStreamVolume(target, safe, AudioManager.FLAG_SHOW_UI)
        } catch (error: SecurityException) {
            throw IllegalStateException("Android denied volume control. Do Not Disturb may be restricting it: ${error.message}")
        }
        return audioInfo()
    }

    fun openSettings(section: String): String {
        val intent = when (section) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            "downloads" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:${context.packageName}"))
            "unknownSources" -> Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).setData(Uri.parse("package:${context.packageName}"))
            else -> Intent(Settings.ACTION_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
        } catch (error: Exception) {
            val fallback = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(fallback)
        }
        return "opened:$section"
    }

    fun setPerformanceMode(mode: String): JSONObject {
        val normalized = when (mode) {
            "performance", "visual", "balanced" -> mode
            else -> "balanced"
        }
        context.getSharedPreferences("kkdex", Context.MODE_PRIVATE).edit().putString("performance_mode", normalized).apply()
        return JSONObject().apply {
            put("ok", true)
            put("applied", true)
            put("mode", normalized)
            put("note", "Android does not allow a normal app to increase CPU or GPU hardware performance. Mode changes KK DEX animation and polling policy only; games use Android's own scheduling.")
        }
    }
}
