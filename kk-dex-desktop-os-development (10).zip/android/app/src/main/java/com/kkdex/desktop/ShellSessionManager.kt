package com.kkdex.desktop

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real process host for KK DEX Terminal.
 *
 * Commands are executed by the Android process API inside the application
 * sandbox: `/system/bin/sh` (or the user's preferred shell) with the session's
 * working directory and environment. Nothing is simulated. Missing tools fail
 * with the operating system's own error.
 *
 * Security: sessions may only start inside the app-private workspace
 * (`filesDir`), the app external files directory, or the cache directory.
 * No root, no escape from the sandbox and no remote command service exists.
 */
/** Forwards terminal stream events to the desktop WebView. */
object TerminalRelay {
    private var listener: ((String) -> Boolean)? = null
    fun attach(block: (String) -> Boolean) { listener = block }
    fun detach() { listener = null }
    fun send(json: String): Boolean = listener?.invoke(json) ?: false
}

class ShellSessionManager(
    private val context: Context,
    private val eventListener: (String) -> Unit,
) {
    data class Session(
        val id: String,
        var cwd: File,
        @Volatile var process: Process? = null,
    )

    private val sessions = ConcurrentHashMap<String, Session>()
    private val shellPath: String = resolveShell()

    private fun resolveShell(): String {
        val candidates = listOf("/system/bin/sh", "/system/bin/bash", "/system/bin/mksh")
        return candidates.firstOrNull { File(it).canExecute() } ?: "/system/bin/sh"
    }

    fun workspaceRoot(): File = File(context.filesDir, "workspace").apply { mkdirs() }

    private fun allowedRoots(): List<File> = listOfNotNull(
        context.filesDir,
        context.externalCacheDir?.parentFile,
        context.cacheDir,
        workspaceRoot().parentFile,
    ).map { it.canonicalFile }

    private fun sanitizeCwd(raw: String?): File {
        if (raw.isNullOrBlank()) return workspaceRoot()
        val requested = File(raw).let { if (it.isAbsolute) it else File(workspaceRoot(), raw) }.canonicalFile
        val inside = allowedRoots().any { root -> requested.path.startsWith(root.path) }
        return if (inside && (requested.isDirectory || requested.mkdirs())) requested else workspaceRoot()
    }

    fun start(id: String, cwd: String?): JSONObject {
        val directory = sanitizeCwd(cwd)
        sessions[id] ?: sessions.put(id, Session(id, directory))
        val session = sessions[id]!!
        session.cwd = directory
        return JSONObject()
            .put("ok", true)
            .put("id", session.id)
            .put("cwd", session.cwd.path)
            .put("alive", true)
    }

    fun exec(id: String, command: String, timeoutMs: Long = 120_000): JSONObject {
        if (command.isBlank()) throw IllegalArgumentException("Empty command.")
        val session = sessions[id] ?: Session(id, workspaceRoot()).also { sessions[id] = it }
        if (session.process?.isAlive == true) throw IllegalStateException("A command is already running in this session. Interrupt it first (Ctrl+C).")
        val started = System.currentTimeMillis()
        val processBuilder = ProcessBuilder(shellPath, "-c", command)
            .directory(session.cwd)
            .redirectErrorStream(false)
        val env = processBuilder.environment()
        env["HOME"] = context.filesDir.absolutePath
        env["TMPDIR"] = context.cacheDir.absolutePath
        env["PREFIX"] = File(context.filesDir, "usr").absolutePath
        env["PATH"] = listOf(
            File(context.filesDir, "usr/bin").absolutePath,
            File(context.filesDir, "bin").absolutePath,
            "/system/bin",
            "/system/xbin",
        ).joinToString(":")
        env["LANG"] = "en_US.UTF-8"
        env["TERM"] = "xterm-256color"
        env["KKDEX_SESSION"] = session.id

        val process = try {
            processBuilder.start()
        } catch (error: Exception) {
            throw IllegalStateException("The shell could not start: ${error.message}")
        }
        session.process = process
        val finished = AtomicBoolean(false)

        val outBuffer = StringBuilder()
        val errBuffer = StringBuilder()
        val stdoutThread = stream(process.inputStream, session.id, "stdout", outBuffer)
        val stderrThread = stream(process.errorStream, session.id, "stderr", errBuffer)

        val completed = try {
            process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            process.destroy()
            false
        }
        if (!completed) {
            process.destroy()
            emit(session.id, "stderr", "\n[kkdex] command timed out after ${timeoutMs} ms and was terminated.\n")
        }
        stdoutThread.join(1_000)
        stderrThread.join(1_000)
        val exit = try {
            if (completed) process.exitValue() else 137
        } catch (_: Exception) {
            137
        }
        session.process = null
        finished.set(true)
        val duration = System.currentTimeMillis() - started
        emitExit(session.id, exit)
        return JSONObject()
            .put("ok", true)
            .put("stdout", outBuffer.toString())
            .put("stderr", errBuffer.toString())
            .put("exitCode", exit)
            .put("cwd", session.cwd.path)
            .put("durationMs", duration)
    }

    fun interrupt(id: String): JSONObject {
        val session = sessions[id] ?: return JSONObject().put("ok", true)
        session.process?.let { process ->
            process.destroy()
            if (process.isAlive) process.destroyForcibly()
        }
        session.process = null
        return JSONObject().put("ok", true).put("interrupted", true)
    }

    fun list(): JSONArray {
        val result = JSONArray()
        sessions.values.forEach { session ->
            result.put(
                JSONObject()
                    .put("id", session.id)
                    .put("cwd", session.cwd.path)
                    .put("alive", session.process?.isAlive != true)
                    .put("pid", session.process?.let { pidOf(it) } ?: 0),
            )
        }
        return result
    }

    fun runtimeInfo(): JSONObject {
        val runtimes = JSONArray()
        val probes = listOf(
            Triple("python", "python3 --version || python --version", "Python interpreter"),
            Triple("node", "node --version", "Node.js runtime"),
            Triple("git", "git --version", "Version control"),
            Triple("clang", "clang --version | head -1", "C/C++ compiler"),
            Triple("php", "php --version | head -1", "PHP runtime"),
            Triple("ruby", "ruby --version", "Ruby runtime"),
            Triple("java", "java -version 2>&1 | head -1", "Java runtime"),
        )
        probes.forEach { (name, probe, note) ->
            val path = detect("command -v $name")
            runtimes.put(
                JSONObject()
                    .put("name", name)
                    .put("available", path.isNotBlank())
                    .put("path", path)
                    .put("version", if (path.isNotBlank()) detect(probe).lineSequence().firstOrNull().orEmpty() else "")
                    .put("note", note),
            )
        }
        val pkgPath = detect("command -v pkg")
        val aptPath = detect("command -v apt")
        val packageManagerName = when {
            pkgPath.isNotBlank() -> "pkg"
            aptPath.isNotBlank() -> "apt"
            else -> "none"
        }
        val packageManagerNote = when (packageManagerName) {
            "pkg" -> "pkg is installed. 'pkg update', 'pkg install <package>' and dependency resolution run for real against the configured repositories."
            "apt" -> "apt is installed. Debian package commands run for real against the configured sources."
            else -> "No package manager is installed. KK DEX does not fabricate package installation. To enable it, install a Termux-compatible bootstrap into the application's usr prefix directory; the terminal will then expose pkg/apt automatically."
        }
        val userlandAvailable = File(context.filesDir, "usr/bin").listFiles()?.isNotEmpty() == true
        return JSONObject()
            .put("ok", true)
            .put("shell", File(shellPath).name)
            .put("shellPath", shellPath)
            .put("runtimes", runtimes)
            .put(
                "packageManager",
                JSONObject()
                    .put("name", packageManagerName)
                    .put("available", packageManagerName != "none")
                    .put("note", packageManagerNote),
            )
            .put(
                "userland",
                JSONObject()
                    .put("available", userlandAvailable)
                    .put(
                        "note",
                        if (userlandAvailable) {
                            "A Linux userland prefix is installed in the app workspace. Commands resolve from that prefix first."
                        } else {
                            "No Linux userland bootstrap is bundled. The host shell and Android toybox utilities are available; a Termux-compatible bootstrap can be installed into the app prefix to unlock full package management."
                        },
                    ),
            )
            .put("cpuAbi", android.os.Build.SUPPORTED_ABIS.joinToString(","))
            .put("apiLevel", android.os.Build.VERSION.SDK_INT)
    }

    private fun detect(command: String): String = try {
        val process = ProcessBuilder(shellPath, "-c", command)
            .directory(workspaceRoot())
            .redirectErrorStream(true)
            .start()
        val output = BufferedReader(InputStreamReader(process.inputStream)).use { reader -> reader.readText() }
        process.waitFor(4, TimeUnit.SECONDS)
        output.trim()
    } catch (_: Exception) {
        ""
    }

    private fun stream(inputStream: java.io.InputStream, sessionId: String, streamName: String, capture: StringBuilder): Thread {
        val thread = Thread {
            try {
                val buffer = CharArray(2048)
                val reader = InputStreamReader(inputStream, Charsets.UTF_8)
                val builder = StringBuilder()
                while (true) {
                    val read = reader.read(buffer)
                    if (read == -1) break
                    builder.append(buffer, 0, read)
                    var index = builder.indexOf("\n")
                    while (index >= 0) {
                        synchronized(capture) { capture.append(builder.substring(0, index + 1)) }
                        emit(sessionId, streamName, builder.substring(0, index + 1))
                        builder.delete(0, index + 1)
                        index = builder.indexOf("\n")
                    }
                    if (builder.isNotEmpty()) {
                        synchronized(capture) { capture.append(builder) }
                        emit(sessionId, streamName, builder.toString())
                        builder.setLength(0)
                    }
                }
            } catch (_: Exception) {
                // Stream closed by process exit.
            }
        }
        thread.isDaemon = true
        thread.start()
        return thread
    }

    private fun emit(sessionId: String, streamName: String, text: String) {
        if (text.isEmpty()) return
        eventListener(
            JSONObject()
                .put("type", "output")
                .put("sessionId", sessionId)
                .put("stream", streamName)
                .put("text", text)
                .toString(),
        )
    }

    private fun emitExit(sessionId: String, exitCode: Int) {
        eventListener(
            JSONObject()
                .put("type", "exit")
                .put("sessionId", sessionId)
                .put("exitCode", exitCode)
                .toString(),
        )
    }

    private fun pidOf(process: Process): Long = try {
        val field = process.javaClass.getMethod("pid")
        (field.invoke(process) as Number).toLong()
    } catch (_: Exception) {
        0L
    }
}
