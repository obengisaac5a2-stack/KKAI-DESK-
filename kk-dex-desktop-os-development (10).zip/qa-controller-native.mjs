import { chromium } from 'playwright';
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const mock = () => {
  window.KKDexNative = {
    getCapabilities:()=>JSON.stringify({bridge:'KKDexNative',platform:'Pixel Test',sdkInt:34,storageAccessFramework:true,mediaStore:true,installedApps:true,appLaunch:true,externalDisplay:true,downloads:true,writeAccess:true,browser:true,storageStats:true,downloadManager:true,apkInstall:true,systemControls:true,gameDiscovery:true,performanceModes:true}),
    relayToDesktop:(json,id)=>{const ch=new BroadcastChannel('qa-relay');ch.postMessage({target:'desktop',json});ch.close();return true;},
    relayToController:(json,id)=>{const ch=new BroadcastChannel('qa-relay');ch.postMessage({target:'controller',json});ch.close();return true;},
    pickFiles:()=>JSON.stringify({ok:true,files:[{uri:'content://file/1',name:'phone-note.txt',mime:'text/plain',size:12,isDirectory:false}]}),
    readFile:()=>JSON.stringify({ok:true,content:'aGVsbG8gcGhvbmU=',encoding:'base64'}),
    getNetworkInfo:()=>JSON.stringify({ok:true,online:true,type:'wifi',wifiEnabled:true,wifiConnected:true,wifiSsid:'QA-WiFi',bluetoothEnabled:false,bluetoothSupported:true,vpnActive:false}),
    getAudioInfo:()=>JSON.stringify({ok:true,musicVolume:8,maxMusicVolume:15,ringerVolume:3,maxRingerVolume:7,isMuted:false}),
    setVolume:()=>JSON.stringify({ok:true,musicVolume:0,maxMusicVolume:15,ringerVolume:3,maxRingerVolume:7,isMuted:true}),
    openSystemSettings:()=>true,
    getStorageInfo:()=>JSON.stringify({ok:true}),
    getSystemStats:()=>JSON.stringify({ok:true,model:'Pixel',manufacturer:'Google',platform:'Pixel',androidVersion:'14',sdkInt:34,cpuCores:8,cpuAbi:'arm64',totalRamBytes:8589934592,availableRamBytes:4294967296,appUsedRamBytes:128,displayWidth:1280,displayHeight:800,density:2,refreshRate:60,supportedRefreshRates:[60],externalDisplay:true,uptimeMs:5000}),
  };
  const ch = new BroadcastChannel('qa-relay');
  ch.onmessage = (event) => {
    if (event.data?.target === 'desktop') window.KKDexHostMessage && window.KKDexHostMessage(event.data.json);
    if (event.data?.target === 'controller') window.KKDexHostState && window.KKDexHostState(event.data.json);
  };
};
// addInitScript doesn't keep channel referenced; window global needed
const init = () => {
  window.KKDexNative = {
    getCapabilities:()=>JSON.stringify({bridge:'KKDexNative',platform:'Pixel Test',sdkInt:34,storageAccessFramework:true,mediaStore:true,installedApps:true,appLaunch:true,externalDisplay:true,downloads:true,writeAccess:true,browser:true,storageStats:true,downloadManager:true,apkInstall:true,systemControls:true,gameDiscovery:true,performanceModes:true}),
    relayToDesktop:(json,id)=>{const ch=new BroadcastChannel('qa-relay');ch.postMessage({target:'desktop',json});ch.close();return true;},
    relayToController:(json,id)=>{const ch=new BroadcastChannel('qa-relay');ch.postMessage({target:'controller',json});ch.close();return true;},
    pickFiles:()=>JSON.stringify({ok:true,files:[{uri:'content://file/1',name:'phone-note.txt',mime:'text/plain',size:12,isDirectory:false}]}),
    readFile:()=>JSON.stringify({ok:true,content:'aGVsbG8gcGhvbmU=',encoding:'base64'}),
    getNetworkInfo:()=>JSON.stringify({ok:true,online:true,type:'wifi',wifiEnabled:true,wifiConnected:true,wifiSsid:'QA-WiFi',bluetoothEnabled:false,bluetoothSupported:true,vpnActive:false}),
    getAudioInfo:()=>JSON.stringify({ok:true,musicVolume:8,maxMusicVolume:15,ringerVolume:3,maxRingerVolume:7,isMuted:false}),
    setVolume:()=>JSON.stringify({ok:true,musicVolume:0,maxMusicVolume:15,ringerVolume:3,maxRingerVolume:7,isMuted:true}),
    openSystemSettings:()=>true,
    getStorageInfo:()=>JSON.stringify({ok:true}),
    getSystemStats:()=>JSON.stringify({ok:true,model:'Pixel',manufacturer:'Google',platform:'Pixel',androidVersion:'14',sdkInt:34,cpuCores:8,cpuAbi:'arm64',totalRamBytes:8589934592,availableRamBytes:4294967296,appUsedRamBytes:128,displayWidth:1280,displayHeight:800,density:2,refreshRate:60,supportedRefreshRates:[60],externalDisplay:true,uptimeMs:5000}),
  };
  window.__relay = new BroadcastChannel('qa-relay');
  window.__relay.onmessage = (event) => {
    if (event.data?.target === 'desktop') window.KKDexHostMessage && window.KKDexHostMessage(event.data.json);
    if (event.data?.target === 'controller') window.KKDexHostState && window.KKDexHostState(event.data.json);
  };
};
await context.addInitScript(init);
const desktop = await context.newPage();
await desktop.goto('http://127.0.0.1:4173/?desktop=1',{waitUntil:'networkidle'});
await desktop.waitForTimeout(900);
console.log('desktop state received by relay host:', await desktop.evaluate(()=>window.KKDexAPI.getState().resolution.width));
const controller = await context.newPage();
await controller.setViewportSize({width:430,height:900});
await controller.goto('http://127.0.0.1:4173/?controller=1',{waitUntil:'networkidle'});
await controller.waitForTimeout(1000);
console.log('controller linked via native:', await controller.getByText(/Android bridge/).count());
// touchpad move & click
const pad=controller.locator('[aria-label^="Touchpad"]');
const pb=await pad.boundingBox();
await controller.mouse.move(pb.x+pb.width/2,pb.y+pb.height/2);
await controller.mouse.down();
await controller.mouse.move(pb.x+pb.width/2+50,pb.y+pb.height/2+30,{steps:8});
await controller.mouse.up();
await controller.waitForTimeout(500);
console.log('desktop pointer state:', await desktop.evaluate(()=>window.KKDexAPI.getState().pointer));
// keyboard tab
await controller.locator('nav button').filter({hasText:'Keyboard'}).click();
await controller.waitForTimeout(250);
await controller.locator('textarea').fill('relay text');
await controller.getByRole('button',{name:'Send to TV'}).click();
await controller.waitForTimeout(500);
// file transfer
await controller.locator('nav button').filter({hasText:'Apps'}).click();
await controller.waitForTimeout(300);
await controller.getByRole('button',{name:/Send a phone file/}).click();
await controller.waitForTimeout(700);
console.log('file transfer status:', await controller.getByText(/phone-note.txt/).count());
console.log('desktop has imported file:', await desktop.evaluate(()=>JSON.parse(localStorage.getItem('kkdex.files')||'[]').some(f=>f.name==='phone-note.txt')));
console.log('wifi status:', await controller.getByText(/QA-WiFi/).count());
await controller.screenshot({path:'/tmp/controller-native.png'});
await browser.close();
