import { chromium } from 'playwright';
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await context.newPage();
const errors=[]; page.on('pageerror',e=>errors.push(e.message)); page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.addInitScript(() => {
  const now=Date.now();
  const caps={bridge:'KKDexNative',platform:'Pixel 8 Test',sdkInt:34,storageAccessFramework:true,mediaStore:true,installedApps:true,appLaunch:true,externalDisplay:true,shellExecution:false,python:false,node:false,git:false,downloads:true,writeAccess:true,browser:true,storageStats:true,downloadManager:true,apkInstall:true,systemControls:true,gameDiscovery:true,performanceModes:true,downloadLocation:'KK DEX'};
  const down={id:7,uri:'content://downloads/7',localUri:'content://downloads/7',name:'sample.apk',mime:'application/vnd.android.package-archive',status:'successful',bytesDownloaded:2048,totalBytes:2048,progress:100,speedBytesPerSecond:0,destination:'KK DEX/sample.apk'};
  window.KKDexNative={
    getCapabilities:()=>JSON.stringify(caps),
    getStorageInfo:()=>JSON.stringify({ok:true,totalBytes:137438953472,availableBytes:68719476736,usedBytes:68719476736,categories:{apps:25769803776,images:8589934592,videos:17179869184,audio:2147483648,documents:1073741824,downloads:3221225472,apk:536870912,games:21474836480,other:0},categoryNote:'Test-native values',downloadDir:'Download/KK DEX'}),
    getSystemStats:()=>JSON.stringify({ok:true,model:'Pixel 8',manufacturer:'Google',platform:'Google Pixel 8',androidVersion:'14',sdkInt:34,cpuCores:9,cpuAbi:'arm64-v8a',totalRamBytes:8589934592,availableRamBytes:4294967296,appUsedRamBytes:536870912,displayWidth:1920,displayHeight:1080,density:2.75,refreshRate:120,supportedRefreshRates:[60,120],gpuRenderer:'Mali-G715',gpuVendor:'ARM',externalDisplay:true,uptimeMs:500000}),
    getNetworkInfo:()=>JSON.stringify({ok:true,online:true,type:'wifi',wifiEnabled:true,wifiConnected:true,wifiSsid:'KK-Gaming-5G',bluetoothEnabled:false,bluetoothSupported:true,vpnActive:false}),
    getAudioInfo:()=>JSON.stringify({ok:true,musicVolume:9,maxMusicVolume:15,ringerVolume:4,maxRingerVolume:7,isMuted:false}),
    setVolume:(s,v,id)=>{setTimeout(()=>window.KKDexNativeResult(id,JSON.stringify({ok:true,musicVolume:v,maxMusicVolume:15,ringerVolume:4,maxRingerVolume:7,isMuted:v===0})),10);},
    openSystemSettings:(section,id)=>{window.__lastSettings=section;setTimeout(()=>window.KKDexNativeResult(id,JSON.stringify({ok:true})),10);return true;},
    setPerformanceMode:(mode,id)=>JSON.stringify({ok:true,applied:true,note:'Test mode applied'}),
    getNativeDownloads:(id)=>JSON.stringify({ok:true,downloads:[down]}),
    getInstalledApps:(id)=>JSON.stringify({ok:true,apps:[{packageName:'com.kk.gamerace',label:'Turbo Racer',isGame:true,versionName:'2.4.1',size:734003200,installedAt:now-86400000,icon:''},{packageName:'com.kk.notes',label:'Notes Test App',isGame:false,versionName:'1.0',size:10485760}]}),
    launchAndroidApp:(pkg,id)=>JSON.stringify({ok:true,launched:true,display:'phone',message:'Test app launched on phone.'}),
    setDownloadFolder:(folder,id)=>JSON.stringify({ok:true,folder}),
    startDownload:(url,name,mime,ref,id)=>JSON.stringify({ok:true,...down,id:8,name:name||'test.apk',destination:'KK DEX/'+(name||'test.apk')}),
    controlDownload:(id,action,rid)=>JSON.stringify({ok:true}),
    openDownload:(id,rid)=>JSON.stringify({ok:true,opened:true}),
    installApk:(uri,rid)=>JSON.stringify({ok:true,opened:true}),
    getDownloads:(id)=>JSON.stringify({ok:true,files:[]}),
    getNetworkStatus:()=>JSON.stringify({ok:true}),
    relayToController:()=>true,
    relayToDesktop:()=>true,
  };
});
await page.goto('http://127.0.0.1:4173/', {waitUntil:'networkidle'});
await page.waitForTimeout(900);
// Storage app
await page.evaluate(()=>window.KKDexAPI.openApp('storage'));
await page.waitForTimeout(900);
const storage=page.locator('[aria-label="Storage Manager window"]');
console.log('storage total visible:', await storage.getByText('used of 128 GB').count());
console.log('category Images:', await storage.getByText('Images').count());
await page.screenshot({path:'/tmp/storage.png'});
// Gaming
await page.evaluate(()=>window.KKDexAPI.openApp('games'));
await page.waitForTimeout(1000);
const games=page.locator('[aria-label="Gaming Centre window"]');
console.log('game found:', await games.getByText('Turbo Racer').count());
await games.getByRole('button',{name:'Performance'}).click();
await page.waitForTimeout(700);
console.log('refresh hz:', await games.getByText('120 Hz').count());
await page.screenshot({path:'/tmp/games.png'});
// downloads
await page.evaluate(()=>window.KKDexAPI.openApp('downloads'));
await page.waitForTimeout(400);
const downloads=page.locator('[aria-label="Downloads window"]');
await downloads.getByText('Android device').click();
await page.waitForTimeout(800);
console.log('apk listed:', await downloads.getByText('sample.apk').count());
await page.getByRole('button',{name:/Install/}).last().click();
await page.waitForTimeout(400);
await page.screenshot({path:'/tmp/downloads.png'});
// settings network
await page.evaluate(()=>window.KKDexAPI.openApp('settings'));
await page.waitForTimeout(400);
const settings=page.locator('[aria-label="Settings window"]');
await settings.getByText('Network & Bluetooth').first().click();
await page.waitForTimeout(700);
console.log('ssid visible:', await settings.getByText(/KK-Gaming-5G/).count());
await page.screenshot({path:'/tmp/networksettings.png'});
// Browser UI fallback
await page.evaluate(()=>window.KKDexAPI.openApp('browser'));
await page.waitForTimeout(700);
const bw=page.locator('[aria-label="Browser window"]');
console.log('browser tabs:', await bw.getByText('KK Browse').count());
await bw.locator('input[placeholder="Search Google or type a URL"]').last().fill('youtube.com');
await bw.locator('input[placeholder="Search Google or type a URL"]').last().press('Enter');
await page.waitForTimeout(500);
console.log('native browser address:', await bw.locator('input').first().inputValue());
console.log('errors', errors.length ? errors.slice(0,6):'none');
await browser.close();
