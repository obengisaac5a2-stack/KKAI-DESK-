/**
 * KK DEX desktop security.
 *
 * The PIN/password is never stored in plain text. A random 16-byte salt is
 * generated per account and the secret is derived with PBKDF2-SHA256
 * (210,000 iterations, 256-bit key) through WebCrypto. Only
 * `{ salt, hash, iterations, algo, createdAt }` is persisted.
 *
 * Recovery: KK DEX stores no recoverable copy of the secret. If the PIN is
 * lost, Settings -> Security -> Reset desktop security clears the local
 * account (this also erases saved login state, never file contents).
 */

export interface StoredCredential {
  salt: string;
  hash: string;
  iterations: number;
  algo: string;
  createdAt: number;
}

const CREDENTIAL_KEY = "kkdex.credential";
const encoder = new TextEncoder();

function toHex(buffer: ArrayBuffer): string {
  return Array.from(new Uint8Array(buffer))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

function fromHex(hex: string): Uint8Array {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i += 1) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

async function derive(secret: string, saltHex: string, iterations: number): Promise<string> {
  const keyMaterial = await crypto.subtle.importKey("raw", encoder.encode(secret), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: fromHex(saltHex) as unknown as BufferSource, iterations, hash: "SHA-256" },
    keyMaterial,
    256,
  );
  return toHex(bits);
}

export function readCredential(): StoredCredential | null {
  try {
    const raw = localStorage.getItem(CREDENTIAL_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredCredential;
    if (!parsed?.hash || !parsed?.salt) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function hasCredential(): boolean {
  return readCredential() !== null;
}

export async function setCredential(secret: string): Promise<boolean> {
  const trimmed = secret.trim();
  if (trimmed.length < 4) return false;
  const saltBytes = crypto.getRandomValues(new Uint8Array(16));
  const salt = toHex(saltBytes.buffer);
  const iterations = 210_000;
  const hash = await derive(trimmed, salt, iterations);
  const record: StoredCredential = { salt, hash, iterations, algo: "PBKDF2-SHA256", createdAt: Date.now() };
  localStorage.setItem(CREDENTIAL_KEY, JSON.stringify(record));
  return true;
}

export async function verifyCredential(secret: string): Promise<boolean> {
  const record = readCredential();
  if (!record) return true;
  const candidate = await derive(secret.trim(), record.salt, record.iterations);
  if (candidate.length !== record.hash.length) return false;
  // Constant-time comparison to avoid timing side channels.
  let diff = 0;
  for (let i = 0; i < candidate.length; i += 1) diff |= candidate.charCodeAt(i) ^ record.hash.charCodeAt(i);
  return diff === 0;
}

export function clearCredential(): void {
  localStorage.removeItem(CREDENTIAL_KEY);
}

export function describeCredential(): string {
  const record = readCredential();
  if (!record) return "No desktop PIN or password is set.";
  return `Local account protected with ${record.algo} · ${record.iterations.toLocaleString()} iterations · created ${new Date(record.createdAt).toLocaleDateString()}`;
}
