/**
 * KK DEX native bridge adapter.
 *
 * Android hosts may expose `window.KKDexNative`. Methods may return a JSON string
 * synchronously or signal completion through `window.KKDexNativeResult(requestId,
 * payloadJson)`. The adapter supports both shapes. It never fabricates a successful
 * response: unavailable capabilities are surfaced to the UI.
 */

export type NativeMethod =
  | "getCapabilities"
  | "requestStoragePermission"
  | "pickFiles"
  | "pickFolder"
  | "listDirectory"
  | "readFile"
  | "writeFile"
  | "createFolder"
  | "renameFile"
  | "deleteFile"
  | "copyFile"
  | "moveFile"
  | "getInstalledApps"
  | "launchAndroidApp"
  | "openWith"
  | "getDownloads"
  | "getDisplayInfo"
  | "exec"
  | "getStorageInfo"
  | "getSystemStats"
  | "getNetworkInfo"
  | "getAudioInfo"
  | "setVolume"
  | "openSystemSettings"
  | "setPerformanceMode"
  | "startDownload"
  | "getNativeDownloads"
  | "controlDownload"
  | "openDownload"
  | "installApk"
  | "browserOpen"
  | "browserNavigate"
  | "browserBack"
  | "browserForward"
  | "browserReload"
  | "browserClose"
  | "browserSetBounds"
  | "browserSetVisible"
  | "browserFocus"
  | "browserSetDesktopMode"
  | "browserState"
  | "browserInput"
  | "relayToDesktop"
  | "setDownloadFolder"
  | "relayToController"
  | "setFullscreen"
  | "terminalStart"
  | "terminalExec"
  | "terminalInterrupt"
  | "terminalList"
  | "runtimeInfo";

export interface NativeCapabilities {
  bridge: string;
  platform: string;
  sdkInt: number;
  storageAccessFramework: boolean;
  mediaStore: boolean;
  installedApps: boolean;
  appLaunch: boolean;
  externalDisplay: boolean;
  shellExecution: boolean;
  python: boolean;
  node: boolean;
  git: boolean;
  downloads: boolean;
  writeAccess: boolean;
  browser: boolean;
  storageStats: boolean;
  downloadManager: boolean;
  apkInstall: boolean;
  systemControls: boolean;
  gameDiscovery: boolean;
  performanceModes: boolean;
  downloadLocation?: string;
}

export interface NativeFile {
  uri: string;
  name: string;
  mime: string;
  size: number;
  modified: number;
  isDirectory: boolean;
  kind: "folder" | "image" | "video" | "audio" | "document" | "pdf" | "archive" | "apk" | "file";
  source?: string;
}

export interface NativeApp {
  packageName: string;
  label: string;
  icon?: string;
  category?: string;
  isGame?: boolean;
  installedAt?: number;
  versionName?: string;
  size?: number;
}

export interface NativeStorageInfo {
  totalBytes: number;
  availableBytes: number;
  usedBytes: number;
  internalTotalBytes?: number;
  internalAvailableBytes?: number;
  externalTotalBytes?: number;
  externalAvailableBytes?: number;
  categories: Record<"apps" | "images" | "videos" | "audio" | "documents" | "downloads" | "apk" | "games" | "other", number>;
  categoryNote?: string;
  downloadDir?: string;
}

export interface NativeDownload {
  id: number;
  uri: string;
  name: string;
  mime: string;
  status: "pending" | "running" | "paused" | "successful" | "failed";
  bytesDownloaded: number;
  totalBytes: number;
  progress: number;
  speedBytesPerSecond: number;
  reason?: string;
  localUri?: string;
  destination: string;
}

export interface NativeSystemStats {
  model: string;
  manufacturer: string;
  platform: string;
  androidVersion: string;
  sdkInt: number;
  cpuCores: number;
  cpuAbi: string;
  totalRamBytes: number;
  availableRamBytes: number;
  appUsedRamBytes: number;
  displayWidth: number;
  displayHeight: number;
  density: number;
  refreshRate: number;
  supportedRefreshRates: number[];
  gpuRenderer?: string;
  gpuVendor?: string;
  externalDisplay: boolean;
  uptimeMs: number;
}

export interface NativeNetworkInfo {
  online: boolean;
  type: string;
  wifiEnabled: boolean;
  wifiConnected: boolean;
  wifiSsid?: string;
  bluetoothEnabled: boolean;
  bluetoothSupported: boolean;
  vpnActive: boolean;
}

export interface NativeAudioInfo {
  musicVolume: number;
  maxMusicVolume: number;
  ringerVolume: number;
  maxRingerVolume: number;
  isMuted: boolean;
}

export interface NativeBrowserState {
  url: string;
  title: string;
  loading: boolean;
  progress: number;
  canGoBack: boolean;
  canGoForward: boolean;
  desktopMode: boolean;
  error?: string;
}

export interface TerminalSession {
  id: string;
  cwd: string;
  alive: boolean;
  pid?: number;
}

export interface TerminalResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  cwd: string;
  durationMs: number;
}

export interface RuntimeInfo {
  shell: string;
  shellPath: string;
  runtimes: { name: string; available: boolean; version?: string; path?: string; note?: string }[];
  packageManager: { name: string; available: boolean; note: string };
  userland: { available: boolean; note: string };
  cpuAbi: string;
  apiLevel: number;
}

export type TerminalEvent =
  | { type: "output"; sessionId: string; stream: "stdout" | "stderr"; text: string }
  | { type: "exit"; sessionId: string; exitCode: number };

export type BrowserEvent =
  | { type: "state"; state: NativeBrowserState }
  | { type: "download"; download: NativeDownload }
  | { type: "new-tab"; url: string }
  | { type: "permission"; origin: string; resources: string }
  | { type: "fullscreen"; active: boolean };

export interface NativeListing {
  uri: string;
  name: string;
  files: NativeFile[];
}

type HostApi = Record<string, unknown>;

const CAPABILITY_DEFAULTS: NativeCapabilities = {
  bridge: "browser",
  platform: "Web",
  sdkInt: 0,
  storageAccessFramework: false,
  mediaStore: false,
  installedApps: false,
  appLaunch: false,
  externalDisplay: false,
  shellExecution: false,
  python: false,
  node: false,
  git: false,
  downloads: false,
  writeAccess: false,
  browser: false,
  storageStats: false,
  downloadManager: false,
  apkInstall: false,
  systemControls: false,
  gameDiscovery: false,
  performanceModes: false,
};

const CALLBACK_TIMEOUT = 45_000;

function parse<T>(raw: unknown): T {
  if (typeof raw === "string") {
    const text = raw.trim();
    if (!text) throw new Error("Native service returned an empty response.");
    return JSON.parse(text) as T;
  }
  if (raw && typeof raw === "object") return raw as T;
  throw new Error("Native service returned an unsupported response.");
}

function kindForMime(mime: string, name: string): NativeFile["kind"] {
  const value = (mime || "").toLowerCase();
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (value === "application/pdf" || ext === "pdf") return "pdf";
  if (value.startsWith("image/")) return "image";
  if (value.startsWith("video/")) return "video";
  if (value.startsWith("audio/")) return "audio";
  if (value.startsWith("text/") || ["md", "txt", "json", "js", "ts", "css", "html", "xml", "csv"].includes(ext)) return "document";
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return "archive";
  if (ext === "apk") return "apk";
  return "file";
}

export function normalizeNativeFile(input: Partial<NativeFile> & { isDirectory?: boolean }): NativeFile {
  const name = String(input.name ?? "Unnamed");
  const uri = String(input.uri ?? "");
  const mime = String(input.mime ?? "");
  const isDirectory = Boolean(input.isDirectory) || mime === "vnd.android.document/directory";
  const kind = isDirectory ? "folder" : input.kind ?? kindForMime(mime, name);
  return {
    uri,
    name,
    mime,
    size: Number(input.size ?? 0),
    modified: Number(input.modified ?? Date.now()),
    isDirectory,
    kind,
    source: input.source,
  };
}

class NativeBridge {
  private listeners = new Set<(state: NativeBridgeState) => void>();
  private state: NativeBridgeState = {
    available: false,
    ready: false,
    checking: true,
    capabilities: CAPABILITY_DEFAULTS,
    error: null,
  };
  private pending = new Map<string, { resolve: (value: unknown) => void; reject: (error: Error) => void; timer: number }>();
  private host: HostApi | null = null;
  private requestCounter = 0;

  constructor() {
    if (typeof window !== "undefined") {
      this.installCallbackReceiver();
      void this.detect();
    }
  }

  private installCallbackReceiver() {
    (window as unknown as Record<string, unknown>).KKDexNativeResult = (requestId: string, payload: unknown) => {
      const pending = this.pending.get(requestId);
      if (!pending) return;
      window.clearTimeout(pending.timer);
      this.pending.delete(requestId);
      try {
        const parsed = parse<{ ok?: boolean; error?: string }>(payload);
        if (parsed && parsed.ok === false) pending.reject(new Error(parsed.error || "Native request failed."));
        else pending.resolve(parsed);
      } catch (error) {
        pending.reject(error instanceof Error ? error : new Error("Invalid native callback payload."));
      }
    };
  }

  private setState(patch: Partial<NativeBridgeState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((listener) => listener(this.state));
  }

  subscribe(listener: (state: NativeBridgeState) => void) {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  getState() {
    return this.state;
  }

  private findHost(): HostApi | null {
    if (typeof window === "undefined") return null;
     const candidates = [
      (window as unknown as Record<string, unknown>).KKDexNative,
      (window as unknown as Record<string, unknown>).KKDexHost,
      (window as unknown as Record<string, unknown>).AndroidNative,
    ];
    return (candidates.find((candidate) => candidate && typeof candidate === "object") as HostApi | undefined) ?? null;
  }

  async detect(): Promise<NativeBridgeState> {
    const host = this.findHost();
    this.host = host;
    if (!host) {
      this.setState({ available: false, ready: true, checking: false, capabilities: CAPABILITY_DEFAULTS, error: null });
      return this.state;
    }
    this.setState({ available: true, checking: true, error: null });
    try {
      const raw = await this.invoke("getCapabilities", [], { timeout: 4000 });
      const capabilities = { ...CAPABILITY_DEFAULTS, ...(raw as Partial<NativeCapabilities>), bridge: "KKDexNative" };
      this.setState({ ready: true, checking: false, capabilities });
    } catch (error) {
      this.setState({
        ready: true,
        checking: false,
        capabilities: { ...CAPABILITY_DEFAULTS, bridge: "KKDexNative" },
        error: error instanceof Error ? error.message : "Unable to query the native bridge.",
      });
    }
    return this.state;
  }

  private async invoke(method: NativeMethod, args: unknown[], options: { timeout?: number } = {}): Promise<unknown> {
    const host = this.host ?? this.findHost();
    this.host = host;
    if (!host) throw new Error("No Android native bridge is available. The desktop is running in a standalone browser.");
    const fn = host[method];
    if (typeof fn !== "function") throw new Error(`The Android host does not implement ${method}().`);
    const requestId = `kk-${Date.now()}-${++this.requestCounter}`;
    const timeout = options.timeout ?? CALLBACK_TIMEOUT;
    return new Promise((resolve, reject) => {
      const timer = window.setTimeout(() => {
        this.pending.delete(requestId);
        reject(new Error(`${method}() did not respond. The native handler may have crashed or the picker is still open.`));
      }, timeout);
      this.pending.set(requestId, { resolve, reject, timer });
      try {
        const result = (fn as (...input: unknown[]) => unknown).call(host, ...args, requestId);
        if (typeof result === "boolean" || typeof result === "number") {
          window.clearTimeout(timer);
          this.pending.delete(requestId);
          if (result === false || result === 0) reject(new Error(`${method}() returned an unsuccessful result.`));
          else resolve({ ok: true, value: result });
          return;
        }
        if (result !== undefined && result !== null && result !== "") {
          window.clearTimeout(timer);
          this.pending.delete(requestId);
          try {
            const parsed = parse<{ ok?: boolean; error?: string }>(result);
            if (parsed && parsed.ok === false) reject(new Error(parsed.error || "Native request failed."));
            else resolve(parsed);
          } catch (error) {
            reject(error instanceof Error ? error : new Error("Unable to parse native response."));
          }
        }
      } catch (error) {
        window.clearTimeout(timer);
        this.pending.delete(requestId);
        reject(error instanceof Error ? error : new Error("Native invocation failed."));
      }
    });
  }

  async requestStoragePermission(types: ("images" | "video" | "audio" | "documents")[] = ["images", "video", "audio", "documents"]) {
    const result = (await this.invoke("requestStoragePermission", [JSON.stringify({ types })])) as { granted?: string[]; denied?: string[] };
    await this.detect();
    return result;
  }

  async pickFiles(mime = "*/*", multiple = true): Promise<NativeFile[]> {
    const result = (await this.invoke("pickFiles", [mime, multiple])) as { files?: Partial<NativeFile>[] };
    return (result.files ?? []).map(normalizeNativeFile);
  }

  async pickFolder(): Promise<{ uri: string; name: string } | null> {
    const result = (await this.invoke("pickFolder", [])) as { uri?: string; name?: string; cancelled?: boolean };
    if (!result?.uri) return null;
    return { uri: result.uri, name: result.name ?? "Authorized folder" };
  }

  async listDirectory(uri: string): Promise<NativeListing> {
    const result = (await this.invoke("listDirectory", [uri])) as { uri?: string; name?: string; files?: Partial<NativeFile>[] };
    return {
      uri: result.uri ?? uri,
      name: result.name ?? "Device storage",
      files: (result.files ?? []).map(normalizeNativeFile),
    };
  }

  async readFile(uri: string): Promise<{ content: string; encoding: "text" | "base64" }> {
    return (await this.invoke("readFile", [uri])) as { content: string; encoding: "text" | "base64" };
  }

  /** Reads a content URI into a data URL suitable for images, audio, video and PDFs. */
  async readDataUrl(uri: string, mime = "application/octet-stream"): Promise<string> {
    const result = await this.readFile(uri);
    if (/^data:/i.test(result.content)) return result.content;
    if (result.encoding === "base64") return `data:${mime};base64,${result.content}`;
    return `data:${mime};charset=utf-8,${encodeURIComponent(result.content)}`;
  }

  async writeFile(uri: string, content: string, encoding: "text" | "base64" = "text"): Promise<boolean> {
    const result = (await this.invoke("writeFile", [uri, content, encoding])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async createFolder(parentUri: string, name: string): Promise<NativeFile | null> {
    const result = (await this.invoke("createFolder", [parentUri, name])) as { file?: Partial<NativeFile> };
    return result?.file ? normalizeNativeFile(result.file) : null;
  }

  async renameFile(uri: string, name: string): Promise<boolean> {
    const result = (await this.invoke("renameFile", [uri, name])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async deleteFile(uri: string): Promise<boolean> {
    const result = (await this.invoke("deleteFile", [uri])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async getInstalledApps(): Promise<NativeApp[]> {
    const result = (await this.invoke("getInstalledApps", [])) as { apps?: NativeApp[] };
    return result.apps ?? [];
  }

  async launchAndroidApp(packageName: string): Promise<{ launched: boolean; display?: "phone" | "external"; message?: string }> {
    return (await this.invoke("launchAndroidApp", [packageName])) as { launched: boolean; display?: "phone" | "external"; message?: string };
  }

  async openWith(uri: string, mime: string): Promise<boolean> {
    const result = (await this.invoke("openWith", [uri, mime])) as { opened?: boolean; message?: string };
    if (result?.message && result.opened === false) throw new Error(result.message);
    return Boolean(result?.opened);
  }

  async getDownloads(): Promise<NativeFile[]> {
    const result = (await this.invoke("getDownloads", [])) as { files?: Partial<NativeFile>[] };
    return (result.files ?? []).map(normalizeNativeFile);
  }

  async getDisplayInfo(): Promise<Record<string, unknown>> {
    return (await this.invoke("getDisplayInfo", [])) as Record<string, unknown>;
  }

  async getStorageInfo(): Promise<NativeStorageInfo> {
    const result = (await this.invoke("getStorageInfo", [])) as Partial<NativeStorageInfo>;
    const categories = result.categories ?? ({} as NativeStorageInfo["categories"]);
    return {
      totalBytes: Number(result.totalBytes ?? 0),
      availableBytes: Number(result.availableBytes ?? 0),
      usedBytes: Number(result.usedBytes ?? 0),
      internalTotalBytes: Number(result.internalTotalBytes ?? result.totalBytes ?? 0),
      internalAvailableBytes: Number(result.internalAvailableBytes ?? result.availableBytes ?? 0),
      externalTotalBytes: Number(result.externalTotalBytes ?? 0),
      externalAvailableBytes: Number(result.externalAvailableBytes ?? 0),
      categories: {
        apps: Number(categories.apps ?? 0),
        images: Number(categories.images ?? 0),
        videos: Number(categories.videos ?? 0),
        audio: Number(categories.audio ?? 0),
        documents: Number(categories.documents ?? 0),
        downloads: Number(categories.downloads ?? 0),
        apk: Number(categories.apk ?? 0),
        games: Number(categories.games ?? 0),
        other: Number(categories.other ?? 0),
      },
      categoryNote: result.categoryNote,
      downloadDir: result.downloadDir,
    };
  }

  async getSystemStats(): Promise<NativeSystemStats> {
    const result = (await this.invoke("getSystemStats", [])) as Partial<NativeSystemStats>;
    return {
      model: result.model ?? "Android device",
      manufacturer: result.manufacturer ?? "Android",
      platform: result.platform ?? "",
      androidVersion: result.androidVersion ?? "",
      sdkInt: Number(result.sdkInt ?? 0),
      cpuCores: Number(result.cpuCores ?? 1),
      cpuAbi: result.cpuAbi ?? "",
      totalRamBytes: Number(result.totalRamBytes ?? 0),
      availableRamBytes: Number(result.availableRamBytes ?? 0),
      appUsedRamBytes: Number(result.appUsedRamBytes ?? 0),
      displayWidth: Number(result.displayWidth ?? 0),
      displayHeight: Number(result.displayHeight ?? 0),
      density: Number(result.density ?? 1),
      refreshRate: Number(result.refreshRate ?? 60),
      supportedRefreshRates: (result.supportedRefreshRates ?? []).map(Number),
      gpuRenderer: result.gpuRenderer,
      gpuVendor: result.gpuVendor,
      externalDisplay: Boolean(result.externalDisplay),
      uptimeMs: Number(result.uptimeMs ?? 0),
    };
  }

  async getNetworkInfo(): Promise<NativeNetworkInfo> {
    const result = (await this.invoke("getNetworkInfo", [])) as Partial<NativeNetworkInfo>;
    return {
      online: Boolean(result.online),
      type: result.type ?? "unknown",
      wifiEnabled: Boolean(result.wifiEnabled),
      wifiConnected: Boolean(result.wifiConnected),
      wifiSsid: result.wifiSsid,
      bluetoothEnabled: Boolean(result.bluetoothEnabled),
      bluetoothSupported: Boolean(result.bluetoothSupported),
      vpnActive: Boolean(result.vpnActive),
    };
  }

  async getAudioInfo(): Promise<NativeAudioInfo> {
    const result = (await this.invoke("getAudioInfo", [])) as Partial<NativeAudioInfo>;
    return {
      musicVolume: Number(result.musicVolume ?? 0),
      maxMusicVolume: Number(result.maxMusicVolume ?? 15),
      ringerVolume: Number(result.ringerVolume ?? 0),
      maxRingerVolume: Number(result.maxRingerVolume ?? 7),
      isMuted: Boolean(result.isMuted),
    };
  }

  async setVolume(stream: "music" | "ring", volume: number): Promise<NativeAudioInfo> {
    await this.invoke("setVolume", [stream, Math.round(volume)]);
    return this.getAudioInfo();
  }

  async openSystemSettings(section: "wifi" | "bluetooth" | "display" | "sound" | "storage" | "apps" | "downloads" | "unknownSources") {
    await this.invoke("openSystemSettings", [section]);
  }

  async setPerformanceMode(mode: "performance" | "balanced" | "visual") {
    const result = (await this.invoke("setPerformanceMode", [mode])) as { applied?: boolean; note?: string };
    return { applied: result?.applied !== false, note: result?.note ?? "" };
  }

  async startDownload(url: string, filename?: string, mime = "application/octet-stream"): Promise<NativeDownload> {
    const result = (await this.invoke("startDownload", [url, filename ?? "", mime, ""])) as Partial<NativeDownload> & { download?: Partial<NativeDownload> };
    return normalizeDownload(result.download ?? result);
  }

  async getNativeDownloads(): Promise<NativeDownload[]> {
    const result = (await this.invoke("getNativeDownloads", [])) as { downloads?: Partial<NativeDownload>[] };
    return (result.downloads ?? []).map(normalizeDownload);
  }

  async controlDownload(id: number, action: "cancel" | "retry" | "remove"): Promise<boolean> {
    const result = (await this.invoke("controlDownload", [id, action])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async openDownload(id: number): Promise<boolean> {
    const result = (await this.invoke("openDownload", [id])) as { opened?: boolean; message?: string };
    if (result?.message && !result.opened) throw new Error(result.message);
    return Boolean(result?.opened);
  }

  async installApk(uri: string): Promise<boolean> {
    const result = (await this.invoke("installApk", [uri])) as { opened?: boolean; message?: string };
    if (result?.message && !result.opened) throw new Error(result.message);
    return Boolean(result?.opened);
  }

  async browserOpen(url: string, options: { desktopMode?: boolean; privateMode?: boolean } = {}) {
    return (await this.invoke("browserOpen", [url, Boolean(options.desktopMode ?? true), Boolean(options.privateMode ?? false)])) as NativeBrowserState;
  }

  async browserNavigate(url: string) {
    return (await this.invoke("browserNavigate", [url])) as NativeBrowserState;
  }

  async browserCommand(command: "back" | "forward" | "reload" | "close" | "focus" | "state") {
    return (await this.invoke(`browser${command[0].toUpperCase()}${command.slice(1)}` as NativeMethod, [])) as Partial<NativeBrowserState>;
  }

  async browserSetDesktopMode(desktop: boolean) {
    return (await this.invoke("browserSetDesktopMode", [desktop])) as NativeBrowserState;
  }

  private overlay = { visible: false, left: 0, top: 0, width: 0, height: 0 };

  isBrowserOverlayVisible(): boolean {
    return this.overlay.visible;
  }

  isPointInBrowserOverlay(x: number, y: number): boolean {
    const o = this.overlay;
    return o.visible && x >= o.left && x <= o.left + o.width && y >= o.top && y <= o.top + o.height;
  }

  setBrowserBounds(bounds: { left: number; top: number; width: number; height: number; visible: boolean; dpr: number }) {
    this.overlay = {
      visible: Boolean(bounds.visible && bounds.width > 0 && bounds.height > 0),
      left: bounds.left,
      top: bounds.top,
      width: bounds.width,
      height: bounds.height,
    };
    void this.invoke("browserSetBounds", [Math.round(bounds.left), Math.round(bounds.top), Math.round(bounds.width), Math.round(bounds.height), bounds.visible, bounds.dpr]).catch(() => {
      this.overlay.visible = false;
    });
  }

  async browserInput(action: "move" | "click" | "rightClick" | "scroll" | "text" | "key" | "doubleClick", x = 0, y = 0, value = "") {
    return (await this.invoke("browserInput", [action, Math.round(x), Math.round(y), value])) as { ok?: boolean };
  }

  async setDownloadFolder(folder: string): Promise<boolean> {
    const result = (await this.invoke("setDownloadFolder", [folder])) as { ok?: boolean; folder?: string };
    return result?.ok !== false;
  }

  async relayToDesktop(message: Record<string, unknown>): Promise<boolean> {
    const result = (await this.invoke("relayToDesktop", [JSON.stringify(message)])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async setFullscreen(enabled: boolean): Promise<boolean> {
    if (!this.getState().available) return false;
    const result = (await this.invoke("setFullscreen", [Boolean(enabled)])) as { ok?: boolean; enabled?: boolean };
    return result?.ok !== false;
  }

  async terminalStart(cwd?: string): Promise<TerminalSession> {
    const result = (await this.invoke("terminalStart", [cwd ?? ""])) as Partial<TerminalSession>;
    return { id: String(result.id ?? "main"), cwd: String(result.cwd ?? ""), alive: result.alive !== false, pid: result.pid };
  }

  async terminalExec(sessionId: string, command: string, timeoutMs = 60_000): Promise<TerminalResult> {
    const result = (await this.invoke("terminalExec", [sessionId, command], { timeout: timeoutMs })) as Partial<TerminalResult>;
    return {
      stdout: String(result.stdout ?? ""),
      stderr: String(result.stderr ?? ""),
      exitCode: Number(result.exitCode ?? 0),
      cwd: String(result.cwd ?? ""),
      durationMs: Number(result.durationMs ?? 0),
    };
  }

  async terminalInterrupt(sessionId: string): Promise<boolean> {
    const result = (await this.invoke("terminalInterrupt", [sessionId])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async terminalList(): Promise<TerminalSession[]> {
    const result = (await this.invoke("terminalList", [])) as { sessions?: Partial<TerminalSession>[] };
    return (result.sessions ?? []).map((session) => ({
      id: String(session.id ?? "main"),
      cwd: String(session.cwd ?? ""),
      alive: session.alive !== false,
      pid: session.pid,
    }));
  }

  async runtimeInfo(): Promise<RuntimeInfo> {
    const result = (await this.invoke("runtimeInfo", [])) as Partial<RuntimeInfo>;
    return {
      shell: String(result.shell ?? "sh"),
      shellPath: String(result.shellPath ?? ""),
      runtimes: (result.runtimes ?? []).map((runtime) => ({
        name: String(runtime.name),
        available: Boolean(runtime.available),
        version: runtime.version,
        path: runtime.path,
        note: runtime.note,
      })),
      packageManager: {
        name: String(result.packageManager?.name ?? "none"),
        available: Boolean(result.packageManager?.available),
        note: String(result.packageManager?.note ?? "No package manager is installed in this environment."),
      },
      userland: {
        available: Boolean(result.userland?.available),
        note: String(result.userland?.note ?? "No Linux userland bootstrap is bundled."),
      },
      cpuAbi: String(result.cpuAbi ?? ""),
      apiLevel: Number(result.apiLevel ?? 0),
    };
  }

  async relayToController(message: Record<string, unknown>): Promise<boolean> {
    if (!this.getState().available) return false;
    const result = (await this.invoke("relayToController", [JSON.stringify(message)])) as { ok?: boolean };
    return result?.ok !== false;
  }

  async exec(command: string, runtime: "shell" | "python" | "node" | "git"): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    const result = (await this.invoke("exec", [command, runtime])) as { stdout?: string; stderr?: string; exitCode?: number };
    return { stdout: result.stdout ?? "", stderr: result.stderr ?? "", exitCode: result.exitCode ?? 0 };
  }
}

export interface NativeBridgeState {
  available: boolean;
  ready: boolean;
  checking: boolean;
  capabilities: NativeCapabilities;
  error: string | null;
}

export const nativeBridge = new NativeBridge();

function normalizeDownload(input: Partial<NativeDownload>): NativeDownload {
  const total = Number(input.totalBytes ?? 0);
  const downloaded = Number(input.bytesDownloaded ?? 0);
  return {
    id: Number(input.id ?? 0),
    uri: String(input.uri ?? ""),
    name: String(input.name ?? "Download"),
    mime: String(input.mime ?? "application/octet-stream"),
    status: (input.status ?? "pending") as NativeDownload["status"],
    bytesDownloaded: downloaded,
    totalBytes: total,
    progress: Number(input.progress ?? (total > 0 ? Math.round((downloaded / total) * 100) : 0)),
    speedBytesPerSecond: Number(input.speedBytesPerSecond ?? 0),
    reason: input.reason,
    localUri: input.localUri,
    destination: String(input.destination ?? "Download/KK DEX"),
  };
}

type BrowserListener = (event: BrowserEvent) => void;
const browserListeners = new Set<BrowserListener>();
const hostListeners = new Set<(message: Record<string, unknown>) => void>();

export function subscribeBrowserEvents(listener: BrowserListener): () => void {
  browserListeners.add(listener);
  return () => browserListeners.delete(listener);
}

export function subscribeHostMessages(listener: (message: Record<string, unknown>) => void): () => void {
  hostListeners.add(listener);
  return () => hostListeners.delete(listener);
}

const terminalListeners = new Set<(event: TerminalEvent) => void>();
export function subscribeTerminalEvents(listener: (event: TerminalEvent) => void): () => void {
  terminalListeners.add(listener);
  return () => terminalListeners.delete(listener);
}

function installEventReceivers() {
  if (typeof window === "undefined") return;
  const scope = window as unknown as Record<string, unknown>;
  if (typeof scope.KKDexBrowserEvent !== "function") {
    scope.KKDexBrowserEvent = (payload: unknown) => {
      try {
        const event = parse<BrowserEvent>(payload);
        browserListeners.forEach((listener) => listener(event));
      } catch {
        /* Invalid native browser events are ignored. */
      }
    };
  }
  if (typeof scope.KKDexTerminalEvent !== "function") {
    scope.KKDexTerminalEvent = (payload: unknown) => {
      try {
        const event = parse<TerminalEvent>(payload);
        terminalListeners.forEach((listener) => listener(event));
      } catch {
        /* Invalid terminal stream events are ignored. */
      }
    };
  }
  if (typeof scope.KKDexHostMessage !== "function") {
    scope.KKDexHostMessage = (payload: unknown) => {
      try {
        const message = parse<Record<string, unknown>>(payload);
        hostListeners.forEach((listener) => listener(message));
      } catch {
        /* Invalid host relay messages are ignored. */
      }
    };
  }
}

if (typeof window !== "undefined") installEventReceivers();

export function nativeKindLabel(kind: NativeFile["kind"]): string {
  return {
    folder: "Folder",
    image: "Image",
    video: "Video",
    audio: "Audio",
    document: "Document",
    pdf: "PDF document",
    archive: "Archive",
    apk: "Android package",
    file: "File",
  }[kind];
}

export function browserImport(accept = "*/*", multiple = true): Promise<File[]> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = accept;
    input.multiple = multiple;
    input.style.display = "none";
    document.body.appendChild(input);
    let settled = false;
    const finish = (files: File[]) => {
      if (settled) return;
      settled = true;
      input.remove();
      resolve(files);
    };
    input.onchange = () => finish(Array.from(input.files ?? []));
    input.oncancel = () => finish([]);
    window.addEventListener(
      "focus",
      () => {
        window.setTimeout(() => finish(Array.from(input.files ?? [])), 350);
      },
      { once: true },
    );
    input.click();
  });
}

export function readBrowserFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

export function readBrowserFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsText(file);
  });
}
