import type { AppId, AppMeta } from "./types";

const meta = (
  id: AppId,
  name: string,
  category: AppMeta["category"],
  description: string,
  defaultSize: [number, number],
  minSize: [number, number],
  pinned = false,
  desktop = true,
  keywords: string[] = [],
): AppMeta => ({ id, name, category, description, defaultSize, minSize, pinned, desktop, keywords });

export const APP_METAS: Record<AppId, AppMeta> = {
  thispc: meta("thispc", "This PC", "System", "Device, display and storage overview.", [780, 540], [560, 380], false, true, ["computer", "system", "device"]),
  files: meta("files", "Files", "System", "Browse and manage your KK DEX workspace.", [900, 590], [620, 400], true, true, ["explorer", "documents", "storage"]),
  browser: meta("browser", "Browser", "Media", "Browse the web in a tabbed desktop browser.", [1000, 650], [640, 420], true, true, ["web", "internet", "chrome"]),
  ai: meta("ai", "KK AI", "AI", "Your on-device assistant console.", [860, 610], [600, 420], true, true, ["assistant", "chat", "intelligence"]),
  appcenter: meta("appcenter", "App Center", "System", "Discover and launch KK DEX applications.", [880, 600], [620, 420], false, true, ["store", "apps", "install"]),
  settings: meta("settings", "Settings", "System", "Personalize and configure KK DEX.", [900, 620], [640, 440], true, true, ["preferences", "theme", "display"]),
  gallery: meta("gallery", "Gallery", "Media", "Browse and view your photo collection.", [920, 620], [600, 420], false, true, ["photos", "images", "pictures"]),
  notes: meta("notes", "Notes", "Productivity", "Capture ideas, lists and quick thoughts.", [760, 540], [560, 380], false, true, ["notepad", "text", "write"]),
  calculator: meta("calculator", "Calculator", "Utilities", "A precise calculator with history.", [380, 580], [320, 500], true, true, ["math", "numbers", "sum"]),
  terminal: meta("terminal", "Terminal", "Utilities", "A sandboxed KK DEX workspace shell.", [770, 500], [520, 320], true, true, ["shell", "command", "console"]),
  recycle: meta("recycle", "Recycle Bin", "System", "Restore or permanently remove deleted items.", [760, 520], [560, 380], false, true, ["trash", "deleted", "restore"]),
  phone: meta("phone", "Phone Controller", "Utilities", "Pair your Android phone as a touchpad and keyboard.", [780, 600], [600, 440], false, false, ["remote", "touchpad", "controller", "android"]),
  downloads: meta("downloads", "Downloads", "System", "Review transferred, downloaded and exported files.", [830, 560], [580, 380], false, false, ["transfer", "saved", "export"]),
  media: meta("media", "Media Player", "Media", "Play audio and video from authorized device storage.", [860, 580], [560, 400], false, false, ["music", "video", "audio", "player"]),
  pdf: meta("pdf", "PDF Viewer", "Media", "Open and inspect PDF documents from device storage.", [880, 620], [560, 420], false, false, ["document", "reader"]),
  archive: meta("archive", "Archive Manager", "Utilities", "Inspect and extract ZIP archives into the workspace.", [860, 580], [580, 400], false, false, ["zip", "extract", "compress"]),
  developer: meta("developer", "Developer", "Utilities", "Run JavaScript locally and execute supported native runtimes.", [900, 600], [620, 420], false, false, ["code", "python", "node", "git", "shell", "terminal"]),
  games: meta("games", "Gaming Centre", "Media", "Game library, Android games, discovery and performance modes.", [980, 640], [700, 460], true, true, ["games", "gaming", "library", "performance", "launcher"]),
  storage: meta("storage", "Storage Manager", "System", "Real Android storage totals, categories and file access.", [920, 620], [660, 440], false, true, ["storage", "disk", "samsung", "space", "device"]),
};

export const DESKTOP_APPS: AppId[] = [
  "thispc",
  "files",
  "browser",
  "ai",
  "appcenter",
  "settings",
  "gallery",
  "notes",
  "calculator",
  "terminal",
  "recycle",
  "media",
  "games",
  "storage",
];

export const DEFAULT_PINS: AppId[] = ["files", "browser", "ai", "calculator", "settings", "terminal"];
export const ALL_APP_IDS = Object.keys(APP_METAS) as AppId[];
export const VISIBLE_APP_IDS = ALL_APP_IDS.filter((id) => id !== "phone");
export const EXTRA_DESKTOP_APPS: AppId[] = DESKTOP_APPS.concat(["media", "downloads"]);
