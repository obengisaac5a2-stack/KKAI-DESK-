import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  BookmarkPlus,
  ChevronRight,
  Clock3,
  Download,
  ExternalLink,
  Globe,
  Home,
  Info,
  Lock,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  Shield,
  ShieldAlert,
  Star,
  Trash2,
  User,
  X,
} from "lucide-react";
import { AppIcon } from "../icons";
import {
  nativeBridge,
  subscribeBrowserEvents,
  type BrowserEvent,
  type NativeBrowserState,
} from "../native";
import { useOS } from "../OSContext";
import type { AppContentProps } from "../types";
import { useNativeState } from "../NativeStorage";
import { Segmented } from "../ui";
import { cn } from "@/utils/cn";

const HOME_URL = "kkdex://home";
const SEARCH_URL = "https://www.google.com/search?q=";
const HOME_LABEL = "KK DEX start page";

interface Tab {
  id: string;
  title: string;
  url: string;
  history: string[];
  index: number;
  reloadKey: number;
  nativeHasPage: boolean;
}

interface HistoryEntry {
  url: string;
  title: string;
  visitedAt: number;
}

const uid = () => `tab-${Math.random().toString(36).slice(2, 9)}`;

function makeTab(url = HOME_URL): Tab {
  return { id: uid(), title: "New tab", url, history: [url], index: 0, reloadKey: 0, nativeHasPage: false };
}

function titleFor(url: string) {
  if (url === HOME_URL) return "New tab";
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "Page";
  }
}

function normalizeUrl(raw: string): string {
  const value = raw.trim();
  if (!value) return HOME_URL;
  if (value.startsWith("kkdex://")) return HOME_URL;
  if (/^https?:\/\//i.test(value)) return value;
  if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/.test(value)) return `https://${value}`;
  return `${SEARCH_URL}${encodeURIComponent(value)}`;
}

function loadList<T>(key: string, fallback: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T[]) : fallback;
  } catch {
    return fallback;
  }
}

const QUICK_LINKS = [
  { name: "YouTube", url: "https://www.youtube.com", color: "#ff4d4f", letter: "▶" },
  { name: "Google", url: "https://www.google.com", color: "#4f8cff", letter: "G" },
  { name: "Facebook", url: "https://www.facebook.com", color: "#1877f2", letter: "f" },
  { name: "TikTok", url: "https://www.tiktok.com", color: "#f4f4f5", letter: "♪" },
  { name: "Audiomack", url: "https://audiomack.com", color: "#ffa31a", letter: "A" },
  { name: "GitHub", url: "https://github.com", color: "#a78bfa", letter: "◖" },
  { name: "Wikipedia", url: "https://www.wikipedia.org", color: "#94a3b8", letter: "W" },
  { name: "MDN", url: "https://developer.mozilla.org", color: "#5e8bff", letter: "M" },
];

export function BrowserApp({ windowId, payload }: AppContentProps) {
  const { launch, showInfo, notify, openMenu, activeWindow, menu, panel, startOpen, taskViewOpen, settings, dialog } = useOS();
  const native = useNativeState();
  const nativeBrowser = native.available && native.capabilities.browser;
  const initialUrl = typeof payload?.url === "string" ? normalizeUrl(payload.url) : HOME_URL;
  const [tabs, setTabs] = useState<Tab[]>(() => [makeTab(initialUrl)]);
  const [activeId, setActiveId] = useState(() => tabs[0].id);
  const [address, setAddress] = useState(initialUrl === HOME_URL ? "" : initialUrl);
  const [addressFocused, setAddressFocused] = useState(false);
  const [nativeState, setNativeState] = useState<NativeBrowserState | null>(null);
  const [sidePanel, setSidePanel] = useState<null | "bookmarks" | "history" | "settings" | "downloads">(null);
  const [desktopMode, setDesktopMode] = useState(settings.desktopUserAgent);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [activeHomeInput, setActiveHomeInput] = useState("");
  const [bookmarks, setBookmarks] = useState<{ url: string; title: string }[]>(() => loadList("kkdex.browserBookmarks", []));
  const [history, setHistory] = useState<HistoryEntry[]>(() => loadList("kkdex.browserHistory", []));
  const [permissionNotice, setPermissionNotice] = useState("");
  const contentRef = useRef<HTMLDivElement>(null);
  const addressRef = useRef<HTMLInputElement>(null);
  const sessionRef = useRef(false);
  const active = tabs.find((tab) => tab.id === activeId) ?? tabs[0];
  const activeTabRef = useRef(active);
  activeTabRef.current = active;
  const isActive = activeWindow?.id === windowId && !menu && !panel && !startOpen && !taskViewOpen && !dialog;

  useEffect(() => {
    localStorage.setItem("kkdex.browserBookmarks", JSON.stringify(bookmarks));
  }, [bookmarks]);
  useEffect(() => {
    localStorage.setItem("kkdex.browserHistory", JSON.stringify(history.slice(0, 80)));
  }, [history]);

  const updateTab = (id: string, patch: Partial<Tab>) => {
    setTabs((prev) => prev.map((tab) => (tab.id === id ? { ...tab, ...patch } : tab)));
  };

  const pushHistory = (url: string, title = titleFor(url)) => {
    setHistory((prev) => [{ url, title, visitedAt: Date.now() }, ...prev.filter((item) => item.url !== url)].slice(0, 120));
  };

  const recordUrl = (tabId: string, url: string, title?: string) => {
    updateTab(tabId, { url, title: title ?? titleFor(url), nativeHasPage: true });
    if (url !== HOME_URL) pushHistory(url, title);
    setAddress(url === HOME_URL ? "" : url);
    setError("");
  };

  // Create or attach the native browser on first mount.
  useEffect(() => {
    if (!nativeBrowser || sessionRef.current) return;
    sessionRef.current = true;
    const url = active.url === HOME_URL ? "https://www.google.com" : active.url;
    nativeBridge
      .browserOpen(url, { desktopMode })
      .then((state) => {
        setNativeState(state);
        recordUrl(active.id, state.url || url, state.title);
        setLoading(Boolean(state.loading));
      })
      .catch((err) => setError(err instanceof Error ? err.message : "The native browser session could not start."));
    return () => {
      sessionRef.current = false;
      void nativeBridge.browserCommand("close").catch(() => undefined);
    };
    // Session lifetime is tied to the browser window, not tab changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nativeBrowser]);

  useEffect(() => {
    const unsubscribe = subscribeBrowserEvents((event: BrowserEvent) => {
      if (event.type === "state") {
        const state = event.state;
        setNativeState(state);
        const current = activeTabRef.current;
        setLoading(Boolean(state.loading));
        if (state.error) setError(state.error);
        if (state.url) {
          setAddress(state.url);
          setTabs((prev) =>
            prev.map((tab) =>
              tab.id === current.id
                ? {
                    ...tab,
                    url: state.url,
                    title: state.title || titleFor(state.url),
                    nativeHasPage: true,
                  }
                : tab,
            ),
          );
        }
      } else if (event.type === "download") {
        notify("Browser download", `${event.download.name} is being saved to ${event.download.destination}.`, { silent: true, tone: "success" });
      } else if (event.type === "new-tab") {
        const tab = makeTab(normalizeUrl(event.url));
        setTabs((prev) => [...prev, tab]);
        setActiveId(tab.id);
        void nativeBridge.browserNavigate(tab.url).catch((err) => setError(err.message));
      } else if (event.type === "permission") {
        setPermissionNotice(`${event.origin} requested ${event.resources}. Website permissions are approved by Android's runtime permission prompt.`);
      }
    });
    return () => {
      unsubscribe();
    };
  }, [notify]);

  // Keep the native WebView aligned exactly with the browser content area.
  useEffect(() => {
    if (!nativeBrowser) return;
    const element = contentRef.current;
    if (!element) return;
    let frame = 0;
    const sync = () => {
      const rect = element.getBoundingClientRect();
      const homePage = activeTabRef.current.url === HOME_URL;
      const visible = isActive && !sidePanel && !homePage && !error;
      nativeBridge.setBrowserBounds({
        left: rect.left,
        top: rect.top,
        width: rect.width,
        height: rect.height,
        visible,
        dpr: window.devicePixelRatio || 1,
      });
    };
    const schedule = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(sync);
    };
    schedule();
    const observer = new ResizeObserver(schedule);
    observer.observe(element);
    // Window position changes do not fire ResizeObserver; poll lightly while active.
    const follow = window.setInterval(schedule, 140);
    window.addEventListener("resize", schedule);
    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
      window.clearInterval(follow);
      window.removeEventListener("resize", schedule);
      nativeBridge.setBrowserBounds({ left: 0, top: 0, width: 0, height: 0, visible: false, dpr: window.devicePixelRatio || 1 });
    };
  }, [nativeBrowser, isActive, sidePanel, dialog, active.url, error]);

  useEffect(() => {
    setAddress(active.url === HOME_URL ? "" : active.url);
    if (!active.url.startsWith("kkdex://")) setAddress(active.url);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeId]);

  useEffect(() => {
    if (typeof payload?.url === "string") {
      void navigateTo(normalizeUrl(payload.url), true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payload?.url]);

  const navigateTo = async (url: string, push = true) => {
    const tab = activeTabRef.current;
    const historyList = push ? [...tab.history.slice(0, tab.index + 1), url] : tab.history;
    const nextTab: Tab = {
      ...tab,
      url,
      title: titleFor(url),
      history: historyList,
      index: push ? historyList.length - 1 : tab.index,
      nativeHasPage: url !== HOME_URL,
      reloadKey: tab.reloadKey + 1,
    };
    setTabs((prev) => prev.map((item) => (item.id === tab.id ? nextTab : item)));
    setAddress(url === HOME_URL ? "" : url);
    setLoading(url !== HOME_URL);
    setError("");
    setAddressFocused(false);
    addressRef.current?.blur();
    if (url !== HOME_URL) pushHistory(url);
    if (nativeBrowser && url !== HOME_URL) {
      try {
        const state = await nativeBridge.browserNavigate(url);
        setNativeState(state ?? null);
        setLoading(Boolean(state?.loading));
        if (state?.url) {
          setTabs((prev) =>
            prev.map((item) => (item.id === tab.id ? { ...item, url: state.url, title: state.title || titleFor(state.url) } : item)),
          );
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "The native browser could not load this page.");
        setLoading(false);
      }
    } else if (nativeBrowser && url === HOME_URL) {
      nativeBridge.setBrowserBounds({ left: 0, top: 0, width: 0, height: 0, visible: false, dpr: window.devicePixelRatio || 1 });
      await nativeBridge.browserCommand("focus").catch(() => undefined);
    }
  };

  const submitAddress = () => {
    const target = normalizeUrl(address);
    void navigateTo(target);
  };

  const newTab = (url = HOME_URL) => {
    const tab = makeTab(url);
    setTabs((prev) => [...prev, tab]);
    setActiveId(tab.id);
    setAddress(url === HOME_URL ? "" : url);
    if (nativeBrowser && url !== HOME_URL) void nativeBridge.browserNavigate(url).catch((err) => setError(err.message));
  };

  const closeTab = (id: string) => {
    const remaining = tabs.filter((tab) => tab.id !== id);
    if (remaining.length === 0) {
      const fresh = makeTab();
      setTabs([fresh]);
      setActiveId(fresh.id);
      return;
    }
    if (id === activeId) {
      const index = tabs.findIndex((tab) => tab.id === id);
      const next = remaining[Math.max(0, index - 1)];
      setActiveId(next.id);
      if (nativeBrowser && next.url !== HOME_URL) void nativeBridge.browserNavigate(next.url).catch((err) => setError(err.message));
    }
    setTabs(remaining);
  };

  const switchTab = (id: string) => {
    const tab = tabs.find((item) => item.id === id);
    if (!tab) return;
    setActiveId(id);
    setSidePanel(null);
    if (nativeBrowser && tab.url !== HOME_URL) {
      setLoading(true);
      void nativeBridge
        .browserNavigate(tab.url)
        .then((state) => {
          setNativeState(state ?? null);
          setLoading(Boolean(state?.loading));
        })
        .catch((err) => {
          setError(err instanceof Error ? err.message : "The tab could not be restored.");
          setLoading(false);
        });
    }
  };

  const goBack = async () => {
    if (nativeBrowser && nativeState?.canGoBack) {
      try {
        const state = await nativeBridge.browserCommand("back");
        if (state?.url) {
          setNativeState((prev) => (prev ? { ...prev, ...state } : prev));
          setTabs((prev) => prev.map((tab) => (tab.id === active.id ? { ...tab, url: state.url!, title: state.title || tab.title } : tab)));
          setAddress(state.url);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Back navigation failed.");
      }
      return;
    }
    if (active.index <= 0) return;
    const index = active.index - 1;
    const tab = { ...active, index, url: active.history[index], title: titleFor(active.history[index]), nativeHasPage: active.history[index] !== HOME_URL };
    updateTab(active.id, tab);
    setAddress(tab.url === HOME_URL ? "" : tab.url);
    if (nativeBrowser && tab.url !== HOME_URL) void nativeBridge.browserNavigate(tab.url).catch((err) => setError(err.message));
  };

  const goForward = async () => {
    if (nativeBrowser && nativeState?.canGoForward) {
      try {
        const state = await nativeBridge.browserCommand("forward");
        if (state?.url) {
          setNativeState((prev) => (prev ? { ...prev, ...state } : prev));
          setTabs((prev) => prev.map((tab) => (tab.id === active.id ? { ...tab, url: state.url!, title: state.title || tab.title } : tab)));
          setAddress(state.url);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Forward navigation failed.");
      }
      return;
    }
    if (active.index >= active.history.length - 1) return;
    const index = active.index + 1;
    const tab = { ...active, index, url: active.history[index], title: titleFor(active.history[index]), nativeHasPage: active.history[index] !== HOME_URL };
    updateTab(active.id, tab);
    setAddress(tab.url === HOME_URL ? "" : tab.url);
    if (nativeBrowser && tab.url !== HOME_URL) void nativeBridge.browserNavigate(tab.url).catch((err) => setError(err.message));
  };

  const reload = async () => {
    setLoading(true);
    setError("");
    if (nativeBrowser) {
      try {
        const state = await nativeBridge.browserCommand("reload");
        setNativeState((prev) => (prev ? { ...prev, ...state } : prev));
      } catch (err) {
        setError(err instanceof Error ? err.message : "Refresh failed.");
      } finally {
        setLoading(false);
      }
    } else {
      updateTab(active.id, { reloadKey: active.reloadKey + 1 });
      window.setTimeout(() => setLoading(false), 800);
    }
  };

  const toggleDesktop = async () => {
    const next = !desktopMode;
    setDesktopMode(next);
    if (!nativeBrowser) {
      notify("Desktop site mode unavailable", "The browser preview cannot change a website's user agent. Enable it in the Android WebView host.", { tone: "error" });
      return;
    }
    try {
      await nativeBridge.browserSetDesktopMode(next);
      notify(next ? "Desktop site enabled" : "Mobile site enabled", "The native browser user agent was updated and the page will reload.", { silent: true });
      await reload();
    } catch (err) {
      notify("User agent change failed", err instanceof Error ? err.message : "The host rejected the request.", { tone: "error" });
    }
  };

  const toggleBookmark = () => {
    if (active.url === HOME_URL) return;
    const exists = bookmarks.some((bookmark) => bookmark.url === active.url);
    setBookmarks((prev) => (exists ? prev.filter((bookmark) => bookmark.url !== active.url) : [{ url: active.url, title: active.title }, ...prev].slice(0, 60)));
    notify(exists ? "Bookmark removed" : "Bookmarked", active.title, { silent: true });
  };

  const openPage = (url: string) => {
    setSidePanel(null);
    void navigateTo(normalizeUrl(url));
  };

  const externalOpen = () => {
    const url = active.url === HOME_URL ? "https://www.google.com" : active.url;
    if (nativeBrowser) {
      showInfo("Native browsing is active", "This page is rendered by KK DEX's native WebView. It is already the real browsing environment, so opening it externally would leave the desktop and is not required for rendering.", <Globe size={24} />);
      return;
    }
    const popup = window.open(url, "_blank", "noopener,noreferrer");
    if (!popup) notify("Pop-up blocked", "Allow pop-ups, or run the Android host for the native browser.", { tone: "error" });
  };

  const browserMenu = (event: React.MouseEvent) => {
    event.preventDefault();
    openMenu(event.clientX, event.clientY, [
      { label: "New tab", icon: <Plus size={14} />, action: () => newTab() },
      { label: "Reload", icon: <RefreshCw size={14} />, action: () => void reload() },
      { label: "Bookmark this page", icon: <BookmarkPlus size={14} />, disabled: active.url === HOME_URL, action: toggleBookmark },
      { separator: true },
      { label: "Bookmarks", icon: <Bookmark size={14} />, action: () => setSidePanel("bookmarks") },
      { label: "History", icon: <Clock3 size={14} />, action: () => setSidePanel("history") },
      { label: "Downloads", icon: <Download size={14} />, action: () => { launch("downloads", { payload: { tab: "android" } }); } },
      { separator: true },
      { label: "Browser settings", icon: <Settings2 size={14} />, action: () => setSidePanel("settings") },
      { label: "Open page externally", icon: <ExternalLink size={14} />, action: externalOpen },
    ], active.title);
  };

  const pageLoading = loading || Boolean(nativeState?.loading);
  const currentUrl = active.url;
  const startPage = currentUrl === HOME_URL;
  const secure = currentUrl.startsWith("https://");

  const downloadsHref = () => {
    setSidePanel("downloads");
  };

  return (
    <div className="relative flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex h-[32px] shrink-0 items-end gap-1 px-2 pt-1.5" style={{ background: "var(--surface-2)" }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={cn("group relative flex h-[29px] max-w-[190px] min-w-[104px] items-center gap-1.5 rounded-t-lg px-2 text-left text-[10.5px]", tab.id === activeId ? "bg-[var(--surface-solid)]" : "opacity-70 hover:opacity-100")}
            style={{ border: "1px solid var(--border)", borderBottom: tab.id === activeId ? "1px solid var(--surface-solid)" : "1px solid var(--border)" }}
            onClick={() => switchTab(tab.id)}
            onAuxClick={(event) => { if (event.button === 1) closeTab(tab.id); }}
          >
            {tab.url === HOME_URL ? <Search size={11} style={{ color: "var(--muted)" }} /> : secureFor(tab.url) ? <Lock size={10} style={{ color: "var(--success)" }} /> : <Globe size={11} style={{ color: "var(--muted)" }} />}
            <span className="min-w-0 flex-1 truncate">{tab.title || titleFor(tab.url)}</span>
            <span role="button" tabIndex={0} aria-label={`Close ${tab.title}`} className="flex h-4 w-4 shrink-0 items-center justify-center rounded opacity-0 hover:bg-[var(--hover)] group-hover:opacity-100" onClick={(event) => { event.stopPropagation(); closeTab(tab.id); }}>
              <X size={10} />
            </span>
          </button>
        ))}
        <button className="icon-btn mb-1 h-6 w-6" aria-label="New tab" onClick={() => newTab()}><Plus size={13} /></button>
        <button className="icon-btn mb-1 ml-auto hidden h-6 w-6 sm:flex" title={nativeBrowser ? "Native WebView browser" : "Preview browser"} aria-label="Browser engine status" onClick={() => showInfo(nativeBrowser ? "Native browser engine active" : "Browser preview mode", nativeBrowser ? "This browser is rendered with Android's WebView, not an iframe. JavaScript, cookies, local storage, HTML5 media, file uploads, popups and downloads are handled by the native engine. Some sites may still block WebView sign-in or require codecs/DRM the host lacks; KK DEX reports those cases honestly." : "A web page cannot bypass X-Frame-Options or CSP for embedded sites. This is a visual preview only. Run KK DEX inside the Android host to activate the real WebView-backed browser with keyboard, cookies, downloads and YouTube playback.", <Shield size={22} />)}>
          {nativeBrowser ? <Shield size={12} style={{ color: "var(--success)" }} /> : <ShieldAlert size={12} style={{ color: "#f5b84a" }} />}
        </button>
      </div>

      <div className="flex shrink-0 items-center gap-1 px-2 py-1.5" style={{ borderBottom: "1px solid var(--border)" }}>
        <button className="icon-btn h-7 w-7" aria-label="Back" disabled={nativeBrowser ? !nativeState?.canGoBack && active.index <= 0 : active.index <= 0} onClick={() => void goBack()}><ArrowLeft size={14} /></button>
        <button className="icon-btn h-7 w-7" aria-label="Forward" disabled={nativeBrowser ? !nativeState?.canGoForward : active.index >= active.history.length - 1} onClick={() => void goForward()}><ArrowRight size={14} /></button>
        <button className="icon-btn h-7 w-7" aria-label="Reload" onClick={() => void reload()}><RefreshCw size={13} className={pageLoading ? "animate-spin" : ""} /></button>
        <button className="icon-btn h-7 w-7" aria-label="Home" onClick={() => void navigateTo(HOME_URL)}><Home size={13} /></button>
        <div className={cn("flex h-7 min-w-0 flex-1 items-center gap-1.5 rounded-full px-2.5 transition-all", addressFocused && "ring-2")} style={{ background: "var(--field)", border: "1px solid var(--border-strong)", boxShadow: addressFocused ? "0 0 0 3px rgba(var(--accent-rgb),.12)" : undefined }}>
          {startPage ? <Search size={12} style={{ color: "var(--faint)" }} /> : secure ? <Lock size={11} style={{ color: "var(--success)" }} /> : <Globe size={11} style={{ color: "var(--muted)" }} />}
          <input
            ref={addressRef}
            value={address}
            placeholder="Search Google or type a URL"
            className="min-w-0 flex-1 border-0 bg-transparent text-[11.5px] outline-none placeholder:text-[var(--faint)]"
            onChange={(event) => setAddress(event.target.value)}
            onFocus={(event) => { setAddressFocused(true); event.target.select(); }}
            onBlur={() => setAddressFocused(false)}
            onKeyDown={(event) => {
              if (event.key === "Enter") submitAddress();
              if (event.key === "Escape") { setAddress(active.url === HOME_URL ? "" : active.url); event.currentTarget.blur(); }
            }}
          />
          {pageLoading ? <span className="text-[8.5px] tabular-nums" style={{ color: "var(--muted)" }}>{nativeState?.progress ?? 20}%</span> : null}
          {!startPage ? <button className={cn("icon-btn h-5 w-5", bookmarks.some((b) => b.url === active.url) && "text-[var(--accent)]")} aria-label="Bookmark page" onClick={toggleBookmark}><Star size={11} fill={bookmarks.some((b) => b.url === active.url) ? "currentColor" : "none"} /></button> : null}
          <button className="icon-btn h-5 w-5" aria-label="Browser options" onClick={browserMenu}><MoreHorizontal size={12} /></button>
        </div>
        <button className="icon-btn h-7 w-7" title="Downloads" onClick={downloadsHref}><Download size={13} /></button>
        <button className={cn("icon-btn h-7 w-7", desktopMode && "text-[var(--accent)]")} title={desktopMode ? "Desktop site on" : "Mobile site"} aria-label="Desktop site mode" onClick={() => void toggleDesktop()}><User size={13} /></button>
        <button className="icon-btn h-7 w-7" title="Open externally" onClick={externalOpen}><ExternalLink size={13} /></button>
      </div>

      <div className="flex h-6 shrink-0 items-center gap-2 px-3 text-[8.5px]" style={{ background: "var(--surface-2)", borderBottom: "1px solid var(--border)", color: "var(--muted)" }}>
        {nativeBrowser ? <><Shield size={9} style={{ color: "var(--success)" }} /> Native WebView engine · cookies, JavaScript, media and downloads active</> : <><ShieldAlert size={9} style={{ color: "#f5b84a" }} /> Preview engine (iframe) · some sites block embedding · native Android host recommended</>}
        {nativeState?.progress && pageLoading ? <span className="ml-2 h-1 w-24 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}><span className="block h-full rounded-full" style={{ width: `${nativeState.progress}%`, background: "var(--accent)" }} /></span> : null}
        <span className="ml-auto hidden items-center gap-2 md:flex">
          {permissionNotice ? <span className="truncate text-[#f3d18b]">{permissionNotice}</span> : <span>{desktopMode ? "Desktop site" : "Mobile site"} · Physical keyboard & mouse supported in native mode</span>}
        </span>
      </div>

      <div ref={contentRef} className="relative min-h-0 flex-1 overflow-hidden" style={{ background: startPage ? "var(--surface-solid)" : "#fff" }}>
        {startPage ? <StartPage query={activeHomeInput} setQuery={setActiveHomeInput} onNavigate={openPage} bookmarks={bookmarks} history={history} nativeBrowser={nativeBrowser} onNewTab={newTab} onDownload={downloadsHref} /> : null}
        {!startPage && nativeBrowser ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center" style={{ background: "var(--surface-2)" }}>
            <div className="flex h-12 w-12 items-center justify-center rounded-xl" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><Globe size={23} /></div>
            <div className="text-[12px] font-medium">Native browser surface</div>
            <div className="max-w-[360px] text-[9.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
              The page is rendered by Android WebView and placed exactly over this area while the browser is the active window. Bring this window forward if the page is hidden behind another desktop window.
            </div>
            {!isActive ? <div className="text-[9px] text-[#f3d18b]">This window is not focused; the native page is paused visually.</div> : null}
            <button className="btn btn-sm" onClick={() => { void nativeBridge.browserCommand("focus"); nativeBridge.setBrowserBounds({ left: 0, top: 0, width: 0, height: 0, visible: true, dpr: window.devicePixelRatio || 1 }); }}>Focus web page</button>
          </div>
        ) : null}
        {!startPage && !nativeBrowser ? (
          <div className="relative h-full">
            {error ? (
              <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
                <Globe size={25} style={{ color: "#f5b84a" }} />
                <div className="text-[12px] font-medium">This page cannot be embedded in preview mode</div>
                <div className="max-w-[400px] text-[9.5px] leading-relaxed" style={{ color: "var(--muted)" }}>{error}</div>
                <button className="btn btn-sm" onClick={externalOpen}>Open outside the desktop</button>
              </div>
            ) : (
              <>
                <iframe
                  key={`${active.id}-${active.reloadKey}-${active.url}`}
                  src={active.url}
                  title={active.title}
                  className="h-full w-full border-0"
                  style={{ background: "#fff" }}
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
                  referrerPolicy="no-referrer-when-downgrade"
                  onLoad={() => setLoading(false)}
                  onError={() => { setLoading(false); setError("The preview iframe failed to load this site. It may require the native WebView browser."); }}
                />
                <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center p-2">
                  <div className="pointer-events-auto flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[8.5px]" style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--muted)", boxShadow: "var(--shadow-menu)" }}>
                    Preview only. Install the Android host for YouTube, login, popups and downloads. <button className="font-medium underline" style={{ color: "var(--accent)" }} onClick={externalOpen}>Open externally</button>
                  </div>
                </div>
              </>
            )}
          </div>
        ) : null}
        {error && nativeBrowser ? (
          <div className="absolute inset-x-0 bottom-0 flex items-center gap-2 border-t p-2 text-[9px]" style={{ borderColor: "var(--border)", background: "rgba(239,68,68,.1)", color: "var(--text)" }}>
            <Info size={11} /> {error}
            <button className="ml-auto btn btn-sm" onClick={() => void reload()}>Retry</button>
            <button className="icon-btn h-5 w-5" aria-label="Dismiss browser error" onClick={() => setError("")}><X size={10} /></button>
          </div>
        ) : null}
      </div>

      {sidePanel ? (
        <div className="absolute inset-y-0 right-0 z-40 flex w-[292px] flex-col" style={{ background: "var(--surface-solid)", borderLeft: "1px solid var(--border-strong)", boxShadow: "-18px 0 40px -30px rgba(0,0,0,.6)" }}>
          <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
            <div className="text-[11.5px] font-semibold capitalize">{sidePanel === "settings" ? "Browser settings" : sidePanel}</div>
            <button className="icon-btn ml-auto h-6 w-6" aria-label="Close browser panel" onClick={() => setSidePanel(null)}><X size={12} /></button>
          </div>
          <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-2">
            {sidePanel === "bookmarks" ? (
              bookmarks.length === 0 ? <BrowserPanelEmpty icon={<Bookmark size={20} />} title="No bookmarks yet" body="Use the star in the address bar to save a page." /> : bookmarks.map((bookmark) => (
                <div key={bookmark.url} className="group flex items-center gap-1 rounded-md px-2 py-1.5 row-hover">
                  <button className="min-w-0 flex-1 text-left" onClick={() => openPage(bookmark.url)}>
                    <div className="truncate text-[10px] font-medium">{bookmark.title}</div>
                    <div className="truncate text-[8px]" style={{ color: "var(--faint)" }}>{bookmark.url}</div>
                  </button>
                  <button className="icon-btn h-5 w-5 opacity-0 group-hover:opacity-100" aria-label="Remove bookmark" onClick={() => setBookmarks((prev) => prev.filter((item) => item.url !== bookmark.url))}><Trash2 size={10} /></button>
                </div>
              ))
            ) : null}
            {sidePanel === "history" ? (
              history.length === 0 ? <BrowserPanelEmpty icon={<Clock3 size={20} />} title="No browsing history" body="Visited pages are stored locally on this desktop." /> : (
                <>
                  <div className="mb-1 flex justify-end"><button className="text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setHistory([])}>Clear history</button></div>
                  {history.map((entry) => (
                    <button key={`${entry.url}-${entry.visitedAt}`} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left row-hover" onClick={() => openPage(entry.url)}>
                      <Globe size={11} style={{ color: "var(--faint)" }} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[10px] font-medium">{entry.title}</span>
                        <span className="block truncate text-[8px]" style={{ color: "var(--faint)" }}>{new Date(entry.visitedAt).toLocaleString()}</span>
                      </span>
                    </button>
                  ))}
                </>
              )
            ) : null}
            {sidePanel === "downloads" ? (
              <div className="p-1">
                <div className="mb-2 rounded-lg p-2 text-[9px] leading-relaxed" style={{ background: "var(--field)", color: "var(--muted)" }}>
                  Website downloads are handled by Android DownloadManager in native mode and saved to <strong>Internal storage / {settings.downloadLocation || native.capabilities.downloadLocation || "Download/KK DEX"}</strong>. APK files require Android's installer confirmation.
                </div>
                <button className="btn btn-sm btn-accent w-full" onClick={() => { setSidePanel(null); launch("downloads", { payload: { tab: "android" } }); }}><Download size={11} /> Open Download Manager</button>
                <button className="btn btn-sm mt-1 w-full" onClick={() => { setSidePanel(null); launch("downloads"); }}><Download size={11} /> Workspace downloads</button>
              </div>
            ) : null}
            {sidePanel === "settings" ? (
              <div className="space-y-2 p-1">
                <div className="rounded-lg p-2" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
                  <div className="text-[10px] font-medium">Browser engine</div>
                  <div className="mt-0.5 text-[8.5px] leading-relaxed" style={{ color: "var(--muted)" }}>{nativeBrowser ? "Android WebView (native). Real navigation, cookies, DOM storage, media and downloads." : "Iframe preview (web fallback). It cannot provide YouTube login or bypass site embedding policies."}</div>
                </div>
                <button className="flex w-full items-center justify-between rounded-lg px-2 py-2 text-[10px] row-hover" style={{ border: "1px solid var(--border)" }} onClick={() => void toggleDesktop()}>
                  Desktop site user agent <span className={cn("badge", desktopMode && "badge-accent")}>{desktopMode ? "ON" : "OFF"}</span>
                </button>
                <button className="flex w-full items-center justify-between rounded-lg px-2 py-2 text-[10px] row-hover" style={{ border: "1px solid var(--border)" }} onClick={() => showInfo("Private browsing", "A truly isolated private profile requires a separate WebView data directory and cookie manager. The current native host shares one WebView session, so KK DEX does not pretend to offer private browsing. Standard history and bookmarks remain local to this desktop.", <Shield size={22} />)}>
                  Private browsing <span className="badge">Unavailable</span>
                </button>
                <button className="flex w-full items-center justify-between rounded-lg px-2 py-2 text-[10px] row-hover" style={{ border: "1px solid var(--border)" }} onClick={() => showInfo("Website permissions", "Camera, microphone, location and notifications are requested through Android's runtime permission system. If Android denies the permission, the website is told the request was denied. KK DEX does not silently grant permissions.", <Shield size={22} />)}>
                  Website permissions <ChevronRight size={11} />
                </button>
                <button className="flex w-full items-center justify-between rounded-lg px-2 py-2 text-[10px] row-hover" style={{ border: "1px solid var(--border)" }} onClick={() => setBookmarks([])}>
                  Clear bookmarks <Trash2 size={11} />
                </button>
                <div className="rounded-lg p-2 text-[8px] leading-relaxed" style={{ background: "var(--field)", color: "var(--faint)" }}>
                  YouTube and Google sign-in can reject embedded WebViews on some devices. Playback works when the host supports HTML5 media; DRM-protected services require Widevine support that KK DEX cannot add.
                </div>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      <div className="flex h-[22px] shrink-0 items-center justify-between gap-3 px-3 text-[8px]" style={{ borderTop: "1px solid var(--border)", color: "var(--faint)", background: "var(--surface-2)" }}>
        <span className="truncate">{pageLoading ? "Loading…" : startPage ? HOME_LABEL : active.title}</span>
        <span className="flex items-center gap-2">{nativeBrowser ? "WebView" : "Preview iframe"} · {desktopMode ? "Desktop UA" : "Mobile UA"} · {tabs.length} tab{tabs.length === 1 ? "" : "s"}</span>
      </div>
    </div>
  );
}

function secureFor(url: string) {
  return /^https:\/\//i.test(url);
}

function BrowserPanelEmpty({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg" style={{ background: "var(--field)", color: "var(--muted)" }}>{icon}</div>
      <div className="text-[10.5px] font-medium">{title}</div>
      <div className="text-[8.5px] leading-relaxed" style={{ color: "var(--faint)" }}>{body}</div>
    </div>
  );
}

function StartPage({
  query,
  setQuery,
  onNavigate,
  bookmarks,
  history,
  nativeBrowser,
  onNewTab,
  onDownload,
}: {
  query: string;
  setQuery: (value: string) => void;
  onNavigate: (url: string) => void;
  bookmarks: { url: string; title: string }[];
  history: HistoryEntry[];
  nativeBrowser: boolean;
  onNewTab: (url?: string) => void;
  onDownload: () => void;
}) {
  const [mode, setMode] = useState<"shortcuts" | "recent" | "bookmarks">("shortcuts");
  const recent = useMemo(() => history.slice(0, 6), [history]);
  return (
    <div className="scroll-thin h-full overflow-y-auto">
      <div className="mx-auto flex max-w-[760px] flex-col items-center px-6 pt-8 pb-6">
        <AppIcon id="browser" size={42} />
        <div className="mt-3 text-[20px] font-semibold tracking-tight">KK Browse</div>
        <div className="text-[10px]" style={{ color: "var(--muted)" }}>
          {nativeBrowser ? "Native PC-style browsing surface" : "Desktop preview browser — native engine not connected"}
        </div>
        <div className="mt-4 flex w-full max-w-[520px] items-center gap-2 rounded-full px-4 py-2.5" style={{ background: "var(--field)", border: "1px solid var(--border-strong)", boxShadow: "0 12px 30px -22px rgba(0,0,0,.7)" }}>
          <Search size={15} style={{ color: "var(--accent)" }} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={(event) => { if (event.key === "Enter" && query.trim()) onNavigate(normalizeUrl(query)); }}
            placeholder="Search Google or type a URL"
            className="min-w-0 flex-1 border-0 bg-transparent text-[12px] outline-none placeholder:text-[var(--faint)]"
          />
          <span className="rounded px-1.5 py-0.5 text-[8px]" style={{ background: "var(--active)", color: "var(--muted)" }}>Enter</span>
        </div>
        {!nativeBrowser ? (
          <div className="mt-2 flex w-full max-w-[520px] items-start gap-2 rounded-lg px-2.5 py-2 text-[8.5px] leading-relaxed" style={{ background: "rgba(245,158,11,.1)", border: "1px solid rgba(245,158,11,.22)", color: "var(--muted)" }}>
            <ShieldAlert size={12} className="mt-0.5 shrink-0" style={{ color: "#f5b84a" }} />
            The browser preview cannot bypass websites' frame restrictions. Install/run the Android host for YouTube, site logins, file uploads, popups, and real downloads.
          </div>
        ) : null}
        <div className="mt-5 w-full">
          <div className="mb-2 flex items-center gap-1">
            <Segmented size="sm" value={mode} onChange={setMode} options={[{ value: "shortcuts", label: "Shortcuts" }, { value: "recent", label: "Recent" }, { value: "bookmarks", label: "Bookmarks" }]} />
            <button className="btn btn-sm btn-ghost ml-auto" onClick={() => onNewTab()}><Plus size={11} /> New tab</button>
            <button className="btn btn-sm btn-ghost" onClick={onDownload}><Download size={11} /> Downloads</button>
          </div>
          {mode === "shortcuts" ? (
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
              {QUICK_LINKS.map((link) => (
                <button key={link.url} className="group flex items-center gap-2.5 rounded-xl p-2.5 text-left transition-transform hover:-translate-y-0.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }} onClick={() => onNavigate(link.url)}>
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[13px] font-bold" style={{ background: `${link.color}20`, color: link.color }}>{link.letter}</span>
                  <span className="min-w-0">
                    <span className="block truncate text-[10.5px] font-medium">{link.name}</span>
                    <span className="block truncate text-[8px]" style={{ color: "var(--muted)" }}>{link.url.replace("https://www.", "").replace("https://", "")}</span>
                  </span>
                </button>
              ))}
            </div>
          ) : mode === "recent" ? (
            recent.length ? recent.map((entry) => (
              <button key={entry.visitedAt} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left row-hover" onClick={() => onNavigate(entry.url)}>
                <Clock3 size={11} style={{ color: "var(--faint)" }} />
                <span className="min-w-0 flex-1"><span className="block truncate text-[10px]">{entry.title}</span><span className="block truncate text-[8px]" style={{ color: "var(--faint)" }}>{entry.url}</span></span>
              </button>
            )) : <div className="rounded-lg p-4 text-[9.5px]" style={{ background: "var(--surface-2)", color: "var(--muted)" }}>No recent pages. Open a website to start browsing.</div>
          ) : bookmarks.length ? bookmarks.map((entry) => (
            <button key={entry.url} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left row-hover" onClick={() => onNavigate(entry.url)}>
              <Bookmark size={11} style={{ color: "var(--accent)" }} />
              <span className="min-w-0 flex-1"><span className="block truncate text-[10px]">{entry.title}</span><span className="block truncate text-[8px]" style={{ color: "var(--faint)" }}>{entry.url}</span></span>
            </button>
          )) : <div className="rounded-lg p-4 text-[9.5px]" style={{ background: "var(--surface-2)", color: "var(--muted)" }}>No bookmarks yet. Open a site and press the star.</div>}
        </div>
        <div className="mt-4 flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[8.5px]" style={{ background: "var(--field)", color: "var(--muted)", border: "1px solid var(--border)" }}>
          <Lock size={10} />
          <span>{nativeBrowser ? "Cookies, JavaScript and local storage are enabled. Downloads use Android DownloadManager and real phone storage." : "Preview mode uses browser sandboxing. Some sites refuse to load."}</span>
          <button className="ml-auto shrink-0 hover:underline" style={{ color: "var(--accent)" }} onClick={() => onNewTab("https://www.youtube.com")}>Try YouTube</button>
        </div>
      </div>
    </div>
  );
}
