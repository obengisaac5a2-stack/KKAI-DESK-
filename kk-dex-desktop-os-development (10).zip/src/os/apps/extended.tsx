import { useEffect, useRef, useState } from "react";
import JSZip from "jszip";
import {
  AlertTriangle,
  AppWindow,
  Archive,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  CirclePlay,
  Code2,
  Cpu,
  Download,
  ExternalLink,
  FileArchive,
  FileCode2,
  FileDown,
  FileText,
  FolderOpen,
  GitBranch,
  Info,
  Loader2,
  Music,
  Pause,
  Play,
  RefreshCw,
  Search,
  Send,
  Smartphone,
  Terminal,
  Trash2,
  Upload,
  Video,
  X,
} from "lucide-react";
import { FileGlyph } from "../icons";
import {
  browserImport,
  nativeBridge,
  readBrowserFileAsDataUrl,
  readBrowserFileAsText,
} from "../native";
import { formatBytes, formatDate, useOS } from "../OSContext";
import type { AppContentProps, FileKind, FsNode } from "../types";
import { AppNotice, EmptyState, SearchBox, Segmented } from "../ui";
import { useNativeState } from "../NativeStorage";
import { NativeDownloadManager } from "../downloads";
import { cn } from "@/utils/cn";

function nodeKindFromName(name: string): FileKind {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(ext)) return "image";
  if (["mp3", "wav", "ogg", "m4a", "flac"].includes(ext)) return "audio";
  if (["mp4", "webm", "mov", "mkv"].includes(ext)) return "video";
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return "archive";
  if (["js", "ts", "tsx", "jsx", "py", "html", "css", "json", "sh"].includes(ext)) return "code";
  if (["txt", "md", "csv", "log"].includes(ext)) return "document";
  return "file";
}

function useOpenWorkspaceFile() {
  const { launch, showInfo } = useOS();
  return (node: FsNode) => {
    if (node.kind === "folder") {
      launch("files", { payload: { folderId: node.id } });
    } else if (node.kind === "image" && node.src) {
      launch("gallery", { payload: { imageSrc: node.src, imageName: node.name } });
    } else if ((node.kind === "audio" || node.kind === "video") && node.src) {
      launch("media", { payload: { src: node.src, name: node.name, automaticallyOpen: true } });
    } else if (node.kind === "archive") {
      launch("archive", { payload: { nodeId: node.id, name: node.name } });
    } else if (node.kind === "document" || node.kind === "code") {
      launch("files", { payload: { folderId: node.parentId ?? "downloads", previewId: node.id } });
    } else {
      showInfo("No in-app viewer", `“${node.name}” has no readable text or playable media in this workspace. Use the Android storage view to send it to another application.`, <FileText size={24} />);
    }
  };
}

/* --------------------------------- Downloads -------------------------------- */

export function DownloadsApp({ payload }: AppContentProps) {
  const { files, exportedFiles, deleteNode, showConfirm, notify, launch, addFile, pushExportedFile } = useOS();
  const openNode = useOpenWorkspaceFile();
  const [tab, setTab] = useState<"workspace" | "transfers" | "android">((payload?.tab as "workspace" | "transfers" | "android") ?? "workspace");
  const [query, setQuery] = useState("");
  const [textPreview, setTextPreview] = useState<{ name: string; content: string } | null>(null);

  const workspaceFiles = files.filter((file) => file.parentId === "downloads" && file.kind !== "folder");
  const filtered = workspaceFiles.filter((file) => file.name.toLowerCase().includes(query.toLowerCase()));

  const exportFile = (node: FsNode) => {
    try {
      if (!node.src && !node.content) {
        notify("Export source unavailable", "This sample workspace entry has metadata only; no byte content is stored to export.", { tone: "error" });
        return;
      }
      const anchor = document.createElement("a");
      anchor.href = node.src ?? `data:text/plain;charset=utf-8,${encodeURIComponent(node.content ?? "")}`;
      anchor.download = node.name;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      pushExportedFile({ id: `export-${Date.now()}`, name: node.name, kind: node.kind, size: node.size, src: node.src, content: node.content, createdAt: Date.now(), origin: "Workspace export" });
      notify("Export started", `${node.name} was handed to the host download manager.`, { tone: "success", silent: true });
    } catch {
      notify("Export failed", "The host blocked the download.", { tone: "error" });
    }
  };

  const importFile = async () => {
    const selected = await browserImport("*/*", true);
    for (const file of selected) {
      const kind = nodeKindFromName(file.name);
      const src = ["image", "audio", "video"].includes(kind) && file.size <= 18 * 1024 * 1024 ? await readBrowserFileAsDataUrl(file) : undefined;
      const content = ["document", "code"].includes(kind) && file.size <= 900_000 ? await readBrowserFileAsText(file) : undefined;
      addFile("downloads", file.name, kind, { src, content, size: file.size });
    }
    if (selected.length) notify("Files imported", `${selected.length} file(s) are now available in Downloads.`, { tone: "success" });
  };

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><Download size={16} /></div>
        <div className="min-w-0">
          <div className="text-[13px] font-semibold leading-tight">Downloads</div>
          <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{workspaceFiles.length} workspace files · native Downloads available</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" onClick={importFile}><Upload size={12} /> Import file</button>
          <button className="btn btn-sm" onClick={() => launch("files", { payload: { folderId: "downloads" } })}><FolderOpen size={12} /> Open folder</button>
        </div>
      </div>
      <div className="flex items-center gap-2 px-3 py-1.5" style={{ borderBottom: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <Segmented
          size="sm"
          value={tab}
          onChange={setTab}
          options={[
            { value: "workspace", label: "Workspace" },
            { value: "transfers", label: `Exports${exportedFiles.length ? ` ${exportedFiles.length}` : ""}` },
            { value: "android", label: "Android device" },
          ]}
        />
        <div className="relative ml-auto flex items-center">
          <Search size={11} className="pointer-events-none absolute left-2" style={{ color: "var(--faint)" }} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search downloads" className="field !h-7 !w-[150px] pl-6 !text-[10px]" />
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
        {tab === "workspace" ? (
          filtered.length === 0 ? (
            <EmptyState icon={<Download size={22} />} title="No workspace downloads" description="Files imported or copied into the Downloads folder appear here." />
          ) : (
            <div className="grid gap-1">
              {filtered.map((node) => (
                <div key={node.id} className="group flex items-center gap-2.5 rounded-lg px-2.5 py-2 row-hover" style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }}>
                  <FileGlyph kind={node.kind} size={19} />
                  <button className="min-w-0 flex-1 text-left" onClick={() => openNode(node)}>
                    <div className="truncate text-[10.5px] font-medium">{node.name}</div>
                    <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{node.kind} · {formatBytes(node.size)} · {formatDate(node.modified)}</div>
                  </button>
                  <button className="icon-btn h-6 w-6" title="Open" onClick={() => openNode(node)}><ArrowRight size={11} /></button>
                  <button className="icon-btn h-6 w-6" title="Export / download" onClick={() => exportFile(node)}><FileDown size={11} /></button>
                  <button className="icon-btn h-6 w-6" title="Move to Recycle Bin" onClick={() => showConfirm(`Remove “${node.name}” from Downloads?`, "It will move to the workspace Recycle Bin.", () => deleteNode(node.id), "Move to Recycle Bin")}><Trash2 size={11} /></button>
                </div>
              ))}
            </div>
          )
        ) : null}

        {tab === "transfers" ? (
          exportedFiles.length === 0 ? (
            <EmptyState icon={<FileDown size={22} />} title="No exported files yet" description="Files handed to the host download manager are recorded here. Export history is local to this desktop workspace." />
          ) : (
            <div className="grid gap-1">
              {exportedFiles.map((file) => (
                <div key={file.id} className="flex items-center gap-2.5 rounded-lg px-2.5 py-2" style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }}>
                  <FileGlyph kind={file.kind} size={18} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[10.5px] font-medium">{file.name}</div>
                    <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{file.origin} · {formatBytes(file.size)} · {formatDate(file.createdAt)}</div>
                  </div>
                  {file.src ? <button className="btn btn-sm !h-6 !px-2" onClick={() => { const a = document.createElement("a"); a.href = file.src!; a.download = file.name; a.click(); }}><Download size={10} /> Save</button> : null}
                </div>
              ))}
            </div>
          )
        ) : null}

        {tab === "android" ? (
          <NativeDownloadManager />
        ) : null}
      </div>

      {textPreview ? (
        <div className="absolute inset-0 z-20 flex flex-col" style={{ background: "var(--surface-solid)" }}>
          <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
            <FileText size={14} />
            <div className="truncate text-[11px] font-medium">{textPreview.name}</div>
            <button className="icon-btn ml-auto h-7 w-7" aria-label="Close preview" onClick={() => setTextPreview(null)}><X size={13} /></button>
          </div>
          <pre className="scroll-thin min-h-0 flex-1 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px]" style={{ background: "var(--surface-2)" }}>{textPreview.content}</pre>
        </div>
      ) : null}
    </div>
  );
}

/* -------------------------------- Media player ------------------------------ */

export function MediaPlayerApp({ payload }: AppContentProps) {
  const { files, notify, showInfo, addFile } = useOS();
  const native = useNativeState();
  const incomingSrc = typeof payload?.src === "string" ? payload.src : null;
  const incomingName = typeof payload?.name === "string" ? payload.name : "Device media";
  const [source, setSource] = useState<{ src: string; name: string; origin: string } | null>(incomingSrc ? { src: incomingSrc, name: incomingName, origin: "Android storage" } : null);
  const [mode, setMode] = useState<"audio" | "video">(incomingSrc && /\.(mp4|webm|mov|mkv)/i.test(incomingName) ? "video" : "audio");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [imported, setImported] = useState<string[]>([]);
  void imported;

  const workspaceMedia = files.filter((file) => (mode === "audio" ? file.kind === "audio" : file.kind === "video"));

  const pickNative = async () => {
    setBusy(true);
    setError("");
    try {
      const selected = await nativeBridge.pickFiles(mode === "audio" ? "audio/*" : "video/*", false);
      const file = selected[0];
      if (!file) return;
      const src = await nativeBridge.readDataUrl(file.uri, file.mime);
      setSource({ src, name: file.name, origin: "Android SAF" });
      notify("Media loaded", `${file.name} is playing from authorized Android storage.`, { tone: "success", silent: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "The media picker is unavailable.");
    } finally {
      setBusy(false);
    }
  };

  const pickBrowser = async () => {
    const selected = await browserImport(mode === "audio" ? "audio/*" : "video/*", false);
    const file = selected[0];
    if (!file) return;
    const src = await readBrowserFileAsDataUrl(file);
    setSource({ src, name: file.name, origin: "Browser file picker" });
    setImported((prev) => [...prev, file.name]);
    const kind: FileKind = mode;
    addFile("downloads", file.name, kind, { src, size: file.size });
  };

  const playUrl = () => {
    if (!url.trim()) return;
    try {
      const parsed = new URL(url.trim());
      if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Only HTTP and HTTPS media URLs are supported.");
      setSource({ src: parsed.toString(), name: parsed.pathname.split("/").pop() || "Remote media", origin: parsed.hostname });
      setMode(/\.(mp4|webm|mov|mkv)(\?|$)/i.test(parsed.pathname) ? "video" : "audio");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Enter a valid media URL.");
    }
  };

  if (!native.available && !source) {
    // A standalone browser cannot call Android SAF. Browser picker remains available below.
  }

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(239,111,155,.13)", color: "#ef6f9b" }}><Play size={15} /></div>
        <div>
          <div className="text-[12.5px] font-semibold">Media Player</div>
          <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{source ? source.origin : "Audio and video playback"}</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <Segmented size="sm" value={mode} onChange={setMode} options={[{ value: "audio", label: "Audio" }, { value: "video", label: "Video" }]} />
          <button className="btn btn-sm" onClick={pickNative} disabled={!native.capabilities.storageAccessFramework || busy}>{busy ? <Loader2 size={11} className="animate-spin" /> : <Smartphone size={11} />} Android picker</button>
          <button className="btn btn-sm" onClick={pickBrowser}><Upload size={11} /> Open file</button>
        </div>
      </div>
      <div className="flex min-h-0 flex-1">
        <div className="flex min-w-0 flex-1 flex-col items-center justify-center p-3" style={{ background: "#080d15" }}>
          {source ? (
            mode === "video" ? (
              <video key={source.src} src={source.src} controls autoPlay={Boolean(payload?.automaticallyOpen)} className="max-h-full max-w-full rounded-lg" style={{ background: "#000", maxHeight: "100%" }} onError={() => setError("The selected media could not be decoded by this device.")} />
            ) : (
              <div className="w-full max-w-[380px]">
                <div className="mb-4 flex h-28 w-28 mx-auto items-center justify-center rounded-2xl" style={{ background: "linear-gradient(145deg,#3c2748,#1e2635)", border: "1px solid rgba(255,255,255,.1)" }}><Music size={40} color="#ef6f9b" /></div>
                <audio key={source.src} src={source.src} controls autoPlay={Boolean(payload?.automaticallyOpen)} className="w-full" onError={() => setError("The selected audio could not be decoded by this device.")} />
              </div>
            )
          ) : (
            <div className="text-center">
              <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl" style={{ background: "rgba(255,255,255,.06)" }}>{mode === "video" ? <Video size={26} color="#fb923c" /> : <Music size={26} color="#a78bfa" />}</div>
              <div className="text-[13px] font-medium text-white">No media loaded</div>
              <div className="mx-auto mt-1 max-w-[300px] text-[9.5px] leading-relaxed" style={{ color: "rgba(255,255,255,.45)" }}>Open a file from authorized Android storage, choose a local file, or paste a direct HTTPS media URL.</div>
            </div>
          )}
          {source ? (
            <div className="mt-2 flex w-full items-center gap-2 px-2 text-[9px]" style={{ color: "rgba(255,255,255,.55)" }}>
              <span className="truncate">{source.name}</span>
              <button className="ml-auto rounded px-2 py-1 text-[8.5px]" style={{ background: "rgba(255,255,255,.08)" }} onClick={() => setSource(null)}>Close</button>
            </div>
          ) : null}
          {error ? <div className="mt-2 flex items-center gap-1 rounded bg-red-500/15 px-2 py-1 text-[9px] text-red-200"><AlertTriangle size={11} /> {error}</div> : null}
        </div>
        <aside className="scroll-thin flex w-[214px] shrink-0 flex-col overflow-y-auto p-2.5" style={{ borderLeft: "1px solid var(--border)", background: "var(--surface-2)" }}>
          <div className="mb-1.5 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Direct media URL</div>
          <div className="flex gap-1">
            <input value={url} onChange={(event) => setUrl(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") playUrl(); }} placeholder="https://…/media.mp4" className="field !h-7 min-w-0 !text-[9.5px]" />
            <button className="btn btn-sm !px-2" onClick={playUrl}><ArrowRight size={11} /></button>
          </div>
          <div className="mt-3 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>{mode === "audio" ? "Music" : "Videos"} in workspace</div>
          {workspaceMedia.length === 0 ? (
            <div className="py-3 text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>No {mode} files in the workspace. Imports are stored in Downloads.</div>
          ) : (
            workspaceMedia.map((file) => (
              <button key={file.id} className="flex items-center gap-2 rounded-lg px-1.5 py-1.5 text-left row-hover" onClick={() => file.src ? setSource({ src: file.src, name: file.name, origin: "KK DEX workspace" }) : showInfo("Sample has no media", `${file.name} is a workspace sample with metadata only. Import real media to play it.`, <Music size={24} />)}>
                {mode === "audio" ? <Music size={13} color="#a78bfa" /> : <Video size={13} color="#fb923c" />}
                <span className="min-w-0 flex-1 truncate text-[9.5px]">{file.name}</span>
              </button>
            ))
          )}
          <div className="mt-auto rounded-lg p-2 text-[8px] leading-relaxed" style={{ background: "var(--field)", color: "var(--faint)" }}>
            Playback uses the host WebView's codecs. Android may lack codecs for some containers; failures are reported instead of hidden.
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ---------------------------------- PDF ------------------------------------- */

export function PdfViewerApp({ payload }: AppContentProps) {
  const { notify, showInfo } = useOS();
  const native = useNativeState();
  const [src, setSrc] = useState(typeof payload?.src === "string" ? payload.src : "");
  const [name, setName] = useState(typeof payload?.name === "string" ? payload.name : "Document.pdf");
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [favorite, setFavorite] = useState(false);

  const pickNative = async () => {
    setBusy(true);
    setError("");
    try {
      const [file] = await nativeBridge.pickFiles("application/pdf", false);
      if (!file) return;
      const dataUrl = await nativeBridge.readDataUrl(file.uri, "application/pdf");
      setSrc(dataUrl);
      setName(file.name);
      notify("PDF loaded", `${file.name} was read from Android storage.`, { tone: "success", silent: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "The Android PDF picker is unavailable.");
    } finally {
      setBusy(false);
    }
  };

  const pickBrowser = async () => {
    const [file] = await browserImport("application/pdf", false);
    if (!file) return;
    setSrc(await readBrowserFileAsDataUrl(file));
    setName(file.name);
  };

  const loadUrl = () => {
    try {
      const parsed = new URL(url.trim());
      if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Only HTTP and HTTPS PDF URLs are supported.");
      setSrc(parsed.toString());
      setName(parsed.pathname.split("/").pop() || "Document.pdf");
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Enter a valid HTTPS URL.");
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(255,143,128,.13)", color: "#f27a6d" }}><FileText size={16} /></div>
        <div className="min-w-0">
          <div className="truncate text-[12px] font-semibold">{name}</div>
          <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{src ? src.startsWith("data:") ? "Loaded into viewer" : src.replace(/^https?:\/\//, "").slice(0, 60) : "No PDF loaded"}</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" onClick={pickNative} disabled={!native.capabilities.storageAccessFramework || busy}>{busy ? <Loader2 size={11} className="animate-spin" /> : <Smartphone size={11} />} Android PDF</button>
          <button className="btn btn-sm" onClick={pickBrowser}><Upload size={11} /> Open file</button>
          <button className="btn btn-sm" onClick={() => setFavorite((value) => !value)} title="Bookmark this document">{favorite ? "★" : "☆"}</button>
          <button className="btn btn-sm" disabled={!src} onClick={() => window.open(src, "_blank", "noopener")}><ExternalLink size={11} /> External</button>
        </div>
      </div>
      <div className="flex items-center gap-1.5 px-3 py-1.5" style={{ borderBottom: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <input value={url} onChange={(event) => setUrl(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") loadUrl(); }} placeholder="https://example.com/document.pdf" className="field !h-7 max-w-[420px] !text-[10px]" />
        <button className="btn btn-sm" onClick={loadUrl}><ArrowRight size={11} /> Load URL</button>
        <span className="ml-auto text-[8.5px]" style={{ color: "var(--faint)" }}>PDF rendering depends on the WebView's built-in PDF support.</span>
      </div>
      {error ? <div className="mx-3 mt-2 flex items-center gap-1 rounded-md px-2 py-1.5 text-[9px]" style={{ background: "rgba(239,68,68,.1)", color: "var(--text)" }}><AlertTriangle size={11} /> {error}</div> : null}
      <div className="min-h-0 flex-1 p-2" style={{ background: "var(--surface-2)" }}>
        {src ? (
          <object data={src} type="application/pdf" className="h-full w-full rounded-lg" style={{ background: "#fff", border: "1px solid var(--border)" }}>
            <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
              <AlertTriangle size={22} style={{ color: "#f5b84a" }} />
              <div className="text-[12px] font-medium">This WebView cannot embed PDFs</div>
              <div className="max-w-[320px] text-[9.5px] leading-relaxed" style={{ color: "var(--muted)" }}>The file was loaded successfully, but the host has no built-in PDF viewer. Send it to an Android PDF application instead.</div>
              <button className="btn btn-sm" onClick={() => showInfo("Opening externally", "Select this PDF in Android storage and choose “Open with”. On the web, use External to open it in the browser's PDF viewer.", <FileText size={22} />)}>Learn more</button>
            </div>
          </object>
        ) : (
          <EmptyState icon={<FileText size={22} />} title="Open a PDF document" description="Choose an authorized Android PDF, a local file, or paste a direct HTTPS URL. Only the actual document bytes are shown." />
        )}
      </div>
    </div>
  );
}

/* --------------------------------- Archive ---------------------------------- */

interface ArchiveEntry {
  path: string;
  isDirectory: boolean;
  size: number;
  date: Date | null;
}

export function ArchiveApp({ payload }: AppContentProps) {
  const { files, addFile, notify, showInfo } = useOS();
  const native = useNativeState();
  const [zip, setZip] = useState<JSZip | null>(null);
  const [archiveName, setArchiveName] = useState(typeof payload?.name === "string" ? payload.name : "");
  const [origin, setOrigin] = useState("");
  const [entries, setEntries] = useState<ArchiveEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  useEffect(() => {
    const nodeId = typeof payload?.nodeId === "string" ? payload.nodeId : null;
    if (!nodeId) return;
    const node = files.find((file) => file.id === nodeId);
    if (!node?.src) return;
    setBusy(true);
    fetch(node.src)
      .then((response) => response.arrayBuffer())
      .then((buffer) => JSZip.loadAsync(buffer))
      .then((loaded) => {
        hydrate(loaded, node.name, "Workspace");
      })
      .catch(() => setError("The workspace archive sample has no actual ZIP bytes. Import a real ZIP to inspect it."))
      .finally(() => setBusy(false));
    // only follow an explicit incoming archive
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payload?.nodeId]);

  const hydrate = (loaded: JSZip, name: string, source: string) => {
    setZip(loaded);
    setArchiveName(name);
    setOrigin(source);
    const list: ArchiveEntry[] = [];
    loaded.forEach((path, entry) => {
      list.push({ path, isDirectory: entry.dir, size: (entry as JSZip.JSZipObject & { _data?: { uncompressedSize?: number } })._data?.uncompressedSize ?? 0, date: entry.date });
    });
    setEntries(list.sort((a, b) => Number(b.isDirectory) - Number(a.isDirectory) || a.path.localeCompare(b.path)));
    setSelected(new Set());
    setError("");
  };

  const pickNative = async () => {
    setBusy(true);
    setError("");
    try {
      const [file] = await nativeBridge.pickFiles("application/zip", false);
      if (!file) return;
      const result = await nativeBridge.readFile(file.uri);
      const loaded = await JSZip.loadAsync(result.content, { base64: result.encoding === "base64" });
      hydrate(loaded, file.name, "Android SAF");
    } catch (err) {
      setError(err instanceof Error ? err.message : "The native archive picker is unavailable.");
    } finally {
      setBusy(false);
    }
  };

  const pickBrowser = async () => {
    const [file] = await browserImport(".zip,application/zip", false);
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const loaded = await JSZip.loadAsync(await file.arrayBuffer());
      hydrate(loaded, file.name, "Browser file picker");
    } catch {
      setError("This file is not a readable ZIP archive. RAR, 7z and encrypted ZIP archives need an Android extractor.");
    } finally {
      setBusy(false);
    }
  };

  const extract = async (onlySelected = false) => {
    if (!zip) return;
    setBusy(true);
    setProgress(0);
    const targets = entries.filter((entry) => !entry.isDirectory && (!onlySelected || selected.size === 0 || selected.has(entry.path)));
    let done = 0;
    try {
      for (const entry of targets) {
        const object = zip.file(entry.path);
        if (!object) continue;
        const extension = entry.path.split(".").pop()?.toLowerCase() ?? "";
        const kind = nodeKindFromName(entry.path);
        const binary = ["png", "jpg", "jpeg", "gif", "webp", "mp3", "wav", "ogg", "mp4", "webm"].includes(extension);
        if (binary) {
          const base64 = await object.async("base64");
          addFile("downloads", entry.path.split("/").pop() ?? entry.path, kind, { src: `data:${extension === "png" ? "image/png" : extension === "mp3" ? "audio/mpeg" : "application/octet-stream"};base64,${base64}`, size: entry.size });
        } else {
          const text = await object.async("string");
          addFile("downloads", entry.path.split("/").pop() ?? entry.path, kind, { content: text, size: entry.size });
        }
        done += 1;
        setProgress(Math.round((done / Math.max(1, targets.length)) * 100));
      }
      notify("Archive extracted", `${done} file${done === 1 ? "" : "s"} copied into Downloads from ${archiveName}.`, { tone: "success" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Extraction failed.");
    } finally {
      setBusy(false);
    }
  };

  const filtered = entries.filter((entry) => entry.path.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(247,207,106,.13)", color: "#e0b43c" }}><Archive size={16} /></div>
        <div className="min-w-0">
          <div className="truncate text-[12.5px] font-semibold">{archiveName || "Archive Manager"}</div>
          <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{zip ? `${entries.length} entries · ${origin}` : "Inspect and extract ZIP archives"}</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" onClick={pickNative} disabled={!native.capabilities.storageAccessFramework || busy}><Smartphone size={11} /> Android ZIP</button>
          <button className="btn btn-sm" onClick={pickBrowser} disabled={busy}><Upload size={11} /> Open ZIP</button>
          <button className="btn btn-sm btn-accent" onClick={() => void extract(selected.size > 0)} disabled={!zip || busy}>Extract {selected.size ? `(${selected.size})` : "all"}</button>
        </div>
      </div>
      {error ? <div className="mx-3 mt-2 flex items-start gap-1.5 rounded-md px-2.5 py-2 text-[9px]" style={{ background: "rgba(239,68,68,.1)", color: "var(--text)" }}><AlertTriangle size={11} className="mt-0.5 shrink-0" /> {error}</div> : null}
      {busy ? <div className="mx-3 mt-2"><div className="h-1 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}><div className="h-full rounded-full transition-all" style={{ width: `${progress || 12}%`, background: "var(--accent)" }} /></div><div className="mt-1 text-[8px]" style={{ color: "var(--faint)" }}>Working on the archive… {progress}%</div></div> : null}
      <div className="flex items-center gap-2 px-3 py-1.5" style={{ borderBottom: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <SearchBox value={query} onChange={setQuery} placeholder="Filter archive entries" className="w-[220px]" />
        <button className="btn btn-sm" disabled={!entries.length} onClick={() => setSelected(new Set(entries.filter((entry) => !entry.isDirectory).map((entry) => entry.path)))}>Select all</button>
        <button className="btn btn-sm" disabled={!selected.size} onClick={() => setSelected(new Set())}>Clear selection</button>
        <span className="ml-auto text-[8.5px]" style={{ color: "var(--faint)" }}>ZIP extraction is real; RAR/7z require an Android extractor.</span>
      </div>
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-2">
        {!zip ? (
          <EmptyState icon={<Archive size={22} />} title="No archive opened" description="Choose a real ZIP from authorized Android storage or your device. Samples without ZIP bytes are reported accurately." />
        ) : filtered.length === 0 ? (
          <EmptyState icon={<Search size={22} />} title="No matching entries" description="Clear the filter to inspect the archive contents." />
        ) : (
          <div className="grid gap-0.5">
            <div className="grid grid-cols-[minmax(0,1fr)_72px_104px] gap-2 px-2 py-1 text-[8.5px] font-semibold uppercase tracking-wide" style={{ color: "var(--faint)" }}>
              <span>Name</span><span className="text-right">Size</span><span className="text-right">Modified</span>
            </div>
            {filtered.map((entry) => (
              <div key={entry.path} className={cn("grid cursor-pointer grid-cols-[minmax(0,1fr)_72px_104px] items-center gap-2 rounded px-2 py-1 text-[10px] row-hover", selected.has(entry.path) && "row-selected")} onClick={() => { if (entry.isDirectory) return; setSelected((prev) => { const next = new Set(prev); if (next.has(entry.path)) next.delete(entry.path); else next.add(entry.path); return next; }); }}>
                <span className="flex min-w-0 items-center gap-1.5">
                  {entry.isDirectory ? <FolderOpen size={13} color="#f0ae3c" /> : <FileArchive size={13} color="#e0b43c" />}
                  <span className="truncate pl-1" style={{ paddingLeft: entry.path.split("/").length * 6 }}>{entry.path}</span>
                </span>
                <span className="text-right font-mono text-[8.5px]" style={{ color: "var(--muted)" }}>{entry.isDirectory ? "—" : formatBytes(entry.size)}</span>
                <span className="text-right text-[8.5px]" style={{ color: "var(--muted)" }}>{entry.date ? formatDate(entry.date.getTime()) : "—"}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="flex h-7 items-center justify-between px-3 text-[8.5px]" style={{ borderTop: "1px solid var(--border)", background: "var(--surface-2)", color: "var(--muted)" }}>
        <span>{selected.size} selected · {entries.filter((entry) => !entry.isDirectory).length} files</span>
        <button className="hover:underline" onClick={() => showInfo("Extraction target", "Extracted files are written into the KK DEX workspace Downloads folder, where Files and Downloads can open them. Android SAF destinations are not written directly in this build.", <FolderOpen size={20} />)}>Destination: Downloads ▸</button>
      </div>
    </div>
  );
}

/* -------------------------------- Developer --------------------------------- */

interface AndroidApp {
  packageName: string;
  label: string;
  icon?: string;
  category?: string;
}

const PY_SAMPLE = `import sys\nprint("Python", sys.version.split()[0])\nprint("Hello from KK DEX")`;
const NODE_SAMPLE = `console.log("Node", process.version);\nconsole.log(2 ** 10);`;
const SHELL_SAMPLE = `pwd && ls -la`;
const GIT_SAMPLE = `git --version`;

const JS_SAMPLE = `// Real JavaScript execution in an isolated Web Worker.\n// DOM APIs are not available here.\nconst values = [3, 7, 11, 19];\nconst total = values.reduce((sum, n) => sum + n, 0);\nconsole.log("values", values);\nconsole.log("sum", total);\nreturn { total, average: total / values.length };`;

function runJavaScript(code: string): Promise<{ logs: string[]; result?: string; error?: string }> {
  return new Promise((resolve) => {
    const source = `
      self.onmessage = async () => {
        const logs = [];
        const format = (value) => {
          if (typeof value === "string") return value;
          if (value === undefined) return "undefined";
          try { return JSON.stringify(value, null, 2); } catch { return String(value); }
        };
        const record = (level) => (...args) => logs.push(level + ": " + args.map(format).join(" "));
        self.console = { log: record("log"), info: record("info"), warn: record("warn"), error: record("error"), debug: record("debug") };
        try {
          const result = await (async () => { ${code} })();
          self.postMessage({ logs, result: result === undefined ? undefined : format(result) });
        } catch (error) {
          self.postMessage({ logs, error: String(error && error.stack ? error.stack : error) });
        }
      };
    `;
    const blob = new Blob([source], { type: "text/javascript" });
    const url = URL.createObjectURL(blob);
    const worker = new Worker(url);
    const timer = window.setTimeout(() => {
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve({ logs: ["error: Execution exceeded 5000 ms and was terminated."], error: "Timeout: the worker exceeded 5 seconds." });
    }, 5000);
    worker.onmessage = (event: MessageEvent<{ logs: string[]; result?: string; error?: string }>) => {
      window.clearTimeout(timer);
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve(event.data);
    };
    worker.onerror = (event) => {
      window.clearTimeout(timer);
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve({ logs: [], error: event.message || "The worker failed to start." });
    };
    worker.postMessage("run");
  });
}

export function DeveloperApp() {
  const native = useNativeState();
  const caps = native.capabilities;
  const [runtime, setRuntime] = useState<"javascript" | "python" | "node" | "shell" | "git" | "apps">("javascript");
  const [code, setCode] = useState(JS_SAMPLE);
  const [output, setOutput] = useState<{ logs: string[]; error?: string; exitCode?: number } | null>(null);
  const [running, setRunning] = useState(false);
  const [apps, setApps] = useState<AndroidApp[]>([]);
  const [appQuery, setAppQuery] = useState("");
  const [appStatus, setAppStatus] = useState("");
  const [loadingApps, setLoadingApps] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);

  const runtimeInfo = {
    javascript: { available: true, detail: "Web Worker in this WebView", sample: JS_SAMPLE, icon: Code2 },
    python: { available: caps.python, detail: caps.python ? "Native Python runtime" : "No authorized Python runtime", sample: PY_SAMPLE, icon: Terminal },
    node: { available: caps.node, detail: caps.node ? "Native Node.js runtime" : "No authorized Node.js runtime", sample: NODE_SAMPLE, icon: Cpu },
    shell: { available: caps.shellExecution, detail: caps.shellExecution ? "Native workspace shell" : "No native shell access", sample: SHELL_SAMPLE, icon: Terminal },
    git: { available: caps.git, detail: caps.git ? "Native Git executable" : "Git is not installed in the authorized runtime", sample: GIT_SAMPLE, icon: GitBranch },
    apps: { available: caps.installedApps, detail: caps.installedApps ? "Android PackageManager bridge" : "App discovery unavailable", sample: "", icon: AppWindow },
  } as const;

  const switchRuntime = (next: typeof runtime) => {
    setRuntime(next);
    setOutput(null);
    if (next !== "apps") setCode(runtimeInfo[next].sample);
  };

  useEffect(() => {
    if (runtime !== "apps" || !caps.installedApps || apps.length) return;
    void loadApps();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runtime, caps.installedApps]);

  const run = async () => {
    setRunning(true);
    setOutput(null);
    try {
      if (runtime === "javascript") {
        const result = await runJavaScript(code);
        setOutput({ logs: result.logs, error: result.error });
      } else {
        const command = code;
        const execRuntime = runtime as "python" | "node" | "shell" | "git";
        const result = await nativeBridge.exec(command, execRuntime);
        setOutput({
          logs: [result.stdout, result.stderr].filter(Boolean),
          error: result.exitCode !== 0 ? `Process exited with code ${result.exitCode}.` : undefined,
          exitCode: result.exitCode,
        });
      }
    } catch (error) {
      setOutput({ logs: [], error: error instanceof Error ? error.message : "Execution failed." });
    } finally {
      setRunning(false);
      window.setTimeout(() => outputRef.current?.scrollTo({ top: outputRef.current.scrollHeight }), 40);
    }
  };

  const loadApps = async () => {
    setLoadingApps(true);
    setAppStatus("");
    try {
      const discovered = await nativeBridge.getInstalledApps();
      setApps(discovered as AndroidApp[]);
      setAppStatus(discovered.length ? `${discovered.length} launchable applications discovered.` : "Android returned no launchable applications.");
    } catch (error) {
      setAppStatus(error instanceof Error ? error.message : "Installed applications could not be discovered.");
    } finally {
      setLoadingApps(false);
    }
  };

  const launchApp = async (app: AndroidApp) => {
    setAppStatus("Requesting launch…");
    try {
      const result = await nativeBridge.launchAndroidApp(app.packageName);
      setAppStatus(
        result.launched
          ? `${app.label} launched ${result.display === "external" ? "on the external display" : "on the Android phone"}.${result.message ? ` ${result.message}` : ""}`
          : `Android refused to launch ${app.label}. ${result.message ?? "The application may not support the phone's current display mode."}`,
      );
    } catch (error) {
      setAppStatus(error instanceof Error ? error.message : "The native launch request failed.");
    }
  };

  const filteredApps = apps.filter((app) => `${app.label} ${app.packageName}`.toLowerCase().includes(appQuery.toLowerCase()));
  const active = runtimeInfo[runtime];

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(94,234,212,.13)", color: "#2cc9a0" }}><FileCode2 size={16} /></div>
        <div>
          <div className="text-[12.5px] font-semibold">Developer workspace</div>
          <div className="flex items-center gap-1 text-[8.5px]" style={{ color: "var(--muted)" }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: caps.shellExecution ? "#34d399" : "#64748b" }} />
            {native.available ? `${caps.platform} · SDK ${caps.sdkInt || "unknown"}` : "Browser-only session"}
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1">
          <button className="btn btn-sm" onClick={() => { setCode(active.sample); setOutput(null); }}>Reset sample</button>
          <button className="btn btn-sm btn-accent" onClick={() => void run()} disabled={running || !active.available}>{running ? <Loader2 size={11} className="animate-spin" /> : <Play size={11} />} Run</button>
        </div>
      </div>
      <div className="flex min-h-0 flex-1">
        <aside className="flex w-[174px] shrink-0 flex-col p-2" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
          <div className="px-1 pb-1 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Runtimes</div>
          {(Object.keys(runtimeInfo) as (keyof typeof runtimeInfo)[]).map((key) => {
            const info = runtimeInfo[key];
            const Icon = info.icon;
            return (
              <button key={key} className={cn("sidebar-item mb-0.5", runtime === key && "active")} onClick={() => switchRuntime(key)}>
                <Icon size={14} style={{ color: runtime === key ? "var(--accent)" : undefined }} />
                <span className="flex-1 capitalize">{key === "apps" ? "Android apps" : key}</span>
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: info.available ? "#34d399" : "var(--surface-4)" }} />
              </button>
            );
          })}
          <div className="mt-2 rounded-lg p-2 text-[8px] leading-relaxed" style={{ background: "var(--field)", color: "var(--faint)" }}>
            JavaScript is always runnable in this WebView. Native runtimes appear only when the Android bridge genuinely reports them.
          </div>
          <button className="mt-auto flex items-center gap-1 rounded px-1 py-1 text-left text-[8px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => void nativeBridge.detect()}>
            <RefreshCw size={8} /> Refresh capabilities
          </button>
        </aside>
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center gap-2 px-3 py-1.5" style={{ borderBottom: "1px solid var(--border)" }}>
            <span className="text-[10px] font-medium capitalize">{runtime === "apps" ? "Installed Android applications" : `${runtime} runtime`}</span>
            <span className="badge">{active.detail}</span>
            {runtime !== "apps" ? <span className="ml-auto text-[8px]" style={{ color: "var(--faint)" }}>Execution is real; no output is simulated.</span> : null}
          </div>
          {runtime === "apps" ? (
            <div className="flex min-h-0 flex-1 flex-col">
              <div className="flex items-center gap-2 px-3 py-2">
                <div className="relative flex items-center">
                  <Search size={11} className="pointer-events-none absolute left-2" style={{ color: "var(--faint)" }} />
                  <input value={appQuery} onChange={(event) => setAppQuery(event.target.value)} placeholder="Search installed apps" className="field !h-7 !w-[220px] pl-6 !text-[10px]" />
                </div>
                <button className="btn btn-sm" onClick={() => void loadApps()} disabled={!caps.installedApps || loadingApps}>{loadingApps ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />} Discover</button>
                <span className="ml-auto text-[8.5px]" style={{ color: "var(--muted)" }}>{apps.length} apps</span>
              </div>
              {!caps.installedApps ? (
                <div className="p-3"><AppNotice tone="warn"><Info size={12} className="mt-0.5 shrink-0" /> Android package discovery requires the native PackageManager bridge. It is not available in this host, so no application list is fabricated.</AppNotice></div>
              ) : filteredApps.length === 0 ? (
                <EmptyState icon={<AppWindow size={22} />} title="No applications discovered" description="Press Discover to query Android PackageManager through the native bridge." />
              ) : (
                <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-2">
                  {filteredApps.map((app) => (
                    <div key={app.packageName} className="flex items-center gap-2 rounded-lg p-1.5 row-hover" style={{ border: "1px solid transparent" }}>
                      {app.icon ? <img src={app.icon} alt="" className="h-8 w-8 rounded-lg object-cover" /> : <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "var(--field)" }}><AppWindow size={15} style={{ color: "var(--muted)" }} /></div>}
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[10.5px] font-medium">{app.label}</div>
                        <div className="truncate font-mono text-[8px]" style={{ color: "var(--muted)" }}>{app.packageName}</div>
                      </div>
                      <button className="btn btn-sm" onClick={() => void launchApp(app)}>Launch <ArrowRight size={10} /></button>
                    </div>
                  ))}
                </div>
              )}
              {appStatus ? <div className="border-t px-3 py-1.5 text-[9px]" style={{ borderColor: "var(--border)", color: "var(--muted)" }}>{appStatus}</div> : null}
            </div>
          ) : (
            <div className="flex min-h-0 flex-1 flex-col">
              <div className="relative flex min-h-0 flex-[1.2] flex-col" style={{ background: "#0b1018" }}>
                <div className="flex h-7 shrink-0 items-center gap-2 px-3 font-mono text-[8px] uppercase tracking-wider" style={{ color: "#7d91aa", borderBottom: "1px solid #1c2635" }}>
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: active.available ? "#34d399" : "#f59e0b" }} />
                  {runtime === "javascript" ? "main.worker.js" : `runtime.${runtime}`}
                  <span className="ml-auto">{active.available ? "executable" : "unavailable"}</span>
                </div>
                <textarea
                  value={code}
                  onChange={(event) => setCode(event.target.value)}
                  spellCheck={false}
                  className="scroll-thin min-h-0 w-full flex-1 resize-none border-0 bg-transparent p-3 font-mono text-[10.5px] leading-relaxed outline-none"
                  style={{ color: "#cfe0f4", userSelect: "text" }}
                  onKeyDown={(event) => {
                    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
                      event.preventDefault();
                      void run();
                    }
                  }}
                />
              </div>
              <div className="flex h-7 shrink-0 items-center gap-2 border-y px-3" style={{ borderColor: "var(--border)", background: "var(--surface-2)" }}>
                <span className="text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Output</span>
                {output?.exitCode !== undefined ? <span className={`badge ${output.exitCode === 0 ? "badge-accent" : ""}`}>exit {output.exitCode}</span> : null}
                <button className="ml-auto text-[8px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setOutput(null)}>Clear</button>
                <span className="text-[8px]" style={{ color: "var(--faint)" }}>Ctrl+Enter run</span>
              </div>
              <div ref={outputRef} className="scroll-thin min-h-[80px] flex-1 overflow-y-auto p-2.5 font-mono text-[9.5px] leading-relaxed" style={{ background: "#080d15", color: "#c6d6e8" }}>
                {!output ? <span style={{ color: "#6d8098" }}>{active.available ? "Output will appear here." : `${active.detail}. Execution is disabled because this runtime was not reported by the host.`}</span> : output.logs.length === 0 && !output.error ? <span style={{ color: "#6d8098" }}>(no output)</span> : null}
                {output?.logs.map((line, index) => <pre key={index} className="m-0 whitespace-pre-wrap break-words">{line}</pre>)}
                {output?.error ? <pre className="m-0 mt-1 whitespace-pre-wrap break-words" style={{ color: "#ff9a9a" }}>{output.error}</pre> : null}
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="flex h-6 items-center justify-between px-3 text-[8px]" style={{ borderTop: "1px solid var(--border)", background: "var(--surface-2)", color: "var(--faint)" }}>
        <span>{caps.shellExecution ? "Native execution backend connected" : "No native execution backend — JavaScript worker available"}</span>
        <span>Output is genuine execution output</span>
      </div>
    </div>
  );
}

// Keep imported vector icons referenced for the design system without rendering fake controls.
void [ChevronLeft, ChevronRight, CirclePlay, Pause, Send];
