import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  Copy,
  FileCode2,
  FolderOpen,
  Info,
  Lightbulb,
  Loader2,
  Moon,
  Plus,
  Save,
  Square,
  Sun,
  Terminal as TerminalIcon,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { nativeBridge, subscribeTerminalEvents, type RuntimeInfo, type TerminalSession } from "../native";
import { useNativeState } from "../NativeStorage";
import { useOS } from "../OSContext";
import { AppNotice } from "../ui";
import { cn } from "@/utils/cn";

type Mode = "native" | "workspace";

interface Line {
  id: number;
  kind: "in" | "out" | "err" | "sys";
  text: string;
}

interface SessionState {
  key: string;
  label: string;
  cwd: string;
  lines: Line[];
  history: string[];
  historyIndex: number;
  running: boolean;
  exitCode: number | null;
}

let lineId = 0;
const mkLine = (kind: Line["kind"], text: string): Line => ({ id: lineId++, kind, text });

const HELP_TEXT = [
  "KK DEX Terminal — real command execution in the Android app sandbox.",
  "",
  "Sessions   : multiple tabs, persistent cwd, Ctrl+C interrupts a running command",
  "Files      : ls cd pwd mkdir rmdir cp mv rm cat touch find grep sed awk tar",
  "System     : ps df du env whoami date uname id uptime top",
  "Network    : curl wget ping ssh (only if the tool is installed on this device)",
  "Dev tools  : python nodejs git clang php ruby java — executed only when installed",
  "Packages   : pkg/apt run only where a real package manager is present",
  "",
  "Nothing is simulated: every command is executed by a real process. If a tool",
  "is missing you will see the operating system's own 'not found' error.",
].join("\n");

const WORKSPACE_COMMANDS: Record<string, (args: string[]) => { out: string; err?: boolean }> = {
  help: () => ({ out: HELP_TEXT }),
  pwd: () => ({ out: "~/workspace" }),
  whoami: () => ({ out: "kkdex (workspace session)" }),
  date: () => ({ out: new Date().toString() }),
  uname: () => ({ out: "KKDex-Web 1.0 desktop-workspace" }),
  clear: () => ({ out: "" }),
  echo: (args) => ({ out: args.join(" ") }),
};

export default function TerminalApp() {
  const { settings, updateSettings, notify, showInfo, launch } = useOS();
  const native = useNativeState();
  const nativeMode: Mode = native.available && native.capabilities.shellExecution ? "native" : "workspace";
  const [sessions, setSessions] = useState<SessionState[]>(() => {
    try {
      const raw = localStorage.getItem("kkdex.terminalSessions");
      if (raw) {
        const parsed = JSON.parse(raw) as SessionState[];
        if (Array.isArray(parsed) && parsed.length) {
          return parsed.map((session) => ({ ...session, running: false, lines: session.lines ?? [] }));
        }
      }
    } catch {
      /* fall through to a fresh session */
    }
    return [freshSession("main")];
  });
  const [activeKey, setActiveKey] = useState(() => sessions[0].key);
  const [input, setInput] = useState("");
  const [runtime, setRuntime] = useState<RuntimeInfo | null>(null);
  const [editor, setEditor] = useState<{ path: string; body: string } | null>(null);
  const [editorPath, setEditorPath] = useState("hello.py");
  const [busyInfo, setBusyInfo] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const sessionRef = useRef<SessionState | null>(null);

  const active = sessions.find((session) => session.key === activeKey) ?? sessions[0];
  sessionRef.current = active;

  const patchSession = useCallback((key: string, patch: Partial<SessionState>) => {
    setSessions((prev) => prev.map((session) => (session.key === key ? { ...session, ...patch } : session)));
  }, []);

  const pushLines = useCallback((key: string, lines: Line[]) => {
    setSessions((prev) => prev.map((session) => (session.key === key ? { ...session, lines: [...session.lines, ...lines].slice(-4000) } : session)));
  }, []);

  useEffect(() => {
    localStorage.setItem("kkdex.terminalSessions", JSON.stringify(sessions.slice(0, 8).map((session) => ({ ...session, running: false }))));
  }, [sessions]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [active?.lines.length, active?.running]);

  // Real process output stream from the Android host.
  useEffect(() => {
    return subscribeTerminalEvents((event) => {
      const session = sessionRef.current;
      if (!session) return;
      if (event.type === "output" && event.sessionId === session.key) {
        pushLines(session.key, [mkLine(event.stream === "stderr" ? "err" : "out", event.text)]);
      } else if (event.type === "exit") {
        patchSession(session.key, { running: false, exitCode: event.exitCode });
      }
    });
  }, [pushLines, patchSession]);

  const loadRuntime = useCallback(async () => {
    if (!native.available) return;
    setBusyInfo(true);
    try {
      const info = await nativeBridge.runtimeInfo();
      setRuntime(info);
    } catch {
      setRuntime(null);
    } finally {
      setBusyInfo(false);
    }
  }, [native.available]);

  useEffect(() => {
    void loadRuntime();
    // start/refresh the persistent shell session for the active tab
    if (nativeMode === "native" && active && !active.cwd.startsWith("~")) {
      void nativeBridge
        .terminalStart(active.cwd)
        .then((session: TerminalSession) => patchSession(active.key, { cwd: session.cwd || active.cwd }))
        .catch(() => undefined);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nativeMode, loadRuntime]);

  const runCommand = async (raw: string) => {
    const command = raw.trim();
    const session = sessionRef.current;
    if (!session) return;
    pushLines(session.key, [mkLine("in", `${promptFor(session, nativeMode)} ${command}`)]);
    setInput("");
    if (!command) return;

    const [name, ...args] = command.split(/\s+/);
    if (name === "clear") {
      patchSession(session.key, { lines: [] });
      return;
    }
    if (name === "help") {
      pushLines(session.key, [mkLine("out", HELP_TEXT)]);
      return;
    }
    if (name === "kkdex-info") {
      const text = runtime
        ? [
            `shell        : ${runtime.shell} (${runtime.shellPath || "system default"})`,
            `package mgr  : ${runtime.packageManager.name} — ${runtime.packageManager.available ? "available" : "not installed"}`,
            `userland     : ${runtime.userland.available ? "available" : "not bundled"}`,
            `cpu abi      : ${runtime.cpuAbi || "unknown"} · api ${runtime.apiLevel || "?"}`,
            "",
            "Detected runtimes:",
            ...runtime.runtimes.map((item) => `  ${item.name.padEnd(10)} ${item.available ? `available ${item.version ?? ""}` : "not installed"}`),
            "",
            runtime.packageManager.note,
            runtime.userland.note,
          ].join("\n")
        : "Runtime detection requires the KK DEX Android host. No tool list is invented.";
      pushLines(session.key, [mkLine("out", text)]);
      return;
    }
    if (name === "edit") {
      const path = args.join(" ") || editorPath;
      void openEditor(path);
      return;
    }

    if (nativeMode === "workspace") {
      const handler = WORKSPACE_COMMANDS[name];
      if (handler) {
        const result = handler(args);
        if (name === "clear") {
          patchSession(session.key, { lines: [] });
        } else if (result.out) {
          pushLines(session.key, [mkLine(result.err ? "err" : "out", result.out)]);
        }
        patchSession(session.key, { exitCode: result.err ? 1 : 0 });
      } else {
        pushLines(session.key, [
          mkLine("err", `${name}: command not executed — this standalone browser has no process host.`),
          mkLine("sys", "Run KK DEX on Android for real shell execution, or type 'help' for workspace commands."),
        ]);
        patchSession(session.key, { exitCode: 127 });
      }
      return;
    }

    patchSession(session.key, { running: true, exitCode: null });
    try {
      const result = await nativeBridge.terminalExec(session.key, command);
      const chunks: Line[] = [];
      if (result.stdout) chunks.push(mkLine("out", result.stdout.replace(/\n$/, "")));
      if (result.stderr) chunks.push(mkLine("err", result.stderr.replace(/\n$/, "")));
      chunks.push(mkLine("sys", `exit ${result.exitCode} · ${result.durationMs} ms${result.cwd ? ` · ${result.cwd}` : ""}`));
      pushLines(session.key, chunks);
      patchSession(session.key, {
        running: false,
        exitCode: result.exitCode,
        cwd: result.cwd || session.cwd,
        history: [command, ...session.history].slice(0, 200),
        historyIndex: -1,
      });
    } catch (error) {
      pushLines(session.key, [mkLine("err", error instanceof Error ? error.message : "Command failed.")]);
      patchSession(session.key, { running: false, exitCode: 1 });
    }
  };

  const interrupt = async () => {
    const session = sessionRef.current;
    if (!session) return;
    if (nativeMode === "native") {
      await nativeBridge.terminalInterrupt(session.key).catch(() => undefined);
    }
    pushLines(session.key, [mkLine("sys", "^C — interrupt sent")]);
    patchSession(session.key, { running: false });
  };

  const openEditor = async (path: string) => {
    setEditorPath(path);
    if (nativeMode !== "native") {
      setEditor({ path, body: "" });
      return;
    }
    try {
      const result = await nativeBridge.terminalExec(sessionRef.current?.key ?? "main", `cat -- '${path.replace(/'/g, "'\\''")}' 2>/dev/null || true`);
      setEditor({ path, body: result.stdout });
    } catch {
      setEditor({ path, body: "" });
    }
  };

  const saveEditor = async () => {
    if (!editor) return;
    const encoded = btoa(unescape(encodeURIComponent(editor.body)));
    const command = `mkdir -p -- "$(dirname -- '${editor.path.replace(/'/g, "'\\''")}')" && printf '%s' '${encoded}' | base64 -d > '${editor.path.replace(/'/g, "'\\''")}' && echo saved`;
    await runCommand(command);
    setEditor(null);
  };

  const copyOutput = async () => {
    try {
      await navigator.clipboard.writeText(active.lines.map((line) => line.text).join("\n"));
      notify("Terminal output copied", "The visible session output is on the clipboard.", { tone: "success", silent: true });
    } catch {
      notify("Clipboard unavailable", "The host denied clipboard access.", { tone: "error" });
    }
  };

  const promptFor = (session: SessionState, mode: Mode) =>
  mode === "native" ? `kkdex@tv:${session.cwd.split("/").slice(-2).join("/") || "~"}$` : "kkdex@web:~$";

  const createSession = () => {
    const session = freshSession(`s${Date.now().toString(36)}`);
    setSessions((prev) => [...prev, session]);
    setActiveKey(session.key);
  };

  const closeSession = (key: string) => {
    setSessions((prev) => {
      const remaining = prev.filter((session) => session.key !== key);
      if (remaining.length === 0) {
        const fresh = freshSession("main");
        setActiveKey(fresh.key);
        return [fresh];
      }
      if (key === activeKey) setActiveKey(remaining[remaining.length - 1].key);
      return remaining;
    });
    if (nativeMode === "native") void nativeBridge.terminalInterrupt(key).catch(() => undefined);
  };

  const detected = useMemo(() => (runtime?.runtimes ?? []).filter((item) => item.available), [runtime]);

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: settings.terminalTheme === "dark" ? "#0a0f17" : "#f6f8fb" }}>
      <div className="flex h-8 shrink-0 items-center gap-1 px-2" style={{ background: settings.terminalTheme === "dark" ? "#121a26" : "#e8edf5", borderBottom: `1px solid ${settings.terminalTheme === "dark" ? "#223044" : "#cfd8e6"}` }}>
        <TerminalIcon size={13} style={{ color: "var(--accent)" }} />
        <span className="text-[10px] font-semibold" style={{ color: settings.terminalTheme === "dark" ? "#d6e2f1" : "#1d2b3f" }}>
          KK DEX Terminal
        </span>
        <span className="badge ml-1" style={{ background: nativeMode === "native" ? "rgba(52,211,153,.16)" : "rgba(245,158,11,.16)", color: nativeMode === "native" ? "#34d399" : "#f5b84a" }}>
          {nativeMode === "native" ? "LIVE PROCESS HOST" : "WORKSPACE FALLBACK"}
        </span>
        <div className="ml-2 flex items-center gap-0.5">
          {sessions.map((session) => (
            <div key={session.key} className={cn("flex items-center gap-1 rounded-t px-2 py-0.5 text-[9px]", session.key === activeKey ? "bg-[rgba(var(--accent-rgb),.18)] text-[var(--text)]" : "opacity-60")}>
              <button className="max-w-[110px] truncate" onClick={() => setActiveKey(session.key)}>
                {session.label}
                {session.running ? <span className="ml-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full" style={{ background: "var(--accent)" }} /> : null}
              </button>
              <button aria-label={`Close ${session.label}`} className="opacity-60 hover:opacity-100" onClick={() => closeSession(session.key)}>
                <X size={9} />
              </button>
            </div>
          ))}
          <button className="icon-btn h-5 w-5" aria-label="New terminal session" onClick={createSession}><Plus size={11} /></button>
        </div>
        <div className="ml-auto flex items-center gap-1">
          <button className="icon-btn h-6 w-6" title={settings.terminalTheme === "dark" ? "Light theme" : "Dark theme"} onClick={() => updateSettings({ terminalTheme: settings.terminalTheme === "dark" ? "light" : "dark" })}>
            {settings.terminalTheme === "dark" ? <Sun size={11} /> : <Moon size={11} />}
          </button>
          <button className="icon-btn h-6 w-6" title="Copy output" onClick={() => void copyOutput()}><Copy size={11} /></button>
          <button className="icon-btn h-6 w-6" title="Clear" onClick={() => patchSession(active.key, { lines: [] })}><Trash2 size={11} /></button>
          <button className={cn("icon-btn h-6 w-6", active.running && "text-red-400")} title="Interrupt (Ctrl+C)" disabled={!active.running} onClick={() => void interrupt()}><Square size={10} /></button>
          <button className="icon-btn h-6 w-6" title="Source editor" onClick={() => void openEditor(editorPath)}><FileCode2 size={11} /></button>
          <button className="icon-btn h-6 w-6" title="Runtime information" onClick={() => void loadRuntime()}><Info size={11} /></button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1">
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex h-6 shrink-0 items-center gap-2 px-3 text-[8.5px]" style={{ borderBottom: `1px solid ${settings.terminalTheme === "dark" ? "#1c2635" : "#dde5ef"}`, color: settings.terminalTheme === "dark" ? "#7d91aa" : "#5b6b80" }}>
            <FolderOpen size={9} />
            <span className="truncate">{active.cwd}</span>
            <span>· {active.lines.length} lines</span>
            {active.exitCode !== null ? <span className="badge" style={{ background: active.exitCode === 0 ? "rgba(52,211,153,.15)" : "rgba(248,113,113,.15)", color: active.exitCode === 0 ? "#34d399" : "#f87171" }}>exit {active.exitCode}</span> : null}
            <span className="ml-auto flex items-center gap-1">
              <button className="hover:underline" onClick={() => updateSettings({ terminalFontSize: Math.max(9, settings.terminalFontSize - 1) })}>A-</button>
              <button className="hover:underline" onClick={() => updateSettings({ terminalFontSize: Math.min(22, settings.terminalFontSize + 1) })}>A+</button>
              <span>{settings.terminalFontSize}px</span>
            </span>
          </div>

          <div
            ref={scrollRef}
            className="scroll-thin min-h-0 flex-1 select-text overflow-y-auto px-3 py-2"
            style={{
              fontFamily: "'JetBrains Mono', ui-monospace, monospace",
              fontSize: settings.terminalFontSize,
              lineHeight: 1.5,
              color: settings.terminalTheme === "dark" ? "#d6e2f1" : "#16212f",
              background: settings.terminalTheme === "dark" ? "#0a0f17" : "#f6f8fb",
            }}
            onClick={() => inputRef.current?.focus()}
          >
            {active.lines.length === 0 ? (
              <pre className="whitespace-pre-wrap opacity-70">{`KK DEX Terminal — ${nativeMode === "native" ? "real process host" : "workspace fallback"}\nType 'help' for commands, 'kkdex-info' for detected tools.\n`}</pre>
            ) : null}
            {active.lines.map((line) => (
              <pre
                key={line.id}
                className="m-0 whitespace-pre-wrap break-words"
                style={{
                  color:
                    line.kind === "err"
                      ? settings.terminalTheme === "dark" ? "#fb8a8a" : "#b42318"
                      : line.kind === "in"
                        ? settings.terminalTheme === "dark" ? "#9ed0ff" : "#1d4ed8"
                        : line.kind === "sys"
                          ? settings.terminalTheme === "dark" ? "#7f9fc0" : "#64748b"
                          : undefined,
                }}
              >
                {line.text}
              </pre>
            ))}
            {active.running ? <div className="flex items-center gap-1.5 py-0.5 text-[10px] opacity-70"><Loader2 size={10} className="animate-spin" /> process running…</div> : null}
            <div className="flex items-start gap-1.5">
              <span className="shrink-0" style={{ color: settings.terminalTheme === "dark" ? "#62d9a8" : "#047857" }}>{promptFor(active, nativeMode)}</span>
              <input
                ref={inputRef}
                autoFocus
                value={input}
                spellCheck={false}
                autoCapitalize="none"
                autoComplete="off"
                className="min-w-0 flex-1 border-0 bg-transparent p-0 outline-none"
                style={{ fontFamily: "inherit", fontSize: "inherit", color: "inherit" }}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    void runCommand(input);
                  } else if (event.ctrlKey && event.key.toLowerCase() === "c" && active.running) {
                    event.preventDefault();
                    void interrupt();
                  } else if (event.ctrlKey && event.key.toLowerCase() === "l") {
                    event.preventDefault();
                    patchSession(active.key, { lines: [] });
                  } else if (event.ctrlKey && event.key.toLowerCase() === "u") {
                    event.preventDefault();
                    setInput("");
                  } else if (event.ctrlKey && event.key.toLowerCase() === "d") {
                    event.preventDefault();
                    notify("EOF sent", "Ctrl+D signals end-of-input in the real shell.", { silent: true });
                  } else if (event.key === "ArrowUp") {
                    event.preventDefault();
                    const nextIndex = Math.min(active.historyIndex + 1, active.history.length - 1);
                    if (active.history[nextIndex]) {
                      patchSession(active.key, { historyIndex: nextIndex });
                      setInput(active.history[nextIndex]);
                    }
                  } else if (event.key === "ArrowDown") {
                    event.preventDefault();
                    const nextIndex = Math.max(active.historyIndex - 1, -1);
                    patchSession(active.key, { historyIndex: nextIndex });
                    setInput(nextIndex === -1 ? "" : active.history[nextIndex] ?? "");
                  }
                }}
              />
            </div>
          </div>

          <div className="flex h-6 shrink-0 items-center gap-3 px-3 text-[8px]" style={{ borderTop: `1px solid ${settings.terminalTheme === "dark" ? "#1c2635" : "#dde5ef"}`, background: settings.terminalTheme === "dark" ? "#121a26" : "#e8edf5", color: settings.terminalTheme === "dark" ? "#71849d" : "#5b6b80" }}>
            <span>{nativeMode === "native" ? "Real processes in the Android app sandbox" : "Standalone browser — no process host"}</span>
            <span className="ml-auto flex items-center gap-2">
              <button className="hover:underline" onClick={() => void openEditor("hello.py")}>edit hello.py</button>
              <button className="hover:underline" onClick={() => void runCommand("ls -la")}>ls</button>
              <button className="hover:underline" onClick={() => void runCommand("kkdex-info")}>tools</button>
            </span>
          </div>
        </div>

        <aside className="hidden w-[212px] shrink-0 flex-col overflow-y-auto p-2 lg:flex scroll-thin" style={{ borderLeft: `1px solid ${settings.terminalTheme === "dark" ? "#1c2635" : "#dde5ef"}`, background: settings.terminalTheme === "dark" ? "#0d141d" : "#eef2f8" }}>
          <div className="mb-1 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: settings.terminalTheme === "dark" ? "#6d8098" : "#64748b" }}>
            Detected tools
          </div>
          {busyInfo ? <Loader2 size={11} className="animate-spin" /> : null}
          {!runtime ? (
            <div className="text-[8.5px] leading-relaxed" style={{ color: settings.terminalTheme === "dark" ? "#7d91aa" : "#64748b" }}>
              Runtime detection needs the Android host. Nothing is listed until it is really detected.
            </div>
          ) : (
            <>
              <div className="space-y-0.5">
                {runtime.runtimes.map((item) => (
                  <div key={item.name} className="flex items-center gap-1.5 rounded px-1.5 py-1 text-[9px]" style={{ background: settings.terminalTheme === "dark" ? "#111b27" : "#ffffff" }}>
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: item.available ? "#34d399" : "#64748b" }} />
                    <span className="flex-1">{item.name}</span>
                    <span className="truncate text-[8px]" style={{ color: settings.terminalTheme === "dark" ? "#7d91aa" : "#64748b" }}>
                      {item.available ? item.version || "installed" : "not installed"}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-2 rounded-lg p-2 text-[8px] leading-relaxed" style={{ background: settings.terminalTheme === "dark" ? "#111b27" : "#ffffff", color: settings.terminalTheme === "dark" ? "#9db0c7" : "#475569" }}>
                <div className="flex items-center gap-1 font-medium"><Zap size={9} /> {runtime.packageManager.name}</div>
                {runtime.packageManager.note}
              </div>
              <div className="mt-1.5 rounded-lg p-2 text-[8px] leading-relaxed" style={{ background: settings.terminalTheme === "dark" ? "#111b27" : "#ffffff", color: settings.terminalTheme === "dark" ? "#9db0c7" : "#475569" }}>
                {runtime.userland.note}
              </div>
            </>
          )}

          <div className="mt-2 mb-1 text-[8.5px] font-semibold uppercase tracking-wider" style={{ color: settings.terminalTheme === "dark" ? "#6d8098" : "#64748b" }}>
            Quick commands
          </div>
          {["ls -la", "pwd", "df -h", "ps -A", "uname -a", "env | sort", "kkdex-info", "python --version", "node --version", "git status"].map((command) => (
            <button
              key={command}
              className="mb-0.5 w-full truncate rounded px-1.5 py-1 text-left font-mono text-[8.5px]"
              style={{ background: settings.terminalTheme === "dark" ? "#111b27" : "#ffffff", color: settings.terminalTheme === "dark" ? "#9db0c7" : "#334155" }}
              onClick={() => { setInput(command); inputRef.current?.focus(); }}
            >
              {command}
            </button>
          ))}

          <div className="mt-auto rounded-lg p-2 text-[7.5px] leading-relaxed" style={{ background: settings.terminalTheme === "dark" ? "#111b27" : "#ffffff", color: settings.terminalTheme === "dark" ? "#7d91aa" : "#64748b" }}>
            <div className="flex items-center gap-1 font-medium"><Lightbulb size={9} /> Honest capability model</div>
            Commands run in the app sandbox with no root. Missing tools report the OS error; they are never faked. {detected.length} runtime{detected.length === 1 ? "" : "s"} currently detected.
            <button className="mt-1 block hover:underline" style={{ color: "var(--accent)" }} onClick={() => showInfo("KK DEX Terminal capabilities", "Real shell execution uses the Android process API in the application's private workspace, with the user's authorized folders mounted through Storage Access Framework. Package management, Python, Node.js, Git and compilers run only when those tools are actually installed on the device; KK DEX does not bundle a Linux distribution or bypass Android sandboxing. Root operations are always refused.", <TerminalIcon size={24} />)}>
              Read capability notes
            </button>
            <button className="mt-1 block hover:underline" style={{ color: "var(--accent)" }} onClick={() => launch("files", { payload: { native: true } })}>
              Open authorized storage
            </button>
          </div>
        </aside>
      </div>

      {editor ? (
        <div className="absolute inset-0 z-30 flex flex-col" style={{ background: "var(--surface-solid)" }}>
          <div className="flex items-center gap-2 px-3 py-2" style={{ borderBottom: "1px solid var(--border)" }}>
            <FileCode2 size={13} style={{ color: "var(--accent)" }} />
            <input className="field !h-7 max-w-[320px] flex-1" value={editor.path} onChange={(event) => setEditor({ ...editor, path: event.target.value })} />
            <button className="btn btn-sm btn-accent" onClick={() => void saveEditor()}><Save size={11} /> Save to workspace</button>
            <button className="btn btn-sm" onClick={() => setEditor(null)}>Close</button>
          </div>
          <textarea
            value={editor.body}
            onChange={(event) => setEditor({ ...editor, body: event.target.value })}
            spellCheck={false}
            className="scroll-thin min-h-0 flex-1 resize-none border-0 p-3 font-mono text-[11.5px] leading-relaxed outline-none"
            style={{ background: settings.terminalTheme === "dark" ? "#0a0f17" : "#f6f8fb", color: settings.terminalTheme === "dark" ? "#d6e2f1" : "#16212f", userSelect: "text" }}
            placeholder="# Write source code here, then press Save to write it into the terminal workspace."
          />
          <div className="flex items-center gap-2 border-t px-3 py-1.5 text-[8.5px]" style={{ borderColor: "var(--border)", color: "var(--muted)" }}>
            <Check size={10} /> Saving writes the file through the real shell (base64 stream), so scripts can be executed immediately after.
            <button className="ml-auto hover:underline" onClick={() => void runCommand(`cat -- '${editor.path.replace(/'/g, "'\\''")}'`)}>Preview with cat</button>
          </div>
        </div>
      ) : null}

      {nativeMode === "workspace" ? (
        <div className="px-3 pb-2">
          <AppNotice tone="warn">
            <AlertTriangle size={11} className="mt-0.5 shrink-0" />
            This browser session has no process host, so commands are not simulated. Install/run the Android build of KK DEX for the real shell, package tools and language runtimes.
          </AppNotice>
        </div>
      ) : null}
    </div>
  );
}

function freshSession(label: string): SessionState {
  return {
    key: `t${Math.random().toString(36).slice(2, 8)}`,
    label,
    cwd: "~/workspace",
    lines: [],
    history: [],
    historyIndex: -1,
    running: false,
    exitCode: null,
  };
}
