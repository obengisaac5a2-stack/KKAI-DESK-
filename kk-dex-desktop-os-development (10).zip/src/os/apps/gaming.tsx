import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Box,
  Cloud,
  Cpu,
  Database,
  Download,
  ExternalLink,
  FolderOpen,
  Gamepad2,
  Gauge,
  HardDrive,
  Info,
  Loader2,
  MemoryStick,
  Monitor,
  Play,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Star,
  Wifi,
} from "lucide-react";
import { AppIcon } from "../icons";
import {
  nativeBridge,
  type NativeApp,
  type NativeDownload,
  type NativeNetworkInfo,
  type NativeStorageInfo,
  type NativeSystemStats,
} from "../native";
import { formatBytes, formatDate, useOS } from "../OSContext";
import type { AppContentProps } from "../types";
import { AppNotice, EmptyState, SearchBox } from "../ui";
import { useNativeState } from "../NativeStorage";
import { cn } from "@/utils/cn";

function useAsync<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const refresh = () => {
    setLoading(true);
    setError("");
    loader()
      .then((value) => setData(value))
      .catch((err) => setError(err instanceof Error ? err.message : "The Android host could not complete this request."))
      .finally(() => setLoading(false));
  };
  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return { data, setData, loading, error, refresh };
}

/* ------------------------------- Storage Manager ------------------------------ */

const CATEGORY_META = [
  { key: "apps", label: "Applications", color: "#8b7cff" },
  { key: "images", label: "Images", color: "#f0729b" },
  { key: "videos", label: "Videos", color: "#fb923c" },
  { key: "audio", label: "Audio", color: "#a78bfa" },
  { key: "documents", label: "Documents", color: "#5b9dff" },
  { key: "downloads", label: "Downloads", color: "#2cc9a0" },
  { key: "apk", label: "APK files", color: "#facc15" },
  { key: "games", label: "Games", color: "#f472b6" },
  { key: "other", label: "Other", color: "#94a3b8" },
] as const;

export function StorageApp() {
  const { launch, showInfo, notify, files } = useOS();
  const native = useNativeState();
  const canNative = native.available && native.capabilities.storageStats;
  const info = useAsync<NativeStorageInfo>(
    () => (canNative ? nativeBridge.getStorageInfo() : Promise.reject(new Error("Native Android storage statistics are unavailable in this browser session."))),
    [canNative],
  );
  const [requesting, setRequesting] = useState(false);
  const workspaceBytes = files.filter((file) => file.kind !== "folder").reduce((sum, file) => sum + file.size, 0);

  const total = info.data?.totalBytes ?? 0;
  const available = info.data?.availableBytes ?? 0;
  const used = info.data?.usedBytes || Math.max(0, total - available);
  const percent = total ? Math.min(100, Math.round((used / total) * 100)) : 0;
  const categories = info.data?.categories;
  const categoryTotal = categories ? Object.values(categories).reduce((sum, value) => sum + value, 0) : 0;

  const requestAccess = async () => {
    setRequesting(true);
    try {
      await nativeBridge.requestStoragePermission(["images", "video", "audio", "documents"]);
      notify("Android permission prompt requested", "SAF still requires you to choose a folder explicitly.", { tone: "success" });
    } catch (err) {
      notify("Permission request failed", err instanceof Error ? err.message : "Android rejected the request.", { tone: "error" });
    } finally {
      setRequesting(false);
    }
  };

  return (
    <div className="scroll-thin h-full overflow-y-auto" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-3 px-4 pt-3.5 pb-3" style={{ background: "linear-gradient(120deg, rgba(14,165,233,.14), transparent)", borderBottom: "1px solid var(--border)" }}>
        <div className="flex h-11 w-11 items-center justify-center rounded-xl" style={{ background: "rgba(14,165,233,.14)", color: "#38bdf8" }}><Database size={22} /></div>
        <div className="min-w-0">
          <div className="text-[15px] font-semibold tracking-tight">Storage Manager</div>
          <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>
            {canNative ? "Actual Android storage metrics via StatFs and MediaStore" : "Native Android storage bridge not connected"}
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn btn-sm" onClick={info.refresh} disabled={!canNative || info.loading}>{info.loading ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />} Refresh</button>
          <button className="btn btn-sm btn-accent" onClick={() => launch("files", { payload: { native: true } })}><FolderOpen size={11} /> Browse device files</button>
        </div>
      </div>

      {!canNative ? (
        <div className="px-3.5 pt-3">
          <AppNotice tone="warn">
            <Info size={12} className="mt-0.5 shrink-0" />
            <span>
              Real phone storage cannot be read from a standalone web page. Run KK DEX inside the Android host to see the device's actual total, used and available storage. No placeholder capacity is shown.
              {native.available ? " The native bridge is present but does not advertise storage statistics." : ""}
            </span>
          </AppNotice>
          <div className="mt-2 rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
            <div className="text-[10px] font-medium">KK DEX workspace (web-only)</div>
            <div className="mt-1 text-[22px] font-light">{formatBytes(workspaceBytes)} <span className="text-[10px]" style={{ color: "var(--muted)" }}>of workspace content</span></div>
            <button className="btn btn-sm mt-2" onClick={() => void requestAccess()} disabled={requesting}>{requesting ? <Loader2 size={11} className="animate-spin" /> : <ShieldCheck size={11} />} Request Android access</button>
          </div>
        </div>
      ) : info.error ? (
        <div className="p-4"><AppNotice tone="warn"><AlertTriangle size={12} /> {info.error} <button className="ml-auto underline" onClick={info.refresh}>Retry</button></AppNotice></div>
      ) : (
        <div className="grid gap-2.5 p-3.5 md:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
          <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
            <div className="flex items-center justify-between">
              <div className="text-[12px] font-semibold">Internal storage</div>
              <span className="badge badge-accent"><ShieldCheck size={8} /> Live Android data</span>
            </div>
            <div className="mt-3 flex items-center gap-4">
              <div className="relative flex h-[124px] w-[124px] shrink-0 items-center justify-center rounded-full" style={{ background: `conic-gradient(var(--accent) 0 ${percent}%, var(--surface-4) ${percent}% 100%)` }}>
                <div className="flex h-[94px] w-[94px] flex-col items-center justify-center rounded-full" style={{ background: "var(--surface-2)" }}>
                  <span className="text-[23px] font-light leading-none">{percent}%</span>
                  <span className="mt-0.5 text-[8px]" style={{ color: "var(--muted)" }}>used</span>
                </div>
              </div>
              <div className="min-w-0 flex-1 space-y-2">
                <div>
                  <div className="text-[22px] font-light leading-none">{formatBytes(used)}</div>
                  <div className="mt-0.5 text-[9px]" style={{ color: "var(--muted)" }}>used of {formatBytes(total)}</div>
                </div>
                <div className="text-[10px]"><span className="font-medium">{formatBytes(available)}</span> <span style={{ color: "var(--muted)" }}>available</span></div>
                <div className="h-1.5 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}>
                  <div className="h-full rounded-full" style={{ width: `${Math.max(2, percent)}%`, background: "linear-gradient(90deg,var(--accent),#8b7cff)" }} />
                </div>
                {percent >= 90 ? <div className="text-[8.5px] text-red-300">Storage is critically low. Free space before downloading games or updates.</div> : null}
                {info.data?.externalTotalBytes ? (
                  <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>External: {formatBytes(info.data.externalAvailableBytes ?? 0)} free of {formatBytes(info.data.externalTotalBytes)}</div>
                ) : null}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              <button className="btn btn-sm" onClick={() => launch("downloads", { payload: { tab: "android" } })}><Download size={11} /> Downloads</button>
              <button className="btn btn-sm" onClick={() => launch("files", { payload: { native: true } })}><FolderOpen size={11} /> SAF files</button>
              <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("storage").catch((error) => notify("Android settings unavailable", error.message, { tone: "error" }))}><ExternalLink size={11} /> Android storage settings</button>
            </div>
          </section>

          <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
            <div className="mb-2 flex items-center justify-between">
              <div className="text-[12px] font-semibold">Storage categories</div>
              <span className="text-[8.5px]" style={{ color: "var(--faint)" }}>{formatBytes(categoryTotal)} measured</span>
            </div>
            <div className="space-y-1">
              {CATEGORY_META.map((category) => {
                const value = categories?.[category.key] ?? 0;
                const share = categoryTotal ? Math.max(1, Math.round((value / categoryTotal) * 100)) : 0;
                return (
                  <div key={category.key} className="flex items-center gap-2 text-[9.5px]">
                    <span className="h-2 w-2 shrink-0 rounded-sm" style={{ background: category.color }} />
                    <span className="w-[78px] shrink-0">{category.label}</span>
                    <span className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}>
                      <span className="block h-full rounded-full" style={{ width: `${share}%`, background: category.color }} />
                    </span>
                    <span className="w-[62px] shrink-0 text-right font-mono text-[8.5px]" style={{ color: "var(--muted)" }}>{formatBytes(value)}</span>
                  </div>
                );
              })}
            </div>
            {info.data?.categoryNote ? <div className="mt-2 rounded px-2 py-1.5 text-[8px]" style={{ background: "var(--field)", color: "var(--muted)" }}>{info.data.categoryNote}</div> : null}
            <div className="mt-2 text-[8px] leading-relaxed" style={{ color: "var(--faint)" }}>
              Totals come from Android's filesystem statistics. Categories use MediaStore plus app size queries. Some app-private data may be excluded by Android, so category totals need not equal used storage.
            </div>
          </section>
        </div>
      )}

      <div className="px-3.5 pb-3">
        <div className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
          <div className="mb-1.5 flex items-center gap-2"><HardDrive size={13} style={{ color: "var(--accent)" }} /><span className="text-[11px] font-semibold">File access policy</span></div>
          <p className="text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>
            KK DEX can only read files you explicitly authorize through Android's Storage Access Framework. It does not request unrestricted all-files access and cannot browse private app directories. File operations respect the provider's read/write grants.
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <button className="btn btn-sm" onClick={() => launch("files", { payload: { native: true } })}><ShieldCheck size={11} /> Authorize a folder</button>
            <button className="btn btn-sm" onClick={() => showInfo("Why not every folder?", "Android 11+ intentionally hides shared-storage paths from normal apps. KK DEX uses the document picker so you stay in control of what it can read. Root and MANAGE_EXTERNAL_STORAGE access are not used.", <Database size={22} />)}><Info size={11} /> Learn more</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- Gaming Centre ------------------------------- */

type GameTab = "library" | "discovery" | "downloads" | "performance" | "compatibility";

interface GameShortcut {
  packageName: string;
  label: string;
  icon?: string;
  pinnedAt: number;
}

export function GamesApp({ payload }: AppContentProps) {
  const { launch, showInfo, settings, updateSettings, openPhoneController } = useOS();
  const native = useNativeState();
  const caps = native.capabilities;
  const canApps = native.available && caps.installedApps;
  const canDownload = native.available && caps.downloadManager;
  const [tab, setTab] = useState<GameTab>((payload?.tab as GameTab) ?? "library");
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("");
  const [pinned, setPinned] = useState<GameShortcut[]>(() => {
    try { return JSON.parse(localStorage.getItem("kkdex.gameShortcuts") ?? "[]") as GameShortcut[]; } catch { return []; }
  });
  const apps = useAsync<NativeApp[]>(() => (canApps ? nativeBridge.getInstalledApps() : Promise.reject(new Error("Android package discovery is unavailable in this browser."))), [canApps]);
  const downloads = useAsync<NativeDownload[]>(() => (canDownload ? nativeBridge.getNativeDownloads() : Promise.reject(new Error("Native download manager unavailable."))), [canDownload]);
  const system = useAsync<NativeSystemStats>(() => (native.available ? nativeBridge.getSystemStats() : Promise.reject(new Error("Native system statistics unavailable."))), [native.available]);
  const network = useAsync<NativeNetworkInfo>(() => (native.available ? nativeBridge.getNetworkInfo() : Promise.reject(new Error("Native network information unavailable."))), [native.available]);

  useEffect(() => {
    localStorage.setItem("kkdex.gameShortcuts", JSON.stringify(pinned));
  }, [pinned]);

  useEffect(() => {
    if (tab === "downloads" && canDownload) downloads.refresh();
    if (tab === "performance" && native.available) { system.refresh(); network.refresh(); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  useEffect(() => {
    if (tab !== "performance" || !native.available) return;
    const timer = window.setInterval(() => system.refresh(), 5000);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, native.available]);

  const games = useMemo(() => (apps.data ?? []).filter((app) => app.isGame).sort((a, b) => a.label.localeCompare(b.label)), [apps.data]);
  const apks = useMemo(() => (downloads.data ?? []).filter((item) => /\.apk$/i.test(item.name) || item.mime === "application/vnd.android.package-archive"), [downloads.data]);
  const filteredGames = games.filter((game) => `${game.label} ${game.packageName}`.toLowerCase().includes(query.toLowerCase()));

  const applyMode = async (mode: "performance" | "balanced" | "visual") => {
    updateSettings({ performance: mode, reduceMotion: mode === "performance" ? true : settings.reduceMotion });
    if (!native.available || !caps.performanceModes) {
      setStatus(`Desktop mode set to ${mode}. WebView animations and effects update immediately; native mode is not exposed by this host.`);
      return;
    }
    try {
      const result = await nativeBridge.setPerformanceMode(mode);
      setStatus(`${mode[0].toUpperCase()}${mode.slice(1)} mode applied. ${result.note || "This changes animation and rendering policy only; it does not increase the phone's physical CPU or GPU power."}`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "Native performance mode failed.");
    }
  };

  const launchGame = async (game: NativeApp) => {
    setStatus(`Launching ${game.label}…`);
    try {
      const result = await nativeBridge.launchAndroidApp(game.packageName);
      setStatus(result.launched ? `${game.label} launched ${result.display === "external" ? "on the external display" : "on the Android phone"}. ${result.message ?? ""}` : `Android did not launch ${game.label}. ${result.message ?? "The game may not support the current display mode."}`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "Android rejected the launch request.");
    }
  };

  const installApk = async (download: NativeDownload) => {
    try {
      const ok = await nativeBridge.installApk(download.localUri || download.uri);
      if (ok) setStatus(`Android's package installer opened for ${download.name}. Installation only completes if you approve Android's prompt and the APK signature is valid.`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "Android could not start the package installer.");
    }
  };

  const pickAndInstall = async () => {
    try {
      const [file] = await nativeBridge.pickFiles("application/vnd.android.package-archive", false);
      if (!file) return;
      const ok = await nativeBridge.installApk(file.uri);
      if (ok) setStatus(`Android's installer opened for ${file.name}. KK DEX did not install it silently.`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "The APK picker or installer failed.");
    }
  };

  const togglePin = (game: NativeApp) => {
    setPinned((prev) => prev.some((item) => item.packageName === game.packageName) ? prev.filter((item) => item.packageName !== game.packageName) : [...prev, { packageName: game.packageName, label: game.label, icon: game.icon, pinnedAt: Date.now() }].slice(-12));
  };

  return (
    <div className="flex h-full min-h-0 flex-col" style={{ background: "var(--surface-solid)" }}>
      <div className="relative shrink-0 overflow-hidden px-4 pt-3.5 pb-3" style={{ background: "linear-gradient(115deg, rgba(139,92,246,.24), rgba(14,20,32,.15) 55%, transparent)", borderBottom: "1px solid var(--border)" }}>
        <div className="pointer-events-none absolute -right-8 -top-14 h-40 w-40 rounded-full" style={{ background: "radial-gradient(circle, rgba(167,139,250,.28), transparent 65%)" }} />
        <div className="relative flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl" style={{ background: "linear-gradient(145deg,#a78bfa,#6d28d9)", boxShadow: "0 8px 24px -12px rgba(139,92,246,.7)" }}><Gamepad2 size={22} color="#fff" /></div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-[15px] font-semibold tracking-tight">Gaming Centre <span className="badge badge-accent">KK DEX PLAY</span></div>
            <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>{games.length} Android games discovered · {apks.length} installable APK{apks.length === 1 ? "" : "s"} · real hardware only</div>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <button className="btn btn-sm" onClick={openPhoneController}><Smartphone size={11} /> Controller</button>
            <button className="btn btn-sm" onClick={() => { apps.refresh(); downloads.refresh(); system.refresh(); }} disabled={!native.available}>{apps.loading ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />} Scan</button>
          </div>
        </div>
        <div className="relative mt-2.5 flex flex-wrap items-center gap-1">
          {([
            ["library", "Library", Gamepad2],
            ["discovery", "Installed games", Smartphone],
            ["downloads", "Downloads & APKs", Download],
            ["performance", "Performance", Gauge],
            ["compatibility", "Compatibility", ShieldCheck],
          ] as const).map(([id, label, Icon]) => (
            <button key={id} className={cn("flex items-center gap-1.5 rounded-md px-2.5 py-1 text-[9.5px] transition-colors", tab === id ? "text-white" : "hover:bg-[var(--hover)]")} style={{ background: tab === id ? "var(--accent)" : "var(--field)", border: "1px solid var(--border)" }} onClick={() => setTab(id)}>
              <Icon size={11} /> {label}
            </button>
          ))}
          <div className="ml-auto"><SearchBox value={query} onChange={setQuery} placeholder="Search your library" className="w-[168px]" /></div>
        </div>
        {status ? <div className="relative mt-2 flex items-start gap-1.5 rounded-md px-2 py-1.5 text-[8.5px] leading-relaxed" style={{ background: "rgba(255,255,255,.05)", color: "var(--muted)" }}><Info size={10} className="mt-0.5 shrink-0" /> {status}</div> : null}
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
        {tab === "library" ? (
          <div className="space-y-3">
            {pinned.length ? (
              <section>
                <div className="mb-1.5 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}><Star size={10} /> Pinned shortcuts</div>
                <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3 xl:grid-cols-5">
                  {pinned.map((item) => {
                    const game = games.find((entry) => entry.packageName === item.packageName);
                    return (
                      <button key={item.packageName} className="group overflow-hidden rounded-xl text-left" style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }} onClick={() => game ? void launchGame(game) : setStatus(`${item.label} is no longer installed on this Android device.`)}>
                        <div className="relative flex h-[74px] items-center justify-center" style={{ background: "linear-gradient(140deg, rgba(139,92,246,.32), rgba(30,41,59,.2))" }}>
                          {item.icon ? <img src={item.icon} alt="" className="h-10 w-10 rounded-lg" /> : <Gamepad2 size={26} style={{ color: "#c4b5fd" }} />}
                          <span className="absolute right-1 top-1 rounded bg-black/35 px-1 py-0.5 text-[7px] text-white">PINNED</span>
                        </div>
                        <div className="px-2 py-1.5"><div className="truncate text-[9.5px] font-medium">{item.label}</div><div className="flex items-center gap-1 text-[7.5px]" style={{ color: "var(--muted)" }}><span className="h-1 w-1 rounded-full bg-emerald-400" /> Android compatible</div></div>
                      </button>
                    );
                  })}
                </div>
              </section>
            ) : null}
            <section>
              <div className="mb-1.5 flex items-center justify-between">
                <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}><Sparkles size={10} /> Installed game library</div>
                <button className="text-[8.5px] hover:underline" style={{ color: "var(--muted)" }} onClick={() => setTab("discovery")}>Manage library</button>
              </div>
              {!canApps ? (
                <div className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                  <div className="flex items-start gap-2"><Info size={13} style={{ color: "var(--accent)" }} /><div><div className="text-[10.5px] font-medium">Android game discovery needs the native host</div><p className="mt-1 text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>No game list is fabricated in the browser. When KK DEX runs on Android, PackageManager reports installed launcher games with their real labels, icons and package names.</p></div></div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <button className="btn btn-sm" onClick={() => setTab("compatibility")}><ShieldCheck size={11} /> Compatibility</button>
                    <button className="btn btn-sm" onClick={() => { launch("browser"); }}><Cloud size={11} /> Open cloud gaming</button>
                  </div>
                </div>
              ) : apps.error ? (
                <AppNotice tone="warn"><AlertTriangle size={12} /> {apps.error}</AppNotice>
              ) : apps.loading ? (
                <div className="flex items-center justify-center gap-2 py-10 text-[10px]" style={{ color: "var(--muted)" }}><Loader2 size={14} className="animate-spin" /> Reading Android games…</div>
              ) : filteredGames.length === 0 ? (
                <EmptyState icon={<Gamepad2 size={23} />} title="No Android games found" description="Only launcher games reported by Android are listed. Install a game through Google Play or a valid APK, then scan again." action={<button className="btn btn-sm" onClick={() => setTab("downloads")}><Download size={11} /> Open game downloads</button>} />
              ) : (
                <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                  {filteredGames.map((game) => (
                    <div key={game.packageName} className="group overflow-hidden rounded-xl" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                      <div className="relative flex h-[82px] items-center justify-center overflow-hidden" style={{ background: "linear-gradient(140deg, rgba(139,92,246,.3), rgba(15,23,42,.5))" }}>
                        {game.icon ? <img src={game.icon} alt="" className="h-11 w-11 rounded-xl shadow-lg" /> : <Gamepad2 size={30} style={{ color: "#c4b5fd" }} />}
                        <span className="absolute left-1.5 top-1.5 rounded bg-black/35 px-1.5 py-0.5 text-[7px] text-white">ANDROID</span>
                        <button className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded bg-black/35 text-white" aria-label={`Pin ${game.label}`} onClick={() => togglePin(game)}><Star size={10} fill={pinned.some((item) => item.packageName === game.packageName) ? "currentColor" : "none"} /></button>
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-2 py-1"><div className="truncate text-[10px] font-medium text-white">{game.label}</div></div>
                      </div>
                      <div className="p-2">
                        <div className="flex items-center justify-between text-[8px]" style={{ color: "var(--muted)" }}><span className="truncate">{game.versionName ?? "Installed app"}</span><span>{game.size ? formatBytes(game.size) : "Size not exposed"}</span></div>
                        <div className="mt-1.5 flex gap-1">
                          <button className="btn btn-sm btn-accent flex-1 !h-6" onClick={() => void launchGame(game)}><Play size={10} /> Launch</button>
                          <button className="btn btn-sm !h-6 !px-2" title="Game details" onClick={() => showInfo(game.label, `Package: ${game.packageName}\nVersion: ${game.versionName ?? "not reported"}\nInstalled: ${game.installedAt ? formatDate(game.installedAt) : "not reported"}\n\nLaunch behavior depends on Android and the game's external-display support. KK DEX reports whether it launches on the phone or the TV.`, <Gamepad2 size={24} />)}><Info size={10} /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
            <div className="grid gap-2 sm:grid-cols-3">
              {[
                { icon: Cloud, title: "Cloud gaming", body: "Open a supported cloud gaming site in the native browser.", action: () => launch("browser", { payload: { url: "https://www.google.com/search?q=cloud+gaming+android" } }), label: "Browse cloud services" },
                { icon: Box, title: "Compatibility runtime", body: "Windows .exe files cannot run directly. A compatible emulator/Wine-style runtime must be installed and authorized.", action: () => setTab("compatibility"), label: "Review compatibility" },
                { icon: Download, title: "Install a game APK", body: "Open Android's document picker, then Android's official package installer.", action: () => void pickAndInstall(), label: "Pick APK...", disabled: !caps.apkInstall },
              ].map((card) => (
                <div key={card.title} className="rounded-xl p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                  <card.icon size={14} style={{ color: "var(--accent)" }} />
                  <div className="mt-1 text-[10.5px] font-medium">{card.title}</div>
                  <div className="mt-0.5 text-[8.5px] leading-relaxed" style={{ color: "var(--muted)" }}>{card.body}</div>
                  <button className="btn btn-sm mt-1.5 !h-6 w-full" onClick={card.action} disabled={card.disabled}>{card.label}</button>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {tab === "discovery" ? (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <div><div className="text-[11px] font-semibold">Installed Android applications</div><div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{apps.data?.length ?? 0} launchable apps · games flagged by Android</div></div>
              <button className="btn btn-sm" onClick={apps.refresh} disabled={!canApps || apps.loading}>{apps.loading ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />} Refresh</button>
            </div>
            {!canApps ? <AppNotice tone="warn"><Info size={12} /> PackageManager discovery is not available in this host.</AppNotice> : null}
            <div className="mt-2 grid gap-1">
              {(apps.data ?? []).filter((app) => `${app.label} ${app.packageName}`.toLowerCase().includes(query.toLowerCase())).map((app) => (
                <div key={app.packageName} className="flex items-center gap-2 rounded-lg px-2 py-1.5 row-hover" style={{ border: "1px solid var(--border)", background: "var(--surface-2)" }}>
                  {app.icon ? <img src={app.icon} alt="" className="h-7 w-7 rounded-md" /> : <div className="flex h-7 w-7 items-center justify-center rounded-md" style={{ background: "var(--field)" }}><AppIcon id="appcenter" size={16} /></div>}
                  <div className="min-w-0 flex-1"><div className="flex items-center gap-1"><span className="truncate text-[10px] font-medium">{app.label}</span>{app.isGame ? <span className="badge !text-[7px]">GAME</span> : null}</div><div className="truncate font-mono text-[7.5px]" style={{ color: "var(--muted)" }}>{app.packageName}</div></div>
                  <button className="btn btn-sm !h-6" onClick={() => void nativeBridge.launchAndroidApp(app.packageName).then((r) => setStatus(`${app.label}: ${r.message ?? (r.launched ? "launched" : "not launched")}`)).catch((err) => setStatus(err.message))}><Play size={9} /> Launch</button>
                  <button className="btn btn-sm !h-6 !px-2" onClick={() => nativeBridge.openSystemSettings("apps").catch(() => undefined)}><Info size={10} /></button>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {tab === "downloads" ? (
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-2 rounded-lg px-2.5 py-2" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
              <Download size={13} style={{ color: "var(--accent)" }} />
              <div className="text-[9px] leading-snug" style={{ color: "var(--muted)" }}>Game downloads are real Android DownloadManager entries, saved to <strong>Download/KK DEX</strong>. APK installation always goes through Android's package installer.</div>
              <div className="ml-auto flex gap-1"><button className="btn btn-sm" onClick={downloads.refresh} disabled={!canDownload}><RefreshCw size={10} /> Refresh</button><button className="btn btn-sm btn-accent" onClick={() => void pickAndInstall()} disabled={!caps.apkInstall}><Download size={10} /> Install APK</button></div>
            </div>
            {!canDownload ? <AppNotice tone="warn"><Info size={12} /> Native download manager unavailable. Browser downloads cannot be enumerated here.</AppNotice> : null}
            {apks.length ? <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>Downloaded game packages</div> : null}
            {apks.map((item) => (
              <div key={item.id} className="flex items-center gap-2 rounded-lg px-2.5 py-2" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: "rgba(250,204,21,.13)", color: "#facc15" }}><Box size={16} /></div>
                <div className="min-w-0 flex-1"><div className="truncate text-[10px] font-medium">{item.name}</div><div className="text-[8px]" style={{ color: "var(--muted)" }}>{formatBytes(item.totalBytes)} · {item.status} · {item.progress}%</div><div className="mt-0.5 h-1 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}><div className="h-full rounded-full" style={{ width: `${Math.max(2, item.progress)}%`, background: "var(--accent)" }} /></div></div>
                <button className="btn btn-sm" onClick={() => void installApk(item)}><ShieldCheck size={10} /> Install</button>
                <button className="btn btn-sm !px-2" onClick={() => nativeBridge.openDownload(item.id).then(() => setStatus(`Opened ${item.name}.`)).catch((error) => setStatus(error.message))}><ArrowRight size={10} /></button>
              </div>
            ))}
            {(downloads.data ?? []).filter((item) => !apks.includes(item)).map((item) => (
              <div key={item.id} className="flex items-center gap-2 rounded-lg px-2.5 py-1.5" style={{ border: "1px solid var(--border)" }}>
                <Download size={13} style={{ color: "var(--muted)" }} />
                <div className="min-w-0 flex-1"><div className="truncate text-[9.5px]">{item.name}</div><div className="text-[7.5px]" style={{ color: "var(--muted)" }}>{formatBytes(item.totalBytes)} · {item.status} · {item.progress}%</div></div>
                <button className="btn btn-sm !h-6" onClick={() => nativeBridge.openDownload(item.id).catch((error) => setStatus(error.message))}>Open</button>
              </div>
            ))}
            {canDownload && downloads.data && downloads.data.length === 0 && !downloads.loading ? <EmptyState icon={<Download size={22} />} title="No game downloads yet" description="Open a legitimate site in the native browser and download a game file. KK DEX detects APKs automatically after refresh." action={<button className="btn btn-sm" onClick={() => launch("browser")}>Open browser</button>} /> : null}
            <AppNotice tone="warn"><ShieldCheck size={12} className="mt-0.5 shrink-0" /> KK DEX never installs APKs in the background. Android's installer verifies signatures and asks for confirmation. Sideloading unknown packages requires you to allow the installer source in Android settings.</AppNotice>
          </div>
        ) : null}

        {tab === "performance" ? (
          <div className="grid gap-2.5 md:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
            <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
              <div className="flex items-center gap-2"><Gauge size={14} style={{ color: "var(--accent)" }} /><div className="text-[11.5px] font-semibold">Performance modes</div><span className="badge ml-auto">{settings.performance}</span></div>
              <div className="mt-2 grid gap-1.5 sm:grid-cols-3">
                {(["performance", "balanced", "visual"] as const).map((mode) => (
                  <button key={mode} className="rounded-lg p-2 text-left" style={{ background: settings.performance === mode ? "var(--accent-soft)" : "var(--field)", border: `1px solid ${settings.performance === mode ? "var(--accent)" : "var(--border)"}` }} onClick={() => void applyMode(mode)}>
                    <div className="capitalize text-[10px] font-medium">{mode}</div>
                    <div className="mt-0.5 text-[8px] leading-snug" style={{ color: "var(--muted)" }}>{mode === "performance" ? "Minimal animation, responsive input." : mode === "visual" ? "Rich effects where supported." : "Balanced appearance and speed."}</div>
                  </button>
                ))}
              </div>
              <div className="mt-2 rounded-lg p-2 text-[8px] leading-relaxed" style={{ background: "var(--field)", color: "var(--faint)" }}>
                These modes change interface animation, backdrop and polling behavior. They cannot increase physical CPU/GPU performance. Real frame rate is controlled by Android and each game.
              </div>
              <div className="mt-2 grid grid-cols-2 gap-1.5 text-[9px]">
                <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("display").catch((error) => setStatus(error.message))}>Display settings</button>
                <button className="btn btn-sm" onClick={openPhoneController}><Smartphone size={11} /> Controller</button>
              </div>
            </section>
            <section className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
              <div className="flex items-center gap-2"><Activity size={14} style={{ color: "var(--accent)" }} /><div className="text-[11.5px] font-semibold">System monitor</div><button className="icon-btn ml-auto h-6 w-6" onClick={() => { system.refresh(); network.refresh(); }}><RefreshCw size={10} /></button></div>
              {!native.available ? <div className="mt-2 text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>Native Android hardware reporting is unavailable in a standalone browser. No CPU, RAM or GPU values are invented.</div> : system.error ? <div className="mt-2 text-[9px] text-amber-300">{system.error}</div> : system.data ? (
                <>
                  <div className="mt-2 grid grid-cols-2 gap-1.5">
                    <Metric label="RAM used" value={`${formatBytes(Math.max(0, system.data.totalRamBytes - system.data.availableRamBytes))}`} sub={`of ${formatBytes(system.data.totalRamBytes)}`} percent={system.data.totalRamBytes ? Math.round(((system.data.totalRamBytes - system.data.availableRamBytes) / system.data.totalRamBytes) * 100) : 0} />
                    <Metric label="App memory" value={formatBytes(system.data.appUsedRamBytes)} sub="Java/native heap" />
                    <Metric label="Refresh rate" value={`${system.data.refreshRate.toFixed(system.data.refreshRate % 1 ? 1 : 0)} Hz`} sub={system.data.supportedRefreshRates.length ? `${system.data.supportedRefreshRates.join(" / ")} Hz modes` : "reported by display"} />
                    <Metric label="Display" value={`${system.data.displayWidth}×${system.data.displayHeight}`} sub={`density ${system.data.density.toFixed(2)}`} />
                  </div>
                  <dl className="mt-2 space-y-1 text-[8.5px]">
                    <Row label="Device" value={`${system.data.manufacturer} ${system.data.model}`} />
                    <Row label="Android" value={`${system.data.androidVersion} · SDK ${system.data.sdkInt}`} />
                    <Row label="CPU" value={`${system.data.cpuCores} cores · ${system.data.cpuAbi}`} />
                    <Row label="GPU" value={system.data.gpuRenderer || "Not exposed by Android WebView bridge"} />
                    <Row label="Network" value={network.data ? `${network.data.type} · ${network.data.online ? "online" : "offline"}` : "Not reported"} />
                    <Row label="External display" value={system.data.externalDisplay ? "Connected" : "Not detected"} />
                  </dl>
                </>
              ) : <div className="mt-2 flex items-center gap-2 text-[9px]" style={{ color: "var(--muted)" }}>{system.loading ? <Loader2 size={11} className="animate-spin" /> : null} Loading real device data…</div>}
              <div className="mt-2 flex flex-wrap gap-1"><span className="badge"><Cpu size={8} /> {system.data?.cpuCores ?? "?"} cores</span><span className="badge"><MemoryStick size={8} /> {system.data ? formatBytes(system.data.totalRamBytes) : "RAM pending"}</span><span className="badge"><Monitor size={8} /> {system.data ? `${system.data.refreshRate.toFixed(0)} Hz` : "display pending"}</span></div>
            </section>
          </div>
        ) : null}

        {tab === "compatibility" ? (
          <div className="space-y-2.5">
            <div className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
              <div className="flex items-center gap-2"><ShieldCheck size={14} style={{ color: "var(--accent)" }} /><div className="text-[11.5px] font-semibold">Know what will actually run</div></div>
              <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
                {[
                  { title: "Android compatible", label: "ANDROID", color: "#34d399", body: "An installed APK or Play Store game launches through Android's activity system. It may open on the phone rather than the TV." },
                  { title: "Web game", label: "WEB", color: "#5b9dff", body: "HTML5/WebGL games run in the native browser. Performance depends on WebView GPU and network." },
                  { title: "Cloud gaming", label: "CLOUD", color: "#a78bfa", body: "Requires a supported cloud service, account and a fast connection. KK DEX can open the service in its browser; it cannot provide the service itself." },
                  { title: "Requires compatibility runtime", label: "RUNTIME", color: "#f5b84a", body: "Windows .exe or x86 PC games need an installed emulator/Wine-style runtime. Not bundled or claimed." },
                  { title: "Not supported", label: "NO", color: "#f87171", body: "Console exclusives, anti-cheat Windows games and DRM-protected titles that require unsupported components will not run." },
                ].map((row) => (
                  <div key={row.title} className="rounded-lg p-2" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
                    <div className="flex items-center gap-1.5"><span className="rounded px-1 py-0.5 text-[7px] font-bold" style={{ background: `${row.color}22`, color: row.color }}>{row.label}</span><span className="text-[9.5px] font-medium">{row.title}</span></div>
                    <p className="mt-1 text-[8px] leading-relaxed" style={{ color: "var(--muted)" }}>{row.body}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
              <div className="flex items-center gap-2"><Box size={14} style={{ color: "var(--accent)" }} /><div className="text-[11px] font-semibold">Downloaded installers</div></div>
              <p className="mt-1 text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>Detected APK files can be sent to Android's installer. .exe/PC installers are listed for transparency but are not executable by Android or KK DEX.</p>
              <div className="mt-2 space-y-1">
                {apks.length === 0 ? <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>No APK files detected in Android downloads.</div> : apks.map((item) => <div key={item.id} className="flex items-center gap-2 rounded px-2 py-1 text-[9px]" style={{ background: "var(--field)" }}><span className="badge badge-accent">APK</span><span className="min-w-0 flex-1 truncate">{item.name}</span><button className="btn btn-sm !h-5" onClick={() => void installApk(item)}>Install</button></div>)}
              </div>
              <button className="btn btn-sm mt-2" onClick={() => void pickAndInstall()} disabled={!caps.apkInstall}><Download size={11} /> Pick a local APK</button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="flex h-6 shrink-0 items-center justify-between px-3 text-[8px]" style={{ borderTop: "1px solid var(--border)", background: "var(--surface-2)", color: "var(--faint)" }}>
        <span>{native.available ? `${native.capabilities.platform} · ${system.data?.model ?? "Android"}` : "Web preview · native game discovery unavailable"}</span>
        <span className="flex items-center gap-2"><Wifi size={8} /> No fake performance gains · No unauthorized downloads</span>
      </div>
    </div>
  );
}

function Metric({ label, value, sub, percent }: { label: string; value: string; sub: string; percent?: number }) {
  return (
    <div className="rounded-lg p-2" style={{ background: "var(--field)" }}>
      <div className="text-[7.5px] uppercase tracking-wider" style={{ color: "var(--faint)" }}>{label}</div>
      <div className="mt-0.5 truncate text-[12px] font-medium">{value}</div>
      <div className="truncate text-[7.5px]" style={{ color: "var(--muted)" }}>{sub}</div>
      {percent !== undefined ? <div className="mt-1 h-1 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}><div className="h-full rounded-full" style={{ width: `${Math.min(100, percent)}%`, background: "var(--accent)" }} /></div> : null}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex items-start justify-between gap-2"><dt style={{ color: "var(--muted)" }}>{label}</dt><dd className="max-w-[62%] truncate text-right">{value}</dd></div>;
}
