import { useEffect, useState, type ReactNode } from "react";
import {
  Bell,
  Check,
  Cpu,
  Database,
  Fullscreen,
  HardDrive,
  Info,
  Keyboard,
  Lock,
  Monitor,
  Wifi,
  Bluetooth,
  Gamepad2,
  Download,
  ExternalLink,
  Globe,
  Gauge,
  ShieldCheck,
  Moon,
  MousePointer2,
  Palette,
  Power,
  RotateCcw,
  Smartphone,
  Sparkles,
  Sun,
  Timer,
  Volume2,
  Wallpaper,
} from "lucide-react";
import { ACCENTS, WALLPAPERS, formatBytes, useOS, wallpaperStyle } from "../OSContext";
import type { AccentId, AppContentProps } from "../types";
import { AppIcon } from "../icons";
import * as security from "../security";
import { nativeBridge, type NativeAudioInfo, type NativeNetworkInfo, type NativeStorageInfo, type NativeSystemStats } from "../native";
import { useNativeState } from "../NativeStorage";
import { AppNotice, Segmented, Slider, ToggleRow } from "../ui";
import { cn } from "@/utils/cn";

type Section = "personalization" | "display" | "sound" | "network" | "security" | "power" | "gaming" | "downloads" | "mouse" | "keyboard" | "system";

const SECTIONS: { id: Section; label: string; icon: typeof Palette }[] = [
  { id: "personalization", label: "Personalization", icon: Palette },
  { id: "display", label: "Display", icon: Monitor },
  { id: "sound", label: "Sound & notifications", icon: Volume2 },
  { id: "security", label: "Security & login", icon: Lock },
  { id: "power", label: "Power & sleep", icon: Power },
  { id: "network", label: "Network & Bluetooth", icon: Wifi },
  { id: "gaming", label: "Gaming & performance", icon: Gamepad2 },
  { id: "downloads", label: "Downloads & browser", icon: Download },
  { id: "mouse", label: "Pointer & touchpad", icon: MousePointer2 },
  { id: "keyboard", label: "Keyboard", icon: Keyboard },
  { id: "system", label: "System & about", icon: Cpu },
];

function SettingsCard({ children, title, description, icon }: { children: ReactNode; title: string; description?: string; icon?: ReactNode }) {
  return (
    <section className="mb-2.5 rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
      <div className="mb-2.5 flex items-start gap-2">
        {icon ? <span className="mt-0.5" style={{ color: "var(--accent)" }}>{icon}</span> : null}
        <div>
          <div className="text-[12px] font-semibold leading-tight">{title}</div>
          {description ? <div className="mt-0.5 text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>{description}</div> : null}
        </div>
      </div>
      {children}
    </section>
  );
}

const SHORTCUTS: [string, string][] = [
  ["Win / Ctrl + Esc", "Open Start"],
  ["Win + D", "Show desktop / restore"],
  ["Win + E", "Open Files"],
  ["Win + ← / →", "Snap window left or right"],
  ["Win + ↑ / ↓", "Maximize / restore"],
  ["Alt + Tab", "Switch between applications"],
  ["Alt + F4", "Close active window"],
  ["F2", "Rename selected item"],
  ["Delete", "Move selection to Recycle Bin"],
  ["Enter", "Open selected item"],
  ["F5", "Refresh"],
  ["Ctrl + S", "Save in Notes"],
  ["Ctrl + C / X / V", "Copy / cut / paste in Files"],
  ["Esc", "Close menus and cancel"],
];

export default function SettingsApp({ payload }: AppContentProps) {
  const {
    settings,
    updateSettings,
    resetSettings,
    launch,
    showConfirm,
    showInfo,
    notify,
    files,
    notes,
    trash,
    bootTime,
    openPhoneController,
    restartDesktop,
    factoryReset,
    lock,
    soundClick,
    sleepDesktop,
    setCredential,
    clearCredential,
  } = useOS();
  const native = useNativeState();
  const requested = payload?.section;
  const [nativeNetwork, setNativeNetwork] = useState<NativeNetworkInfo | null>(null);
  const [nativeAudio, setNativeAudio] = useState<NativeAudioInfo | null>(null);
  const [nativeStats, setNativeStats] = useState<NativeSystemStats | null>(null);
  const [nativeStorage, setNativeStorage] = useState<NativeStorageInfo | null>(null);
  const [hostMessage, setHostMessage] = useState("");
  const [pinDraft, setPinDraft] = useState("");
  const [pinConfirm, setPinConfirm] = useState("");
  const [hasPin, setHasPin] = useState(() => security.hasCredential());
  const credentialDescription = security.describeCredential();
  const [section, setSection] = useState<Section>(
    typeof requested === "string" && SECTIONS.some((s) => s.id === requested) ? (requested as Section) : "personalization",
  );
  const [displaySize, setDisplaySize] = useState({ w: window.innerWidth, h: window.innerHeight });
  const [uptime, setUptime] = useState(Math.floor((Date.now() - bootTime) / 1000));

  useEffect(() => {
    if (typeof requested === "string" && SECTIONS.some((s) => s.id === requested)) setSection(requested as Section);
  }, [requested]);

  useEffect(() => {
    if (!native.available) return;
    let cancelled = false;
    const load = async () => {
      const [network, audio, stats, storage] = await Promise.all([
        nativeBridge.getNetworkInfo().catch(() => null),
        nativeBridge.getAudioInfo().catch(() => null),
        native.capabilities.storageStats ? nativeBridge.getSystemStats().catch(() => null) : Promise.resolve(null),
        native.capabilities.storageStats ? nativeBridge.getStorageInfo().catch(() => null) : Promise.resolve(null),
      ]);
      if (cancelled) return;
      setNativeNetwork(network);
      setNativeAudio(audio);
      setNativeStats(stats);
      setNativeStorage(storage);
    };
    void load();
    const timer = window.setInterval(load, section === "gaming" ? 5000 : 15000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [native.available, native.capabilities.storageStats, section]);

  useEffect(() => {
    const onResize = () => setDisplaySize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", onResize);
    const timer = window.setInterval(() => setUptime(Math.floor((Date.now() - bootTime) / 1000)), 1000);
    return () => {
      window.removeEventListener("resize", onResize);
      window.clearInterval(timer);
    };
  }, [bootTime]);

  const totalBytes = files.filter((f) => f.kind !== "folder").reduce((sum, f) => sum + f.size, 0);
  const toggleFullscreen = async () => {
    const next = !settings.fullscreen;
    updateSettings({ fullscreen: next });
    try {
      const applied = await nativeBridge.setFullscreen(next);
      if (!applied) {
        // Browser fallback: the Fullscreen API works outside Android WebView.
        if (next && !document.fullscreenElement) await document.documentElement.requestFullscreen();
        if (!next && document.fullscreenElement) await document.exitFullscreen();
      }
      setHostMessage(next ? "Full-screen enabled on the TV display." : "Full-screen disabled; system bars are visible.");
    } catch (error) {
      setHostMessage(`Full-screen ${next ? "enable" : "disable"} failed: ${error instanceof Error ? error.message : "host rejected the request"}.`);
    }
  };

  const uptimeLabel = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m ${uptime % 60}s`;

  const savePin = async () => {
    if (pinDraft.length < 4 || pinDraft !== pinConfirm) {
      setHostMessage("PIN or password must be at least 4 characters and match the confirmation.");
      return;
    }
    const ok = await setCredential(pinDraft);
    setHasPin(ok);
    setPinDraft("");
    setPinConfirm("");
    setHostMessage(ok ? "Desktop PIN or password saved with PBKDF2 hashing." : "PIN could not be saved.");
  };

  return (
    <div className="flex h-full min-h-0" style={{ background: "var(--surface-solid)" }}>
      <aside className="flex w-[202px] shrink-0 flex-col" style={{ borderRight: "1px solid var(--border)", background: "var(--surface-2)" }}>
        <div className="px-3 pt-3 pb-2.5">
          <div className="flex items-center gap-2">
            <AppIcon id="settings" size={28} />
            <div>
              <div className="text-[12.5px] font-semibold leading-tight">Settings</div>
              <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>KK DEX OS 1.0</div>
            </div>
          </div>
        </div>
        <div className="scroll-thin flex-1 overflow-y-auto px-1.5">
          {SECTIONS.map((item) => {
            const Icon = item.icon;
            return (
              <button key={item.id} className={cn("sidebar-item mb-0.5", section === item.id && "active")} onClick={() => setSection(item.id)}>
                <Icon size={15} strokeWidth={1.9} style={{ color: section === item.id ? "var(--accent)" : undefined }} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
        <div className="p-2">
          <button
            className="sidebar-item"
            onClick={() => showInfo("About this interface", "KK DEX Desktop is a React-based operating environment designed for an external TV or monitor. Window state is session-local; files, notes and preferences persist in this browser workspace.", <Info size={14} />)}
          >
            <Info size={14} /> About this interface
          </button>
        </div>
      </aside>

      <div className="scroll-thin min-w-0 flex-1 overflow-y-auto p-3.5">
        <div className="mb-3 flex items-center gap-2">
          <div>
            <h2 className="text-[15px] font-semibold tracking-tight">{SECTIONS.find((s) => s.id === section)?.label}</h2>
            <p className="text-[9.5px]" style={{ color: "var(--muted)" }}>
              Changes apply immediately and persist on this device.
            </p>
          </div>
          <span className="ml-auto flex items-center gap-1 rounded-full px-2 py-1 text-[8.5px]" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
            <Check size={9} /> Saved automatically
          </span>
        </div>

        {section === "personalization" ? (
          <div className="fade-in">
            <SettingsCard title="Background" description="Choose a desktop wallpaper. Images load from local KK DEX assets." icon={<Wallpaper size={15} />}>
              <div className="grid grid-cols-5 gap-2">
                {WALLPAPERS.map((wallpaper) => {
                  const active = settings.wallpaper === wallpaper.id;
                  return (
                    <button
                      key={wallpaper.id}
                      className="group relative overflow-hidden rounded-lg text-left"
                      style={{ outline: active ? `2px solid var(--accent)` : "1px solid var(--border)", outlineOffset: active ? 1 : -1 }}
                      onClick={() => {
                        updateSettings({ wallpaper: wallpaper.id });
                        notify("Wallpaper applied", `${wallpaper.name} is now your desktop background.`, { silent: true, tone: "success" });
                      }}
                    >
                      <div style={{ height: 52, ...wallpaperStyle(wallpaper.id), backgroundSize: "cover" }} />
                      <div className="px-1.5 py-1.5">
                        <div className="truncate text-[9.5px] font-medium leading-tight">{wallpaper.name}</div>
                        <div className="truncate text-[8px]" style={{ color: "var(--faint)" }}>{wallpaper.note}</div>
                      </div>
                      {active ? (
                        <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full" style={{ background: "var(--accent)", color: "#fff" }}>
                          <Check size={10} />
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </SettingsCard>

            <div className="mb-2.5 grid gap-2.5 sm:grid-cols-2">
              <SettingsCard title="Theme" description="Window, menu and panel appearance." icon={<Moon size={15} />}>
                <div className="grid grid-cols-2 gap-2">
                  {(["dark", "light"] as const).map((mode) => (
                    <button
                      key={mode}
                      className="rounded-lg p-1.5 text-left"
                      style={{ border: `1px solid ${settings.theme === mode ? "var(--accent)" : "var(--border)"}`, background: "var(--surface-solid)" }}
                      onClick={() => updateSettings({ theme: mode })}
                    >
                      <div className="mb-1.5 h-12 overflow-hidden rounded-md" style={{ background: mode === "dark" ? "#171b26" : "#f5f8fc", border: "1px solid var(--border)" }}>
                        <div className="m-1.5 rounded p-1" style={{ background: mode === "dark" ? "#242b39" : "#ffffff", height: 30, boxShadow: "0 1px 2px rgba(0,0,0,.1)" }}>
                          <div className="h-1 w-1/2 rounded-full" style={{ background: mode === "dark" ? "#5f6d84" : "#aabbd0" }} />
                          <div className="mt-1 h-1 w-2/3 rounded-full" style={{ background: mode === "dark" ? "#39465a" : "#dbe4ef" }} />
                        </div>
                      </div>
                      <div className="flex items-center justify-between px-0.5 pb-0.5">
                        <span className="text-[10px] font-medium capitalize">{mode}</span>
                        {settings.theme === mode ? <Check size={11} style={{ color: "var(--accent)" }} /> : null}
                      </div>
                    </button>
                  ))}
                </div>
              </SettingsCard>
              <SettingsCard title="Accent color" description="Used by highlights, controls and focus rings." icon={<Palette size={15} />}>
                <div className="flex flex-wrap gap-2 pt-1">
                  {(Object.keys(ACCENTS) as AccentId[]).map((accent) => (
                    <button
                      key={accent}
                      title={ACCENTS[accent].name}
                      className="flex h-7 w-7 items-center justify-center rounded-full transition-transform hover:scale-110"
                      style={{ background: ACCENTS[accent].hex, outline: settings.accent === accent ? "2px solid var(--text)" : "none", outlineOffset: 2 }}
                      onClick={() => updateSettings({ accent })}
                    >
                      {settings.accent === accent ? <Check size={13} color="#fff" /> : null}
                    </button>
                  ))}
                </div>
                <div className="mt-2 text-[9px]" style={{ color: "var(--faint)" }}>{ACCENTS[settings.accent].name}</div>
              </SettingsCard>
            </div>

            <SettingsCard title="Desktop" description="Icon density and motion preferences." icon={<Sparkles size={15} />}>
              <div className="flex items-center justify-between py-1.5">
                <div>
                  <div className="text-[11.5px] font-medium">Desktop icon size</div>
                  <div className="text-[9px]" style={{ color: "var(--muted)" }}>Affects spacing and icon dimensions on the desktop.</div>
                </div>
                <Segmented
                  size="sm"
                  value={settings.iconSize}
                  onChange={(iconSize) => updateSettings({ iconSize })}
                  options={[
                    { value: "small", label: "S" },
                    { value: "medium", label: "M" },
                    { value: "large", label: "L" },
                  ]}
                />
              </div>
              <div className="divider my-1" />
              <ToggleRow title="Reduce motion" description="Minimize window and menu animation." checked={settings.reduceMotion} onChange={(reduceMotion) => updateSettings({ reduceMotion })} />
            </SettingsCard>
          </div>
        ) : null}

        {section === "display" ? (
          <div className="fade-in">
            <SettingsCard title="Full screen" description="Immersion is managed by native Android window APIs and applies immediately." icon={<Fullscreen size={15} />}>
              <ToggleRow
                title="Full screen TV desktop"
                description="Hide system bars and use the complete external display area. Restored automatically after returning from other activities."
                checked={settings.fullscreen}
                onChange={() => void toggleFullscreen()}
              />
              <div className="flex items-center gap-2">
                <button className="btn btn-sm" onClick={() => void toggleFullscreen()}><Fullscreen size={11} /> {settings.fullscreen ? "Exit full screen" : "Enter full screen"}</button>
                <span className="badge badge-accent">{settings.fullscreen ? "ENABLED" : "DISABLED"}</span>
                {hostMessage ? <span className="truncate text-[8.5px]" style={{ color: "var(--muted)" }}>{hostMessage}</span> : null}
              </div>
            </SettingsCard>

            <SettingsCard title="Interface size" description="Scales text, icons and desktop elements. Changes apply instantly and persist." icon={<Monitor size={15} />}>
              <div className="grid grid-cols-4 gap-1.5">
                {([["large", "Large"], ["small", "Small"], ["minimal", "Minimal"], ["manual", "Manual"]] as const).map(([mode, label]) => (
                  <button
                    key={mode}
                    className="rounded-lg px-2 py-2 text-left"
                    style={{ background: settings.uiScale === mode ? "var(--accent-soft)" : "var(--field)", border: `1px solid ${settings.uiScale === mode ? "var(--accent)" : "var(--border)"}` }}
                    onClick={() => updateSettings({ uiScale: mode })}
                  >
                    <div className="text-[10px] font-medium">{label}</div>
                    <div className="text-[8px] leading-snug" style={{ color: "var(--muted)" }}>
                      {mode === "large" ? "Bigger text and icons" : mode === "small" ? "Compact desktop" : mode === "minimal" ? "Dense, clean layout" : "Your own scale"}
                    </div>
                  </button>
                ))}
              </div>
              {settings.uiScale === "manual" ? (
                <div className="mt-2 flex items-center gap-3">
                  <span className="text-[10px]">Scale</span>
                  <Slider value={settings.uiScaleManual} min={0.8} max={1.35} step={0.05} onChange={(uiScaleManual) => updateSettings({ uiScaleManual })} label="Manual interface scale" />
                  <span className="w-12 text-right font-mono text-[10px]">{Math.round(settings.uiScaleManual * 100)}%</span>
                </div>
              ) : null}
              <div className="mt-2 rounded-lg px-2.5 py-2 text-[9px] leading-relaxed" style={{ background: "var(--field)", color: "var(--muted)" }}>
                The desktop keeps its 16:9 aspect and full display area at every size. Scaling changes typography and element density; it never stretches or crops the wallpaper.
              </div>
            </SettingsCard>

            <SettingsCard title="Display" description="Live host display metrics." icon={<Monitor size={15} />}>
              <div className="mb-2 flex items-center gap-2 rounded-lg p-2.5" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}>
                <div className="flex h-12 w-[72px] items-center justify-center rounded border-2" style={{ borderColor: "var(--accent)", background: "var(--field)" }}>
                  <span className="font-mono text-[8.5px]">{displaySize.w} × {displaySize.h}</span>
                </div>
                <div>
                  <div className="text-[11.5px] font-medium">KK DEX external display</div>
                  <div className="text-[9px]" style={{ color: "var(--muted)" }}>CSS viewport {displaySize.w} × {displaySize.h} · DPR {window.devicePixelRatio.toFixed(1)}</div>
                  <div className="text-[9px]" style={{ color: "var(--muted)" }}>Taskbar reserves {56}px · windows are clamped to the workspace</div>
                </div>
              </div>
            </SettingsCard>

            <SettingsCard title="Brightness & comfort" description="Display dimming and visual aids." icon={<Sun size={15} />}>
              <div className="flex items-center gap-3">
                <Sun size={13} style={{ color: "var(--faint)" }} />
                <Slider value={settings.brightness} min={45} max={100} onChange={(brightness) => updateSettings({ brightness })} label="Display brightness" />
                <span className="w-8 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.brightness}%</span>
              </div>
              <ToggleRow title="Night light" description="Warm color filter to reduce blue light." checked={settings.nightLight} onChange={(nightLight) => updateSettings({ nightLight })} />
              <ToggleRow title="Reduce motion" description="Disable most menu and window transitions." checked={settings.reduceMotion} onChange={(reduceMotion) => updateSettings({ reduceMotion })} />
            </SettingsCard>
          </div>
        ) : null}

        {section === "sound" ? (
          <div className="fade-in">
            <SettingsCard title="System sound" description="Short UI tones for supported desktop interactions." icon={<Volume2 size={15} />}>
              <ToggleRow title="System sounds" description="Play subtle feedback for supported desktop actions." checked={settings.sound} onChange={(sound) => updateSettings({ sound })} />
              <div className="flex items-center gap-3 py-2">
                <Volume2 size={13} style={{ color: "var(--faint)" }} />
                <Slider value={settings.volume} onChange={(volume) => updateSettings({ volume, muted: false })} label="Volume" />
                <span className="w-8 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.volume}%</span>
              </div>
              <div className="flex items-center gap-2">
                <button className="btn btn-sm" disabled={!settings.sound || settings.muted} onClick={soundClick}>Play test sound</button>
                <button className="btn btn-sm" onClick={() => { updateSettings({ muted: !settings.muted }); }}>{settings.muted ? "Unmute KK DEX" : "Mute KK DEX"}</button>
              </div>
              <div className="mt-2.5 text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>
                Browser security prevents changing host speaker volume. This controls KK DEX interface sounds only.
              </div>
            </SettingsCard>
            <SettingsCard title="Notifications" description="Control desktop alerts and toast banners." icon={<Bell size={15} />}>
              <ToggleRow title="Do not disturb" description="Silence toast banners. Notifications remain available in the notification center." checked={settings.doNotDisturb} onChange={(doNotDisturb) => updateSettings({ doNotDisturb })} />
              <div className="mt-1.5">
                <button
                  className="btn btn-sm"
                  onClick={() =>
                    notify("Notification test", "Desktop notifications are working in this workspace.", { tone: "success" })
                  }
                >
                  Send test notification
                </button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "network" ? (
          <div className="fade-in">
            <SettingsCard title="Android network" description="Real host connectivity reported by ConnectivityManager. KK DEX does not toggle radios directly." icon={<Wifi size={15} />}>
              {nativeNetwork ? (
                <>
                  <div className="flex items-center gap-2 rounded-lg p-2.5" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}>
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: nativeNetwork.online ? "rgba(52,211,153,.14)" : "rgba(239,68,68,.13)", color: nativeNetwork.online ? "var(--success)" : "var(--danger)" }}>
                      <Wifi size={16} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-[11px] font-medium">{nativeNetwork.wifiSsid || nativeNetwork.type} · {nativeNetwork.online ? "Online" : "Offline"}</div>
                      <div className="text-[8.5px]" style={{ color: "var(--muted)" }}>{nativeNetwork.wifiConnected ? "Wi-Fi connected" : nativeNetwork.wifiEnabled ? "Wi-Fi enabled, not connected" : "Wi-Fi disabled"} · {nativeNetwork.vpnActive ? "VPN active" : "no VPN"}</div>
                    </div>
                    <span className={nativeNetwork.online ? "badge badge-accent" : "badge"}>{nativeNetwork.type.toUpperCase()}</span>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-1.5">
                    <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("wifi").catch((error) => setHostMessage(error.message))}><Wifi size={11} /> Wi-Fi settings</button>
                    <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("bluetooth").catch((error) => setHostMessage(error.message))}><Bluetooth size={11} /> Bluetooth settings</button>
                  </div>
                  <div className="mt-2 flex items-center justify-between rounded-lg px-2 py-2 text-[10px]" style={{ background: "var(--field)" }}>
                    <span className="flex items-center gap-1.5"><Bluetooth size={12} /> Bluetooth</span>
                    <span style={{ color: nativeNetwork.bluetoothEnabled ? "var(--success)" : "var(--muted)" }}>{nativeNetwork.bluetoothSupported ? nativeNetwork.bluetoothEnabled ? "Enabled" : "Disabled" : "Not supported"}</span>
                  </div>
                  {hostMessage ? <div className="mt-1 text-[8.5px]" style={{ color: "var(--danger)" }}>{hostMessage}</div> : null}
                  <p className="mt-2 text-[8.5px] leading-relaxed" style={{ color: "var(--faint)" }}>Android does not permit a WebView to toggle Wi-Fi/Bluetooth silently. Use the buttons above to open the system panels; no fake switch state is shown here.</p>
                </>
              ) : (
                <AppNotice tone="warn"><Info size={12} /> Native network status is unavailable. Run the Android host to read actual Wi-Fi, Bluetooth and connectivity state.</AppNotice>
              )}
            </SettingsCard>
            <SettingsCard title="Phone audio" description="Controls the Android media stream through AudioManager." icon={<Volume2 size={15} />}>
              {nativeAudio ? (
                <div className="flex items-center gap-3">
                  <Volume2 size={13} style={{ color: "var(--muted)" }} />
                  <Slider value={nativeAudio.musicVolume} min={0} max={nativeAudio.maxMusicVolume} label="Android media volume" onChange={(value) => void nativeBridge.setVolume("music", value).then(setNativeAudio).catch((error) => setHostMessage(error.message))} />
                  <span className="w-10 text-right font-mono text-[9px]">{nativeAudio.musicVolume}/{nativeAudio.maxMusicVolume}</span>
                  <button className="btn btn-sm !px-2" onClick={() => nativeBridge.setVolume("music", nativeAudio.isMuted ? nativeAudio.musicVolume : 0).then(setNativeAudio).catch((error) => setHostMessage(error.message))}>{nativeAudio.isMuted ? "Unmute" : "Mute"}</button>
                </div>
              ) : <AppNotice tone="warn"><Info size={12} /> Android audio control is unavailable in this host.</AppNotice>}
            </SettingsCard>
            <SettingsCard title="Network diagnostics" icon={<Wifi size={15} />}>
              <div className="flex items-center justify-between text-[10px]"><span style={{ color: "var(--muted)" }}>Browser network (navigator)</span><span>{navigator.onLine ? "online" : "offline"}</span></div>
              <div className="mt-1 flex items-center justify-between text-[10px]"><span style={{ color: "var(--muted)" }}>Native network</span><span>{nativeNetwork ? nativeNetwork.online ? "online" : "offline" : "unavailable"}</span></div>
              <button className="btn btn-sm mt-2" onClick={() => launch("browser", { payload: { url: "https://www.google.com" } })}><Globe size={11} /> Test in browser</button>
            </SettingsCard>
          </div>
        ) : null}

        {section === "gaming" ? (
          <div className="fade-in">
            <SettingsCard title="Performance mode" description="Changes KK DEX rendering policy only; it cannot increase physical CPU/GPU power." icon={<Gamepad2 size={15} />}>
              <div className="grid gap-1.5 sm:grid-cols-3">
                {(["performance", "balanced", "visual"] as const).map((mode) => (
                  <button key={mode} className="rounded-lg p-2 text-left" style={{ background: settings.performance === mode ? "var(--accent-soft)" : "var(--field)", border: `1px solid ${settings.performance === mode ? "var(--accent)" : "var(--border)"}` }} onClick={async () => {
                    updateSettings({ performance: mode, reduceMotion: mode === "performance" });
                    if (native.available && native.capabilities.performanceModes) {
                      try { const result = await nativeBridge.setPerformanceMode(mode); setHostMessage(`${mode} mode applied. ${result.note || "Animation policy only."}`); } catch (error) { setHostMessage(error instanceof Error ? error.message : "Native mode failed."); }
                    } else setHostMessage(`Desktop ${mode} mode applied. Native mode control unavailable in this host.`);
                  }}>
                    <div className="flex items-center justify-between capitalize text-[10px] font-medium">{mode}{settings.performance === mode ? <Check size={10} style={{ color: "var(--accent)" }} /> : null}</div>
                    <div className="mt-0.5 text-[8px] leading-snug" style={{ color: "var(--muted)" }}>{mode === "performance" ? "Fewer effects, responsive input." : mode === "visual" ? "Rich effects where hardware permits." : "Balanced defaults."}</div>
                  </button>
                ))}
              </div>
              {hostMessage ? <div className="mt-1.5 rounded px-2 py-1 text-[8.5px]" style={{ background: "var(--field)", color: "var(--muted)" }}>{hostMessage}</div> : null}
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button className="btn btn-sm" onClick={() => launch("games")}><Gamepad2 size={11} /> Gaming Centre</button>
                <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("display").catch((error) => setHostMessage(error.message))}><Monitor size={11} /> Refresh rate & display</button>
              </div>
            </SettingsCard>
            <SettingsCard title="Device monitor" description="Values are read from Android; unavailable sensors are never invented." icon={<Gauge size={15} />}>
              {nativeStats ? (
                <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
                  {[
                    ["ANDROID", `${nativeStats.androidVersion} · SDK ${nativeStats.sdkInt}`],
                    ["CPU", `${nativeStats.cpuCores} cores · ${nativeStats.cpuAbi}`],
                    ["RAM", `${formatBytes(nativeStats.totalRamBytes - nativeStats.availableRamBytes)} used / ${formatBytes(nativeStats.totalRamBytes)}`],
                    ["REFRESH", `${nativeStats.refreshRate.toFixed(0)} Hz`],
                    ["DISPLAY", `${nativeStats.displayWidth}×${nativeStats.displayHeight}`],
                    ["GPU", nativeStats.gpuRenderer || "Not exposed"],
                    ["DEVICE", `${nativeStats.manufacturer} ${nativeStats.model}`],
                    ["EXTERNAL", nativeStats.externalDisplay ? "Connected" : "Not detected"],
                  ].map(([label, value]) => <div key={label} className="rounded-lg p-2" style={{ background: "var(--field)" }}><div className="text-[7.5px] uppercase tracking-wider" style={{ color: "var(--faint)" }}>{label}</div><div className="mt-0.5 truncate text-[9.5px] font-medium">{value}</div></div>)}
                </div>
              ) : <AppNotice tone="warn"><Info size={12} /> Native hardware data is unavailable in this host. No CPU, GPU or RAM values are fabricated.</AppNotice>}
              <button className="btn btn-sm mt-2" onClick={() => nativeBridge.openSystemSettings("apps").catch((error) => setHostMessage(error.message))}><ExternalLink size={11} /> Android application settings</button>
            </SettingsCard>
          </div>
        ) : null}

        {section === "downloads" ? (
          <div className="fade-in">
            <SettingsCard title="Download location" description="Android DownloadManager can write inside the public Download collection. KK DEX uses a named subfolder." icon={<Download size={15} />}>
              <label className="text-[9px] font-medium" style={{ color: "var(--muted)" }}>Subfolder under Internal storage / Download</label>
              <div className="mt-1 flex gap-1.5">
                <input className="field !h-7 flex-1" value={settings.downloadLocation} onChange={(event) => updateSettings({ downloadLocation: event.target.value })} />
                <button className="btn btn-sm" onClick={async () => {
                  if (!native.available) { setHostMessage("This preference is saved for the desktop workspace. The Android host will apply it when connected."); return; }
                  try { await nativeBridge.setDownloadFolder(settings.downloadLocation); setHostMessage(`Android downloads will use Download/${settings.downloadLocation}.`); } catch (error) { setHostMessage(error instanceof Error ? error.message : "Android rejected the folder."); }
                }}>Apply</button>
              </div>
              <div className="mt-1 text-[8px]" style={{ color: "var(--faint)" }}>Resolved path: /storage/emulated/0/Download/{settings.downloadLocation.replace(/^\/+|\/+$/g, "") || "KK DEX"}</div>
              {nativeStorage ? <div className="mt-2 flex items-center justify-between rounded-lg px-2 py-1.5 text-[9px]" style={{ background: "var(--field)" }}><span>{formatBytes(nativeStorage.availableBytes)} available</span><button className="hover:underline" style={{ color: "var(--accent)" }} onClick={() => launch("storage")}>Storage Manager →</button></div> : null}
              {hostMessage ? <div className="mt-1 text-[8.5px]" style={{ color: "var(--muted)" }}>{hostMessage}</div> : null}
            </SettingsCard>
            <SettingsCard title="Browser engine" description="The native Android WebView is the real browsing environment." icon={<Globe size={15} />}>
              <ToggleRow title="Desktop site user agent by default" description="Request desktop layouts. The native browser reloads to apply the user agent." checked={settings.desktopUserAgent} onChange={(desktopUserAgent) => updateSettings({ desktopUserAgent })} />
              <div className="flex items-center justify-between rounded-lg px-2 py-1.5 text-[9.5px]" style={{ background: "var(--field)" }}><span>Native WebView browser</span><span style={{ color: native.capabilities.browser ? "var(--success)" : "var(--muted)" }}>{native.capabilities.browser ? "Available" : "Unavailable in this host"}</span></div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button className="btn btn-sm" onClick={() => launch("browser", { payload: { url: "https://www.youtube.com" } })}><Globe size={11} /> Test YouTube</button>
                <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("apps").catch((error) => setHostMessage(error.message))}><ExternalLink size={11} /> Android app permissions</button>
              </div>
              <p className="mt-2 text-[8px] leading-relaxed" style={{ color: "var(--faint)" }}>Cookies, DOM storage, media autoplay and downloads are native WebView features. Google/YouTube can still reject WebView sign-in, and DRM-protected content may require Widevine that the host does not provide.</p>
            </SettingsCard>
            <SettingsCard title="Application installation" icon={<ShieldCheck size={15} />}>
              <p className="text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>APK installation is performed only by Android's package installer after your confirmation. KK DEX cannot bypass signature checks or install silently.</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("unknownSources").catch((error) => setHostMessage(error.message))}><ExternalLink size={11} /> Unknown app sources</button>
                <button className="btn btn-sm" onClick={() => launch("downloads", { payload: { tab: "android" } })}><Download size={11} /> Download Manager</button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "mouse" ? (
          <div className="fade-in">
            <SettingsCard title="Phone controller pointer" description="The TV uses the host's native mouse cursor. These options tune the remote Android pointer." icon={<MousePointer2 size={15} />}>
              <div className="flex items-center gap-3 py-2">
                <span className="text-[10.5px]">Pointer speed</span>
                <Slider value={settings.pointerSpeed} min={1} max={10} onChange={(pointerSpeed) => updateSettings({ pointerSpeed })} label="Pointer speed" />
                <span className="w-7 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.pointerSpeed}</span>
              </div>
              <div className="flex items-center gap-3 py-2">
                <span className="text-[10.5px]">Pointer size</span>
                <Slider value={settings.pointerSize} min={1} max={6} onChange={(pointerSize) => updateSettings({ pointerSize })} label="Pointer size" />
                <span className="w-7 text-right font-mono text-[10px]" style={{ color: "var(--muted)" }}>{settings.pointerSize}</span>
              </div>
              <ToggleRow title="Click effects" description="Show a visible click ripple on the TV from phone input." checked={settings.clickEffects} onChange={(clickEffects) => updateSettings({ clickEffects })} />
              <div className="mt-1.5 flex flex-wrap gap-2">
                <button className="btn btn-sm btn-accent" onClick={openPhoneController}><Smartphone size={12} /> Open phone controller</button>
                <button className="btn btn-sm" onClick={() => launch("phone")}><Info size={12} /> Pairing guide</button>
              </div>
            </SettingsCard>
            <SettingsCard title="How pointer input works" description="The phone never renders a duplicate desktop." icon={<MousePointer2 size={15} />}>
              <div className="space-y-1.5 text-[10px] leading-relaxed" style={{ color: "var(--muted)" }}>
                <p>The Android controller sends pointer positions through the KKDexAPI bridge. The TV translates each position into an actual pointer event using <code className="font-mono">elementFromPoint</code>.</p>
                <p>Hover, click, double-click, right-click, scroll and text insertion therefore reach real HTML controls, not a decorative overlay.</p>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "keyboard" ? (
          <div className="fade-in">
            <SettingsCard title="Keyboard shortcuts" description="Shortcuts are handled globally unless focus is inside a text field." icon={<Keyboard size={15} />}>
              <div className="overflow-hidden rounded-lg" style={{ border: "1px solid var(--border)" }}>
                {SHORTCUTS.map(([keys, label], index) => (
                  <div key={keys} className="flex items-center justify-between px-2.5 py-1.5 text-[10.5px]" style={{ background: index % 2 ? "var(--field)" : "transparent" }}>
                    <span className="flex flex-wrap gap-1">{keys.split(" + ").map((key) => <kbd key={key} className="kbd">{key}</kbd>)}</span>
                    <span style={{ color: "var(--muted)" }}>{label}</span>
                  </div>
                ))}
              </div>
            </SettingsCard>
            <SettingsCard title="Text input from your phone" description="Use the controller keyboard to type into the focused desktop field." icon={<Smartphone size={15} />}>
              <p className="text-[10px] leading-relaxed" style={{ color: "var(--muted)" }}>
                Tap a desktop text field first, then use the phone's keyboard panel. Text is inserted through the same bridge handlers used by Android's <code className="font-mono">insertText</code> and <code className="font-mono">pressKey</code> calls.
              </p>
              <div className="mt-2 flex gap-2">
                <button className="btn btn-sm btn-accent" onClick={openPhoneController}><Smartphone size={12} /> Open controller</button>
                <button
                  className="btn btn-sm"
                  onClick={() => showInfo("Keyboard bridge", "The desktop exposes KKDexAPI-compatible handlers including insertText(text), pressKey(key, modifiers), movePointer(x,y), pointerClick(), scrollDesktop(delta), and getState(). They operate on the real DOM.", <Keyboard size={24} />)}
                >
                  Bridge details
                </button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "security" ? (
          <div className="fade-in">
            <SettingsCard title="Desktop account" description="Local login protects the TV desktop independently of the phone controller." icon={<Lock size={15} />}>
              <div className="rounded-lg p-2.5" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
                <div className="text-[10px] font-medium">{hasPin ? "PIN or password is set" : "No PIN or password configured"}</div>
                <div className="mt-0.5 text-[8.5px] leading-relaxed" style={{ color: "var(--muted)" }}>{credentialDescription}</div>
              </div>
              <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-[9px] font-medium" style={{ color: "var(--muted)" }}>{hasPin ? "New PIN or password" : "Create PIN or password (4+ characters)"}</label>
                  <input className="field" type="password" value={pinDraft} onChange={(event) => setPinDraft(event.target.value)} placeholder="••••" />
                </div>
                <div>
                  <label className="mb-1 block text-[9px] font-medium" style={{ color: "var(--muted)" }}>Confirm</label>
                  <input className="field" type="password" value={pinConfirm} onChange={(event) => setPinConfirm(event.target.value)} placeholder="••••" />
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button className="btn btn-sm btn-accent" onClick={() => void savePin()} disabled={!pinDraft || pinDraft !== pinConfirm}>
                  <Lock size={11} /> {hasPin ? "Change PIN / password" : "Create PIN / password"}
                </button>
                <button className="btn btn-sm" onClick={() => { lock(); setHostMessage("Desktop locked."); }}><Lock size={11} /> Lock now</button>
                <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("unknownSources").catch(() => undefined)}><ExternalLink size={11} /> Android app security</button>
              </div>
              <div className="mt-2 text-[8px] leading-relaxed" style={{ color: "var(--faint)" }}>
                The secret is never stored in plain text: KK DEX derives a PBKDF2-SHA256 hash (210,000 iterations) from a random salt and stores only the hash. Recovery: if the PIN is forgotten, use "Reset desktop security" below, which removes the local account without touching files.
              </div>
            </SettingsCard>
            <SettingsCard title="Lock behaviour" description="Automatic locking follows your preference." icon={<Timer size={15} />}>
              <div className="flex items-center gap-3">
                <span className="text-[10px]">Auto-lock after</span>
                <Slider value={settings.autoLockMinutes} min={0} max={60} step={5} onChange={(autoLockMinutes) => updateSettings({ autoLockMinutes })} label="Auto-lock timeout" />
                <span className="w-16 text-right text-[10px]">{settings.autoLockMinutes === 0 ? "Never" : `${settings.autoLockMinutes} min`}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button className="btn btn-sm" onClick={() => updateSettings({ autoLockMinutes: 0 })}>Never lock</button>
                <button className="btn btn-sm" onClick={() => updateSettings({ autoLockMinutes: 5 })}>5 minutes</button>
                <button className="btn btn-sm" onClick={() => updateSettings({ autoLockMinutes: 15 })}>15 minutes</button>
                <button className="btn btn-sm" onClick={() => updateSettings({ autoLockMinutes: 30 })}>30 minutes</button>
              </div>
              {hasPin ? (
                <button className="btn btn-sm btn-danger mt-2" onClick={() => showConfirm("Reset desktop security?", "The local PIN/password account is removed and the desktop no longer requires a login. Files, notes and settings are kept.", () => { clearCredential(); setHasPin(false); setHostMessage("Desktop security reset."); }, "Reset security")}>
                  Reset desktop security
                </button>
              ) : null}
            </SettingsCard>
          </div>
        ) : null}

        {section === "power" ? (
          <div className="fade-in">
            <SettingsCard title="Desktop power" description="Sleep suspends desktop activity without shutting down the Android phone." icon={<Power size={15} />}>
              <div className="grid gap-1.5 sm:grid-cols-4">
                <button className="btn btn-sm" onClick={() => { sleepDesktop(); }}><Moon size={11} /> Sleep</button>
                <button className="btn btn-sm" onClick={() => { lock(); }}><Lock size={11} /> Lock</button>
                <button className="btn btn-sm" onClick={() => restartDesktop()}><RotateCcw size={11} /> Restart session</button>
                <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("display").catch((error) => setHostMessage(error.message))}><ExternalLink size={11} /> Android display</button>
              </div>
              <div className="mt-2 rounded-lg px-2.5 py-2 text-[9px] leading-relaxed" style={{ background: "var(--field)", color: "var(--muted)" }}>
                Sleep pauses wallpaper animation and background refresh while keeping every window and its position. Waking restores the exact session and requests login if security is enabled. Android device shutdown is never triggered from this panel.
              </div>
            </SettingsCard>
            <SettingsCard title="Sleep preferences" icon={<Timer size={15} />}>
              <div className="flex items-center gap-3">
                <span className="text-[10px]">Sleep after inactivity</span>
                <Slider value={settings.sleepTimeoutMinutes} min={0} max={120} step={10} onChange={(sleepTimeoutMinutes) => updateSettings({ sleepTimeoutMinutes })} label="Sleep timeout" />
                <span className="w-16 text-right text-[10px]">{settings.sleepTimeoutMinutes === 0 ? "Never" : `${settings.sleepTimeoutMinutes} min`}</span>
              </div>
              <div className="mt-2 flex gap-1.5">
                <button className="btn btn-sm" onClick={() => updateSettings({ sleepTimeoutMinutes: 0 })}>Never</button>
                <button className="btn btn-sm" onClick={() => updateSettings({ sleepTimeoutMinutes: 30 })}>30 minutes</button>
                <button className="btn btn-sm" onClick={() => updateSettings({ sleepTimeoutMinutes: 60 })}>1 hour</button>
                <button className="btn btn-sm" onClick={() => updateSettings({ sleepTimeoutMinutes: 120 })}>2 hours</button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        {section === "system" ? (
          <div className="fade-in">
            <div className="mb-2.5 flex items-center gap-3 rounded-xl p-3" style={{ background: "linear-gradient(120deg, rgba(var(--accent-rgb),.17), var(--surface-2))", border: "1px solid var(--border)" }}>
              <AppIcon id="thispc" size={48} />
              <div>
                <div className="text-[14px] font-semibold">KK DEX Station</div>
                <div className="text-[9.5px]" style={{ color: "var(--muted)" }}>Desktop build 1.0.0 · external display session</div>
                <div className="mt-1 flex flex-wrap gap-1">
                  <span className="badge badge-accent">OS 1.0</span>
                  <span className="badge">React desktop</span>
                  <span className="badge">KKDexAPI receiver</span>
                </div>
              </div>
            </div>
            <div className="mb-2.5 grid grid-cols-3 gap-2">
              <div className="rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>UPTIME</div>
                <div className="mt-0.5 truncate font-mono text-[11px]">{uptimeLabel}</div>
              </div>
              <div className="rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>WORKSPACE</div>
                <div className="mt-0.5 font-mono text-[11px]">{formatBytes(totalBytes)}</div>
              </div>
              <div className="rounded-lg p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="text-[8.5px]" style={{ color: "var(--faint)" }}>CONTENT</div>
                <div className="mt-0.5 font-mono text-[11px]">{notes.length} notes · {trash.length} trash</div>
              </div>
            </div>
            <SettingsCard title="Device & bridge" icon={<Cpu size={15} />}>
              <dl className="space-y-1.5 text-[10px]">
                {[
                  ["Display", `${displaySize.w} × ${displaySize.h} CSS px`],
                  ["Logical cores", String(navigator.hardwareConcurrency ?? "Not reported")],
                  ["Platform", navigator.platform || "External WebView"],
                  ["Network", navigator.onLine ? "Host reports online" : "Host reports offline"],
                  ["Bridge", typeof window !== "undefined" && "KKDexAPI" in window ? "KKDexAPI receiver active" : "Local browser session"],
                  ["Storage", "Browser workspace (persistent)"],
                ].map(([key, value]) => (
                  <div key={key} className="flex items-start justify-between gap-3">
                    <dt style={{ color: "var(--muted)" }}>{key}</dt>
                    <dd className="text-right">{value}</dd>
                  </div>
                ))}
              </dl>
            </SettingsCard>
            <SettingsCard title="Storage" description={nativeStorage ? "Live Android storage reported by the native bridge." : "Workspace storage only; native Android storage is not exposed in this host."} icon={<Database size={15} />}>
              <div className="flex items-center justify-between text-[10px]">
                <span className="flex items-center gap-1.5"><HardDrive size={12} /> {files.filter((f) => f.kind !== "folder").length} files</span>
                <span style={{ color: "var(--muted)" }}>{formatBytes(totalBytes)} of 256 MB shown</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}>
                <div className="h-full rounded-full" style={{ width: `${Math.min(100, Math.max(2, (totalBytes / (256 * 1024 * 1024)) * 100))}%`, background: "var(--accent)" }} />
              </div>
              {nativeStorage ? <div className="mt-1 text-[8.5px]" style={{ color: "var(--muted)" }}>Android: {formatBytes(nativeStorage.availableBytes)} free of {formatBytes(nativeStorage.totalBytes)}</div> : null}
              <div className="mt-2.5 flex flex-wrap gap-1.5"><button className="btn btn-sm" onClick={() => launch("files")}><HardDrive size={12} /> Open storage workspace</button><button className="btn btn-sm" onClick={() => launch("storage")}><Database size={12} /> Android Storage Manager</button></div>
            </SettingsCard>
            <SettingsCard title="Session actions" description="These operations affect this desktop workspace." icon={<RotateCcw size={15} />}>
              <div className="flex flex-wrap gap-2">
                <button className="btn btn-sm" onClick={lock}><Lock size={12} /> Lock screen</button>
                <button className="btn btn-sm" onClick={() => showConfirm("Restart desktop session?", "Open windows will be closed and the workspace reloaded. Your files and settings are preserved.", restartDesktop, "Restart session")}>
                  <RotateCcw size={12} /> Restart session
                </button>
                <button className="btn btn-sm" onClick={() => showConfirm("Reset preferences?", "Theme, wallpaper, accent, pointer and sound preferences will return to defaults. Files and notes are kept.", resetSettings, "Reset preferences")}>
                  <Palette size={12} /> Reset preferences
                </button>
                <button className="btn btn-sm btn-danger" onClick={() => showConfirm("Reset all KK DEX data?", "This permanently removes workspace files, notes, deleted items, settings and notifications. This cannot be undone.", factoryReset, "Erase workspace")}>
                  Reset workspace
                </button>
              </div>
            </SettingsCard>
          </div>
        ) : null}

        <div className="mt-2 flex items-center gap-1.5 text-[8.5px]" style={{ color: "var(--faint)" }}>
          <Info size={10} />
          Controls in this build perform real local actions. Host-level operations that are unavailable are identified as such.
          <button className="ml-auto flex items-center gap-1 hover:underline" onClick={openPhoneController}><Smartphone size={10} /> Phone controller</button>
        </div>
      </div>
    </div>
  );
}
