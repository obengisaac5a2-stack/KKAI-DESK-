import { useEffect, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Download,
  ExternalLink,
  FolderOpen,
  Info,
  Loader2,
  RefreshCw,
  RotateCcw,
  ShieldAlert,
  Trash2,
  X,
} from "lucide-react";
import {
  nativeBridge,
  type NativeDownload,
  type NativeStorageInfo,
} from "./native";
import { formatBytes } from "./OSContext";
import { useOS } from "./OSContext";
import { useNativeState } from "./NativeStorage";
import { EmptyState } from "./ui";
import { cn } from "@/utils/cn";

export function NativeDownloadManager() {
  const native = useNativeState();
  const { notify, showConfirm, launch, showInfo } = useOS();
  const available = native.available && native.capabilities.downloadManager;
  const [downloads, setDownloads] = useState<NativeDownload[]>([]);
  const [storage, setStorage] = useState<NativeStorageInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [url, setUrl] = useState("");
  const [filename, setFilename] = useState("");
  const [starting, setStarting] = useState(false);

  const refresh = async (silent = false) => {
    if (!available) return;
    if (!silent) setLoading(true);
    setError("");
    try {
      const [items, space] = await Promise.all([
        nativeBridge.getNativeDownloads(),
        native.capabilities.storageStats ? nativeBridge.getStorageInfo() : Promise.resolve(null),
      ]);
      setDownloads(items.sort((a, b) => b.id - a.id));
      if (space) setStorage(space);
    } catch (err) {
      setError(err instanceof Error ? err.message : "The Android DownloadManager could not be queried.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!available) return;
    void refresh();
    const timer = window.setInterval(() => void refresh(true), 1800);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [available]);

  useEffect(() => {
    const handler = (event: MessageEvent) => {
      if (event.data?.type === "kkdex-download") void refresh(true);
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const start = async () => {
    if (!url.trim()) return;
    setStarting(true);
    setError("");
    try {
      const parsed = new URL(url.trim());
      if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Only HTTP and HTTPS downloads are supported.");
      if (storage && storage.availableBytes < 20 * 1024 * 1024) {
        notify("Low storage warning", "Less than 20 MB is available. Android may reject this download.", { tone: "error" });
      }
      if (/\.apk$/i.test(filename || parsed.pathname)) {
        notify("APK security notice", "Android will verify this package and show its installer. KK DEX never installs APKs silently.", { tone: "default" });
      }
      await nativeBridge.startDownload(url.trim(), filename.trim() || undefined);
      setUrl("");
      setFilename("");
      await refresh(true);
      notify("Download started", "Android DownloadManager is saving the file to Download/KK DEX.", { tone: "success" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "The download could not be started.");
    } finally {
      setStarting(false);
    }
  };

  const control = async (item: NativeDownload, action: "cancel" | "retry" | "remove") => {
    try {
      await nativeBridge.controlDownload(item.id, action);
      if (action === "retry") {
        notify("Retry requested", `${item.name} will restart if the server allows it.`, { silent: true });
      }
      await refresh(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "The download action failed.");
    }
  };

  const open = async (item: NativeDownload) => {
    try {
      const opened = await nativeBridge.openDownload(item.id);
      if (!opened) notify("Open failed", "Android could not open this file.", { tone: "error" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Android could not open the download.");
    }
  };

  const install = async (item: NativeDownload) => {
    try {
      const opened = await nativeBridge.installApk(item.localUri || item.uri);
      if (!opened) throw new Error("Android's installer did not open.");
      notify("Package installer opened", "Review Android's prompt. KK DEX has not executed the APK.", { tone: "success" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Android could not start the package installer.");
    }
  };

  if (!available) {
    return (
      <div className="space-y-2.5">
        <div className="rounded-lg p-3" style={{ background: "rgba(245,158,11,.09)", border: "1px solid rgba(245,158,11,.22)" }}>
          <div className="flex items-center gap-1.5 text-[10.5px] font-medium"><AlertTriangle size={12} style={{ color: "#f5b84a" }} /> Native Android download manager unavailable</div>
          <p className="mt-1 text-[9px] leading-relaxed" style={{ color: "var(--muted)" }}>
            Browser downloads cannot be queried from a standalone web page. Run the Android host to use DownloadManager with real phone storage. The workspace import/download controls remain available and genuinely operate on this desktop workspace.
          </p>
          <div className="mt-2 flex gap-1.5"><button className="btn btn-sm" onClick={() => launch("files", { payload: { folderId: "downloads" } })}><FolderOpen size={10} /> Workspace Downloads</button><button className="btn btn-sm" onClick={() => void nativeBridge.detect()}><RefreshCw size={10} /> Recheck host</button></div>
        </div>
        <EmptyState icon={<Download size={22} />} title="No Android download queue" description="Downloads started by a native WebView browser will appear here with real progress and storage destinations." />
      </div>
    );
  }

  const activeCount = downloads.filter((item) => ["running", "pending", "paused"].includes(item.status)).length;
  const apkCount = downloads.filter((item) => /\.apk$/i.test(item.name)).length;

  return (
    <div className="space-y-2.5">
      <div className="flex flex-wrap items-center gap-2 rounded-lg px-2.5 py-2" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
        <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><Download size={14} /></div>
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-medium">Android DownloadManager</div>
          <div className="text-[8px]" style={{ color: "var(--muted)" }}>{activeCount} active · {downloads.length} total · {apkCount} APK · destination <strong>Download/KK DEX</strong></div>
        </div>
        {storage ? <div className="hidden text-right text-[8px] md:block"><div style={{ color: "var(--muted)" }}>{formatBytes(storage.availableBytes)} free</div><div style={{ color: "var(--faint)" }}>of {formatBytes(storage.totalBytes)}</div></div> : null}
        <button className="btn btn-sm" onClick={() => void refresh()} disabled={loading}>{loading ? <Loader2 size={10} className="animate-spin" /> : <RefreshCw size={10} />} Refresh</button>
        <button className="btn btn-sm" onClick={() => nativeBridge.openSystemSettings("downloads").catch((err) => setError(err.message))}><ExternalLink size={10} /> Location</button>
      </div>

      <div className="flex flex-col gap-1.5 rounded-lg p-2" style={{ background: "var(--field)", border: "1px solid var(--border)" }}>
        <div className="flex gap-1.5">
          <input value={url} onChange={(event) => setUrl(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") void start(); }} placeholder="Direct download URL (https://…)" className="field min-w-0 flex-1 !h-7 !text-[10px]" />
          <input value={filename} onChange={(event) => setFilename(event.target.value)} placeholder="Optional file name" className="field !h-7 w-[170px] !text-[10px]" />
          <button className="btn btn-sm" onClick={() => void start()} disabled={!url.trim() || starting}>{starting ? <Loader2 size={10} className="animate-spin" /> : <Download size={10} />} Start</button>
        </div>
        <div className="text-[7.5px]" style={{ color: "var(--faint)" }}>Server must allow direct downloads. Android DownloadManager handles pause only by cancel/retry; KK DEX does not pretend to pause when the platform cannot resume.</div>
      </div>

      {error ? <div className="flex items-start gap-1.5 rounded-md px-2.5 py-2 text-[9px]" style={{ background: "rgba(239,68,68,.1)", border: "1px solid rgba(239,68,68,.22)" }}><AlertTriangle size={11} className="mt-0.5 shrink-0" /> {error}<button className="ml-auto" aria-label="Dismiss" onClick={() => setError("")}><X size={10} /></button></div> : null}

      {downloads.length === 0 && !loading ? (
        <EmptyState icon={<Download size={22} />} title="No Android downloads yet" description="Use the native browser or start a direct URL above. Progress and storage are read from Android DownloadManager." />
      ) : (
        <div className="space-y-1">
          {downloads.map((item) => {
            const apk = /\.apk$/i.test(item.name);
            const done = item.status === "successful";
            const failed = item.status === "failed";
            return (
              <div key={item.id} className="rounded-lg px-2.5 py-2" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style={{ background: apk ? "rgba(74,222,128,.12)" : "var(--field)", color: apk ? "#4ade80" : "var(--muted)" }}>{apk ? <ShieldAlert size={15} /> : <Download size={15} />}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5"><span className="truncate text-[10px] font-medium">{item.name}</span>{apk ? <span className="badge !text-[7px]">APK</span> : null}<span className={cn("badge !text-[7px]", done && "badge-accent")}>{item.status}</span></div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[8px]" style={{ color: "var(--muted)" }}>
                      <span>{formatBytes(item.bytesDownloaded)} / {item.totalBytes ? formatBytes(item.totalBytes) : "size pending"}</span>
                      {item.speedBytesPerSecond ? <span>· {formatBytes(item.speedBytesPerSecond)}/s</span> : null}
                      <span>· {item.destination}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-2">
                      <div className="h-1 flex-1 overflow-hidden rounded-full" style={{ background: "var(--surface-4)" }}><div className="h-full rounded-full transition-all" style={{ width: `${done ? 100 : Math.max(1, item.progress)}%`, background: failed ? "var(--danger)" : "var(--accent)" }} /></div>
                      <span className="w-8 text-right font-mono text-[8px]">{done ? 100 : item.progress}%</span>
                    </div>
                    {item.reason ? <div className="mt-1 text-[8px]" style={{ color: "var(--danger)" }}>{item.reason}</div> : null}
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    {done ? <>
                      <button className="btn btn-sm !h-6" onClick={() => void open(item)}><ArrowRight size={9} /> Open</button>
                      {apk ? <button className="btn btn-sm btn-accent !h-6" onClick={() => void install(item)}><ShieldAlert size={9} /> Install</button> : null}
                    </> : null}
                    {failed ? <button className="btn btn-sm !h-6" onClick={() => void control(item, "retry")}><RotateCcw size={9} /> Retry</button> : null}
                    {!done ? <button className="btn btn-sm btn-danger !h-6 !px-1.5" title="Cancel download" onClick={() => showConfirm(`Cancel “${item.name}”?`, "Android will remove this transfer. A partially downloaded file may also be removed.", () => void control(item, "cancel"), "Cancel download")}><X size={10} /></button> : <button className="btn btn-sm btn-danger !h-6 !px-1.5" title="Remove from history" onClick={() => void control(item, "remove")}><Trash2 size={10} /></button>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="flex items-start gap-1.5 rounded-md px-2.5 py-2 text-[8px] leading-relaxed" style={{ background: "var(--field)", color: "var(--muted)" }}>
        <Info size={10} className="mt-0.5 shrink-0" />
        Downloads are real files in Android's Download collection. Pause/resume is controlled by Android DownloadManager and the server; when unsupported, use cancel and retry. APK installation requires Android's confirmation and a valid signature. Unknown-source installation may need to be enabled in Android settings.
        <button className="ml-auto shrink-0 underline" onClick={() => showInfo("Download security", "KK DEX validates URL schemes only. It does not virus-scan arbitrary files and never executes them automatically. APKs are handed to Android's package installer, which performs signature verification. Sideloading remains your responsibility.", <ShieldAlert size={22} />)}>Details</button>
      </div>
    </div>
  );
}
