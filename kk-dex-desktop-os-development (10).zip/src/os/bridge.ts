import type { AppId, WallpaperId } from "./types";

export interface KKDexPointerState {
  x: number;
  y: number;
  visible: boolean;
  controllerConnected: boolean;
}

export interface KKDexDesktopHandlers {
  movePointer: (x: number, y: number) => void;
  pointerDown: (button?: number) => void;
  pointerUp: (button?: number) => void;
  pointerClick: (button?: number) => void;
  pointerDoubleClick: () => void;
  pointerRightClick: () => void;
  scrollDesktop: (deltaY: number) => void;
  insertText: (text: string) => boolean;
  pressKey: (key: string, modifiers?: string[] | Record<string, boolean>) => boolean;
  getState: () => Record<string, unknown>;
  openApp: (appId: string) => boolean;
  setTheme: (theme: "dark" | "light") => boolean;
  setWallpaper: (wallpaper: string) => boolean;
}

export interface KKDexAPI {
  movePointer: (x: number, y: number) => void;
  pointerDown: () => void;
  pointerUp: () => void;
  pointerClick: () => void;
  pointerDoubleClick: () => void;
  pointerRightClick: () => void;
  scrollDesktop: (deltaY: number) => void;
  insertText: (text: string) => boolean;
  pressKey: (key: string, modifiers?: string[] | Record<string, boolean>) => boolean;
  getState: () => Record<string, unknown>;
  openApp: (appId: string) => boolean;
  setTheme: (theme: "dark" | "light") => boolean;
  setWallpaper: (wallpaper: string) => boolean;
}

declare global {
  interface Window {
    KKDexAPI?: Partial<KKDexAPI>;
    KKDexDesktop?: Partial<KKDexAPI>;
    __KKDEX_BRIDGE__?: { version: string; installedAt: number };
  }
}

let handlers: KKDexDesktopHandlers | null = null;

function safe<T>(fn: () => T, fallback: T): T {
  try {
    return fn();
  } catch {
    return fallback;
  }
}

const api: KKDexAPI = {
  movePointer: (x, y) => handlers?.movePointer(Number(x), Number(y)),
  pointerDown: () => handlers?.pointerDown(0),
  pointerUp: () => handlers?.pointerUp(0),
  pointerClick: () => handlers?.pointerClick(0),
  pointerDoubleClick: () => handlers?.pointerDoubleClick(),
  pointerRightClick: () => handlers?.pointerRightClick(),
  scrollDesktop: (deltaY) => handlers?.scrollDesktop(Number(deltaY)),
  insertText: (text) => safe(() => handlers?.insertText(String(text)) ?? false, false),
  pressKey: (key, modifiers) => safe(() => handlers?.pressKey(String(key), modifiers) ?? false, false),
  getState: () => safe(() => handlers?.getState() ?? { ready: false }, { ready: false }),
  openApp: (appId) => safe(() => handlers?.openApp(String(appId)) ?? false, false),
  setTheme: (theme) => safe(() => handlers?.setTheme(theme === "light" ? "light" : "dark") ?? false, false),
  setWallpaper: (wallpaper) => safe(() => handlers?.setWallpaper(String(wallpaper)) ?? false, false),
};

export function installBridge(nextHandlers: KKDexDesktopHandlers): void {
  handlers = nextHandlers;
  if (typeof window === "undefined") return;
  window.KKDexDesktop = api;
  if (!window.KKDexAPI) {
    window.KKDexAPI = api;
  } else {
    // Preserve the host's existing bridge methods. Only fill in missing ones.
    const current = window.KKDexAPI as Record<string, unknown>;
    (Object.keys(api) as (keyof KKDexAPI)[]).forEach((key) => {
      if (typeof current[key] !== "function") current[key] = api[key];
    });
  }
  if (!window.__KKDEX_BRIDGE__) {
    window.__KKDEX_BRIDGE__ = { version: "1.0.0", installedAt: Date.now() };
  }
}

export function getBridgeApi(): KKDexAPI {
  return api;
}

export type ControllerMessage =
  | { type: "hello"; client?: string }
  | { type: "move"; x: number; y: number; deltaX?: number; deltaY?: number }
  | { type: "down"; button?: number }
  | { type: "up"; button?: number }
  | { type: "click"; button?: number }
  | { type: "doubleClick" }
  | { type: "rightClick" }
  | { type: "scroll"; deltaY: number }
  | { type: "text"; text: string }
  | { type: "key"; key: string; modifiers?: string[] }
  | { type: "openApp"; appId: string }
  | { type: "setTheme"; theme: "dark" | "light" }
  | { type: "query-state" }
  | { type: "disconnect" };

export type DesktopMessage =
  | { type: "state"; state: Record<string, unknown> }
  | { type: "ack"; action: string; ok: boolean; detail?: string }
  | { type: "hello"; role: "desktop"; version: string };

export function normalizeKey(key: string): string {
  if (!key) return "";
  const map: Record<string, string> = {
    " ": " ",
    space: " ",
    Space: " ",
    esc: "Escape",
    escape: "Escape",
    enter: "Enter",
    return: "Enter",
    tab: "Tab",
    backspace: "Backspace",
    delete: "Delete",
    del: "Delete",
    up: "ArrowUp",
    down: "ArrowDown",
    left: "ArrowLeft",
    right: "ArrowRight",
    win: "Meta",
    super: "Meta",
    cmd: "Meta",
    ctrl: "Control",
    control: "Control",
    shift: "Shift",
    alt: "Alt",
  };
  if (map[key]) return map[key];
  if (/^Key[A-Z]$/.test(key)) return key.slice(3).toLowerCase();
  if (/^Digit\d$/.test(key)) return key.slice(5);
  return key;
}

export function parseModifiers(modifiers?: string[] | Record<string, boolean>): {
  ctrlKey: boolean;
  shiftKey: boolean;
  altKey: boolean;
  metaKey: boolean;
} {
  const result = { ctrlKey: false, shiftKey: false, altKey: false, metaKey: false };
  if (!modifiers) return result;
  if (Array.isArray(modifiers)) {
    modifiers.forEach((modifier) => {
      const m = modifier.toLowerCase();
      if (m === "ctrl" || m === "control") result.ctrlKey = true;
      if (m === "shift") result.shiftKey = true;
      if (m === "alt") result.altKey = true;
      if (m === "meta" || m === "win" || m === "cmd") result.metaKey = true;
    });
    return result;
  }
  return {
    ctrlKey: Boolean(modifiers.ctrlKey || modifiers.ctrl),
    shiftKey: Boolean(modifiers.shiftKey || modifiers.shift),
    altKey: Boolean(modifiers.altKey || modifiers.alt),
    metaKey: Boolean(modifiers.metaKey || modifiers.meta),
  };
}

export function isAppId(value: string): value is AppId {
  return [
    "thispc",
    "files",
    "browser",
    "ai",
    "appcenter",
    "settings",
    "gallery",
    "notes",
    "calculator",
    "terminal",
    "recycle",
    "phone",
    "downloads",
    "media",
    "pdf",
    "archive",
    "developer",
    "games",
    "storage",
  ].includes(value);
}

export const VALID_WALLPAPERS: WallpaperId[] = ["sports-car", "luxury-car", "motorcycle", "forest", "trees", "mountains", "sunset", "aurora", "dunes", "anim-abstract", "anim-future", "anim-avatar"];
